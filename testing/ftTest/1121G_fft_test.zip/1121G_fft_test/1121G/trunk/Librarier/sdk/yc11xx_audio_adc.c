/**
***************************************************************************
* @file:  yc11xx_audio_adc.c
* @Date:  2021-7-14-21:22:02
* @brief:  Audio_adc dirver

* Change Logs:
* Date           Author      Version        Notes
* 2021-07-14     xxx         V1.0.0         the first version
**************************************************************************
*/
#include "yc11xx_audio_adc.h"
#include "board_config.h"
#include "reg_addr.h"
#include "reg_struct.h"
#include "yc11xx_gpio.h"
#include "yc11xx.h"
#include "rfreg_struct.h"
#include "rfreg_addr.h"
//#include "yc11xx_systick.h"

//#define REG_CLOCK_OFF_VOICE_FILTER           (0x0040)

const int64_t Adc_CicFirCoeffTablel[] =
{
    322, 564, -126, -698, 412, 971, -984, -1206, 1873, 1134, -3152, -547, 4648, -919, -6141,
    3470, 7097, -7327, -6921, 12411, 4724, -18559, 460, 25322, -10158, -32422, 27278, 40358, -61509, -57063,
    173450, 331522, 173450, -57063, -61509, 40358, 27278, -32422, -10158, 25322, 460, -18559, 4724, 12411, -6921,
    -7327, 7097, 3470, -6141, -919, 4648, -547, -3152, 1134, 1873, -1206, -984, 971, 412, -698,
    -126, 564, 322
};
const int64_t Adc_HalfBandCoefTablel[] =
{
    -430, 0, 643, 0, -1100, 0, 1748, 0, -2640, 0, 3841, 0, -5439, 0, 7567,
        0, -10446, 0, 14484, 0, -20557, 0, 30962, 0, -54150, 0, 166388, 262144, 166388, 0,
        -54150, 0, 30962, 0, -20557, 0, 14484, 0, -10446, 0, 7567, 0, -5439, 0, 3841,
        0, -2640, 0, 1748, 0, -1100, 0, 643, 0, -430
    };

/**
 * @brief    Adc initional
 * @param    adcparam :   ADC configuration parameter structure
 * @return  None
 */
void Audio_AdcInit(Audio_ADCInitParamDev adcparam)
{
    CoreReg_ClkControl(REG_CLOCK_OFF_VOICE_FILTER, TRUE);
    HWCOR(CORE_CLKOFF2, BIT1);
    uint8_t temp;
    if((uint32_t *)adcparam.Adc_StartAddr == NULL || adcparam.Adc_BufferSize <= 0)
    {

        return;
    }
    if(adcparam.Adc_Vol >= 10)
    {
        adcparam.Adc_Vol = 10;
    }
    uint8_t *adcEndAddr = (adcparam.Adc_StartAddr + adcparam.Adc_BufferSize - 1);

    ADC_MIC_CTRLRegDef AdcMicCtrl;
    AUDIO_CLKSELDef AdcClkSource;
    AUDIO_DIV_CLK_SELRegDef AdcClkdiv;
    ADCD_CTRLRegDef AdcCtrl;
    ADC_VOLRegDef AdcVol;
    //Audio_AnaStartAdcWork(adcparam.Adc_WorkMode,adcparam.Adc_BiasVoltage);
    BOOL AdcStartAddrIsMram = reg_check_ram_m0(adcparam.Adc_StartAddr);

    //Step1: init adc
    Audio_AdcFilterInit();
    // ADC SCAL setting
    HWRITE(CORE_ADC_FILTER_CTRL, 0x44);//0-7 low db+

    HWRITE(CORE_ADC_DC_CTRL, 0x80);

    //Step2: init adc buffer info
    HWRITEW(CORE_ADCD_SADDR, adcparam.Adc_StartAddr);
    HWRITEW(CORE_ADCD_EADDR, adcEndAddr);

    HREADW_STRUCT(CORE_ADC_VOL + 1, &AdcVol);
    if(adcparam.Adc_VolFadeEnable == ENABLE)
    {
        HWRITE(CORE_ADC_VOL, adcparam.Adc_VolStep);
        AdcVol.adc_vol_fade_dis = 0;
    }
    else
    {
        AdcVol.adc_vol_fade_dis = 1;
    }

    AdcVol.adc_voll_target_val = 0;
    if(adcparam.Adc_MuteChannel == ENABLE)
    {
        AdcVol.adc_mute_en = 1;
    }
    else
    {
        AdcVol.adc_mute_en = 0;
    }

    HWRITEW_STRUCT(CORE_ADC_VOL + 1, &AdcVol);

    HREAD_STRUCT(CORE_ADC_MIC_CTRL, &AdcMicCtrl);
    HREAD_STRUCT(CORE_AUDIO_DIV_CLK_SEL, &AdcClkdiv);
    HREAD_STRUCT(CORE_ADCD_CTRL, &AdcCtrl);
    HREADW_STRUCT(CORE_AUDIO_CLKSEL, &AdcClkSource);
    if(adcparam.Mic_Type == MicIsPDM)
    {
        AdcMicCtrl.adc_mic_src = TRUE;
        AdcMicCtrl.adc_pdmdat_sel = TRUE;
        AdcMicCtrl.adc_pdmclk_en = TRUE;
    }
    else
    {
        AdcMicCtrl.adc_mic_src = FALSE;
        AdcMicCtrl.adc_anaclk_en = TRUE;

    }

    AdcMicCtrl.adc_micdat_mode = FALSE;
    //	AdcMicCtrl.adc_anaclk_en=TRUE;
    AdcMicCtrl.adc_micclk_inv = TRUE;

    switch(adcparam.Adc_Sample)
    {
#ifndef CLOCK_HALVED
    case ADC_Sample8K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide3;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv4;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample11p025K:
        AdcClkSource.mic_clksel = ADCClk11p2896M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv4;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample12K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv4;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample16K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide3;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv2;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample22p05K:
        AdcClkSource.mic_clksel = ADCClk11p2896M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv2;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample24K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv2;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample32K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide3;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPll;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample44p1K:
        AdcClkSource.mic_clksel = ADCClk11p2896M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide1;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv2;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample48K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPll;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
#else
    case ADC_Sample8K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide3;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv2;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample11p025K:
        AdcClkSource.mic_clksel = ADCClk11p2896M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv2;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample12K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPllDiv2;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample16K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide3;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPll;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample22p05K:
        AdcClkSource.mic_clksel = ADCClk11p2896M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPll;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample24K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide2;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPll;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample32K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide3;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPll;
        AdcCtrl.adcd_cic_ds_sel = Down_sample16;
        break;
    case ADC_Sample44p1K:
        AdcClkSource.mic_clksel = ADCClk11p2896M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide1;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPll;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
    case ADC_Sample48K:
        AdcClkSource.mic_clksel = ADCClk12p288M;
        AdcClkdiv.adc_divclk_sel = ADC_ClkDivide1;
        AdcMicCtrl.adc_micclk_sel = MicClkFromPll;
        AdcCtrl.adcd_cic_ds_sel = Down_sample32;
        break;
#endif
    }
    HWRITE_STRUCT(CORE_AUDIO_DIV_CLK_SEL, &AdcClkdiv);
    HWRITE_STRUCT(CORE_ADC_MIC_CTRL, &AdcMicCtrl);
    HWRITE_STRUCT(CORE_ADCD_CTRL, &AdcCtrl);
    HWRITEW_STRUCT(CORE_AUDIO_CLKSEL, &AdcClkSource);

    HWRITE(CORE_ADCD_DELAY, 0x80);

    AdcCtrl.adcd_mram_sel = AdcStartAddrIsMram;

    HWRITE(CORE_ADC_DC_CTRL, 0x80);

    if(adcparam.Adc_RssiConfig == adc_RssiDisable)
    {
        AdcCtrl.adcd_rssi_en = 0;
    }
    else
    {
        AdcCtrl.adcd_rssi_en = 1;
        AdcCtrl.adcd_rssi_avg_time = adcparam.Adc_RssiConfig;
        AdcCtrl.adcd_rssi_clr = 0;
    }
    HWRITE_STRUCT(CORE_ADCD_CTRL, &AdcCtrl);
    if(adcparam.Adc_HPFConfig != adc_HPFDisable)
    {
        Audio_AdcHPFInit(adcparam.Adc_HPFConfig);
    }
    else
    {
        Audio_AdcHPFClr();
    }
    Audio_AdcDmaEnable();
    if(adcparam.Adc_OutputMode == ADC_DifferentialOutput)
    {
        AUDIO_AdcAnaDiffConfig();
    }
    else if(adcparam.Adc_OutputMode == ADC_SingleEndOutput)
    {
        AUDIO_AdcAnaSEConfig();
    }
    else if(adcparam.Adc_OutputMode == ADC_VcomOutput)
    {
        AUDIO_AdcAnaVcomConfig();
    }

    Audio_AdcVolConfig(adcparam.Adc_Vol);
}
/**
 * @brief  Adc Filter Init
 * @param    void
 * @return  None
 */
uint8_t adc_ChkSum = 0;
void Audio_AdcFilterInit(void)
{
    uint16_t i = 0;
    //uint32_t temp_32;
    HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x10);
    for(i = 0; i < 32; i++)
    {
        //HWRITE24BIT(CORE_REG_COEF_WDATA, Adc_CicFirCoeffTablel[i]);
        HWRITE(CORE_ADDA_COEF_WDATA_0, Adc_CicFirCoeffTablel[i]);
        HWRITE(CORE_ADDA_COEF_WDATA_1, Adc_CicFirCoeffTablel[i] >> 8);
        HWRITE(CORE_ADDA_COEF_WDATA_2, Adc_CicFirCoeffTablel[i] >> 16);

        adc_ChkSum += ((uint8_t)Adc_CicFirCoeffTablel[i] + (uint8_t)(Adc_CicFirCoeffTablel[i] >> 8) + (uint8_t)(Adc_CicFirCoeffTablel[i] >> 16));

        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x30);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x10);
    }
    for(i = 0; i < 28; i++)
    {
        //HWRITE24BIT(CORE_REG_COEF_WDATA, Adc_HalfBandCoefTablel[i]);
        HWRITE(CORE_ADDA_COEF_WDATA_0, Adc_HalfBandCoefTablel[i]);
        HWRITE(CORE_ADDA_COEF_WDATA_1, Adc_HalfBandCoefTablel[i] >> 8);
        HWRITE(CORE_ADDA_COEF_WDATA_2, Adc_HalfBandCoefTablel[i] >> 16);

        adc_ChkSum += ((uint8_t)Adc_HalfBandCoefTablel[i] + (uint8_t)(Adc_HalfBandCoefTablel[i] >> 8) + (uint8_t)(Adc_HalfBandCoefTablel[i] >> 16));

        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x30);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x10);
    }
    for(i = 0; i < 128; i ++)
    {
        HWRITE24BIT(CORE_ADDA_COEF_WDATA_0, 0);

        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x30);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x10);
    }
    HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x00);
}

/**
 * @brief  To enable the DMA of ADC
 * @param    void
 * @return  None
 */
void Audio_AdcDmaEnable(void)
{
    ADCD_CTRLRegDef adcCtrl;
    HREAD_STRUCT(CORE_ADCD_CTRL, &adcCtrl);
    adcCtrl.adcd_dma_en = 1;
    HWRITE_STRUCT(CORE_ADCD_CTRL, &adcCtrl);
}
/**
 * @brief  Check Adc  dma enable
 * @param    void
 * @return  1:adc DMA enable,0:adc DMA disable
 */
BOOL Audio_AdcCheckEnable(void)
{
    ADCD_CTRLRegDef adcCtrl;
    HREAD_STRUCT(CORE_ADCD_CTRL, &adcCtrl);
    return (adcCtrl.adcd_dma_en);
    //return (HREAD(CORE_ADCD_CTRL) & BIT_7) != 0;
}

/**
 * @brief   Check using SRAM or MRAM
 * @param    void
 * @return  1: mram; 0: schedule ram/xram
 */
BOOL Audio_AdcCheckUseMram(void)
{
    ADCD_CTRLRegDef adcCtrl;
    HREAD_STRUCT(CORE_ADCD_CTRL, &adcCtrl);
    return adcCtrl.adcd_mram_sel;
}

/**
 * @brief  stop Adc work
 * @param    void
 * @return  None
 */
void Audio_AdcStop(void)
{
    HWRITE(CORE_ADCD_DELAY, 0);
    HWRITE(CORE_ADCD_CTRL, 0);
}

/**
 * @brief  Gets the lower sixteen bits of the ADC write pointer address
 * @param    void
 * @return  None
 */
uint16_t Audio_AdcWptr(void)
{
    return HREADW(CORE_ADCD_ADDR);
}

void Audio_AdcHPFInit(Audio_ADCHighPassFilter alpha1)
{
    HWRITE(CORE_MIC_HPF_ALPHA, alpha1);
    MIC_HPF_CTRLRegDef hpfCon;
    memset(&hpfCon, 0, sizeof(hpfCon));
    hpfCon.mic_hpf_ctrl_reserved1 = alpha1 >> 8;
    HWRITE_STRUCT(CORE_MIC_HPF_CTRL, &hpfCon);
    Audio_AdcHPFEnable();
}

void Audio_AdcHPFEnable()
{
    MIC_HPF_CTRLRegDef hpfCon;
    HREAD_STRUCT(CORE_MIC_HPF_CTRL, &hpfCon);
    hpfCon.mic_hpf_en = 1;
    hpfCon.mic_hpf_clr = 0;
    HWRITE_STRUCT(CORE_MIC_HPF_CTRL, &hpfCon);
}

void Audio_AdcHPFDisable()
{
    MIC_HPF_CTRLRegDef hpfCon;
    HREAD_STRUCT(CORE_MIC_HPF_ALPHA, &hpfCon);
    hpfCon.mic_hpf_en = 0;
    HWRITE_STRUCT(CORE_MIC_HPF_CTRL, &hpfCon);
}

void Audio_AdcHPFClr()
{
    MIC_HPF_CTRLRegDef hpfCon;
    HREAD_STRUCT(CORE_MIC_HPF_ALPHA, &hpfCon);
    hpfCon.mic_hpf_en = 0;
    HWRITE_STRUCT(CORE_MIC_HPF_CTRL, &hpfCon);
    hpfCon.mic_hpf_clr = 1;
    HWRITE_STRUCT(CORE_MIC_HPF_CTRL, &hpfCon);
    hpfCon.mic_hpf_clr = 0;
    HWRITE_STRUCT(CORE_MIC_HPF_CTRL, &hpfCon);
}

BOOL Audio_AdcVolConfig(uint8_t vol)
{
    if(vol > 10)
    {
        return FALSE;
    }
    ADC_VOLRegDef adcVol;
    HREADW_STRUCT(CORE_ADC_VOL + 1, &adcVol);
    adcVol.adc_voll_target_val = AUDIO_ADC_VOL_MAX * 10 / vol;
    HWRITEW_STRUCT(CORE_ADC_VOL + 1, &adcVol);
    return TRUE;
}

void AUDIO_AdcAnaDiffConfig()
{
    //    HWRITE(0x8b00,0x3e);
    codec_ldo_en0RegDef ldoEn0;
    HREAD_STRUCT(CORE_codec_ldo_en0, &ldoEn0);
    ldoEn0.da_ldo_daccore_en = 1;
    ldoEn0.da_ldohp_dacdrv_en = 1;
    ldoEn0.da_adc_reg_en = 1;
    ldoEn0.da_mic_reg_en = 1;
    ldoEn0.da_adc_pwrsw_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &ldoEn0);

    //    HWRITE(0x8b01,0x51);
    codec_ldo_cfg0RegDef lodCfg0;
    HREAD_STRUCT(CORE_codec_ldo_cfg0, &lodCfg0);
    lodCfg0.rg_mic_hvreg_vc = 1;
    lodCfg0.rg_adc_reg_vol_sel = 2;
    lodCfg0.rg_adc_reg_ibias_sel = 1;
    HWRITE_STRUCT(CORE_codec_ldo_cfg0, &lodCfg0);

    //    HWRITE(0x8b02,0x55);
    codec_ldo_cfg1RegDef lodCfg1;
    HREAD_STRUCT(CORE_codec_ldo_cfg1, &lodCfg1);
    lodCfg1.rg_ibsel_hpldo = 1;
    lodCfg1.rg_ldo_excap_en = 1;
    lodCfg1.rg_ldo_voutsel = 2;
    lodCfg1.rg_ibsel_ldo = 1;
    HWRITE_STRUCT(CORE_codec_ldo_cfg1, &lodCfg1);

    //    HWRITE(0x8b04,0x2a);
    codec_ldo_cfg2RegDef lodCfg2;
    lodCfg2.rg_ldohp_excap_en = 1;
    lodCfg2.rg_ldohp_voutsel = 2;
    lodCfg2.rg_ldohp_ocp_sel = 1;
    HWRITE_STRUCT(CORE_codec_ldo_cfg2, &lodCfg2);

    //    HWRITE(0x8b05,0x36);
    codec_vmid_en0RegDef vmidEn0;
    HREAD_STRUCT(CORE_codec_vmid_en0, &vmidEn0);
    vmidEn0.da_vmid_discharge = 0;
    vmidEn0.da_vmid_en = 1;
    vmidEn0.da_vmid_bias_en = 1;
    vmidEn0.da_vmid_extcap_en = 1;
    vmidEn0.da_vmid_bg_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b06,0x08);
    codec_vmid_cfg0RegDef vmidCfg0;
    HREAD_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
    vmidCfg0.rg_vmid_isel_lsb = 8;
    HWRITE_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);

    //    HWRITE(0x8b07,0x68);
    codec_vmid_cfg1RegDef vmidCfg1;
    HREAD_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg1);
    vmidCfg1.rg_vmid_isel_msb = 8;
    vmidCfg1.rg_vmid_discharge_cc = 1;
    vmidCfg1.rg_vmid_discharge_auto = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg1);

    //    HWRITE(0x8b08,0x05);
    codec_vmid_cfg2RegDef vmidCfg2;
    HREAD_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);
    vmidCfg2.rg_vmid_bg_fastsetting = 1;
    vmidCfg2.rg_vmid_vref_sel = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b09,0x84);
    codec_vmid_cfg3RegDef vmidCfg3;
    HREAD_STRUCT(CORE_codec_vmid_cfg3, &vmidCfg3);
    vmidCfg3.rg_vmid_bg_trim = 4;
    vmidCfg3.rg_vmid_bg_rct = 8;
    HWRITE_STRUCT(CORE_codec_vmid_cfg3, &vmidCfg3);

    //    HWRITE(0x8b0b,0xe6);
    au_adc_en0RegDef adcEn0;
    memset(&adcEn0, 0, sizeof(adcEn0));
    adcEn0.da_pga_gm_en = 0;
    adcEn0.da_pga_gm_fst_en = 1;
    adcEn0.da_sdm_dem_en = 1;
    adcEn0.da_sdm_en = 1;
    adcEn0.da_aadc_top_ibias_en = 1;
    HWRITE_STRUCT(CORE_au_adc_en0, &adcEn0);

    //    SysTick_DelayMs(10);

    //    HWRITE(0x8b0b,0xe2);
    adcEn0.da_pga_gm_fst_en = 0;
    HWRITE_STRUCT(CORE_au_adc_en0, &adcEn0);

    //    HWRITE(0x8b0c,0x0b);
    au_adc_en1RegDef adcEn1;
    memset(&adcEn1, 0, sizeof(adcEn1));
    adcEn1.da_micbias_en = 1;
    adcEn1.da_pga_en = 1;
    adcEn1.da_pga_diff_en = 1;
    adcEn1.da_pga_rbias_en = 0;
    HWRITE_STRUCT(CORE_au_adc_en1, &adcEn1);

    //    HWRITE(0x8b0d,0x55);
    au_adc_cfg0RegDef adcCfg0;
    memset(&adcCfg0, 0, sizeof(adcCfg0));
    adcCfg0.rg_sdm_cmp_isel = 1;
    adcCfg0.rg_sdm_ota1_isel = 1;
    adcCfg0.rg_sdm_ota2_isel = 1;
    adcCfg0.rg_sdm_ref_isel = 1;
    HWRITE_STRUCT(CORE_au_adc_cfg0, &adcCfg0);

    //    HWRITE(0x8b0e,0x51);
    au_adc_cfg1RegDef adcCfg1;
    memset(&adcCfg1, 0, sizeof(adcCfg1));
    adcCfg1.rg_pga_opa2_ibias_sel = 1;
    adcCfg1.rg_pga_cz_ibias_sel = 2;
    adcCfg1.rg_pga_gm_ibias_sel = 2;
    HWRITE_STRUCT(CORE_au_adc_cfg1, &adcCfg1);

    //    HWRITE(0x8b0f,0x05);
    HWRITE(CORE_au_adc_cfg2, 0x05);

    //    HWRITE(0x8b10,0x0f);
    au_adc_cfg3RegDef adcCfg3;
    memset(&adcCfg3, 0, sizeof(adcCfg3));
    adcCfg3.rg_pga_gc = 4;
    HWRITE_STRUCT(CORE_au_adc_cfg3, &adcCfg3);

    //    HWRITE(0x8b11,0x05);
    au_adc_cfg4RegDef adcCfg4;
    memset(&adcCfg4, 0, sizeof(adcCfg4));
    adcCfg4.rg_pga_rcfilt_coarse = 1;
    adcCfg4.rg_pga_dcoc_ibc = 1;
    HWRITE_STRUCT(CORE_au_adc_cfg4, &adcCfg4);

    //    HWRITE(0x8b12,0x4e);
    au_adc_cfg5RegDef adcCfg5;
    memset(&adcCfg5, 0, sizeof(adcCfg5));
    adcCfg5.rg_micbias_rc = 6;
    adcCfg5.rg_micbias_ibias_sel = 1;
    adcCfg5.rg_pga_rcfilt_fine = 2;
    HWRITE_STRUCT(CORE_au_adc_cfg5, &adcCfg5);

    //    HWRITE(0x8b13,0x40);
    au_adc_cfg6RegDef adcCfg6;
    memset(&adcCfg6, 0, sizeof(adcCfg6));
    adcCfg6.rg_micbias_mode = 1;
    HWRITE_STRUCT(CORE_au_adc_cfg6, &adcCfg6);
}
void AUDIO_AdcAnaSEConfig()
{

#if 1                                         //With capacitance
    //    HWRITE(0x8b00,0x3e);
    codec_ldo_en0RegDef ldoEn0;
    HREAD_STRUCT(CORE_codec_ldo_en0, &ldoEn0);
    ldoEn0.da_ldo_daccore_en = 1;
    ldoEn0.da_ldohp_dacdrv_en = 1;
    ldoEn0.da_adc_reg_en = 1;
    ldoEn0.da_mic_reg_en = 1;
    ldoEn0.da_adc_pwrsw_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &ldoEn0);

    //    HWRITE(0x8b01,0x51);
    codec_ldo_cfg0RegDef lodCfg0;
    HREAD_STRUCT(CORE_codec_ldo_cfg0, &lodCfg0);
    lodCfg0.rg_mic_hvreg_vc = 1;
    lodCfg0.rg_adc_reg_vol_sel = 2;
    lodCfg0.rg_adc_reg_ibias_sel = 1;
    HWRITE_STRUCT(CORE_codec_ldo_cfg0, &lodCfg0);

    //    HWRITE(0x8b02,0x55);
    codec_ldo_cfg1RegDef lodCfg1;
    HREAD_STRUCT(CORE_codec_ldo_cfg1, &lodCfg1);
    lodCfg1.rg_ibsel_hpldo = 1;
    lodCfg1.rg_ldo_excap_en = 1;
    lodCfg1.rg_ldo_voutsel = 2;
    lodCfg1.rg_ibsel_ldo = 1;
    HWRITE_STRUCT(CORE_codec_ldo_cfg1, &lodCfg1);

    //    HWRITE(0x8b04,0x2a);
    codec_ldo_cfg2RegDef lodCfg2;
    lodCfg2.rg_ldohp_excap_en = 1;
    lodCfg2.rg_ldohp_voutsel = 2;
    lodCfg2.rg_ldohp_ocp_sel = 1;
    HWRITE_STRUCT(CORE_codec_ldo_cfg2, &lodCfg2);

    //    HWRITE(0x8b05,0x36);
    codec_vmid_en0RegDef vmidEn0;
    HREAD_STRUCT(CORE_codec_vmid_en0, &vmidEn0);
    vmidEn0.da_vmid_discharge = 0;
    vmidEn0.da_vmid_en = 1;
    vmidEn0.da_vmid_bias_en = 1;
    vmidEn0.da_vmid_extcap_en = 1;
    vmidEn0.da_vmid_bg_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b06,0x08);
    codec_vmid_cfg0RegDef vmidCfg0;
    HREAD_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
    vmidCfg0.rg_vmid_isel_lsb = 8;
    HWRITE_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);

    //    HWRITE(0x8b07,0x68);
    codec_vmid_cfg1RegDef vmidCfg1;
    HREAD_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg1);
    vmidCfg1.rg_vmid_isel_msb = 8;
    vmidCfg1.rg_vmid_discharge_cc = 1;
    vmidCfg1.rg_vmid_discharge_auto = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg1);

    //    HWRITE(0x8b08,0x05);
    codec_vmid_cfg2RegDef vmidCfg2;
    HREAD_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);
    vmidCfg2.rg_vmid_bg_fastsetting = 1;
    vmidCfg2.rg_vmid_vref_sel = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b09,0x84);
    codec_vmid_cfg3RegDef vmidCfg3;
    HREAD_STRUCT(CORE_codec_vmid_cfg3, &vmidCfg3);
    vmidCfg3.rg_vmid_bg_trim = 4;
    vmidCfg3.rg_vmid_bg_rct = 8;
    HWRITE_STRUCT(CORE_codec_vmid_cfg3, &vmidCfg3);

    //    HWRITE(0x8b0b,0xe6);
    au_adc_en0RegDef adcEn0;
    memset(&adcEn0, 0, sizeof(adcEn0));
    adcEn0.da_pga_gm_en = 0;
    adcEn0.da_pga_gm_fst_en = 1;
    adcEn0.da_sdm_dem_en = 1;
    adcEn0.da_sdm_en = 1;
    adcEn0.da_aadc_top_ibias_en = 1;
    HWRITE_STRUCT(CORE_au_adc_en0, &adcEn0);

    //    SysTick_DelayMs(10);

    //    HWRITE(0x8b0b,0xe2);
    adcEn0.da_pga_gm_fst_en = 0;
    HWRITE_STRUCT(CORE_au_adc_en0, &adcEn0);

    //    HWRITE(0x8b0c,0x0b);
    au_adc_en1RegDef adcEn1;
    memset(&adcEn1, 0, sizeof(adcEn1));
    adcEn1.da_micbias_en = 1;
    adcEn1.da_pga_en = 1;
    adcEn1.da_pga_diff_en = 0;
    adcEn1.da_pga_rbias_en = 0;
    HWRITE_STRUCT(CORE_au_adc_en1, &adcEn1);

    //    HWRITE(0x8b0d,0x55);
    au_adc_cfg0RegDef adcCfg0;
    memset(&adcCfg0, 0, sizeof(adcCfg0));
    adcCfg0.rg_sdm_cmp_isel = 1;
    adcCfg0.rg_sdm_ota1_isel = 1;
    adcCfg0.rg_sdm_ota2_isel = 1;
    adcCfg0.rg_sdm_ref_isel = 1;
    HWRITE_STRUCT(CORE_au_adc_cfg0, &adcCfg0);

    //    HWRITE(0x8b0e,0x51);
    au_adc_cfg1RegDef adcCfg1;
    memset(&adcCfg1, 0, sizeof(adcCfg1));
    adcCfg1.rg_pga_opa2_ibias_sel = 1;
    adcCfg1.rg_pga_cz_ibias_sel = 2;
    adcCfg1.rg_pga_gm_ibias_sel = 2;
    HWRITE_STRUCT(CORE_au_adc_cfg1, &adcCfg1);

    //    HWRITE(0x8b0f,0x05);
    HWRITE(CORE_au_adc_cfg2, 0x05);

    //    HWRITE(0x8b10,0x0f);
    au_adc_cfg3RegDef adcCfg3;
    memset(&adcCfg3, 0, sizeof(adcCfg3));
    adcCfg3.rg_pga_gc = 15;
    HWRITE_STRUCT(CORE_au_adc_cfg3, &adcCfg3);

    //    HWRITE(0x8b11,0x05);
    au_adc_cfg4RegDef adcCfg4;
    memset(&adcCfg4, 0, sizeof(adcCfg4));
    adcCfg4.rg_pga_rcfilt_coarse = 1;
    adcCfg4.rg_pga_dcoc_ibc = 1;
    HWRITE_STRUCT(CORE_au_adc_cfg4, &adcCfg4);

    //    HWRITE(0x8b12,0x4e);
    au_adc_cfg5RegDef adcCfg5;
    memset(&adcCfg5, 0, sizeof(adcCfg5));
    adcCfg5.rg_micbias_rc = 6;
    adcCfg5.rg_micbias_ibias_sel = 1;
    adcCfg5.rg_pga_rcfilt_fine = 2;
    HWRITE_STRUCT(CORE_au_adc_cfg5, &adcCfg5);

    //    HWRITE(0x8b13,0x40);
    au_adc_cfg6RegDef adcCfg6;
    memset(&adcCfg6, 0, sizeof(adcCfg6));
    adcCfg6.rg_micbias_mode = 1;
    HWRITE_STRUCT(CORE_au_adc_cfg6, &adcCfg6);
#endif
}

void AUDIO_AdcAnaVcomConfig()
{
    //    HWRITE(0x8b00,0x3c);
    codec_ldo_en0RegDef ldoEn0;
    HREAD_STRUCT(CORE_codec_ldo_en0, &ldoEn0);
    ldoEn0.da_ldo_daccore_en = 1;
    ldoEn0.da_ldohp_dacdrv_en = 1;
    ldoEn0.da_adc_reg_en = 1;
    ldoEn0.da_mic_reg_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &ldoEn0);

    //    HWRITE(0x8b01,0x51);
    codec_ldo_cfg0RegDef lodCfg0;
    HREAD_STRUCT(CORE_codec_ldo_cfg0, &lodCfg0);
    lodCfg0.rg_mic_hvreg_vc = 1;
    lodCfg0.rg_adc_reg_vol_sel = 2;
    lodCfg0.rg_adc_reg_ibias_sel = 1;
    HWRITE_STRUCT(CORE_codec_ldo_cfg0, &lodCfg0);

    //    HWRITE(0x8b02,0x51);
    codec_ldo_cfg1RegDef lodCfg1;
    HREAD_STRUCT(CORE_codec_ldo_cfg1, &lodCfg1);
    lodCfg1.rg_ibsel_hpldo = 1;
    lodCfg1.rg_ldo_voutsel = 2;
    lodCfg1.rg_ibsel_ldo = 1;
    HWRITE_STRUCT(CORE_codec_ldo_cfg1, &lodCfg1);

    //    HWRITE(0x8b05,0x26);
    codec_vmid_en0RegDef vmidEn0;
    HREAD_STRUCT(CORE_codec_vmid_en0, &vmidEn0);
    vmidEn0.da_vmid_discharge = 0;
    vmidEn0.da_vmid_en = 1;
    vmidEn0.da_vmid_bias_en = 1;
    vmidEn0.da_vmid_bg_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b06,0x08);
    codec_vmid_cfg0RegDef vmidCfg0;
    HREAD_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
    vmidCfg0.rg_vmid_isel_lsb = 8;
    HWRITE_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);

    //    HWRITE(0x8b07,0x68);
    codec_vmid_cfg1RegDef vmidCfg1;
    HREAD_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg1);
    vmidCfg1.rg_vmid_isel_msb = 8;
    vmidCfg1.rg_vmid_discharge_cc = 1;
    vmidCfg1.rg_vmid_discharge_auto = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg1);

    //    HWRITE(0x8b08,0x05);
    codec_vmid_cfg2RegDef vmidCfg2;
    HREAD_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);
    vmidCfg2.rg_vmid_bg_fastsetting = 1;
    vmidCfg2.rg_vmid_vref_sel = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b09,0x84);
    codec_vmid_cfg3RegDef vmidCfg3;
    HREAD_STRUCT(CORE_codec_vmid_cfg3, &vmidCfg3);
    vmidCfg3.rg_vmid_bg_trim = 4;
    vmidCfg3.rg_vmid_bg_rct = 8;
    HWRITE_STRUCT(CORE_codec_vmid_cfg3, &vmidCfg3);

    //    HWRITE(0x8b0b,0xe0);
    au_adc_en0RegDef adcEn0;
    memset(&adcEn0, 0, sizeof(adcEn0));
    adcEn0.da_sdm_dem_en = 1;
    adcEn0.da_sdm_en = 1;
    adcEn0.da_aadc_top_ibias_en = 1;
    HWRITE_STRUCT(CORE_au_adc_en0, &adcEn0);

    //    HWRITE(0x8b0c,0x07);
    au_adc_en1RegDef adcEn1;
    memset(&adcEn1, 0, sizeof(adcEn1));
    adcEn1.da_micbias_en = 1;
    adcEn1.da_pga_en = 1;
    adcEn1.da_pga_diff_en = 0;
    HWRITE_STRUCT(CORE_au_adc_en1, &adcEn1);

    //    HWRITE(0x8b0d,0x55);
    au_adc_cfg0RegDef adcCfg0;
    memset(&adcCfg0, 0, sizeof(adcCfg0));
    adcCfg0.rg_sdm_cmp_isel = 1;
    adcCfg0.rg_sdm_ota1_isel = 1;
    adcCfg0.rg_sdm_ota2_isel = 1;
    adcCfg0.rg_sdm_ref_isel = 1;
    HWRITE_STRUCT(CORE_au_adc_cfg0, &adcCfg0);

    //    HWRITE(0x8b0e,0x51);
    au_adc_cfg1RegDef adcCfg1;
    memset(&adcCfg1, 0, sizeof(adcCfg1));
    adcCfg1.rg_pga_opa2_ibias_sel = 1;
    adcCfg1.rg_pga_cz_ibias_sel = 2;
    adcCfg1.rg_pga_gm_ibias_sel = 2;
    HWRITE_STRUCT(CORE_au_adc_cfg1, &adcCfg1);

    //    HWRITE(0x8b0f,0x05);
    HWRITE(CORE_au_adc_cfg2, 0x05);

    //    HWRITE(0x8b10,0x04);
    au_adc_cfg3RegDef adcCfg3;
    memset(&adcCfg3, 0, sizeof(adcCfg3));
    adcCfg3.rg_pga_gc = 4;
    HWRITE_STRUCT(CORE_au_adc_cfg3, &adcCfg3);

    //    HWRITE(0x8b11,0x05);
    au_adc_cfg4RegDef adcCfg4;
    memset(&adcCfg4, 0, sizeof(adcCfg4));
    adcCfg4.rg_pga_rcfilt_coarse = 1;
    adcCfg4.rg_pga_dcoc_ibc = 1;
    HWRITE_STRUCT(CORE_au_adc_cfg4, &adcCfg4);

    //    HWRITE(0x8b12,0x4a);
    au_adc_cfg5RegDef adcCfg5;
    memset(&adcCfg5, 0, sizeof(adcCfg5));
    adcCfg5.rg_micbias_rc = 2;
    adcCfg5.rg_micbias_ibias_sel = 1;
    adcCfg5.rg_pga_rcfilt_fine = 2;
    HWRITE_STRUCT(CORE_au_adc_cfg5, &adcCfg5);
}

void AUDIO_AdcAnaStop(void)
{
    codec_ldo_en0RegDef ldoEn0;
    HREAD_STRUCT(CORE_codec_ldo_en0, &ldoEn0);
    ldoEn0.da_adc_reg_en = 0;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &ldoEn0);

    //    HWRITE(0x8b0b,0x20);
    au_adc_en0RegDef adcEn0;
    memset(&adcEn0, 0, sizeof(adcEn0));
    adcEn0.da_sdm_dem_en = 1;
    HWRITE_STRUCT(CORE_au_adc_en0, &adcEn0);

    //    HWRITE(0x8b0c,0x00);
    au_adc_en1RegDef adcEn1;
    memset(&adcEn1, 0, sizeof(adcEn1));
    HWRITE_STRUCT(CORE_au_adc_en1, &adcEn1);
}
