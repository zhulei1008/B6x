/**
***************************************************************************
* @file:  yc11xx_uart.c
* @Date:  2021-6-4-20:14:05
* @brief: UART driver
*
* Change Logs:
* Date           Author      Version        Notes
* 2021-03-08     zhouduo     V1.0.0      the first version
* 2021-06-15     zhouduo     V1.1.0      the formal version
**************************************************************************
*/
#include "yc11xx_uart.h"
#include "reg_addr.h"

#include "reg_struct.h"
#include "yc11xx_gpio.h"

#define UARTC_BIT_ENABLE (1<<0)
#define BAUD_USE_SETTING (1<<7)
/**
  * @brief  Deinit the UARTx peripheral registers
  *         to their default reset values.
  * @param  UARTx : Select the UART peripheral.UARTA,UARTB
  * @return None
  */
void UART_DeInit(UART_TypeDef UARTx)
{
    UART_CONTROLRegDef uartCtrl;
    UartxRegDef *uartAdr = NULL;
    if(UARTx == UARTA)
    {
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_BAUD_RATE));
    }
    else
    {
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_B_BAUD_RATE));
    }

    uartCtrl.uart_en = 0;
    HWRITE_STRUCT(uartAdr, &uartCtrl);
}



/**
  * @brief  Initializes the UARTx peripheral according to the specified
  *         parameters in the UART_InitStruct.
  * @param  UARTx : Select the UART peripheral. UARTA,UARTB
  * @param  UART_InitStruct : pointer to a UART_InitTypeDef structure
  *         that contains the configuration information for the specified UART
  *         peripheral.
  * @return None
  */
void UART_Init(UART_TypeDef UARTx, UART_InitTypeDef *UART_InitStruct)//111
{
    UART_CONTROLRegDef uartCtrl;
    uint8_t ctrValue = 0;
    uint16_t uartxCtrlAdr = 0;
    CLOCK_CTRLRegDef clockSlect;

    UartxRegDef *uartAdr = NULL;
    if(UARTx == UARTA)
    {
        uartxCtrlAdr = CORE_UART_CONTROL;
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_BAUD_RATE));
    }
    else
    {
        uartxCtrlAdr = CORE_UART_B_CONTROL;
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_B_BAUD_RATE));
    }

    clockSlect.uart_clock_sel = 1;
    HWRITE_STRUCT(CORE_CLOCK_CTRL, &clockSlect);
    CoreReg_ClkControl(REG_CLOCK_OFF_UART, ENABLE);


    ctrValue =  UART_InitStruct->UART_Mode | \
                UART_InitStruct->UART_HardwareFlowControl | \
                UART_InitStruct->UART_Parity | \
                UART_InitStruct->UART_StopBits | \
                UART_InitStruct->UART_WordLength | \
                BAUD_USE_SETTING | \
                UARTC_BIT_ENABLE;

    HWRITEW((uint32_t)(&uartAdr->Baudrate), UART_InitStruct->UART_BaudRate);
    HWRITEW((uint32_t)(&uartAdr->RxSadr), UART_InitStruct->UART_RxBuffer);
    HWRITEW((uint32_t)(&uartAdr->RxEadr), UART_InitStruct->UART_RxBuffer + UART_InitStruct->UART_RXLen - 1);
    HWRITEW((uint32_t)(&uartAdr->RxRptr), UART_InitStruct->UART_RxBuffer);
    HWRITEW((uint32_t)(&uartAdr->TxSadr), UART_InitStruct->UART_TxBuffer);
    HWRITEW((uint32_t)(&uartAdr->TxEadr), UART_InitStruct->UART_TxBuffer + UART_InitStruct->UART_TXLen - 1);
    HWRITEW((uint32_t)(&uartAdr->TxWptr), UART_InitStruct->UART_TxBuffer);



    uartCtrl.uart_en = 0;
    HWRITE_STRUCT(uartxCtrlAdr, &uartCtrl);

    HWRITE(uartxCtrlAdr, ctrValue);
}


/**
  * @brief  Transmits single data through the UARTx peripheral.
  * @param  UARTx : Select the UART peripheral. UARTA,UARTB
  * @param  Data : the data to transmit.
  * @return None
  */
void UART_SendData(UART_TypeDef UARTx, uint8_t Data)
{
    uint32_t txItems = 0;
    uint16_t  wptr = 0;
    uint16_t  bufLen = 0;
    UartxRegDef *uartAdr = NULL;
    if(UARTx == UARTA)
    {
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_BAUD_RATE));
        txItems = CORE_UART_TX_ITEMS;
    }
    else
    {
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_B_BAUD_RATE));
        txItems = CORE_UART_B_TX_ITEMS;
    }
    bufLen = (HREADW(&uartAdr->TxEadr)) - (HREADW(&uartAdr->TxSadr));
    wptr = HREADW((uint32_t)(&uartAdr->TxWptr));
    while(1 >= (bufLen - (HREADW(txItems)))); //ready to send
    HWRITE(reg_map_m0(wptr), Data); //send from mram
    //HWRITE(reg_map(wptr),Data);//send from sram
    RB_UPDATE_PTR(wptr, HREADW((uint32_t)(&uartAdr->TxSadr)), HREADW((uint32_t)(&uartAdr->TxEadr)));
    HWRITEW((uint32_t)(&uartAdr->TxWptr), (uint32_t)(wptr)); // ring back
    //while(HREADW(txItems));//wait for finished
}

/**
  * @brief  Returns the most recent received data by the UARTx peripheral.
  * @param  UARTx : Select the UART peripheral. UARTA,UARTB
  * @return The received data.
  */
uint8_t UART_ReceiveData(UART_TypeDef UARTx)
{

    uint16_t  rptr = 0;
    uint8_t  rdData = 0;
    UartxRegDef *uartAdr = NULL;
    if(UARTx == UARTA)
    {
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_BAUD_RATE));
    }
    else
    {
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_B_BAUD_RATE));
    }
	rptr = HREADW((uint32_t)(&uartAdr->RxRptr));//1111
	rdData = HREADW(reg_map_m0(rptr));//receive from mram
	//rdData = HREADW(reg_map(rptr));//receive from sram
	RB_UPDATE_PTR(rptr, HREADW((uint32_t)(&uartAdr->RxSadr)), HREADW((uint32_t)(&uartAdr->RxEadr)));
	HWRITEW((uint32_t)(&uartAdr->RxRptr), rptr);
    return rdData;
}

/**
  * @brief  Saves the received data to a buff
  * @param  UARTx : Select the UART peripheral. UARTA,UARTB
  * @param	RxBuff : The buffer where data receive to.
  * @param	RxSize : The length of receive data.
  * @return None
  */
uint16_t UART_ReadDatatoBuff(UART_TypeDef UARTx, uint8_t *RxBuff, uint16_t RxSize)
{
    uint32_t rxItems = 0;
    uint16_t rxLen = 0;
    uint16_t rptr = 0;
    uint16_t rDataLen = 0;
    UartxRegDef *uartAdr = NULL;
    if(UARTx == UARTA)
    {
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_BAUD_RATE));
        rxItems = CORE_UART_RX_ITEMS;
    }
    else
    {
        uartAdr = (UartxRegDef *)(reg_map(CORE_UART_B_BAUD_RATE));
        rxItems = CORE_UART_B_RX_ITEMS;
    }
    rxLen = HREADW(reg_map(rxItems));//11111
    if (RxSize != 0)
    {
        if (rxLen < RxSize) return 0;
        else rxLen = RxSize;
    }
    if (0 == rxLen)
    {
        return 0;
    }
    else
    {
        rptr = HREADW((uint32_t)(&uartAdr->RxRptr));
        for(rDataLen = 0; rDataLen < rxLen; rDataLen++ )
        {
            RxBuff[rDataLen] = HREAD(reg_map_m0(rptr));
            RB_UPDATE_PTR(rptr, HREADW((uint32_t)(&uartAdr->RxSadr)), HREADW((uint32_t)(&uartAdr->RxEadr)));
        }
    }
    HWRITEW((uint32_t)(&uartAdr->RxRptr), (rptr));
    return rDataLen;
}

/**
  * @brief  Transmits specified length data through the UARTx peripheral.
  * @param  UARTx : Select the UART peripheral. UARTA,UARTB
  * @param  TxBuff : The buffer where data transmit from.
  * @param	TxLen : The specified length to transmit.
  * @return None
  */
uint16_t UART_SendDataFromBuff(UART_TypeDef UARTx, uint8_t *TxBuff, uint16_t TxLen)
{
    while(TxLen--)
    {
        UART_SendData(UARTx, *TxBuff++);
    }
}

/**
  * @brief  Get the length of RX DMA.
  * @param  UARTx : Select the UART peripheral. UARTA,UARTB
  * @return None.
  */
uint16_t UART_GetRxCount(UART_TypeDef UARTx)
{
    if(UARTx == UARTA)
    {
        return HREADW(reg_map(CORE_UART_RX_ITEMS));
    }
    else
    {
        return HREADW(reg_map(CORE_UART_B_RX_ITEMS));
    }
}

/**
  * @brief  Returns the most recent received data by the UARTx peripheral.
  * @param  UARTx : Select the UART peripheral. UARTA,UARTB
  * @param  Num : interrupt Number of data.
  * @return The received data.
  */
void UART_SetRxITNum(UART_TypeDef UARTx, uint8_t Num)
{
    if(UARTx == UARTA)
    {
        HWRITE(reg_map(CORE_UART_CTRL), Num);
    }
    else
    {
        HWRITE(reg_map(CORE_UARTB_CTRL), Num);
    }
}

/**
  * @brief  Sets the RX interrupt trigger timeout.
  * @param  time : timeout of trigger interrupt.
  * @return None.
  */
void UART_SetRxTimeout(UART_TypeDef UARTx, uint16_t time)
{
    if(UARTx == UARTA)
    {
        HWRITEW(reg_map(CORE_UART_CTRL + 1), time);
    }
    else
    {
        HWRITEW(reg_map(CORE_UARTB_CTRL + 1), time);
    }
}

