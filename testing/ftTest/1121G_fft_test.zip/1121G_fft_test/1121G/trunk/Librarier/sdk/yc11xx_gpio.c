/**
 * @file yc11xx_gpio.c
 * @author duanchu.he
 * @brief GPIO driver
 * @version 0.1
 * @date 2021-07-06
 *
 *
 */
#include "yc11xx_gpio.h"
#include "reg_addr.h"
#include "btreg.h"


/**
 * @brief  Initializes the GPIOx peripheral according to the specified
 *          parameters in the GPIO_InitStruct.
 *
 * @param gpiox  where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_InitStruct
 */
void GPIO_Init(GPIO_X gpio_pin, GPIOMode_TypeDef gpioMode)
{
	_ASSERT(IS_GPIO_PIN(gpio_pin));

    if(gpio_pin < GPIO_32)
    	HWRITE(CORE_GPIO0_CONFIG + gpio_pin, gpioMode);
    else
    	HWRITE(CORE_GPIO_CONF1 + gpio_pin, gpioMode);
}

/**
 * @brief Reads the specified GPIO input data bit.
 *
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  	 				This parameter can be GPIO_Pin_x where x can be (0..7).
 * @return gpio input data bit value.
 */
uint8_t GPIO_ReadDataBit(GPIO_X gpio_pin)
{
    uint32_t regConfigAddr = 0;

    _ASSERT(IS_GPIO_PIN(gpio_pin));

    if(gpio_pin < GPIO_32)
    {
    	if(HREADL(CORE_GPIO_IN) & (uint32_t)(1 << gpio_pin))
    	     return 1;
    	else
    	     return 0;
    }
    else
    {
    	if(HREAD(CORE_GPIO_IN1) & (1 << (gpio_pin - GPIO_32)))
    	     return 1;
    	else
    	     return 0;
    }

}

/**
 * @brief Read gpio interrupt status.
 *
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  				 	This parameter can be GPIO_Pin_x where x can be (0..7).
 * @return true
 * @return false
 */
uint8_t GPIO_GetInterruptStatus(GPIO_X gpio_pin)
{
    uint8_t col = 0;
    uint8_t ret = 0;
    uint32_t temp = 0;

    _ASSERT(IS_GPIO_PIN(gpio_pin));

    if(gpio_pin < GPIO_32)
    {
    	if(HREADL(CORE_GPIO_ISR_L) & (uint32_t)(1 << gpio_pin))
    	     return 1;
    	else
    	     return 0;
    }
    else
    {
        col -= 32;
        temp = HREAD(CORE_GPIO_ISR_H);

        if((temp & (1 << col)) != 0)
            ret = 1;
        else
            ret = 0;
    }
}

/**
 * @brief Sets the gpio interrupt trigger mode.
 *
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  				 	This parameter can be GPIO_Pin_x where x can be (0..7).
 * @param interrupt_type gpio interrupt type structure
 */
void GPIO_SetInterrupt(GPIO_X gpio_pin, GPIO_IntrTypeDef intr_type)
{
    uint8_t  col = 0;
    uint32_t addr = 0;
    uint32_t tmp = 0;

    _ASSERT(IS_GPIO_PIN(gpio_pin));
	_ASSERT(IS_INTERRUPT(intr_type));

	col = gpio_pin;

    if(gpio_pin < GPIO_32)
    {
        switch(intr_type)
        {
			case Rising_Interrupt :
				tmp = HREADL(CORE_GPIO_RTS_L);
				tmp |= 1 << col;
				HWRITEL(CORE_GPIO_RTS_L, tmp);
				break;
			case Fall_Interrupt :
				tmp = HREADL(CORE_GPIO_RTS_L);
				tmp |= 1 << col;
				HWRITEL(CORE_GPIO_FTS_L, tmp);
				break;
			case Low_Interrupt :
				tmp = HREADL(CORE_GPIO_LTS_L);
				tmp |= 1 << col;
				HWRITEL(CORE_GPIO_LTS_L, tmp);
				break;
			case High_Interrupt :
				tmp = HREADL(CORE_GPIO_LTS_L);
				tmp &= ~(1 << col);
				HWRITEL(CORE_GPIO_LTS_L, tmp);
				break;
			case Rising_Fall_interrupt :
				tmp = HREADL(CORE_GPIO_RTS_L);
				tmp |= 1 << col;
				HWRITEL(CORE_GPIO_RTS_L, tmp);
				tmp = HREADL(CORE_GPIO_FTS_L);
				tmp |= 1 << col;
				HWRITEL(CORE_GPIO_FTS_L, tmp);
				break;
        }

        tmp = HREADL(CORE_GPIO_IEN_L);
        tmp |= 1 << col;
        HWRITEL(CORE_GPIO_IEN_L, tmp);


    }
    else
    {
        col -= GPIO_32;

        switch(intr_type)
        {
        case Rising_Interrupt :
            tmp = HREAD(CORE_GPIO_RTS_H);
            tmp |= 1 << col;
            HWRITE(CORE_GPIO_RTS_H, tmp);
            break;
        case Fall_Interrupt :
            tmp = HREAD(CORE_GPIO_FTS_H);
            tmp |= 1 << col;
            HWRITE(CORE_GPIO_FTS_H, tmp);
            break;
        case Low_Interrupt :
            tmp = HREAD(CORE_GPIO_LTS_H);
            tmp |= 1 << col;
            HWRITE(CORE_GPIO_LTS_H, tmp);
            break;
        case High_Interrupt :
            tmp = HREAD(CORE_GPIO_LTS_H);
            tmp &= ~(1 << col);
            HWRITE(CORE_GPIO_LTS_H, tmp);
            break;
        case Rising_Fall_interrupt :
            tmp = HREAD(CORE_GPIO_RTS_H);
            tmp |= 1 << col;
            HWRITE(CORE_GPIO_RTS_H, tmp);
            tmp = HREAD(CORE_GPIO_FTS_H);
            tmp |= 1 << col;
            HWRITE(CORE_GPIO_FTS_H, tmp);
            break;
        }

        tmp = HREAD(CORE_GPIO_IEN_H);
        tmp |= 1 << col;
        HWRITE(CORE_GPIO_IEN_H, tmp);
    }
}

/**
 * @brief Clear  gpio interrupt status
 *
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  				 	This parameter can be GPIO_Pin_x where x can be (0..7).
 */
void  GPIO_ClearInterrupt(GPIO_X gpio_pin)
{
    uint8_t col = 0;
    uint8_t ret = 0;
    uint32_t temp = 0;

    _ASSERT(IS_GPIO_PIN(gpio_pin));

    col = gpio_pin;

    if(col < GPIO_32)
    {
        temp = HREADL(CORE_GPIO_ICR_L);
        temp |= (1 << col);
        HWRITEL(CORE_GPIO_ICR_L, temp);
        temp &= ~(1 << col);
        HWRITEL(CORE_GPIO_ICR_L, temp);
    }
    else
    {
        col -= GPIO_32;
        temp = HREAD(CORE_GPIO_ICR_H);
        temp |= (1 << col);
        HWRITE(CORE_GPIO_ICR_H, temp);
        temp &= ~(1 << col);
        HWRITE(CORE_GPIO_ICR_H, temp);
    }
}

/**
 * @brief Gpio long press reset
 *
 * @param GPIO_Pinx_Reset Initializes the GPIOx  peripheral according to the specified
 *          parameters in the GPIO_LongPress_Reset.
 * @param newstate DISABE or ENABLE
 */
void GPIO_SetLongPressReset(GPIO_LongPress_Reset GPIOX_Reset, FunctionalState newstate)
{
	uint32_t val = 0;

    if(newstate != 0)
    {
    	val = HREADL(CORE_ICE_WDT_MODE) | (1 << 3);

    	CoreReg_LpmWrite2IceWdtLongRst(val);
        HWOR(CORE_AUDIO_CLKSEL + 1, 1 << GPIOX_Reset);
    }
    else
    {
    	val = HREADL(CORE_ICE_WDT_MODE) & (~(1 << 3));

    	CoreReg_LpmWrite2IceWdtLongRst(val);
    	HWCOR(CORE_AUDIO_CLKSEL + 1, 1 << GPIOX_Reset);
    }
}

/**
 * @brief Gpio long press reset time config
 *
 * @param longpress_timeout gpio longpress reset time set
 */
void GPIO_SetLongPressResetTimeOut(GPIO_LongPress_TimeOut longpress_timeout)
{
    HWRITE(CORE_LPM_RD_MUX + 1, longpress_timeout);
}

/**
 * @brief Gpio long press reset time config
 *
 * @param longpress_timeout gpio longpress reset time set
 */
void GPIOx_WakeUp(GPIO_X gpio_pin, GPIOWakeUp_TypeDef wakeuptype)
{
    uint8_t col = 0;
    uint32_t temp = 0;

    col = gpio_pin;

    if(wakeuptype != GPIO_WakeUpLow)
    {
        if(col < GPIO_32)
        {
            temp = HREADL(mem_gpio_wakeup_low);
            temp &= ~(1 << col);
            HWRITEL(mem_gpio_wakeup_low, temp);
            temp = HREADL(mem_gpio_wakeup_high);
            temp |= (1 << col);
            HWRITEL(mem_gpio_wakeup_high, temp);

        }
        else
        {
            col -= GPIO_32;

            temp = HREADL(mem_gpio2_wakeup_low);
            temp &= ~(1 << col);
            HWRITEL(mem_gpio2_wakeup_low, temp);
            temp = HREADL(mem_gpio2_wakeup_high);
            temp |= (1 << col);
            HWRITEL(mem_gpio2_wakeup_high, temp);
        }
    }
    else
    {
        if(col < GPIO_32)
        {
            temp = HREADL(mem_gpio_wakeup_high);
            temp &= ~(1 << col);
            HWRITEL(mem_gpio_wakeup_high, temp);
            temp = HREADL(mem_gpio_wakeup_low);
            temp |= (1 << col);
            HWRITEL(mem_gpio_wakeup_low, temp);
        }
        else
        {
            col -= GPIO_32;

            temp = HREADL(mem_gpio2_wakeup_high);
            temp &= ~(1 << col);
            HWRITEL(mem_gpio2_wakeup_high, temp);
            temp = HREADL(mem_gpio2_wakeup_low);
            temp |= (1 << col);
            HWRITEL(mem_gpio2_wakeup_low, temp);
        }
    }
}

/**
 * @brief Gpio long press reset time config
 *
 * @param longpress_timeout gpio longpress reset time set
 */
void GPIO_ICEREUSE(FunctionalState newstate)
{
	uint32_t value = 0;

	value = CoreReg_LpmGetIceWdtLongRst();

	if(newstate != DISABLE)
		value |= 1 << 3;
	else
		value &= ~(1 << 3);

	CoreReg_LpmWrite2IceWdtLongRst(value);
}

