/*
 * Copyright (c) 2006-2020, YICHIP Development Team
 * @file     yc_board_config.h
 * @brief    source file for setting board_config
 *
 * Change Logs:
 * Date           Author             Version        Notes
 * 2020-11-05     wushengyan         V1.0.0         the first version
 */

#ifndef __BOARD_CONFIG_H__
#define __BOARD_CONFIG_H__

#include "yc11xx.h"
#include "yc11xx_gpio.h"

/*Clock halved*/
#define CLOCK_HALVED

/*Board Setting*/
#define FPGA_BOARD  (1)
#define EVB_BOARD   (2)

#define BOARD_TYPE  FPGA_BOARD

#define FUNCTION_CONTROL_DEBUG_ENABLE

/*IIS Board*/

#define IIS_OUT_D_GPIONUM				GPIO_4

#define IIS_OUT_LRCLK_GPIONUM			GPIO_5

#define IIS_OUT_CLK_GPIONUM				GPIO_8


#define IIS_IN_D_GPIONUM					GPIO_1

#define IIS_IN_LRCLK_GPIONUM				GPIO_2

#define IIS_IN_CLK_GPIONUM				GPIO_3


#define IIS_MCLK_GPIO_PIN                                     GPIO_12
#if (BOARD_TYPE == FPGA_BOARD)


#define SD_SDIO_CLK_PORT							GPIOB
#define SD_SDIO_CMD_PORT							GPIOB
#define SD_SDIO_DATA0_PORT							GPIOB

#define SD_SDIO_CLK_PIN								GPIO_Pin_5
#define SD_SDIO_CMD_PIN								GPIO_Pin_6
#define SD_SDIO_DATA0_PIN							GPIO_Pin_7

/*ADC PDM GPIO*/
#define ADC_PDM_CLK_GPIO GPIO_6
#define ADC_PDM_DAT_GPIO GPIO_7

/*Print Port*/
#define PRINTPORT       UART0
#define PRINT_BAUD      (115200)
#define PRINTRX_PORT    GPIOB
#define PRINTRX_IO_PIN  1
#define PRINTTX_PORT    GPIOB
#define PRINTTX_IO_PIN  0

#define DEBUG_GPIO_DEFINE (7)

/*Audio Dac*/
#define AUDIO_DAC_VOL_MAX 0x1000
//#define AUDIO_DAC_VOL_MAX 0x0600
/*Audio Adc*/
//#define AUDIO_ADC_VOL_MIN 0x4cc
#define AUDIO_ADC_VOL_MAX 0x1000
/*IR*/
#define IR_USER_CODE 0x7f80

#define IR_RCV_UNIT_NUM ((2 + 2*4*8)*2) /* (start signal + usercode+ datacode)every two bytes record ir value bit */
#define KEY_LEFT_IR 0
#define KEY_RIGHT_IR 1
#define KEY_DOWN_IR 2
#define KEY_UP_IR 3

#define IR_BOOT_CODE_START_TIME     9000    //9ms
#define IR_BOOT_CODE_STOP_TIME          4500    //9ms
#define IR_REPEAT_START_TIME            9000    //9ms
#define IR_REPEAT_STOP_TIME             2250    //2250us
#define IR_DATA_START_TIME              560 //560us
#define IR_DATA_BIT0_STOP_TIME          560 //560us
#define IR_DATA_BIT1_STOP_TIME          1690//1690us
#define IR_CYCLE_TIMER                  110 //110ms
#define IR_ERROR_RANGE                  100  //10us
#define IR_DATA_RCV_STOP_TIME           9000*2
#define IR_VALID_DATA_NUM   4*8
#define PWM_CLK_FREQ        12000       //12MHz
#define IR_CLK_FREQ         38          //38kHz
#define IR_DUTY_CYCLE       4           //DUTY 1:3
#define IR_PCNT             PWM_CLK_FREQ/IR_CLK_FREQ*2/10*IR_DUTY_CYCLE
#define IR_NCNT             PWM_CLK_FREQ/IR_CLK_FREQ*2/10*(10-IR_DUTY_CYCLE)
#define MY_ABS(a,b)         ((a)-(b)>=0?(a)-(b):(b)-(a))
#define IR_PULSETIME_CHECK(real_time,ir_reference_time) (MY_ABS((real_time),(ir_reference_time))<= IR_ERROR_RANGE)

/*EQ IIS*/
#define EQ_Open
//#define UART_OPEN

#endif

/*  IIC GPIO CONFIG */
#define IIC_SCL_PORT							GPIOB
#define IIC_SDA_PORT							GPIOB

#define IIC_SCL_PIN								GPIO_Pin_0
#define IIC_SDA_PIN								GPIO_Pin_1

/*  UART */
//#define UARTA 0
//#define UARTB 1

/* QPIS1 */
#define QSPIX               QSPI1
#define QSPIX_IRQHandler    QSPI1_IRQHandler
#define QSPIX_IRQn          qspi1_IRQn


#define  W25Q16_QSPI_NCS_PIN                        GPIO_1
#define  W25Q16_QSPI_SCK_PIN                        GPIO_2
#define  W25Q16_QSPI_IO0_PIN                        GPIO_3
#define  W25Q16_QSPI_IO1_PIN                        GPIO_4
#define  W25Q16_QSPI_IO2_PIN                        GPIO_5
#define  W25Q16_QSPI_IO3_PIN                        GPIO_6

#define  PSRAM_QSPI_NCS_PIN                        GPIO_1
#define  PSRAM_QSPI_SCK_PIN                        GPIO_2
#define  PSRAM_QSPI_IO0_PIN                        GPIO_3
#define  PSRAM_QSPI_IO1_PIN                        GPIO_4
#define  PSRAM_QSPI_IO2_PIN                        GPIO_5
#define  PSRAM_QSPI_IO3_PIN                        GPIO_6

#define  PSRAM_QSPI_NCS_MODE                       GPIO_Mode_Qspi1_Ncs
#define  PSRAM_QSPI_SCK_MODE                       GPIO_Mode_Qspi1_Sck
#define  PSRAM_QSPI_IO0_MODE                       GPIO_Mode_Qspi1_Io0
#define  PSRAM_QSPI_IO1_MODE                       GPIO_Mode_Qspi1_Io1
#define  PSRAM_QSPI_IO2_MODE                       GPIO_Mode_Qspi1_Io2
#define  PSRAM_QSPI_IO3_MODE                       GPIO_Mode_Qspi1_Io3

#define  W25Q16_QSPI_NCS_MODE                       GPIO_Mode_Qspi1_Ncs
#define  W25Q16_QSPI_SCK_MODE                       GPIO_Mode_Qspi1_Sck
#define  W25Q16_QSPI_IO0_MODE                       GPIO_Mode_Qspi1_Io0
#define  W25Q16_QSPI_IO1_MODE                       GPIO_Mode_Qspi1_Io1
#define  W25Q16_QSPI_IO2_MODE                       GPIO_Mode_Qspi1_Io2
#define  W25Q16_QSPI_IO3_MODE                       GPIO_Mode_Qspi1_Io3


#define  W25Q16_SPI_NCS_PIN                         GPIO_1
#define  W25Q16_SPI_SCK_PIN                         GPIO_2
#define  W25Q16_SPI_MISO_PIN                        GPIO_3
#define  W25Q16_SPI_MOSI_PIN                        GPIO_4

#define  LCD_NCS_PIN                         GPIO_1
#define  LCD_SCK_PIN                         GPIO_2
#define  LCD_MISO_PIN                        GPIO_3
#define  LCD_MOSI_PIN                        GPIO_4

#define  Sensor_TSPI_NCS_PIN						GPIO_1
#define  Sensor_TSPI_SCK_PIN						GPIO_2
#define  Sensor_TSPI_MOSI_PIN						GPIO_3

#endif
