#ifndef __YICHIP_DTYPE__
#define __YICHIP_DTYPE__

#ifdef FIXED_POINT
    #include "Q.h"
    #include <stdbool.h>
    #define YC_t                Q_t
    #define YC(x)               Q(x)
    #define YC_from_int(x)      Q_from_int(x)
    #define YC_from_float(x)    Q_from_float(x)
    #define YC_to_int(x)        Q_to_int(x)
    #define YC_to_float(x)      Q_to_float(x)
    #define YC_add(x,y)         Q_add(x,y)
    #define YC_sub(x,y)         Q_sub(x,y)
    #define YC_mul(x,y)         Q_mul(x,y)
    #define YC_div(x,y)         Q_div(x,y)
    #define YC_sqrt(x)          Q_sqrt(x)
    #define YC_cos(x)           Q_cos(x)
    #define YC_sin(x)           Q_sin(x)
    #define YC_floor(x)         Q_floor(x)
    #define YC_nint(x)          Q_nint(x)
    #define YC_ceil(x)          Q_ceil(x)
    #define YC_abs(x)           Q_abs(x)
    #define YC_log2(x)          Q_log2(x)
    #define YC_pow(x,y)         Q_pow(x,y)
    #define YC_ONE              Q_ONE
    #define YC_HALF             Q_HALF
    #define YC_PI               Q_PI
#else
    #include <stdbool.h>
    #include <stdint.h>
    #include <math.h>
    #define YC(x)               (x)
    #define YC_t                float
    #define YC_from_int(x)      ((YC_t)(x))
    #define YC_from_float(x)    (x)
    #define YC_to_int(x)        ((int)(x))
    #define YC_to_float(x)      ((float)(x))
    #define YC_add(x,y)         ((x) + (y))
    #define YC_sub(x,y)         ((x) - (y))
    #define YC_mul(x,y)         ((x) * (y))
    #define YC_div(x,y)         ((x) / (y))
    #define YC_sqrt(x)          ((YC_t)sqrt(x))
    #define YC_cos(x)           ((YC_t)cos(x))
    #define YC_sin(x)           ((YC_t)sin(x))
    #define YC_floor(x)         ((YC_t)floor(x))
    #define YC_nint(x)          ((YC_t)round(x))
    #define YC_ceil(x)          ((YC_t)ceil(x))
    #define YC_abs(x)           ((YC_t)fabs(x))
    #define YC_log2(x)          ((YC_t)log2(x))
    #define YC_pow(x,y)         ((YC_t)pow(x,y))
    #define YC_ONE              (1.0f)
    #define YC_HALF             (0.5f)
    #define YC_PI               (3.14159265358979323846f)
#endif

#endif // __YICHIP_DTYPE__