/**
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file      yifft_bfly.h
 * @brief     DIT and TEM butterfly operation header
 * 
 * Change Logs:
 * Date         Author      Version     Notes
 * 2021-10-29   Ge Jiahao   0.1         init
 * 2021-12-28   Ge Jiahao   1.0         first release
 */

#ifndef __YIFFT_BFLY_H__
#define __YIFFT_BFLY_H__

#include "../include/yifft_config.h"

#ifdef BUILD_CFFT

#include "../include/yifft.h"
/* DIT */

void YIFFT_bfly2_DIT(const YIFFT_Plan plan, YIFFT_Complex *x, uint32_t f, uint8_t m);
void YIFFT_bfly3_DIT(const YIFFT_Plan plan, YIFFT_Complex *x, uint32_t f, uint8_t m);
void YIFFT_bfly4_DIT(const YIFFT_Plan plan, YIFFT_Complex *x, uint32_t f, uint8_t m);
void YIFFT_bfly5_DIT(const YIFFT_Plan plan, YIFFT_Complex *x, uint32_t f, uint8_t m);
void YIFFT_bfly7_DIT(const YIFFT_Plan plan, YIFFT_Complex *x, uint32_t f, uint8_t m);
void YIFFT_bflyP_DIT(const YIFFT_Plan plan, YIFFT_Complex *x, uint32_t f, uint8_t m, uint8_t p);

/* TEM */
void YIFFT_bflyP_TEM(const YIFFT_Plan plan, YIFFT_Complex *x, uint32_t f, uint8_t m, uint8_t p);

#endif /* BUILD_CFFT */

#endif /* __YIFFT_BFLY_H__ */