#ifndef __Q_H__
#define __Q_H__

#include <stdint.h>
// #include <stdio.h>

typedef int32_t Q_t;

/* Constants */
#define Q_ONE(Q_FBITS)      (1U<<Q_FBITS)
#define Q_TWO(Q_FBITS)      (1U<<(Q_FBITS+1))
#define Q_HALF(Q_FBITS)     (1U<<(Q_FBITS-1))
#define Q_FMASK(Q_FBITS)    ((1U << Q_FBITS) - 1) /* all fraction bits are 1, all word bits are 0 */
#define Q_WMASK(Q_FBITS)    (~Q_FMASK(Q_FBITS))
#define Q_PI_OVER_4_Q31     (1686629713)
#define Q_PI(Q_FBITS)       (Q_PI_OVER_4_Q31>>(29-Q_FBITS)) /* when Q_FBITS>29, pi will overflow */

/* compiler time float/intger to Q converter */
#define Q(x,Q_FBITS)        ((Q_t)((x) * Q_ONE(Q_FBITS)))

/* run time float/intger <=> Q converter */
static inline Q_t Q_from_int(int x, int Q_FBITS)
    { return (x << Q_FBITS);}

static inline Q_t Q_from_float(float x, int Q_FBITS)
    { return (Q_t)(x * Q_ONE(Q_FBITS)); }

static inline int32_t Q_to_int(Q_t x, int Q_FBITS)
    { return (int32_t)(x >> Q_FBITS); }

static inline float Q_to_float(Q_t x, int Q_FBITS)
    { return ((float)x / Q_ONE(Q_FBITS)); }

/* ============= Fixed point arithmetic ============= */

/*  To add/sub different QX.Y format: say x is Q16.16 y is Q1.31
        sum = x + (y>>(31-16)) and sum is Q16.16 
    i.e.: discard extra Q_FBITS for 

    To mul/div different QX.Y format: say x is Q16.16 and y is Q1.31 
        product = Q_mul(x, y, 31) and product is Q16.16 
        div = Q_div(y, x, 16) amd div is Q1.31
    i.e.: product and x have same Q_FBITS, and Q(x,y,Q_FBITS) Q_FBITS is y's Q_FBITS 
*/

static inline Q_t Q_add(Q_t x, Q_t y)
{
    /* using uint32_t to avoid signed int overflow, which is undefined behavior */
    uint32_t a = x;
    uint32_t b = y;
    uint32_t sum = a + b; 

    /* overflow check only need 3 extra instruction 
        but we cannot use C code because compiler will optimized it away */
    // if (!((a ^ b) & 0x80000000) && ((a ^ sum) & 0x80000000))
    // {
    //     // printf("add overflow\n");
    //     if (x > 0)
    //         return INT32_MAX;
    //     else
    //         return INT32_MIN;
    // }

   return sum;
}

static inline Q_t Q_sub(Q_t x, Q_t y)
{
    /* using uint32_t to avoid signed int overflow, which is undefined behavior */
    uint32_t a = x;
    uint32_t b = y;
    uint32_t diff = a - b; 

    // if (((a ^ b) & 0x80000000) && ((a ^ diff) & 0x80000000))
    // {
    //     // printf("sub overflow\n");
    //     if (x > 0)
    //         return INT32_MAX;
    //     else
    //         return INT32_MIN;
    // }

    return diff;
}

/* RISC-V M-extension has mul and mulh, so 32x32=64 is easy */
static inline Q_t Q_mul(Q_t x, Q_t y, int32_t Q_FBITS)
{
    int64_t product = (((int64_t)x) * y) >> Q_FBITS;
    // if (product > INT32_MAX)
    // {
    //     // printf("mul overflow\n");
    //     return INT32_MAX;
    // }
    // else if (product < INT32_MIN)
    // {
    //     // printf("mul overflow\n");
    //     return INT32_MIN;
    // }
    return (Q_t)product;
}

/* But M-extension has no 64 bit division. (int64_t)(x<<Q_FBITS)/y will call __divdi3 soft div 
subroutine, 64 bit div using 32 bit div also exists(see Q_div_alt), need profile these two to 
find which is faster. 
In practice we avoid division as much as possible so performance of div should be trivial */
static inline Q_t Q_div(Q_t x, Q_t y, int32_t Q_FBITS)
{
    int64_t quo = ((int64_t)x << Q_FBITS) / (int64_t)y;

    // if (quo > INT32_MAX)
    // {
    //     // printf("div overflow\n");
    //     return INT32_MAX;
    // }
    // else if (quo < INT32_MIN)
    // {
    //     // printf("div overflow\n");
    //     return INT32_MIN;
    // }
    return (Q_t)quo;
}

static int32_t clz(uint32_t x)
{
	int32_t result = 0;
	if (x == 0) return 32;
	while (!(x & 0xF0000000)) { result += 4; x <<= 4; }
	while (!(x & 0x80000000)) { result += 1; x <<= 1; }
	return result;
}
static inline Q_t Q_div_alt(Q_t x, Q_t y, int32_t Q_FBITS)
{
    if (y==0) 
        { return (x>0) ? (INT32_MAX) : (INT32_MIN); }
    uint32_t remainder = (x>0) ? (x) : (-x);
    uint32_t divider = (y>0) ? (y) : (-y);
    uint32_t quotient = 0;
    int bit_pos = Q_FBITS + 1;

	// If the divider is divisible by 2^n, take advantage of it.
	while (!(divider & 0xF) && bit_pos >= 4)
	{
		divider >>= 4;
		bit_pos -= 4;
	}

    while (remainder && bit_pos >= 0)
	{
		// Shift remainder as much as we can without overflowing
		int shift = clz(remainder);
		if (shift > bit_pos) 
            { shift = bit_pos; }
		remainder <<= shift;
		bit_pos -= shift;
		
		uint32_t div = remainder / divider;
        remainder = remainder % divider;
        quotient += div << bit_pos;

        // CHECK_OVERFLOW(div & ~(0xFFFFFFFF >> bit_pos),x,/,y);
		
		remainder <<= 1;
		bit_pos--;
	}

    Q_t result = quotient >> 1;

    if ((x^y) & 0x80000000) /* if negative */
    {
        result = -result-1;
    }
    return result;
}

/*  % operator means two things:
    mod:  r = a - b * floor(a / b)   or   rem:  r = a - b * trunc(a / b)
    mod and rem are equal when x and y have same sign, but when x and y have different sign,
    C's % operator is machine-dependent, as for RISC-V gcc, it compiled to `rem` instrcution. */
static inline Q_t Q_mod(Q_t x, Q_t y)
{   return x % y;   }

/* =============================== Fixed point math.h ========================= */
/* QX.Y format converter */
static  Q_t Q_to_Q(Q_t x, int32_t old_Y, int32_t new_Y)
{
    if (new_Y <= old_Y) /* convert to larger range, no overflow */
        return x >> (old_Y - new_Y);
    /* convert to smaller range, use Q_mul to protect from overflow */
    return Q_mul(x, Q_ONE(new_Y), old_Y);
}

static inline Q_t Q_abs(Q_t x)
{ 
    if (x == INT32_MIN) /* avoid -INT32_MIN overflow */
        return INT32_MAX;
    return ((x > 0) ? (x) : (-x));
}

static inline Q_t Q_floor(Q_t x, int32_t Q_FBITS)   /* rounding towards -inf */
{   return (x & (~Q_FMASK(Q_FBITS)));   }

static inline Q_t Q_ceil(Q_t x, int32_t Q_FBITS)    /* rounding towards +inf */
{   return (x & (~Q_FMASK(Q_FBITS))) + ((x & Q_FMASK(Q_FBITS)) ? (Q_ONE(Q_FBITS)) : (0));   }

static inline Q_t Q_nint(Q_t x, int32_t Q_FBITS)    /* rounding towards nearest integer */
{ 
    return (x > 0) ? (Q_floor(Q_add( x, Q_HALF(Q_FBITS)), Q_FBITS)) : \
                    (-Q_floor(Q_add(-x, Q_HALF(Q_FBITS)), Q_FBITS)); 
}
#define Q_round(x)  Q_nint(x)   /* alias of Q_nint */ 
#define Q_around(x) Q_nint(x)   /* alias of Q_nint */

static inline Q_t Q_trunc(Q_t x, int32_t Q_FBITS)   /* rounding towards zero */
{   return ((x>0) ? (Q_floor(x, Q_FBITS)) : (Q_ceil(x, Q_FBITS)));  }

static inline Q_t Q_away(Q_t x, int32_t Q_FBITS)    /* rounding away zero */
{   return ((x>0) ? (Q_ceil(x, Q_FBITS)) : (Q_floor(x, Q_FBITS)));  }



/* Turkowski, Ken. "Fixed point square root." Apple Technical Report No. 96 (1994). */
#define SQRT_2_Q30 0x5A827999U
static Q_t Q_sqrt(Q_t x, int32_t Q_FBITS)
{
    uint32_t root = 0, remHi = 0, remLo = x, count = 15 + (Q_FBITS/2);
    do {
        remHi = (remHi << 2) | (remLo >> 30);
        remLo <<= 2;
        root  <<= 1;
        uint32_t testDiv = (root << 1) + 1;
        if (remHi >= testDiv)
        {
            remHi -= testDiv;
            root++;
        }
    } while (count-- != 0);

    if (Q_FBITS & 0x1)
        return Q_mul(root, SQRT_2_Q30, 30);
    return (Q_t)root;
}


/* from https://github.com/dmoulding/log2fix
The MIT License (MIT)  Copyright (c) 2015 Dan Moulding

[1] C. S. Turner, "A Fast Binary Logarithm Algorithm", 
IEEE Signal Processing Mag., pp. 124,140, Sep. 2010. */
#define LOGE_2_Q31  0x58b90bfcU // Inverse log base 2 of e
#define LOG10_2_Q31 0x268826a1U // Inverse log base 2 of 10

static Q_t Q_log2(int32_t x, int32_t Q_FBITS)
{
   if (x <= 0)
      return INT32_MIN; /* represents negative infinity */

   int32_t half = Q_HALF(26);
   int32_t f26 = x;
   int32_t n = 0;

   while (f26 >= 2) 
   {
      f26 >>= 1;
      n++;  /* n is integer part of log2(x), n = floor(log2(x)) */
   }
   /* log2(x) = n + log2(y), where log2(y) is fraction part of log2(x), thus
      log2(y) ∈ [0,1), y ∈ [1,2). 
      y30 is Q2.30 format of y. f26 is Q6.26 format of log2(y)
      y30 = 2^30 * x / 2^n, n = floor(log2(x)). so 2^31 > y30 > 2^30  */
   f26 = 0; 
   int64_t y30 = x << (30 - n); 
   if (y30 != 0x40000000) 
   {  /* y30 == 0x40000000 means y == 1 and log2(y) == 0, fraction part is 0 */
      for (int i = 0; i < 26; i++) 
      {  /* y is always < 2^31, so we can use 32x32=>64 mul/mulh 
            then >> 30, when overflow(for int32_t) y will >> 1, 
            so total >> 31 make sure new y < 2^31 */
         y30 = (((int64_t)y30 * (int32_t)y30) >> 30 );
         if (y30 >= 0x80000000ULL)
         {
            y30 >>= 1;
            f26 += half;
         }
         half >>= 1;
      }
   }
   /* combine decimal integer part n and Q6.26 fraction part f26 and convert to 
      Q(31-Q_FBITS).Q_FBITS format */
   return Q_to_Q((n << 26) + f26 - (Q_FBITS << 26), 26, Q_FBITS);
}

static Q_t Q_log (Q_t x, int32_t Q_FBITS)   /* loge(x) = log2(x) * loge(2) */
{   return Q_mul(Q_log2(x, Q_FBITS), LOGE_2_Q31, 31);   }

static Q_t Q_log10 (Q_t x, int32_t Q_FBITS) /* log10(x) = log2(x) * log10(2) */
{   return Q_mul(Q_log2(x, Q_FBITS), LOG10_2_Q31, 31);  }


/*  from https://www.nullhardware.com/blog/fixed-point-sine-and-cosine-for-embedded-systems/
    input  rad_Q31 ∈ [0,1) in Q1.31 format ( [0, pi/2) )
    output sin_Q31 ∈ [0,1) in Q1.31 format (first quarter)*/
#define TWO_OVER_PI_Q31 1367130551U
#define A5_Q31 3370945098U
#define B5_Q31 1373181078U
#define C5_Q34 1197757015U

static inline int32_t Q_sin_kernel(uint32_t rad_Q31)
{
   uint32_t sin_Q31 = (uint32_t)(((int64_t)rad_Q31 * (uint32_t)C5_Q34) >> 34);
   sin_Q31 = (uint32_t)(((int64_t)sin_Q31 * (int32_t)rad_Q31) >> 31);
   sin_Q31 = B5_Q31 - sin_Q31;
   sin_Q31 = (uint32_t)(((int64_t)sin_Q31 * (int32_t)rad_Q31) >> 31);
   sin_Q31 = (uint32_t)(((int64_t)sin_Q31 * (int32_t)rad_Q31) >> 31);
   sin_Q31 = A5_Q31 - sin_Q31;
   sin_Q31 = (uint32_t)(((int64_t)sin_Q31 * (int32_t)rad_Q31) >> 31);
   return (int32_t)sin_Q31; /* output is Q1.31 */
}

static Q_t Q_sin(Q_t x, int32_t Q_FBITS)
{
    int32_t neg = 0;
    if (x < 0) /* wrap sin(-x) = -sin(x) */
    {
        neg = 1;
        x = -x;
    }    
    Q_t pi = Q_PI(Q_FBITS);
    x = Q_mod(x, pi<<1); /* wrap sin(x+2pi) = sin(x) */
    Q_t rad_Q31 = 0;
    Q_t sin_Q31 = 0;
    if (x < pi>>1) /* [0, pi/2) */
    {
        rad_Q31 = Q_mul(TWO_OVER_PI_Q31, x, Q_FBITS);
        sin_Q31 = Q_sin_kernel(rad_Q31);
    }
    else if (x < pi) /* [pi/2, pi) */
    {
        rad_Q31 = Q_mul(TWO_OVER_PI_Q31, pi-x, Q_FBITS);
        sin_Q31 = Q_sin_kernel(rad_Q31);
    }
    else if (x < pi/2*3)
    {
        rad_Q31 = Q_mul(TWO_OVER_PI_Q31, x-pi, Q_FBITS);
        sin_Q31 = -Q_sin_kernel(rad_Q31);
    }
    else
    {
        rad_Q31 = Q_mul(TWO_OVER_PI_Q31, (pi<<1)-x, Q_FBITS);
        sin_Q31 = -Q_sin_kernel(rad_Q31);
    }
    return (neg) ? (-sin_Q31) : (sin_Q31);
}

static Q_t Q_cos(Q_t x, int32_t Q_FBITS)
{   /* cos(x) = sin(x+pi/2) */
    return Q_sin(x + (Q_PI(Q_FBITS)>>1), Q_FBITS); 
}
#endif/*__Q_H__*/