/**
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file      yifft_dct.c
 * @brief     Discrete Cosine Transform code
 * 
 * Change Logs:
 * Date         Author      Version     Notes
 * 2021-12-03   Ge Jiahao   r0.1        refactor
 * 2021-12-28   Ge Jiahao   1.0         first release
 */

#include "../include/yifft_config.h"
#include "../include/yifft.h"

#ifdef BUILD_DCT

#include "yifft_kernel.h"

static YIFFT_STATE YIDCT_update_twiddles(YIDCT_Plan dct_plan)
{
    YIFFT_ASSERT(dct_plan, ERROR_PLAN_IS_NULL);    
    const uint32_t N = dct_plan->N;
    YI_t minus_two_pi_over_4N = 0, phase = 0;
    YIFFT_Complex *dct_tw = dct_plan->dct_twiddles;
    minus_two_pi_over_4N = YI_div(YI_mul(YC(-2), YI_PI), YI_from_int(4*N)); /* -2π/(4*N) */
    switch (dct_plan->type)
    {
        case DCT_I:
            break;
        default:
        case DCT_II:
        {   /* exp(-2jπ/(4*N)*k), k = 0 ~ N-1 */
            for (int k = 0; k < N; k++)
            {
                C_EXP(dct_tw[k], phase);
                phase = YI_add(phase, minus_two_pi_over_4N);
            }
            break;
        }
        case DCT_III:
        {   /* 0.5*exp(+2jπ/(4*N)*k), k = 1 ~ N/2 */
            minus_two_pi_over_4N = -minus_two_pi_over_4N;
            for (int k = 0; k < N/2; k++)
            {
                phase = YI_add(phase, minus_two_pi_over_4N);
                C_EXP(dct_tw[k], phase);
                dct_tw[k].r /= 2;
                dct_tw[k].i /= 2;
            }
            break;
        }
        case DCT_IV:
        case MDCT:
        case IMDCT:
        {
            /* N/4 DCT III twiddles: 0.5*exp( 2jπ/(2*N)*k), k = 1 ~ N/4 */
            YI_t theta_III = YI_div(YI_mul(YC(2), YI_PI), YI_from_int(2*N));
            for (int k = 0; k < N/4; k++)
            {
                phase = YI_add(phase, theta_III);
                C_EXP(dct_tw[k], phase);
                dct_tw[k].r /= 2;
                dct_tw[k].i /= 2;
            }
            /* N DCT IV twiddles: exp(-2jπ/(4*N)*(k+0.5)), k = 0 ~ N-1 */
            phase = minus_two_pi_over_4N / 2;
            for (int k = 0; k < N; k++)
            {
                C_EXP(dct_tw[k+N/4], phase);
                phase = YI_add(phase, minus_two_pi_over_4N);
            }
            break;
        }
    }
    
    return SUCCESS;
}

/** @details
 * Memory Layout of YIDCT_Plan:
 * 
 *      START
 * -----------------  <- YIDCT_Plan  dct_plan  ---------------------
 * | YIDCT_Memory  |                                                
 * -----------------  <- dct_plan->dct_twiddles     dct_mem_needed  
 * | dct_twiddles  |                                                
 * -----------------  <- dct_plan->tmp_buf  ------------------------
 * |   tmp_buf     |                                tmp_buf_needed  
 * -----------------  <- dct_plan->real_plan  ----------------------
 * |   real_plan   |  (details see YIRFFT_alloc())  real_mem_needed                             
 * -----------------  ----------------------------------------------
 *      END
 * 
 * Memory Layout of tmp_buf:
 *  ------------------------------------------------------------------------------------
 * | DCT type |    DCT I     |  DCT II    |    DCT III     | DCT IV / MDCT / IMDCT      |
 * |------------------------------------------------------------------------------------|
 * |          |    YI_t *y   |            |                |   YI_cpx *V (in DCT-III)   |
 * |          |   2N-2 real  |            |                |        N/2 complex         |
 * |          |--------------|  YI_cpx *V |   YI_cpx *V    |----------------------------|
 * | tmp_buf  |              |            |                |        YI_t *dct3_w        |
 * |          |  YI_cpx *Y   |  N complex |   N complex    |          N/2 real          |
 * |          | 2N-2 complex |            |                |        YI_t *dst_v         |
 * |          |              |            |                |          N/2 real          |
 *  ------------------------------------------------------------------------------------
 * 
 * @note one can see that DCT-IV/MDCT/IMDCT has same plan, so we can do three different
 *      work with one plan.
 */
YIDCT_Plan YIDCT_alloc(
    const uint32_t N, YIDCT_Type type, void *ext_mem, uint32_t *ext_mem_len)
{
    YIDCT_Plan dct_plan = NULL;
    bool inverse = false;
    uint32_t dct_mem_needed = sizeof(struct YIDCT_Memory);
    uint32_t real_mem_needed = 0;
    uint32_t mem_needed = 0;
    uint32_t tmp_buf_needed = 0;
    uint32_t real_N = N;
    switch (type)
    {    
        case DCT_I:
        {
            inverse = false;
            real_N = 2*N - 2;
            tmp_buf_needed = real_N * sizeof(YI_t) + real_N * sizeof(YIFFT_Complex);
            break;
        }
        default:
        case DCT_II:
        {
            type = DCT_II;
            inverse = false;
            dct_mem_needed += sizeof(YIFFT_Complex) * (N - 1);
            tmp_buf_needed = N * sizeof(YIFFT_Complex);
            break;
        }
        case DCT_III:
        {
            inverse = true;
            dct_mem_needed += sizeof(YIFFT_Complex) * (N/2 - 1);
            tmp_buf_needed = real_N * sizeof(YIFFT_Complex);
            break;
        }
        case DCT_IV:
        case MDCT:
        case IMDCT:
        {
            if (IS_ODD(N))
                return NULL;
            real_N = N/2;
            inverse = true;
            dct_mem_needed += sizeof(YIFFT_Complex) * (N + N/4 - 1);
            tmp_buf_needed = N * sizeof(YI_t) + real_N * sizeof(YIFFT_Complex);
            break;
        }
    }
    YIRFFT_alloc(real_N, false, NULL, &real_mem_needed);
    mem_needed = dct_mem_needed + real_mem_needed + tmp_buf_needed;
    if (ext_mem_len)
    {
        if ((*ext_mem_len >= mem_needed) && (ext_mem))
        {
            dct_plan = (YIDCT_Plan)ext_mem;
            dct_plan->ext_mem = true;
        }
        *ext_mem_len = mem_needed;
    }
    else
    {
        dct_plan = YIFFT_MALLOC(mem_needed);
        if (dct_plan)
            dct_plan->ext_mem = false;
    }

    if (dct_plan)
    {
        dct_plan->N = N;
        dct_plan->type = type;
        dct_plan->real_plan = YIRFFT_alloc(real_N, inverse, 
            (uint8_t *)dct_plan+dct_mem_needed+tmp_buf_needed, &real_mem_needed);
        dct_plan->tmp_buf = (uint8_t *)dct_plan+dct_mem_needed;
        dct_plan->dct_twiddles[0].r = YC(2);
        YIDCT_update_twiddles(dct_plan);
    }
    return dct_plan;
}

void YIDCT_free(YIDCT_Plan *dct_plan_ptr)
{
    if ((dct_plan_ptr) && (*dct_plan_ptr) && (!(*dct_plan_ptr)->ext_mem))
    {
        YIRFFT_free(&((*dct_plan_ptr)->real_plan));
        free(*dct_plan_ptr);
        *dct_plan_ptr = NULL;
    }
}

/* ================================ DCT work ================================== */

void YIDCT_DCT_I    (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out)
{
    YIFFT_ASSERT(dct_plan->type == DCT_I, VOID);
    uint32_t N = dct_plan->N;
    uint32_t real_N = 2*N - 2;
    YI_t *y = (YI_t *)(dct_plan->tmp_buf + 0);
    YIFFT_Complex *Y = (YIFFT_Complex *)(dct_plan->tmp_buf + sizeof(YI_t)* real_N);

    for (int n = 0; n < N; n++)
    {
        y[n] = in[n];
    }
    for (int n = N; n < real_N; n++)
    {
        y[n] = in[real_N-n];
    }

    YIRFFT_r2c(dct_plan->real_plan, y, Y); /* 2N-2 point real FFT */

    for (int k = 0; k < N; k++)
    {
        out[k] = Y[k].r / 2;
    }
}


void YIDCT_DCT_II   (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out)
{
    YIFFT_ASSERT(dct_plan->type >= DCT_III, VOID);
    uint32_t N = dct_plan->N;
    YIFFT_Complex *V = (YIFFT_Complex *)(dct_plan->tmp_buf + 0);
    YIFFT_Complex *tw = dct_plan->dct_twiddles;

    for (int n = 0; n < (N+1)/2; n++)
    {
        out[n] = in[2*n];
    }
    for (int n = (N+1)/2; n < N; n++)
    {
        out[n] = in[2*N-2*n-1];
    }

    YIRFFT_r2c(dct_plan->real_plan, out, V);

    for (int k = 0; k < N; k++)
    {
        out[k] = YI_sub(YI_mul(V[k].r, tw[k].r), YI_mul(V[k].i, tw[k].i));
    }
}

void YIDCT_DCT_III  (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out)
{
    /* DCT-III(and DST-III below) use real_plan->N as length N, 
        if dct_plan->type = DCT_III, real_plan->N = dct_plan->N
        if dct_plan->type = DCT_IV/MDCT/IMDCT, real_plan->N = dct_plan->N / 2 */
    YIFFT_ASSERT(dct_plan->type > DCT_II, VOID);
    uint32_t N = dct_plan->real_plan->N;
    YIFFT_Complex *V = (YIFFT_Complex *)(dct_plan->tmp_buf + 0);
    YIFFT_Complex *tw = dct_plan->dct_twiddles;

    V[0].r = in[0] / 2;
    V[0].i = 0;
    for (int k = 1; k < N/2+1; k++)
    {
        V[k].r = YI_add(YI_mul(tw[k-1].r, in[k]), YI_mul(tw[k-1].i, in[N-k]));
        V[k].i = YI_sub(YI_mul(tw[k-1].i, in[k]), YI_mul(tw[k-1].r, in[N-k]));
    }
    /* use Hermitian symmetry */
    for (int k = N/2+1; k < N; k++)
    {
        C_CONJUGATE(V[k], V[N-k]);
    }

    YIRFFT_c2r(dct_plan->real_plan, V, out);

    for (int k = 0; k < N; k++)
    {
        V[k].r = out[k];
    }
    for (int n = 0; n < (N+1)/2; n++)
    {
        out[2*n] = V[n].r;
    }
    for (int n = (N+1)/2; n < N; n++)
    {
        out[2*N-2*n-1] = V[n].r;
    }
}

static void YIFFT_DST_III(const YIDCT_Plan dct_plan, YI_t *in, YI_t *out)
{
    YI_t x0 = in[0] / 2;
    uint32_t N = dct_plan->real_plan->N;   

    out[0] = in[0];
    for (int n = 1; n < N; n++)
    {
        out[n] = in[N-n];
    }

    YIDCT_DCT_III(dct_plan, out, in);

    for (int k = 0; k < N; k++)
    {
        YI_t one = (IS_EVEN(k)) ? (YC(1)) : (YC(-1));
        out[k] = YI_add(YI_mul(YI_sub(in[k], x0), one), x0);
    }
}

void YIDCT_DCT_IV   (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out)
{  
    YIFFT_ASSERT(dct_plan->type >= DCT_IV, VOID);
    uint32_t N = dct_plan->N;
    uint32_t M = N>>1;
    YI_t *v = out;
    YI_t *w = out + M;
    YI_t *dct3_w = NULL, *dst3_v = NULL;
    YI_t v0 = 0, w0 = 0;
    YIFFT_Complex *tw = dct_plan->dct_twiddles + N/4;

    w[0] = in[0];
    v[0] = -in[N-1];
    for (int k = 1; k < M; k++)
    {
        w[k] = YI_add(in[2*k], in[2*k-1]);
        v[k] = YI_sub(in[2*k-1], in[2*k]);
    }
    w0 =  w[0] / 2;
    v0 = -v[0] / 2;

    dct3_w = (YI_t *)(dct_plan->tmp_buf + M*sizeof(YIFFT_Complex));
    dst3_v = (YI_t *)(dct_plan->tmp_buf + M*sizeof(YIFFT_Complex) + M*sizeof(YI_t));

    YIDCT_DCT_III(dct_plan, w, dct3_w);
    YIFFT_DST_III(dct_plan, v, dst3_v);

    for (int k = 0; k < M; k++)
    {
        YI_t xN_1 = (IS_EVEN(k)) ? (in[N-1]) : (-in[N-1]);
        out[k] = YI_sub(
            YI_mul(tw[k].r, YI_add(dct3_w[k], w0)),
            YI_mul(tw[k].i, YI_add(dst3_v[k], YI_add(v0, xN_1)))
        );
    }

    for (int k = M; k < N; k++)
    {
        YI_t xN_1 = (IS_EVEN(k)) ? (in[N-1]) : (-in[N-1]);
        out[k] = YI_sub(
            YI_mul(tw[k].r, YI_add(dct3_w[N-k-1], w0)),
            YI_mul(tw[k].i, YI_sub(YI_sub(xN_1, dst3_v[N-k-1]), v0))
        );
    }
}

void YIDCT_MDCT     (const YIDCT_Plan dct_plan, YI_t *in, YI_t *out)
{
    YIFFT_ASSERT(dct_plan->type >= DCT_IV, VOID);
    uint32_t N = dct_plan->N;
    uint32_t M = N >> 1;
    for (int n = 0; n < M; n++)
    {
        YI_t xn = in[n];
        in[n] = -YI_add(in[3*M-1-n], in[3*M+n]);
        in[3*M+n] = xn;
        in[3*M-1-n] = in[N-1-n];
    }
    for (int n = M; n < N; n++)
    {
        in[n] = YI_sub(in[n+N], in[2*N-1-n]);
    }    
    YIDCT_DCT_IV(dct_plan, in, out);
}

void YIDCT_IMDCT    (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out)
{
    YIFFT_ASSERT(dct_plan->type >= DCT_IV, VOID);
    uint32_t N = dct_plan->N;
    uint32_t M = N >> 1;
    YIDCT_DCT_IV(dct_plan, in, out);
    YI_t scale = YI_div(YI_ONE, YI_from_int(N));
    for (int k = 0; k < N; k++)
    {
        out[k] = YI_mul(out[k], scale);
    }
    for (int n = 0; n < M; n++)
    {
        out[N+M+n] = -out[n];
        out[N+M-n-1] = -out[n];
        out[n] = out[M+n];
    }
    for (int n = 0; n < M; n++)
    {
        out[M+n] = -out[M-n-1];
    }
}

#endif /* BUILD_DCT */