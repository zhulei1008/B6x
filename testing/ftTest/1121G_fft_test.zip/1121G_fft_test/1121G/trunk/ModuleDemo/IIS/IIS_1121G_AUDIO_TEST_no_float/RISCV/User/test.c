#include "test.h"



void TEST_AudioDAC(uint8_t* addr,uint16_t buffSize,DAC_ClkDev clock,DAC_DateModeDev dataBit,DAC_SoundTrackDev sound)
{
    DAC_InitParamDef dacParamInit;
    dacParamInit.DacClk=clock;
    dacParamInit.SoundTrack=sound;
    dacParamInit.DacBufferSize=buffSize;
    dacParamInit.DacStartAddr=(uint8_t*)addr;
    if(sound == stereo)
    {
        dacParamInit.LeftChannelConfig=DAC_LChannelSelLeft;
        dacParamInit.RightChannelConfig=DAC_RChannelSelRight;
    }
    else
    {
        dacParamInit.LeftChannelConfig=DAC_LChannelSelLeft;
        dacParamInit.RightChannelConfig=DAC_RChannelClose;
    }
    dacParamInit.DacWorkMode=DAC_WorkContinuous;
    dacParamInit.DateMode=dataBit;
    dacParamInit.DacDsmDitherEn=DAC_DSMDitherDisable;
    dacParamInit.DSMOutdisMode=DAC_DSMModeNormal;
    dacParamInit.DacZeroNumSel=1;
    dacParamInit.DWAMode=DAC_ScrambleDWARButterfly;
    dacParamInit.FadeEn=DAC_FadeEnable;
    dacParamInit.FadeStep=0x08;
    dacParamInit.Vol=10;
    dacParamInit.OutMode = DAC_DifferentialOutput;
    AUDIO_DacInit(dacParamInit);
}

void Audio_AdcParamConfig(uint32_t startaddr,uint32_t size,Audio_MicTypeDev mic,Audio_ADCSample sample)
{
    Audio_ADCInitParamDev adcparaminit;
    adcparaminit.Adc_StartAddr=(uint8_t*)startaddr;/*adc start address*/
    adcparaminit.Adc_BufferSize=size;/*adc buffer */
    adcparaminit.Adc_Sample=sample;/*adc samples*/
    adcparaminit.Adc_BiasVoltage=MicBiasVol1_5V;/* micbas voltage*/
    adcparaminit.Mic_Type=mic;/*mic typedev */
    adcparaminit.Adc_VolFadeEnable= ENABLE;/*audio vol fade enable or disable*/
    adcparaminit.Adc_VolStep=2;/*ADC vol step of Channel Prompt*/
    adcparaminit.Adc_Vol=10;/* voice data:0-10*/
    adcparaminit.Adc_MuteChannel=DISABLE;/*mute adc channel*/
    adcparaminit.Adc_RssiConfig=adc_RssiDisable;
    adcparaminit.Adc_HPFConfig = adc_HPFDisable;
    adcparaminit.Adc_OutputMode = ADC_DifferentialOutput;
    Audio_AdcInit(adcparaminit);
}


