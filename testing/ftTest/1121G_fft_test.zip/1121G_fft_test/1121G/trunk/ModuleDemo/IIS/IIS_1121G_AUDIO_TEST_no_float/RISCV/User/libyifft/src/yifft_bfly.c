/**
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file      yifft_bfly.c
 * @brief     DIT and TEM butterfly operation code
 * 
 * Change Logs:
 * Date         Author      Version     Notes
 * 2021-10-29   Ge Jiahao   0.1         init
 * 2021-12-28   Ge Jiahao   1.0         first release
 */

#include "../include/yifft_config.h"

#ifdef BUILD_CFFT

#include <stdlib.h>
#include "yifft_bfly.h"
#include "yifft_kernel.h"

void YIFFT_bfly2_DIT(
    const YIFFT_Plan plan, YIFFT_Complex *x, const uint32_t f, const uint8_t m)
{
    YIFFT_Complex abc[2] = {0};
    int r = 0;
    YIFFT_Complex *tw = plan->twiddles;
    for (int I = 0; I < m; I++)
    {
        abc[0] = x[I];
        C_MUL(abc[1], x[I+m], tw[r]);   
        C_ADD(x[I], abc[0], abc[1]);   
        C_SUB(x[I+m], abc[0], abc[1]);        
        r += f;
    }
}

void YIFFT_bfly3_DIT(
    const YIFFT_Plan plan, YIFFT_Complex *x, const uint32_t f, const uint8_t m)
{
    YIFFT_Complex abc[3] = {0};
    YIFFT_Complex tmp = {0,0};
    YIFFT_Complex *tw = plan->twiddles;
    YIFFT_Complex bfly3_tw = tw[m*f];
    int r = 0;
    for (int I = 0; I < m; I++)
    {
        abc[0] = x[I];
        C_MUL(abc[1], x[I+m], tw[r]);
        C_MUL(abc[2], x[I+2*m], tw[2*r]);
        C_ADD(x[I], abc[0], abc[1]);
        C_ADD(x[I], x[I], abc[2]);        
        C_MUL(tmp, abc[1], bfly3_tw);
        C_ADD(x[I+m], abc[0], tmp);
        C_MUL_CONJ(tmp, abc[2], bfly3_tw);
        C_ADD(x[I+m], x[I+m], tmp);
        C_MUL_CONJ(tmp, abc[1], bfly3_tw);
        C_ADD(x[I+2*m], abc[0], tmp);
        C_MUL(tmp, abc[2], bfly3_tw);
        C_ADD(x[I+2*m], x[I+2*m], tmp);
        r += f;
    }    
}

void YIFFT_bfly4_DIT(
    const YIFFT_Plan plan, YIFFT_Complex *x, const uint32_t f, const uint8_t m)
{
    YIFFT_Complex abc[4] = {0};
    YIFFT_Complex *tw = plan->twiddles;
    int r = 0;
    for (int I = 0; I < m; I++)
    {
        abc[0] = x[I];
        C_MUL(abc[1], x[I+m], tw[r]);
        C_MUL(abc[2], x[I+2*m], tw[2*r]);
        C_MUL(abc[3], x[I+3*m], tw[3*r]);
        C_ADD(x[I], abc[0], abc[1]);
        C_ADD(x[I], x[I], abc[2]);     
        C_ADD(x[I], x[I], abc[3]);   
        C_SUB(x[I+2*m], abc[0], abc[1]);
        C_ADD(x[I+2*m], x[I+2*m], abc[2]);
        C_SUB(x[I+2*m], x[I+2*m], abc[3]);

        C_SUB_1J(x[I+m], abc[0], abc[1]);
        C_ADD_1J(x[I+m], x[I+m], abc[3]);
        C_ADD_1J(x[I+3*m], abc[0], abc[1]);
        C_SUB_1J(x[I+3*m], x[I+3*m], abc[3]);
        
        C_SUB(x[I+m], x[I+m], abc[2]);
        C_SUB(x[I+3*m], x[I+3*m], abc[2]);
        r += f;
    }    
}

// void YIFFT_bfly5_DIT(
//     const YIFFT_Plan plan, YIFFT_Complex *x, const uint32_t f, const uint8_t m)
// {
//     YIFFT_Complex abc[5] = {0};
//     YIFFT_Complex tmp = {0,0};
//     YIFFT_Complex bfly5_tw[2] = {0};
//     YIFFT_Complex *tw = plan->twiddles;
//     bfly5_tw[0] = tw[m*f];
//     bfly5_tw[1] = tw[2*m*f];
//     int r = 0;
//     for (int I = 0; I < m; I++)
//     {
//         abc[0] = x[I];
//         C_MUL(abc[1], x[I+m], tw[r]);
//         C_MUL(abc[2], x[I+2*m], tw[2*r]);
//         C_MUL(abc[3], x[I+3*m], tw[3*r]);
//         C_MUL(abc[4], x[I+4*m], tw[4*r]);

//         C_ADD(x[I], abc[0], abc[1]);
//         C_ADD(x[I], x[I], abc[2]);
//         C_ADD(x[I], x[I], abc[3]);
//         C_ADD(x[I], x[I], abc[4]);

//         C_MUL(tmp, abc[1], bfly5_tw[0]);
//         C_ADD(x[I+m], abc[0], tmp);
//         C_MUL(tmp, abc[2], bfly5_tw[1]);
//         C_ADD(x[I+m], x[I+m], tmp);
//         C_MUL_CONJ(tmp, abc[3], bfly5_tw[1]);
//         C_ADD(x[I+m], x[I+m], tmp);
//         C_MUL_CONJ(tmp, abc[4], bfly5_tw[0]);
//         C_ADD(x[I+m], x[I+m], tmp);

//         C_MUL(tmp, abc[1], bfly5_tw[1]);
//         C_ADD(x[I+2*m], abc[0], tmp);
//         C_MUL_CONJ(tmp, abc[2], bfly5_tw[0]);
//         C_ADD(x[I+2*m], x[I+2*m], tmp);
//         C_MUL(tmp, abc[3], bfly5_tw[0]);
//         C_ADD(x[I+2*m], x[I+2*m], tmp);
//         C_MUL_CONJ(tmp, abc[4], bfly5_tw[1]);
//         C_ADD(x[I+2*m], x[I+2*m], tmp);

//         C_MUL_CONJ(tmp, abc[1], bfly5_tw[1]);
//         C_ADD(x[I+3*m], abc[0], tmp);
//         C_MUL(tmp, abc[2], bfly5_tw[0]);
//         C_ADD(x[I+3*m], x[I+3*m], tmp);
//         C_MUL_CONJ(tmp, abc[3], bfly5_tw[0]);
//         C_ADD(x[I+3*m], x[I+3*m], tmp);
//         C_MUL(tmp, abc[4], bfly5_tw[1]);
//         C_ADD(x[I+3*m], x[I+3*m], tmp);

//         C_MUL_CONJ(tmp, abc[1], bfly5_tw[0]);
//         C_ADD(x[I+4*m], abc[0], tmp);
//         C_MUL_CONJ(tmp, abc[2], bfly5_tw[1]);
//         C_ADD(x[I+4*m], x[I+4*m], tmp);
//         C_MUL(tmp, abc[3], bfly5_tw[1]);
//         C_ADD(x[I+4*m], x[I+4*m], tmp);
//         C_MUL(tmp, abc[4], bfly5_tw[0]);
//         C_ADD(x[I+4*m], x[I+4*m], tmp);

//         r += f;
//     }
// }

// void YIFFT_bfly7_DIT(
//     const YIFFT_Plan plan, YIFFT_Complex *x, const uint32_t f, const uint8_t m)
// {
//     YIFFT_Complex abc[7] = {0};
//     YIFFT_Complex tmp = {0,0};
//     YIFFT_Complex bfly5_tw[3] = {0};
//     YIFFT_Complex *tw = plan->twiddles;
//     bfly5_tw[0] = tw[m*f];
//     bfly5_tw[1] = tw[2*m*f];
//     bfly5_tw[2] = tw[3*m*f];
//     int r = 0;
//     for (int I = 0; I < m; I++)
//     {
//         abc[0] = x[I];
//         C_MUL(abc[1], x[I+m], tw[r]);
//         C_MUL(abc[2], x[I+2*m], tw[2*r]);
//         C_MUL(abc[3], x[I+3*m], tw[3*r]);
//         C_MUL(abc[4], x[I+4*m], tw[4*r]);
//         C_MUL(abc[5], x[I+5*m], tw[5*r]);
//         C_MUL(abc[6], x[I+6*m], tw[6*r]);

//         C_ADD(x[I], abc[0], abc[1]);
//         C_ADD(x[I], x[I], abc[2]);
//         C_ADD(x[I], x[I], abc[3]);
//         C_ADD(x[I], x[I], abc[4]);
//         C_ADD(x[I], x[I], abc[5]);
//         C_ADD(x[I], x[I], abc[6]);

//         C_MUL(tmp, abc[1], bfly5_tw[0]);
//         C_ADD(x[I+m], abc[0], tmp);
//         C_MUL(tmp, abc[2], bfly5_tw[1]);
//         C_ADD(x[I+m], x[I+m], tmp);
//         C_MUL(tmp, abc[3], bfly5_tw[2]);
//         C_ADD(x[I+m], x[I+m], tmp);
//         C_MUL_CONJ(tmp, abc[4], bfly5_tw[2]);
//         C_ADD(x[I+m], x[I+m], tmp);
//         C_MUL_CONJ(tmp, abc[5], bfly5_tw[1]);
//         C_ADD(x[I+m], x[I+m], tmp);
//         C_MUL_CONJ(tmp, abc[6], bfly5_tw[0]);
//         C_ADD(x[I+m], x[I+m], tmp);

//         C_MUL(tmp, abc[1], bfly5_tw[1]);
//         C_ADD(x[I+2*m], abc[0], tmp);
//         C_MUL_CONJ(tmp, abc[2], bfly5_tw[2]);
//         C_ADD(x[I+2*m], x[I+2*m], tmp);
//         C_MUL_CONJ(tmp, abc[3], bfly5_tw[0]);
//         C_ADD(x[I+2*m], x[I+2*m], tmp);
//         C_MUL(tmp, abc[4], bfly5_tw[0]);
//         C_ADD(x[I+2*m], x[I+2*m], tmp);
//         C_MUL(tmp, abc[5], bfly5_tw[2]);
//         C_ADD(x[I+2*m], x[I+2*m], tmp);
//         C_MUL_CONJ(tmp, abc[6], bfly5_tw[1]);
//         C_ADD(x[I+2*m], x[I+2*m], tmp);

//         C_MUL(tmp, abc[1], bfly5_tw[2]);
//         C_ADD(x[I+3*m], abc[0], tmp);
//         C_MUL_CONJ(tmp, abc[2], bfly5_tw[0]);
//         C_ADD(x[I+3*m], x[I+3*m], tmp);
//         C_MUL(tmp, abc[3], bfly5_tw[1]);
//         C_ADD(x[I+3*m], x[I+3*m], tmp);
//         C_MUL_CONJ(tmp, abc[4], bfly5_tw[1]);
//         C_ADD(x[I+3*m], x[I+3*m], tmp);
//         C_MUL(tmp, abc[5], bfly5_tw[0]);
//         C_ADD(x[I+3*m], x[I+3*m], tmp);
//         C_MUL_CONJ(tmp, abc[6], bfly5_tw[2]);
//         C_ADD(x[I+3*m], x[I+3*m], tmp);

//         C_MUL_CONJ(tmp, abc[1], bfly5_tw[2]);
//         C_ADD(x[I+4*m], abc[0], tmp);
//         C_MUL(tmp, abc[2], bfly5_tw[0]);
//         C_ADD(x[I+4*m], x[I+4*m], tmp);
//         C_MUL_CONJ(tmp, abc[3], bfly5_tw[1]);
//         C_ADD(x[I+4*m], x[I+4*m], tmp);
//         C_MUL(tmp, abc[4], bfly5_tw[1]);
//         C_ADD(x[I+4*m], x[I+4*m], tmp);
//         C_MUL_CONJ(tmp, abc[5], bfly5_tw[0]);
//         C_ADD(x[I+4*m], x[I+4*m], tmp);
//         C_MUL(tmp, abc[6], bfly5_tw[2]);
//         C_ADD(x[I+4*m], x[I+4*m], tmp);

//         C_MUL_CONJ(tmp, abc[1], bfly5_tw[1]);
//         C_ADD(x[I+5*m], abc[0], tmp);
//         C_MUL(tmp, abc[2], bfly5_tw[2]);
//         C_ADD(x[I+5*m], x[I+5*m], tmp);
//         C_MUL(tmp, abc[3], bfly5_tw[0]);
//         C_ADD(x[I+5*m], x[I+5*m], tmp);
//         C_MUL_CONJ(tmp, abc[4], bfly5_tw[0]);
//         C_ADD(x[I+5*m], x[I+5*m], tmp);
//         C_MUL_CONJ(tmp, abc[5], bfly5_tw[2]);
//         C_ADD(x[I+5*m], x[I+5*m], tmp);
//         C_MUL(tmp, abc[6], bfly5_tw[1]);
//         C_ADD(x[I+5*m], x[I+5*m], tmp);

//         C_MUL_CONJ(tmp, abc[1], bfly5_tw[0]);
//         C_ADD(x[I+6*m], abc[0], tmp);
//         C_MUL_CONJ(tmp, abc[2], bfly5_tw[1]);
//         C_ADD(x[I+6*m], x[I+6*m], tmp);
//         C_MUL_CONJ(tmp, abc[3], bfly5_tw[2]);
//         C_ADD(x[I+6*m], x[I+6*m], tmp);
//         C_MUL(tmp, abc[4], bfly5_tw[2]);
//         C_ADD(x[I+6*m], x[I+6*m], tmp);
//         C_MUL(tmp, abc[5], bfly5_tw[1]);
//         C_ADD(x[I+6*m], x[I+6*m], tmp);
//         C_MUL(tmp, abc[6], bfly5_tw[0]);
//         C_ADD(x[I+6*m], x[I+6*m], tmp);

//         r += f;
//     }
// }

/** @note although larger P usually means faster (as long as bflyP fits in cache),
 *      but the code size also grows with P^2, so one should make a balance 
 *      between explicit butterfly radix P and code size. */
// void YIFFT_bflyP_DIT(
//     const YIFFT_Plan plan, YIFFT_Complex *x, const uint32_t f, const uint8_t m, const uint8_t p)
// {
//     /* if user need fully static memory allocation, one can discard this generic
//         butterfly, and add bflyP for P other than 2/3/4/5/7 if needed */
//     YIFFT_Complex *abc = malloc(sizeof(YIFFT_Complex)*p);
//     YIFFT_Complex *tw = plan->twiddles;
//     for (int I = 0; I < m; I++)
//     {
//         for (int i = 0; i < p; i++)
//             abc[i] = x[I+m*i];

//         for (int i = 0; i < p; i++)
//         {
//             C_ASSIGN(x[I+m*i], 0, 0);
//             for (int j = 0; j < p; j++)
//             {
//                 int idx = ((i*m + I)*j*f) % plan->NFFT;
//                 C_IADD_MUL(x[I+m*i], abc[j], tw[idx]);
//             }
//         }
//     }
//     free(abc);
// }

/* algorithm is Temperton's paper is mainly about DIF. Here we use DIT version 
    to be compatiable with DIT we used for YIFFT */
// void YIFFT_bflyP_TEM(
//     const YIFFT_Plan plan, YIFFT_Complex *x, const uint32_t f, const uint8_t m, const uint8_t p)
// {
//     /* if user need fully static memory allocation, one can discard this generic
//         butterfly, and add bflyP for P other than 2/3/4/5/7 if needed. Or just 
//         remove inplace algorithm since code size will grow very faster for larger P */
//     YIFFT_Complex *abc = malloc(sizeof(YIFFT_Complex)*p*p);
//     YIFFT_Complex *tw = plan->twiddles;
//     uint32_t T = 0;
//     uint32_t idx = 0;
//     uint32_t Ncouple = m / f / p;
//     for (int ib = 0; ib < Ncouple; ib++)
//     {
//         for (int I = 0; I < f; I++)
//         {
//             T = I + ib*p*f;
//             for (int i = 0; i < p; i++)
//             {
//                 for (int j = 0; j < p; j++)
//                     abc[i*p + j] = x[T + i*f + j*m];
//             }

//             for (int i = 0; i < p; i++)
//             {
//                 for (int j = 0; j < p; j++)
//                 {
//                     YIFFT_Complex tmp = {0,0};
//                     for (int k = 0; k < p; k++)
//                     {
//                         idx = ((k*f + I)*m*j) % plan->NFFT;
//                         /* TODO: abc[k*p + j] accessed with stride p, access with stride 1 may be faster */
//                         C_IADD_MUL(tmp, abc[i*p + k], tw[idx]);
//                     }
//                     x[T + j*f + i*m] = tmp;
//                 }
//             }
//         }
//     }
//     free(abc);
// }

#endif /* BUILD_CFFT */