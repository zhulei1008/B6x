/**
 * Copyright (z) 2006-2021, YICHIP Development Team
 * @file      yifft_kernel.h
 * @brief     internal marco and memory layout header
 * 
 * Change Logs:
 * Date         Author      Version     Notes
 * 2021-10-29   Ge Jiahao   0.1         init
 * 2021-12-28   Ge Jiahao   1.0         first release
 */

#ifndef __YIFFT_KERNEL_H__
#define __YIFFT_KERNEL_H__

#include "../include/yifft_config.h"
#include "../include/yifft.h"
#include "../../libyichip/include/Q_refactor.h"


#ifndef CUSTOM_MALLOC
// # include <stdlib.h>
// # define YIFFT_MALLOC(size) malloc(size)
#define YIFFT_MALLOC(size) ((void *)(0))
#else
# include <stdlib.h>
# include <stdio.h>
__attribute__ ((unused)) static void* MyMalloc(size_t size) 
{
    void *ptr = malloc(size);
    if (ptr)
        printf("    MALLOC: [%p  < %lld bytes >  %p]\n", ptr, size, (uint8_t*)ptr+size);
    else
        printf("    MALLOC: fails! \n");
    return ptr;
}
# define YIFFT_MALLOC(size) MyMalloc(size)
#endif

#define YIFFT_ASSERT(condition, err_code) if(!(condition)) { return err_code; }
#define VOID

#ifdef BUILD_CFFT
struct YIFFT_Memory
{
    int32_t NFFT;
    uint32_t plan[2*MAX_FACTORS];
    YIFFT_Complex twiddles[1];
};
#else  /* BUILD_CFFT */
struct YIFFT_Memory
{
    /* custom complex FFT plan */
    uint32_t NFFT;
    bool inverse;
};
#endif /* BUILD_CFFT */

#ifdef BUILD_RFFT
struct YIRFFT_Memory
{
    int32_t N;
    YIFFT_Plan cpx_plan;
    YIFFT_Complex *real_twiddles;
};
#elif defined(BUILD_DCT)  /* BUILD_RFFT */
struct YIRFFT_Memory
{
    uint32_t N;
    bool inverse;
};
#endif /* BUILD_RFFT */

#ifdef BUILD_DCT
struct YIDCT_Memory
{
    uint32_t N;
    bool ext_mem;
    YIDCT_Type type;
    YIRFFT_Plan real_plan;
    uint8_t* tmp_buf;
    YIFFT_Complex dct_twiddles[1];
};
#endif /* BUILD_DCT */

/* Arithmetic Operation */

#ifdef FFT_FIXED_POINT
    #define YI_t                  Q_t
    #define YI(x,q)               Q(x,q)
    #define YI_from_int(x,q)      Q_from_int(x,q)
    #define YI_from_float(x,q)    Q_from_float(x,q)
    #define YI_to_int(x,q)        Q_to_int(x,q)
    #define YI_to_float(x,q)      Q_to_float(x,q)
    #define YI_add(x,y)           Q_add(x,y)
    #define YI_sub(x,y)           Q_sub(x,y)
    #define YI_mul(x,y,q)         Q_mul(x,y,q)
    #define YI_div(x,y,q)         Q_div(x,y,q)
    #define YI_cos(x,q)           Q_cos(x,q)
    #define YI_sin(x,q)           Q_sin(x,q)
    #define YI_ONE(q)             Q_ONE(q)
    #define YI_HALF(q)            Q_HALF(q)
    #define YI_PI(q)              Q_PI(q)
#else
    #include <math.h>
    #define YI_t                  float
    #define YI(x,q)               ((float)(x))
    #define YI_from_int(x,q)      ((float)(x))
    #define YI_from_float(x,q)    ((float)(x))
    #define YI_to_int(x,q)        ((int32_t)(x))
    #define YI_to_float(x,q)      ((float)(x))
    #define YI_add(x,y)           ((x) + (y))
    #define YI_sub(x,y)           ((x) - (y))
    #define YI_mul(x,y,q)         ((x) * (y))
    #define YI_div(x,y,q)         ((x) / (y))
    #define YI_cos(x,q)           ((float)cosf(x))
    #define YI_sin(x,q)           ((float)sinf(x))
    #define YI_ONE(q)             (1.0f)
    #define YI_HALF(q)            (0.5f)
    #define YI_PI(q)              (3.14159265358979323846f)
#endif


/* Notation: x/y/z are complex, a/b/c are real */

/* a % 2 == 0 */
#define IS_ODD(a)  (((a) & 0x1))
#define IS_EVEN(a) (!IS_ODD(a))

/* x = a + 1j*b */
#define C_ASSIGN(x, a, b) \
    do {(x).r = (a); (x).i = (b); }while(0)

/* x = exp(1j*a) */
#define C_EXP(x,a,q) C_ASSIGN(x, YI_cos(a,q), YI_sin(a,q))

/* x = *y (conjugate) */
#define C_CONJUGATE(x, y) \
    do {(x).r = (y).r; (x).i = -(y).i; }while(0)

/* x = y + z */
#define C_ADD(x, y, z) \
    do {(x).r = YI_add((y).r, (z).r); (x).i = YI_add((y).i, (z).i); }while(0) 

/* x = y + *z */
#define C_ADD_CONJ(x, y, z) \
    do {(x).r = YI_add((y).r, (z).r); (x).i = YI_sub((y).i, (z).i); }while(0)

/* x = y + 1j*z */
#define C_ADD_1J(x, y, z) \
    do {(x).r = YI_sub((y).r, (z).i); (x).i = YI_add((y).i, (z).r); }while(0) 

/* x = y - z */
#define C_SUB(x, y, z) \
    do {(x).r = YI_sub((y).r, (z).r); (x).i = YI_sub((y).i, (z).i); }while(0)

/* x = y - *z */
#define C_SUB_CONJ(x, y, z) \
    do {(x).r = YI_sub((y).r, (z).r); (x).i = YI_add((y).i, (z).i); }while(0)

/* x = y - 1j*z */
#define C_SUB_1J(x, y, z) \
    do {(x).r = YI_add((y).r, (z).i); (x).i = YI_sub((y).i, (z).r); }while(0)

/* x = y * tw_Q31 */ 
#define C_MUL(x,y,tw_Q31) \
    do { (x).r = YI_sub(YI_mul((y).r, (tw_Q31).r, 31), YI_mul((y).i, (tw_Q31).i, 31)); \
         (x).i = YI_add(YI_mul((y).r, (tw_Q31).i, 31), YI_mul((y).i, (tw_Q31).r, 31)); }while(0)

/* x = y * *tw_Q31 */ 
#define C_MUL_CONJ(x,y,tw_Q31) \
    do { (x).r = YI_sub(YI_mul((y).r,  (tw_Q31).r, 31), YI_mul((y).i, -(tw_Q31).i, 31)); \
         (x).i = YI_add(YI_mul((y).r, -(tw_Q31).i, 31), YI_mul((y).i,  (tw_Q31).r, 31)); }while(0)         

/* x = y * 1j*tw_Q31 */
#define C_MUL_1J(x,y,tw_Q31) \
    do { (x).r = -YI_add(YI_mul((y).r, (tw_Q31).i, 31), YI_mul((y).i, (tw_Q31).r, 31)); \
         (x).i =  YI_sub(YI_mul((y).r, (tw_Q31).r, 31), YI_mul((y).i, (tw_Q31).i, 31)); }while(0)

/* NO C_DIV, because we should avoid divide as much as possible */         

/* x += y * tw_Q31 */
#define C_IADD_MUL(x,y,tw_Q31) \
    do { (x).r = YI_add((x).r, YI_sub(YI_mul((y).r, (tw_Q31).r, 31), YI_mul((y).i, (tw_Q31).i, 31))); \
         (x).i = YI_add((x).i, YI_add(YI_mul((y).r, (tw_Q31).i, 31), YI_mul((y).i, (tw_Q31).r, 31))); }while(0)

#endif /* __YIFFT_KERNEL_H__ */