
#include "board_config.h"
#include "yc11xx_audio_dac.h"
#include "yc11xx_audio_adc.h"
void TEST_AudioDAC(uint8_t* addr,uint16_t buffSize,DAC_ClkDev clock,DAC_DateModeDev dataBit,DAC_SoundTrackDev sound);
void Audio_AdcPdmGpioInit();
