#!/usr/bin/perl

$inputfile_addr = $ARGV[0];
print "\input:  $inputfile_addr\n";
$outputfile_addr =$ARGV[1];
print "\output:  $outputfile_addr\n";

open(DATA,$inputfile_addr);

#删除目标文件
unlink($outputfile_addr);
#创建目标文件
$outputfile_addr = '+>'.$outputfile_addr;
open(DATA1,$outputfile_addr) or die "des file open fail,$!";

@ct = <DATA>;$len = $#ct + 1;
print DATA1 sprintf("03\n00\n00\naa\n55\n%02x\n%02x\n%02x\n", $len & 0xff, $len >> 8 & 0xff, $len >> 16 & 0xff);
print DATA1 @ct;
