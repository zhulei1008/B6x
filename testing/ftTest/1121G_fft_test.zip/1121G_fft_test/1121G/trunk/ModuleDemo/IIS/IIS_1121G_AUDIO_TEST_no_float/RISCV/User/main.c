#include "test.h"
#include "btreg.h"
short testBuff[576]={};
uint8_t voiceSample48k16bitStereoDataF4DBFS[192] = {
		 0X62,0X28,0X62,0X28,0Xe9,0X1e,0Xe9
		,0X1e,0Xe7,0X14,0Xe7,0X14,0X8b,0X0a
		,0X8b,0X0a,0X00,0X00,0X00,0X00,0X75
		,0Xf5,0X75,0Xf5,0X19,0Xeb,0X19,0Xeb
		,0X17,0Xe1,0X17,0Xe1,0X9e,0Xd7,0X9e
		,0Xd7,0Xd5,0Xce,0Xd5,0Xce,0Xe3,0Xc6
		,0Xe3,0Xc6,0Xec,0Xbf,0Xec,0Xbf,0X0e
		,0Xba,0X0e,0Xba,0X61,0Xb5,0X61,0Xb5
		,0Xfc,0Xb1,0Xfc,0Xb1,0Xec,0Xaf,0Xec
		,0Xaf,0X3b,0Xaf,0X3b,0Xaf,0Xec,0Xaf
		,0Xec,0Xaf,0Xfc,0Xb1,0Xfc,0Xb1,0X61
		,0Xb5,0X61,0Xb5,0X0e,0Xba,0X0e,0Xba
		,0Xec,0Xbf,0Xec,0Xbf,0Xe3,0Xc6,0Xe3
		,0Xc6,0Xd5,0Xce,0Xd5,0Xce,0X9e,0Xd7
		,0X9e,0Xd7,0X17,0Xe1,0X17,0Xe1,0X19
		,0Xeb,0X19,0Xeb,0X75,0Xf5,0X75,0Xf5
		,0X00,0X00,0X00,0X00,0X8b,0X0a,0X8b
		,0X0a,0Xe7,0X14,0Xe7,0X14,0Xe9,0X1e
		,0Xe9,0X1e,0X62,0X28,0X62,0X28,0X2b
		,0X31,0X2b,0X31,0X1d,0X39,0X1d,0X39
		,0X14,0X40,0X14,0X40,0Xf2,0X45,0Xf2
		,0X45,0X9f,0X4a,0X9f,0X4a,0X04,0X4e
		,0X04,0X4e,0X14,0X50,0X14,0X50,0Xc5
		,0X50,0Xc5,0X50,0X14,0X50,0X14,0X50
		,0X04,0X4e,0X04,0X4e,0X9f,0X4a,0X9f
		,0X4a,0Xf2,0X45,0Xf2,0X45,0X14,0X40
		,0X14,0X40,0X1d,0X39,0X1d,0X39,0X2b
		,0X31,0X2b,0X31};
int cnt;
#if 1
#include "libyifft/include/yifft.h"
#include "libyifft/src/yifft_kernel.h"
#include "libyichip/include/Q_refactor.h"
#define Q_FBITS 16

// #include <stdio.h> /* for testing */
// #include <math.h> /* for testing */
#define NULL ((void *)0)
#define NFFT 576

#include "win.h"
#define ADC_NBITS 16 /* width of ADC */
#define N_HARMONIC 20 /* number of harmonic to be considered */

//int16_t testbuf[576] = {
//            0,    565,   3580,   6535,   9379,  12061,  14540,  16769,
//        18710,  20331,  21605,  22511,  23030,  23155,  22885,  22225,
//        21185,  19780,  18039,  15989,  13665,  11108,   8361,   5470,
//         2488,   -537,  -3552,  -6507,  -9351, -12033, -14511, -16740,
//       -18682, -20302, -21578, -22480, -23001, -23126, -22857, -22195,
//       -21155, -19749, -18010, -15962, -13637, -11078,  -8333,  -5442,
//        -2459,    565,   3581,   6535,   9379,  12062,  14540,  16768,
//        18712,  20332,  21605,  22510,  23030,  23155,  22885,  22224,
//        21183,  19781,  18039,  15989,  13663,  11107,   8361,   5470,
//         2488,   -537,  -3552,  -6507,  -9350, -12034, -14512, -16741,
//       -18681, -20304, -21579, -22481, -23001, -23127, -22857, -22195,
//       -21154, -19750, -18011, -15962, -13637, -11079,  -8333,  -5441,
//        -2460,    564,   3581,   6536,   9378,  12061,  14541,  16770,
//        18711,  20332,  21608,  22509,  23029,  23157,  22885,  22225,
//        21184,  19782,  18040,  15990,  13665,  11108,   8361,   5471,
//         2488,   -537,  -3553,  -6507,  -9351, -12034, -14512, -16740,
//       -18682, -20303, -21577, -22481, -22999, -23127, -22857, -22195,
//       -21154, -19751, -18011, -15960, -13636, -11079,  -8333,  -5441,
//        -2460,    566,   3582,   6536,   9378,  12062,  14541,  16769,
//        18711,  20333,  21607,  22510,  23030,  23156,  22886,  22225,
//        21185,  19781,  18039,  15990,  13663,  11106,   8361,   5470,
//         2487,   -538,  -3553,  -6507,  -9352, -12034, -14512, -16741,
//       -18682, -20302, -21578, -22481, -23001, -23127, -22856, -22196,
//       -21156, -19752, -18011, -15963, -13637, -11080,  -8334,  -5443,
//        -2461,    565,   3580,   6536,   9380,  12062,  14541,  16770,
//        18710,  20332,  21606,  22510,  23030,  23155,  22886,  22224,
//        21185,  19782,  18040,  15991,  13664,  11107,   8361,   5469,
//         2488,   -538,  -3552,  -6508,  -9351, -12036, -14513, -16741,
//       -18682, -20305, -21578, -22482, -23002, -23127, -22857, -22196,
//       -21157, -19752, -18010, -15961, -13637, -11079,  -8332,  -5442,
//        -2461,    566,   3581,   6536,   9379,  12061,  14541,  16769,
//        18712,  20333,  21608,  22510,  23030,  23157,  22885,  22227,
//        21184,  19782,  18040,  15990,  13664,  11109,   8361,   5470,
//         2487,   -538,  -3552,  -6507,  -9351, -12034, -14512, -16741,
//       -18682, -20306, -21579, -22482, -23001, -23128, -22857, -22197,
//       -21156, -19752, -18012, -15962, -13638, -11079,  -8333,  -5442,
//        -2459,    566,   3581,   6536,   9379,  12062,  14541,  16770,
//        18712,  20332,  21607,  22511,  23030,  23156,  22886,  22225,
//        21184,  19781,  18041,  15990,  13664,  11107,   8361,   5470,
//         2488,   -536,  -3551,  -6507,  -9352, -12034, -14513, -16742,
//       -18682, -20303, -21579, -22483, -23003, -23129, -22859, -22197,
//       -21156, -19753, -18011, -15961, -13636, -11079,  -8332,  -5441,
//        -2459,    565,   3580,   6534,   9379,  12062,  14540,  16769,
//        18711,  20332,  21606,  22511,  23031,  23156,  22885,  22225,
//        21184,  19780,  18040,  15990,  13664,  11107,   8361,   5470,
//         2489,   -537,  -3552,  -6506,  -9352, -12034, -14513, -16741,
//       -18683, -20304, -21579, -22483, -23002, -23128, -22857, -22196,
//       -21154, -19750, -18010, -15961, -13637, -11079,  -8333,  -5442,
//        -2461,    565,   3581,   6535,   9380,  12061,  14540,  16770,
//        18710,  20331,  21606,  22508,  23031,  23155,  22885,  22224,
//        21183,  19780,  18039,  15990,  13663,  11107,   8361,   5469,
//         2487,   -538,  -3553,  -6507,  -9351, -12033, -14512, -16742,
//       -18682, -20303, -21579, -22481, -23002, -23127, -22858, -22198,
//       -21156, -19752, -18012, -15962, -13638, -11080,  -8333,  -5442,
//        -2460,    566,   3580,   6534,   9380,  12062,  14540,  16769,
//        18711,  20332,  21607,  22510,  23029,  23157,  22885,  22227,
//        21185,  19783,  18039,  15989,  13665,  11107,   8360,   5471,
//         2489,   -538,  -3552,  -6506,  -9350, -12033, -14512, -16741,
//       -18682, -20303, -21579, -22482, -23000, -23128, -22857, -22196,
//       -21156, -19752, -18010, -15961, -13636, -11079,  -8333,  -5442,
//        -2459,    565,   3580,   6534,   9378,  12061,  14541,  16770,
//        18709,  20333,  21606,  22509,  23031,  23156,  22885,  22226,
//        21184,  19781,  18040,  15990,  13665,  11106,   8360,   5469,
//         2488,   -538,  -3553,  -6507,  -9351, -12033, -14513, -16742,
//       -18682, -20304, -21579, -22481, -23001, -23127, -22858, -22196,
//       -21157, -19752, -18010, -15961, -13635, -11078,  -8333,  -5442,
//        -2460,    565,   3579,   6537,   9379,  12061,  14541,  16768,
//        18710,  20331,  21606,  22509,  23029,  23155,  22886,  22225,
//        21183,  19780,  18040,  15988,  13664,  11107,   8360,   5470,
//         2489,   -537,  -3552,  -6507,  -9350, -12035, -14511, -16740,
//       -18682, -20302, -21577, -22481, -23000, -23126, -22856, -22195,
//       -21154, -19749, -18011, -15961, -13638, -11079,  -8332,  -5442
//};

typedef struct ADC_perf
{
    Q_t SNR;    /* SNR = 10/20 * log10(signal/noise) */
    Q_t SNR_t;  /* theoretical SNR of N bits ADC */
    Q_t SINAD;  /* SIAND = 10/20 * log10(signal/(noise+harmonic))*/
    Q_t SFDR;   /* SFDR = 10/20 * log10(signal/max peak other than signal) */
    Q_t NF;     /* NoiseFloor = 10*20 * log10(average noise) */
    Q_t ENOB;   /* effective-number-of-bits ENOB = (SINAD-1.76+20*log10(Fullscale/Input))/6.02 */
    Q_t THD;    /* THD = 10/20 * log10(harmonic/signal) */
    Q_t THDN;   /* THDN = 10/20 * log10((noise+harmonic)/signal), THDN is defined upon certain bandwidth, for full bandwidth, THDN = -SINAD */
} ADC_perf;

void ADC_READ(Q_t *raw, int nfft)
{
    //int16_t *adc_buf = testbuf;
    int16_t *adc_buf = testBuff;

    // int16_t adc_buf[576];
    // FILE *f = fopen("20220114_145702.wav","rb");
    // fseek(f, 44, SEEK_SET);
    // fread(adc_buf, sizeof(int16_t), NFFT, f);
    // fclose(f);

    for (int i = 0; i < nfft; i++)
        raw[i] = (Q_t)adc_buf[i];
}

int32_t max_s32(int32_t *x, int32_t N)
{
    int32_t x_max = 0;
    for (int i = 0; i < N; i++)
    {   /* avoid -INT32_MIN overflow */
        int32_t t = (x[i]==INT32_MIN) ? (INT32_MAX) : ((x[i] > 0) ? (x[i]) : (-x[i])) ;
        if (t > x_max)
            x_max = t;
    }
    return x_max;
}

int32_t safe_rms(int32_t *x, int32_t N, int32_t mean)
{
    int32_t x_max = max_s32(x, N);
    if (!x_max)
        return 0;
    int32_t sum_square = 0;
    for (int i = 0; i < N; i++)
    {
        /* use float div to avoid int64_t div (__divi3 */
        int32_t t = (int32_t) ((float)x[i] / x_max * (1<<Q_FBITS));
        sum_square += Q_mul(t,t, Q_FBITS);
    }
    int32_t ans = Q_mul(x_max, Q_sqrt(sum_square/mean, Q_FBITS), Q_FBITS);
    return ans;
}

ADC_perf ADC_test(
    int fs, int fc, Q_t th, YIRFFT_Plan real_plan)
{
    int32_t raw[NFFT] = {0};
    int32_t rawFFT[2*NFFT] = {0}; /* assuming FFT result is {r[0],i[0],r[1],i[1],...}*/
    YIFFT_Complex *rawCFFT = (YIFFT_Complex *)rawFFT;
    int32_t P[NFFT/2] = {0};
    int32_t harmonic[N_HARMONIC+2] = {0};
    ADC_perf ans = {0};

    /* FFT ADC reading to get power spectrum P */
    /* ADC read sine wave and write reading value to raw */
    ADC_READ(raw, NFFT);

    /* find input amplitude, use max(raw), as long as noise is small, this
        will give well approximation */
    int raw_amp = max_s32(raw, NFFT);

    /* add window function to time domain array raw,
        if ADC has added window already by itself, skip this */
    /* hanning is always < 1, so will not overflow */
    for (int n = 0; n < NFFT; n++)
        raw[n] = Q_mul(raw[n], hanning[n], Q_FBITS);

    /* do NFFT points FFT on raw, return rawFFT = FFT(raw, NFFT) */
    /* FFT must be at least 32bit or float, cause the resulotion of int16 is only -90 dB,
        means any noise/signal below -90 dBFS will be lost(become 0). if a ADC has SNR > 90 dB,
        then the noise will become all 0 and cannot continue analyze anymore,
        int32 has 186 dB range which enough for ADC test */
    YIRFFT_r2c(real_plan, raw, rawCFFT);

    /* assuming FFT result rawFFT is {r[0],i[0],r[1],i[1],...}
        raw is real, so rawFFT is hermitian symmetric, only need first half spectrum */
    for (int k = 0; k < NFFT/2; k++)
        P[k] = safe_rms(rawFFT+2*k,2,2);

    /* harmonic analyze */
    int32_t spurious = 0;
    int n_harm = 0;

    for (int n = 0; n < N_HARMONIC + 2; n++)
    {   /* 0 for DC, 1 for signal, 2+ for harmonic */
        /* get n-th order harmonic frequency projection on [0,fs/2) */
        int margin = (n==1) ? (18) : (2);
        int freq_harm = (n*fc) % fs;
        freq_harm = (freq_harm < fs/2) ? (freq_harm) : (fs - freq_harm);
        /* get harmonic index */
        int hidx = (freq_harm*NFFT/fs);
        int start = (hidx - margin > 0)      ? (hidx - margin) : (0);
        int end   = (hidx + margin < NFFT/2) ? (hidx + margin) : (NFFT/2);
        /* find peak within P[hidx ± margin] */
        int32_t max = max_s32(P+start, end-start);

        /* consider max is harmonic peak if (max > th*end_points ) */
        if ((n == 0) || \
            ((max > (int32_t)Q_mul(th,(Q_t)P[start], Q_FBITS)) && \
             (max > (int32_t)Q_mul(th,(Q_t)P[end-1], Q_FBITS))))
        {
            for (int k = start; k < end; k++)
            {
                harmonic[n] = Q_add(P[k], harmonic[n]);
                P[k] = 0;
            }
            if (n>1)
            {
                n_harm++;
                if (max > spurious)
                    { spurious = max; }
            }
        }
    }

    int32_t H = 0;
    if (n_harm > 0)
        H = safe_rms(harmonic+2, N_HARMONIC, n_harm);

    int32_t S  = harmonic[1];

    int32_t N = 0;
    int n_noise = 0;
    for (int n = 0; n < NFFT/2; n++)
    {
        if (P[n] > 0)
        {   /* this skip any peak previous calculate, only noise remain */
            n_noise++;
            if (P[n] > spurious) /* find highest peak other than main signal */
                spurious = P[n];
        }
    }
    N = safe_rms(P, NFFT/2, 1);
    N = N*2/3; /* NPB of hanning window */

    /* ADC performance calculation */
    int32_t Qlog10_S = Q_log10(S, Q_FBITS);
    int32_t Qlog10_N = Q_log10(N, Q_FBITS);
    int32_t Qlog10_spur = Q_log10(spurious, Q_FBITS);
    int32_t Qlog10_H = (H==0) ? (INT32_MIN) : (Q_log10(H, Q_FBITS));
    int32_t Qlog10_HN = Q_log10(H+N, Q_FBITS);

    ans.SNR = 20 * (Qlog10_S - Qlog10_N);
    ans.SNR_t = Q_add(Q_mul(Q(6.02f,Q_FBITS), Q_from_int(ADC_NBITS, Q_FBITS), Q_FBITS), Q(1.76f, Q_FBITS));
    ans.SINAD = 20 * (Qlog10_S - Qlog10_HN);
    ans.SFDR = 20 * (Qlog10_S - Qlog10_spur);
    ans.THD = (H==0) ? (INT32_MIN) : (20*(Qlog10_H - Qlog10_S));
    ans.THDN = 20 * (Qlog10_HN - Qlog10_S);
    ans.ENOB = Q_sub(ans.SINAD, Q(1.76f,Q_FBITS)) + 20*(Q_log10(32768, Q_FBITS)-Q_log10(raw_amp, Q_FBITS));
    ans.ENOB = Q_mul(ans.ENOB, Q(1.0f/6.02f, Q_FBITS), Q_FBITS);
    ans.NF = 20 * (Qlog10_N + 315652); // this constant is (int32_t)((1<<Q_FBITS) * log10(1<<Q_FBITS))

    /* debug */
    float snr = Q_to_float(ans.SNR, Q_FBITS);
    float snrt = Q_to_float(ans.SNR_t, Q_FBITS);
    float sinad = Q_to_float(ans.SINAD, Q_FBITS);
    float sfdr = Q_to_float(ans.SFDR, Q_FBITS);
    float nf = Q_to_float(ans.NF, Q_FBITS);
    float enob = Q_to_float(ans.ENOB, Q_FBITS);
    float thd = Q_to_float(ans.THD, Q_FBITS);
    float thdn = Q_to_float(ans.THDN, Q_FBITS);

    return ans;
}
#endif

int main(void)
{
//	 do
//	 {
//
//	 }while(HREAD(0x4ff4 != 0xff));

	for (int a= 0; a<192;a++)
	{
		HWRITE(0x4e00+a, voiceSample48k16bitStereoDataF4DBFS[a]);
	}
    int reloadvalue =0- 1;
    *INITCPU_SYST_CSR &= ~ (((uint32_t)1) << INITCPU_SYST_CSR_ENABLE);
    *INITCPU_SYST_CVR = reloadvalue; //clear the current value
    *INITCPU_SYST_CSR |= \
                         ((INITCPU_SYSTICK_SYSCLOCK << INITCPU_SYST_CSR_CLKSOURCE) | \
                          (1 << INITCPU_SYST_CSR_ENABLE) | (1 << INITCPU_SYST_CSR_TICKINT));
	Audio_ClkInit();  //Open audio clock
	HWRITE(0x8042,0x05);
	HWRITE(0X4ffd,(int)0xff);
	printport_init();

	int i = 10000;
	//TEST_AudioDAC((uint8_t*)voiceSample48k16bitStereoDataF4DBFS,sizeof(voiceSample48k16bitStereoDataF4DBFS),DAC_Clk48k,DAC_Date16Bit,stereo);

	HWRITE(0x8050,0x01);
    //?//AUDIO_DacAnaDiffConfig(DAC_AnaStereo,DAC_VmidNoCapacitance);


    HWRITE(0x8107,0xc0);
    HWRITE(0x811e,0x54);

	AUDIO_DacCoefConfig();
    HWRITEW(0x8100,(0x4e00));
 //   HWRITEW(0x8100,(uint8_t*)voiceSample48k16bitStereoDataF4DBFS);
 //   HWRITEW(0x8104, (uint8_t*)voiceSample48k16bitStereoDataF4DBFS);
    HWRITEW(0x8102, sizeof(voiceSample48k16bitStereoDataF4DBFS) - 1);
	HWRITE(0x817d,0x08);
	HWRITE(0x8047,0x00);
	HWRITE(0x8106,0x35);
	//HWRITE(0x8107,0x40);
	HWRITE(0x8108,0xe9);
	HWRITE(0x815b,0x01);
	HWRITE(0x815c,0x00);
	HWRITE(0x815d,0x10);
	HWRITE(0x815e,0x01);
	HWRITE(0x815f,0x00);
	HWRITE(0x8160,0x10);
	//HWRITE(0x811e,0x54);
	HWRITE(0x811f,0x04);


	HWRITE(0x8b00,0x3e);
	HWRITE(0x8b01,0x51);
	HWRITE(0x8b02,0x55);
	HWRITE(0x8b03,0x00);
	HWRITE(0x8b04,0x2a);
	HWRITE(0x8b05,0x36);
	HWRITE(0x8b06,0x08);
	HWRITE(0x8b07,0x68);
	HWRITE(0x8b08,0x05);
	HWRITE(0x8b09,0x84);
	HWRITE(0x8b0a,0x04);
	HWRITE(0x8b0b,0xe0);
	HWRITE(0x8b0c,0x07);
	HWRITE(0x8b0d,0x55);
	HWRITE(0x8b0e,0xa1);
	HWRITE(0x8b0f,0x05);
	HWRITE(0x8b10,0x04);
	HWRITE(0x8b11,0x05);
	HWRITE(0x8b12,0x4e);
	HWRITE(0x8b13,0x40);
	HWRITE(0x8b14,0x04);
	HWRITE(0x8b15,0xf3);
	HWRITE(0x8b16,0xf3);
	HWRITE(0x8b17,0x05);
	HWRITE(0x8b18,0x12);
	HWRITE(0x8b19,0x40);
	HWRITE(0x8b1a,0x48);
	HWRITE(0x8b1b,0x7f);


	while(i--);
    //Audio_AdcParamConfig((uint32_t)testBuff,sizeof(testBuff),MicIsANA,ADC_Sample48K);

	HWRITE(0x801b,0x00);
    HWRITEW(0x803c,(uint8_t*)(uint32_t)testBuff);
    HWRITEW(0x803e,(uint8_t*)(uint32_t)testBuff+sizeof(testBuff)-1);
    Audio_AdcFilterInit();

	HWRITE(0x811c,0x44);

	HWRITE(0x817f,0x02);
	HWRITE(0x8180,0x00);
	HWRITE(0x8181,0x90);

	HWRITE(0x8148,0x0c);
	HWRITE(0x8149,0x80);
	HWRITE(0x8047,0x00);
	HWRITE(0x817d,0x49);
	HWRITE(0x803a,0x80);
	HWRITE(0x80c5,0x00);
	//MyPrintf("1121G_fft_test\r\n");
	HWRITE(0x803b,0xc0);

    while(1)
    {


				cnt ++;
			 	if(cnt>506000)//ǰ�ζ������ȴ�һ��20000000//
			 	{

					//ADC_UART();
			 		#if 1
			 		  uint32_t ext_mem_len = 3172; /* this number can get from YIRFFT_alloc(NFFT, 0, NULL, &ext_mem_len) when NFFT is fixed */
			 		    // YIRFFT_alloc(NFFT, 0, NULL, &ext_mem_len);
			 		  	if(!HREAD(0X4fff))
			 		  	{
			 		  		uint32_t ext_mem_len = 592+2348; /* this number can get from YIRFFT_alloc(NFFT, 0, NULL, &ext_mem_len) when NFFT is fixed */
			 		  		    // YIRFFT_alloc(NFFT, 0, NULL, &ext_mem_len);

			 		  		    uint8_t ext_mem[592+2348];
			 		  		    YIRFFT_Plan real_plan = YIRFFT_alloc(NFFT, 0, ext_mem, &ext_mem_len);

			 		  		    ADC_perf ans = ADC_test(48000, 1000, Q(2,Q_FBITS), real_plan);

			 		  		    YIRFFT_free(&real_plan);
			////////////////////////////--------------------------------------------------------------

							float snr = Q_to_float(ans.SNR, Q_FBITS);
							float snrt = Q_to_float(ans.SNR_t, Q_FBITS);
							float sinad = Q_to_float(ans.SINAD, Q_FBITS);
							float sfdr = Q_to_float(ans.SFDR, Q_FBITS);
							float nf = Q_to_float(ans.NF, Q_FBITS);
							float enob = Q_to_float(ans.ENOB, Q_FBITS);
							float thd = Q_to_float(ans.THD, Q_FBITS);
							float thdn = Q_to_float(ans.THDN, Q_FBITS);

			////////////////////////////--------------------------------------------------------------
							MyPrintf("ans.SNR = %d.%d\r\n",(int)snr,(int)(snr*100000)%100000);
							MyPrintf("ans.SNR_t = %d.%d\r\n",(int)snrt,(int)(snrt*100000)%100000);
							MyPrintf("ans.SINAD = %d.%d\r\n",(int)sinad,(int)(sinad*100000)%100000);
							MyPrintf("ans.SFDR = %d.%d\r\n",(int)sfdr,(int)(sfdr*100000)%100000);
							MyPrintf("ans.THD = %d.%d\r\n",(int)thd,(int)(thd*100000)%100000);
							MyPrintf("ans.THDN = %d.%d\r\n",(int)thdn,(int)(thdn*100000)%100000);
							MyPrintf("ans.ENOB = %d.%d\r\n",(int)enob,(int)(enob*100000)%100000);
							MyPrintf("ans.NF = %d.%d\r\n",(int)nf,(int)(nf*100000)%100000);
							HWRITE(0X4ff0,(int)snr);
							HWRITE(0X4ff1,(int)-thd);
							if((int)snr>80&&(int)thd<-80)
							{
								HWRITE(0X4fff,1);
							}
							else
							{
								HWRITE(0X4fff,0xff);
							}
			 		  	}

			 	    	if(HREAD(0x4ffe) == 1)
			 	    	{
			 	    		uint32_t ext_mem_len = 592+2348; /* this number can get from YIRFFT_alloc(NFFT, 0, NULL, &ext_mem_len) when NFFT is fixed */
			 	    					 		  		    // YIRFFT_alloc(NFFT, 0, NULL, &ext_mem_len);
			 	    		uint8_t ext_mem[592+2348];
			 	    		YIRFFT_Plan real_plan = YIRFFT_alloc(NFFT, 0, ext_mem, &ext_mem_len);

			 	    		ADC_perf ans = ADC_test(48000, 1000, Q(2,Q_FBITS), real_plan);

			 	    		YIRFFT_free(&real_plan);
			////////////////////////////--------------------------------------------------------------
							float snr = Q_to_float(ans.SNR, Q_FBITS);
							float snrt = Q_to_float(ans.SNR_t, Q_FBITS);
							float sinad = Q_to_float(ans.SINAD, Q_FBITS);
							float sfdr = Q_to_float(ans.SFDR, Q_FBITS);
							float nf = Q_to_float(ans.NF, Q_FBITS);
							float enob = Q_to_float(ans.ENOB, Q_FBITS);
							float thd = Q_to_float(ans.THD, Q_FBITS);
							float thdn = Q_to_float(ans.THDN, Q_FBITS);

			////////////////////////////--------------------------------------------------------------
							MyPrintf("ans.SNR = %d.%d\r\n",(int)snr,(int)(snr*100000)%100000);
							MyPrintf("ans.SNR_t = %d.%d\r\n",(int)snrt,(int)(snrt*100000)%100000);
							MyPrintf("ans.SINAD = %d.%d\r\n",(int)sinad,(int)(sinad*100000)%100000);
							MyPrintf("ans.SFDR = %d.%d\r\n",(int)sfdr,(int)(sfdr*100000)%100000);
							MyPrintf("ans.THD = %d.%d\r\n",(int)thd,(int)(thd*100000)%100000);
							MyPrintf("ans.THDN = %d.%d\r\n",(int)thdn,(int)(thdn*100000)%100000);
							MyPrintf("ans.ENOB = %d.%d\r\n",(int)enob,(int)(enob*100000)%100000);
							MyPrintf("ans.NF = %d.%d\r\n",(int)nf,(int)(nf*100000)%100000);
							HWRITE(0X4ff2,(int)snr);
							HWRITE(0X4ff3,(int)-thd);
							if((int)snr>80&&(int)thd<-80)
							{
								HWRITE(0X4fff,2);
							}
							else
							{
								HWRITE(0X4fff,0xff);
							}
							while(1);
			 	    	}

//			 			{
//			 				UART_SendDataFromBuff(0,(uint8_t*)testBuff,sizeof(testBuff));
//			 			}
#endif
			    	}


    }


    return 0;
}


void ADC_UART()
{
    uint16_t adcWptr = HREADW(0x8316);
    uint16_t adcStart=HREADW(0X803C);
    uint16_t adcEnd=HREADW(0X803e);
    uint16_t adcRptr = adcWptr;
    while(1)
    {
        adcWptr = HREADW(0x8316);
        if( ((adcWptr - adcRptr)%2 == 0) && (adcWptr > adcRptr))
        {
            UART_SendDataFromBuff(0,(uint8_t*)reg_map_m0(adcRptr),adcWptr - adcRptr);
            adcRptr = adcWptr;
        }
        else if( ((adcRptr - adcWptr)%2 == 0) &&  (adcRptr > adcWptr))
        {
            UART_SendDataFromBuff(0,(uint8_t*)reg_map_m0(adcRptr),adcEnd - adcRptr + 1);
            UART_SendDataFromBuff(0,(uint8_t*)reg_map_m0(adcStart),adcWptr - adcStart);
            adcRptr = adcWptr;
        }
    }
}

