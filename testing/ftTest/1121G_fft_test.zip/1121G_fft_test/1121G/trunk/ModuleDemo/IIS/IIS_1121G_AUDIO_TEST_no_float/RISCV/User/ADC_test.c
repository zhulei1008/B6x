/**
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file      ADC_test.c
 * @brief     ADC performance test
 * 
 * Change Logs:
 * Date         Author      Version     Notes
 * 2021-12-14   Ge Jiahao   0.1         init
 */

#include "libyifft/include/yifft.h"
#include "libyifft/src/yifft_kernel.h"
#include "libyichip/include/Q_refactor.h"
#define Q_FBITS 16

// #include <stdio.h> /* for testing */
// #include <math.h> /* for testing */
#define NULL ((void *)0)
#define NFFT 576

#include "win.h"
#define ADC_NBITS 16 /* width of ADC */
#define N_HARMONIC 20 /* number of harmonic to be considered */ 

int16_t testbuf[576] = {
            0,    565,   3580,   6535,   9379,  12061,  14540,  16769,
        18710,  20331,  21605,  22511,  23030,  23155,  22885,  22225,
        21185,  19780,  18039,  15989,  13665,  11108,   8361,   5470,
         2488,   -537,  -3552,  -6507,  -9351, -12033, -14511, -16740,
       -18682, -20302, -21578, -22480, -23001, -23126, -22857, -22195,
       -21155, -19749, -18010, -15962, -13637, -11078,  -8333,  -5442,
        -2459,    565,   3581,   6535,   9379,  12062,  14540,  16768,
        18712,  20332,  21605,  22510,  23030,  23155,  22885,  22224,
        21183,  19781,  18039,  15989,  13663,  11107,   8361,   5470,
         2488,   -537,  -3552,  -6507,  -9350, -12034, -14512, -16741,
       -18681, -20304, -21579, -22481, -23001, -23127, -22857, -22195,
       -21154, -19750, -18011, -15962, -13637, -11079,  -8333,  -5441,
        -2460,    564,   3581,   6536,   9378,  12061,  14541,  16770,
        18711,  20332,  21608,  22509,  23029,  23157,  22885,  22225,
        21184,  19782,  18040,  15990,  13665,  11108,   8361,   5471,
         2488,   -537,  -3553,  -6507,  -9351, -12034, -14512, -16740,
       -18682, -20303, -21577, -22481, -22999, -23127, -22857, -22195,
       -21154, -19751, -18011, -15960, -13636, -11079,  -8333,  -5441,
        -2460,    566,   3582,   6536,   9378,  12062,  14541,  16769,
        18711,  20333,  21607,  22510,  23030,  23156,  22886,  22225,
        21185,  19781,  18039,  15990,  13663,  11106,   8361,   5470,
         2487,   -538,  -3553,  -6507,  -9352, -12034, -14512, -16741,
       -18682, -20302, -21578, -22481, -23001, -23127, -22856, -22196,
       -21156, -19752, -18011, -15963, -13637, -11080,  -8334,  -5443,
        -2461,    565,   3580,   6536,   9380,  12062,  14541,  16770,
        18710,  20332,  21606,  22510,  23030,  23155,  22886,  22224,
        21185,  19782,  18040,  15991,  13664,  11107,   8361,   5469,
         2488,   -538,  -3552,  -6508,  -9351, -12036, -14513, -16741,
       -18682, -20305, -21578, -22482, -23002, -23127, -22857, -22196,
       -21157, -19752, -18010, -15961, -13637, -11079,  -8332,  -5442,
        -2461,    566,   3581,   6536,   9379,  12061,  14541,  16769,
        18712,  20333,  21608,  22510,  23030,  23157,  22885,  22227,
        21184,  19782,  18040,  15990,  13664,  11109,   8361,   5470,
         2487,   -538,  -3552,  -6507,  -9351, -12034, -14512, -16741,
       -18682, -20306, -21579, -22482, -23001, -23128, -22857, -22197,
       -21156, -19752, -18012, -15962, -13638, -11079,  -8333,  -5442,
        -2459,    566,   3581,   6536,   9379,  12062,  14541,  16770,
        18712,  20332,  21607,  22511,  23030,  23156,  22886,  22225,
        21184,  19781,  18041,  15990,  13664,  11107,   8361,   5470,
         2488,   -536,  -3551,  -6507,  -9352, -12034, -14513, -16742,
       -18682, -20303, -21579, -22483, -23003, -23129, -22859, -22197,
       -21156, -19753, -18011, -15961, -13636, -11079,  -8332,  -5441,
        -2459,    565,   3580,   6534,   9379,  12062,  14540,  16769,
        18711,  20332,  21606,  22511,  23031,  23156,  22885,  22225,
        21184,  19780,  18040,  15990,  13664,  11107,   8361,   5470,
         2489,   -537,  -3552,  -6506,  -9352, -12034, -14513, -16741,
       -18683, -20304, -21579, -22483, -23002, -23128, -22857, -22196,
       -21154, -19750, -18010, -15961, -13637, -11079,  -8333,  -5442,
        -2461,    565,   3581,   6535,   9380,  12061,  14540,  16770,
        18710,  20331,  21606,  22508,  23031,  23155,  22885,  22224,
        21183,  19780,  18039,  15990,  13663,  11107,   8361,   5469,
         2487,   -538,  -3553,  -6507,  -9351, -12033, -14512, -16742,
       -18682, -20303, -21579, -22481, -23002, -23127, -22858, -22198,
       -21156, -19752, -18012, -15962, -13638, -11080,  -8333,  -5442,
        -2460,    566,   3580,   6534,   9380,  12062,  14540,  16769,
        18711,  20332,  21607,  22510,  23029,  23157,  22885,  22227,
        21185,  19783,  18039,  15989,  13665,  11107,   8360,   5471,
         2489,   -538,  -3552,  -6506,  -9350, -12033, -14512, -16741,
       -18682, -20303, -21579, -22482, -23000, -23128, -22857, -22196,
       -21156, -19752, -18010, -15961, -13636, -11079,  -8333,  -5442,
        -2459,    565,   3580,   6534,   9378,  12061,  14541,  16770,
        18709,  20333,  21606,  22509,  23031,  23156,  22885,  22226,
        21184,  19781,  18040,  15990,  13665,  11106,   8360,   5469,
         2488,   -538,  -3553,  -6507,  -9351, -12033, -14513, -16742,
       -18682, -20304, -21579, -22481, -23001, -23127, -22858, -22196,
       -21157, -19752, -18010, -15961, -13635, -11078,  -8333,  -5442,
        -2460,    565,   3579,   6537,   9379,  12061,  14541,  16768,
        18710,  20331,  21606,  22509,  23029,  23155,  22886,  22225,
        21183,  19780,  18040,  15988,  13664,  11107,   8360,   5470,
         2489,   -537,  -3552,  -6507,  -9350, -12035, -14511, -16740,
       -18682, -20302, -21577, -22481, -23000, -23126, -22856, -22195,
       -21154, -19749, -18011, -15961, -13638, -11079,  -8332,  -5442
};

typedef struct ADC_perf
{
    Q_t SNR;    /* SNR = 10/20 * log10(signal/noise) */
    Q_t SNR_t;  /* theoretical SNR of N bits ADC */
    Q_t SINAD;  /* SIAND = 10/20 * log10(signal/(noise+harmonic))*/
    Q_t SFDR;   /* SFDR = 10/20 * log10(signal/max peak other than signal) */
    Q_t NF;     /* NoiseFloor = 10*20 * log10(average noise) */
    Q_t ENOB;   /* effective-number-of-bits ENOB = (SINAD-1.76+20*log10(Fullscale/Input))/6.02 */
    Q_t THD;    /* THD = 10/20 * log10(harmonic/signal) */
    Q_t THDN;   /* THDN = 10/20 * log10((noise+harmonic)/signal), THDN is defined upon certain bandwidth, for full bandwidth, THDN = -SINAD */
} ADC_perf;

void ADC_READ(Q_t *raw, int nfft)
{
    int16_t *adc_buf = testbuf;

    // int16_t adc_buf[576];
    // FILE *f = fopen("20220114_145702.wav","rb");
    // fseek(f, 44, SEEK_SET);
    // fread(adc_buf, sizeof(int16_t), NFFT, f);
    // fclose(f);

    for (int i = 0; i < nfft; i++)
        raw[i] = (Q_t)adc_buf[i];
}

int32_t max_s32(int32_t *x, int32_t N)
{
    int32_t x_max = 0;
    for (int i = 0; i < N; i++)
    {   /* avoid -INT32_MIN overflow */
        int32_t t = (x[i]==INT32_MIN) ? (INT32_MAX) : ((x[i] > 0) ? (x[i]) : (-x[i])) ;
        if (t > x_max)
            x_max = t; 
    }
    return x_max;
}

int32_t safe_rms(int32_t *x, int32_t N, int32_t mean)
{
    int32_t x_max = max_s32(x, N);
    if (!x_max)
        return 0;
    int32_t sum_square = 0;
    for (int i = 0; i < N; i++)
    {
        /* use float div to avoid int64_t div (__divi3 */
        int32_t t = (int32_t) ((float)x[i] / x_max * (1<<Q_FBITS));
        sum_square += Q_mul(t,t, Q_FBITS);
    }
    int32_t ans = Q_mul(x_max, Q_sqrt(sum_square/mean, Q_FBITS), Q_FBITS);
    return ans;
}

ADC_perf ADC_test(
    int fs, int fc, Q_t th, YIRFFT_Plan real_plan)
{
    int32_t raw[NFFT] = {0};
    int32_t rawFFT[2*NFFT] = {0}; /* assuming FFT result is {r[0],i[0],r[1],i[1],...}*/  
    YIFFT_Complex *rawCFFT = (YIFFT_Complex *)rawFFT;  
    int32_t P[NFFT/2] = {0};
    int32_t harmonic[N_HARMONIC+2] = {0};
    ADC_perf ans = {0};

    /* FFT ADC reading to get power spectrum P */
    /* ADC read sine wave and write reading value to raw */
    ADC_READ(raw, NFFT); 

    /* find input amplitude, use max(raw), as long as noise is small, this
        will give well approximation */
    int raw_amp = max_s32(raw, NFFT);

    /* add window function to time domain array raw, 
        if ADC has added window already by itself, skip this */
    /* hanning is always < 1, so will not overflow */
    for (int n = 0; n < NFFT; n++)
        raw[n] = Q_mul(raw[n], hanning[n], Q_FBITS);    
    
    /* do NFFT points FFT on raw, return rawFFT = FFT(raw, NFFT) */
    /* FFT must be at least 32bit or float, cause the resulotion of int16 is only -90 dB,
        means any noise/signal below -90 dBFS will be lost(become 0). if a ADC has SNR > 90 dB,
        then the noise will become all 0 and cannot continue analyze anymore, 
        int32 has 186 dB range which enough for ADC test */
    YIRFFT_r2c(real_plan, raw, rawCFFT); 

    /* assuming FFT result rawFFT is {r[0],i[0],r[1],i[1],...} 
        raw is real, so rawFFT is hermitian symmetric, only need first half spectrum */            
    for (int k = 0; k < NFFT/2; k++)    
        P[k] = safe_rms(rawFFT+2*k,2,2);
    
    /* harmonic analyze */
    int32_t spurious = 0;
    int n_harm = 0;
    
    for (int n = 0; n < N_HARMONIC + 2; n++)
    {   /* 0 for DC, 1 for signal, 2+ for harmonic */
        /* get n-th order harmonic frequency projection on [0,fs/2) */
        int margin = (n==1) ? (18) : (2);
        int freq_harm = (n*fc) % fs;
        freq_harm = (freq_harm < fs/2) ? (freq_harm) : (fs - freq_harm);
        /* get harmonic index */
        int hidx = (freq_harm*NFFT/fs);
        int start = (hidx - margin > 0)      ? (hidx - margin) : (0);
        int end   = (hidx + margin < NFFT/2) ? (hidx + margin) : (NFFT/2);
        /* find peak within P[hidx ± margin] */
        int32_t max = max_s32(P+start, end-start);

        /* consider max is harmonic peak if (max > th*end_points ) */
        if ((n == 0) || \
            ((max > (int32_t)Q_mul(th,(Q_t)P[start], Q_FBITS)) && \
             (max > (int32_t)Q_mul(th,(Q_t)P[end-1], Q_FBITS))))
        {
            for (int k = start; k < end; k++)
            {
                harmonic[n] = Q_add(P[k], harmonic[n]);  
                P[k] = 0; 
            }
            if (n>1)
            {
                n_harm++;
                if (max > spurious)
                    { spurious = max; }
            }
        }
    }

    int32_t H = 0;
    if (n_harm > 0)
        H = safe_rms(harmonic+2, N_HARMONIC, n_harm);

    int32_t S  = harmonic[1];

    int32_t N = 0;
    int n_noise = 0;
    for (int n = 0; n < NFFT/2; n++)
    {
        if (P[n] > 0) 
        {   /* this skip any peak previous calculate, only noise remain */
            n_noise++;
            if (P[n] > spurious) /* find highest peak other than main signal */ 
                spurious = P[n];
        }
    }
    N = safe_rms(P, NFFT/2, 1);
    N = N*2/3; /* NPB of hanning window */

    /* ADC performance calculation */
    int32_t Qlog10_S = Q_log10(S, Q_FBITS);
    int32_t Qlog10_N = Q_log10(N, Q_FBITS);
    int32_t Qlog10_spur = Q_log10(spurious, Q_FBITS);
    int32_t Qlog10_H = (H==0) ? (INT32_MIN) : (Q_log10(H, Q_FBITS));
    int32_t Qlog10_HN = Q_log10(H+N, Q_FBITS);

    ans.SNR = 20 * (Qlog10_S - Qlog10_N);
    ans.SNR_t = Q_add(Q_mul(Q(6.02f,Q_FBITS), Q_from_int(ADC_NBITS, Q_FBITS), Q_FBITS), Q(1.76f, Q_FBITS)); 
    ans.SINAD = 20 * (Qlog10_S - Qlog10_HN);
    ans.SFDR = 20 * (Qlog10_S - Qlog10_spur);
    ans.THD = (H==0) ? (INT32_MIN) : (20*(Qlog10_H - Qlog10_S));
    ans.THDN = 20 * (Qlog10_HN - Qlog10_S);
    ans.ENOB = Q_sub(ans.SINAD, Q(1.76f,Q_FBITS)) + 20*(Q_log10(32768, Q_FBITS)-Q_log10(raw_amp, Q_FBITS));
    ans.ENOB = Q_mul(ans.ENOB, Q(1.0f/6.02f, Q_FBITS), Q_FBITS); 
    ans.NF = 20 * (Qlog10_N + 315652); // this constant is (int32_t)((1<<Q_FBITS) * log10(1<<Q_FBITS))
    
    /* debug */
    float snr = Q_to_float(ans.SNR, Q_FBITS);
    float snrt = Q_to_float(ans.SNR_t, Q_FBITS);
    float sinad = Q_to_float(ans.SINAD, Q_FBITS);
    float sfdr = Q_to_float(ans.SFDR, Q_FBITS);
    float nf = Q_to_float(ans.NF, Q_FBITS);
    float enob = Q_to_float(ans.ENOB, Q_FBITS);
    float thd = Q_to_float(ans.THD, Q_FBITS);
    float thdn = Q_to_float(ans.THDN, Q_FBITS);
    
    return ans;
}

int main()
{
    uint32_t ext_mem_len = 592+2348; /* this number can get from YIRFFT_alloc(NFFT, 0, NULL, &ext_mem_len) when NFFT is fixed */
    // YIRFFT_alloc(NFFT, 0, NULL, &ext_mem_len);

    uint8_t ext_mem[592+2348];
    YIRFFT_Plan real_plan = YIRFFT_alloc(NFFT, 0, ext_mem, &ext_mem_len);

    ADC_perf ans = ADC_test(48000, 1000, Q(2,Q_FBITS), real_plan);

    YIRFFT_free(&real_plan);
    return 0;
}