/**
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file      yifft.h
 * @brief     This library YIFFT is a C subroutine, fork from kiss_fft but add some useful features
 *            for embedded audio application like DCT, static allocation and minimal memory usage.
 * 
 * Change Logs:
 * Date         Author      Version     Notes
 * 2021-12-01   Ge Jiahao   r0.1        refactor
 * 2021-12-28   Ge Jiahao   1.0         first release
 */
#ifndef __YIFFT_H__
#define __YIFFT_H__

#include "yifft_config.h"
#include <stdint.h>
#include <stdbool.h>

/*******************
 *   Using YIFFT   *
 *******************
 *  
 *  YIFFT contains three submodules, each with a unique prefix:
 *  1. `YIFFT_xxx` for complex FFT and some global definitions.
 *  2. `YIRFFT_xxx` for real valued FFT
 *  3. `YIDCT_xxx` for type I~IV DCT(discrete cosine transform) and MDCT/IMDCT
 *  `YIFFT` is basic submodule, `YIRFFT` use `YIFFT` and `YIDCT` use `YIRFFT`.
 * 
 *  Each submodule has similar structure and usage:
 *  1. `YIXXX_Memory` is the memory block that holds everything `YIXXX` 
 *      submodule needs. This struct is internally and privately used 
 *      within YIFFT and not exposed to FFT user.
 * 
 *  2. `YIXXX_Plan` is typedef-ed as a pointer to `YIXXX_Memory`. 
 * 
 *  3. `YIXXX_alloc(uint32_t N, bool inverse[YIDCT_Type type], 
 *                  void *ext_mem, uint32_t *ext_mem_len)` 
 *      will first allocate memory(via malloc or ext_mem, see below) to FFT plan, 
 *      then initialize it.
 * 
 *      It takes an integer as length of FFT plan and a boolean for whether do 
 *      forward/inverse FFT. For `YIDCT_` submodule, it will take `YIDCT_Type` 
 *      from six different DCT types instead of `bool inverse`(FFT direction of 
 *      DCT is determined by their type).
 *      These two parameters will determine how much memory should be allocated 
 *      and how to initialize it.
 * 
 *      Last two parameter `void *ext_mem` and `uint32_t *ext_mem_len` is used 
 *      for static memory allocation:
 *      YIXXX_alloc(..., NULL, NULL) or YIXXX_alloc(..., ext_mem, NULL): 
 *          it will use malloc to dynamic allocated memory for FFT plan. 
 *          return NULL when malloc fails.
 *      YIXXX_alloc(..., NULL, &ext_mem_len): 
 *          it will update `ext_mem_len` as memory needed(bytes) according to 
 *          length/DCT type. return NULL.
 *      YIXXX_alloc(..., ext_mem, &ext_mem_len):
 *          when `ext_mem_len` is large enough, it will use memory pointed by 
 *          `ext_mem` as FFT plan, return plan points to same place as `ext_mem`. 
 *          If `ext_mem_len` is not enough, return NULL.
 *          Either way, it will update `ext_mem_len` to memory needed.
 * 
 *  4. `YIXXX_free(YIXXX_Plan *xxx_plan_ptr)` is a safe free for `YIXXX_Plan`, 
 *      it will free if and only if:
 *      1. xxx_plan_ptr(pointer to plan) is not NULL;  
 *      2. *xxx_plan_ptr(plan itself) is not NULL;  
 *      3. *xxx_plan_ptr(plan itself) is allocated by malloc, not by external memory.
 *      After free, it will set `xxx_plan_ptr to NULL.
 * 
 *  X. `YIXXX_xxx(YIXXX_Plan xxx_plan, input_data, output_data)`
 *      These functions take allocated and initialized `YIXXX_Plan` and do FFT work.
 *      If not specified, the data inside input_data buffer will not be modified.
 *      If not specified, the input_data and output_data are length N array of 
 *      real(YI_t) or complex(YIFFT_Complex) number. 
 * 
 *  Y. `YIXXX_update_xxx(YIXXX_Plan xxx_plan, ...)`
 *      These function take allocated `YIXXX_Plan` and initialize it. 
 *      They are mainly used for manually update existing FFT plan.
 * 
 *  Details about function in X/Y group can be found at each individual function comments. 
 */



/***************************
 *   Global Declaration    *
 ***************************/

/* YIFFT takes `YI_t` as real data type and YIFFT_Complex as complex data type 
   for fixed-point/floating-point implementation */

#ifdef  FFT_FIXED_POINT
typedef int32_t YI_t;
#else
typedef float YI_t;
#endif /*FIXED_POINT*/ 

typedef struct _YIFFT_Complex {
    YI_t r;
    YI_t i;
} YIFFT_Complex;

typedef enum {
    //SUCCESS = 0,
    ERROR_PLAN_IS_NULL              = -1,   /* raise when expect an vaild plan but get NULL */
    ERROR_RADIX_IS_NULL             = -2,   /* raise when expect an vaild radix but get NULL */
    ERROR_TOO_MANY_RADIX            = -3,   /* raise when length of radix larger than MAX_FACTORS */
    ERROR_RADIX_LESS_THAN_TWO       = -4,   /* raise when 0 or 1 exists in radix */
    ERROR_RADIX_NOT_FACTOR_OF_NFFT  = -5,   /* raise when product of all radix is not equal to NFFT */
    ERROR_INIT_ODD_LENGTH_RFFT      = -7,   /* raise when try to initialize twiddels of odd length real FFT plan */
    ERROR_TEST_FAIL                 = -999  /* raise when test fails */
} YIFFT_STATE;




/********************************
 *   Complex FFT Declaration    *
 ********************************/

/* ============ Complex FFT Plan =========== */
typedef struct YIFFT_Memory* YIFFT_Plan;

/** @param  NFFT is the length of complex FFT, may not equal to N of RFFT/DCT due to optimization */
YIFFT_Plan YIFFT_alloc(uint32_t NFFT, bool inverse, void *ext_mem, uint32_t *ext_mem_len);

void YIFFT_free(YIFFT_Plan *cpx_plan_ptr);

/* ============ Complex FFT Work =========== */

/**
 * @brief     do complex FFT, note that inverse result is not scaled by 1/NFFT
 * 
 * @note when `out` is NULL, or `in` and `out` overlap (|out-in| < NFFT), if radix
 *      is palindrome, it will do inplace FFT, result will be writen to `in` buffer.
 *      otherwise, FFT will fail(do nothing and return).
 */
void YIFFT_cfft(const YIFFT_Plan cpx_plan, YIFFT_Complex *in, YIFFT_Complex *out);


/* ============ Complex FFT Plan Updater =========== */
#ifdef BUILD_CFFT /* not working for custom complex FFT */
/**
 * @brief     update radix of a YIFFT_Plan
 * 
 * @param cpx_plan an existing YIFFT_Plan
 * @param radix new radix of plan
 * @param rank length of `radix`
 * @return YIFFT_STATE, 0 for SUCCESS, otherwise is ERROR, see YIFFT_STATE for details.
 */
YIFFT_STATE YIFFT_update_plan(YIFFT_Plan cpx_plan, const uint8_t *radix, uint8_t rank);


/**
 * @brief     update pre-computed twiddles of a YIFFT_Plan. This can transform a forward
 *          FFT plan to inverse one and vice versa.
 * 
 * @param cpx_plan an existing YIFFT_Plan
 * @param inverse forward/inverse FFT
 * @return YIFFT_STATE, 0 for SUCCESS, otherwise is ERROR, see YIFFT_STATE for details.
 */
YIFFT_STATE YIFFT_update_twiddles(YIFFT_Plan cpx_plan, bool inverse);

#endif /* BUILD CFFT*/





#if defined(BUILD_RFFT) || defined(BUILD_DCT)
/*****************************
 *   Real FFT Declaration    *
 *****************************/

/* ============ Real FFT Plan =========== */
typedef struct YIRFFT_Memory* YIRFFT_Plan;

YIRFFT_Plan YIRFFT_alloc(uint32_t N, bool inverse, void *ext_mem, uint32_t *ext_mem_len);

void YIRFFT_free(YIRFFT_Plan *real_plan_ptr);

/* ============ Real FFT Work =========== */

/** @brief do two real FFT with one complex FFT, out_r = FFT(Re(in)) and out_i = FFT(Im(in)).
 *  @param in/out_r/out_i are YIFFT_Complex buffer with length NFFT */
void YIRFFT_2rfft(
    const YIFFT_Plan cpx_plan, const YIFFT_Complex *in, 
    YIFFT_Complex *out_r, YIFFT_Complex *out_i);

/* fourier transform has property: if x is pure real, then X = fourier(x) is hermitian symmetric 
 * i.e. X[k] = X*[N-k] (* is conjugate), this holds for both forward and inverse transform.
 * so here we have 2 real FFT: one is input real array and output hermitian symmetric 
 * complex array(YIRFFT_r2c) and another one is input hermitian symmetric complex array 
 * and output real array (YIRFFT_c2r)
 */

/** @brief do real to complex FFT where `out` will be hermitian symmetric 
 *  @note same as cfft, inverse r2c result is not scaled by 1/N */
void YIRFFT_r2c(const YIRFFT_Plan real_plan, const YI_t *in, YIFFT_Complex *out);


/** @brief do complex to real FFT when `in` is hermitian symmetric
 *  @note same as cfft, inverse c2r result is not scaled by 1/N
 *  @warning this function will destory data in `in` buffer */
void YIRFFT_c2r(const YIRFFT_Plan real_plan, YIFFT_Complex *in, YI_t *out);

#ifdef BUILD_RFFT /* not working for custom real FFT */
/** @brief similar to YIFFT_update_twiddles, update pre-computed twiddles of a YIRFFT_Plan. 
 *  @note This will **NOT** update compelx twiddles inside cpx_plan */
YIFFT_STATE YIRFFT_update_twiddles(YIRFFT_Plan real_plan, bool inverse);
#endif /* BUILD_RFFT */

#endif /* BUILD_RFFT || BUILD_DCT */





#ifdef BUILD_DCT
/************************
 *   DCT Declaration    *
 ************************/

typedef enum {
    DCT_I   = 1,
    DCT_II  = 2, /* DCT-II is default if one give type outside [1,6] */
    DCT_III = 3,
    DCT_IV  = 4,
    MDCT    = 5,
    IMDCT   = 6
} YIDCT_Type;

/* ============ DCT Plan =========== */
typedef struct YIDCT_Memory* YIDCT_Plan;

/** @note DCT-IV/MDCT/IMDCT only accpet even length N */
YIDCT_Plan YIDCT_alloc(
    uint32_t N, YIDCT_Type type, void *ext_mem, uint32_t *ext_mem_len);

void YIDCT_free(YIDCT_Plan *dct_plan_ptr);

/* ============ DCT Work =========== */

/** @brief  do DCT work of different DCT types 
 *  @note   for MDCT, length of `in` is 2N, for IMDCT, length of `out` is 2N.
 *      otherwise, length of both `in` and `out` are N.
 *  @warning YIDCT_MDCT() function will destory input buffer `in`
 */
void YIDCT_DCT_I    (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out);
void YIDCT_DCT_II   (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out);
void YIDCT_DCT_III  (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out);
void YIDCT_DCT_IV   (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out);
void YIDCT_MDCT     (const YIDCT_Plan dct_plan,       YI_t *in, YI_t *out);
void YIDCT_IMDCT    (const YIDCT_Plan dct_plan, const YI_t *in, YI_t *out);

#endif /* BUILD_DCT */


#endif /* __YIFFT_H__ */
