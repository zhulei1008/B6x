#ifndef __Q_H__
#define __Q_H__
// TODO: saturate mode add/sub/mul/div/nint OVERFLOW_SATURATE
// TODO: Q_ROUNDING
#include <stdint.h>

#define XSTR(x) STR(x)
#define STR(x) #x

#ifndef FIXED_POINT
    #error "Q.h only works with FIXED_POINT defined"
#endif 

typedef int64_t Q_long;
typedef int32_t Q_t;
#define Q_IMAX INT32_MAX
#define Q_IMIN INT32_MIN

// #if !(FIXED_POINT + 0) /* when FIXED_POINT is defined but empty, use default 32 */
//     #undef  FIXED_POINT
//     #define FIXED_POINT 32
// #endif

// #if (FIXED_POINT <= 16)     /* 16 bit FIXED_POINT */
//     typedef int32_t Q_long;
//     typedef int16_t Q_t;
//     #define Q_IMAX INT16_MAX
//     #define Q_IMIN INT16_MIN
// #elif (FIXED_POINT <= 32)   /* 32 bit FIXED_POINT */ 
//     # ifndef NO_INT64
//     typedef int64_t Q_long;
//     # endif
//     typedef int32_t Q_t;
//     #define Q_IMAX INT32_MAX
//     #define Q_IMIN INT32_MIN
// #else
//     #error "FIXED_POINT > 32 is not supported"
// #endif 





#ifdef OVERFLOW_CHECK

#ifdef OVERFLOW_PRINT
    #include <stdio.h>
    #define OVERFLOW_WARNING(x,op,y) printf("overflow when (%ld " #op" %ld) \n",(int32_t)(x),(int32_t)(y))
#else 
    #define OVERFLOW_WARNING(x,op,y) /* no-op */
#endif

#define CHECK_OVERFLOW(condition, x, op, y) do{ \
if (condition) { \
    OVERFLOW_WARNING(x,op,y); \
    return Q_IMAX; \
}}while(0)

#define CHECK_UNDERFLOW(condition, x, op, y) do{ \
if (condition) { \
    OVERFLOW_WARNING(x,op,y); \
    return Q_IMIN; \
}}while(0)

#else // defined(CHECK_OVERFLOW) 

#define CHECK_OVERFLOW(condition,x,op,y) /* no-op */
#define CHECK_UNDERFLOW(condition,x,op,y) /* no-op */

#endif // defined(CHECK_OVERFLOW)





/* Fixed point word/fraction bit length setting */
#ifndef Q_WBITS
    #define Q_WBITS 16
#endif
#ifndef Q_FBITS
    #define Q_FBITS 16
#endif

// #if (Q_WBITS + Q_FBITS) != FIXED_POINT
//     #pragma message "Q_WBITS("XSTR(Q_WBITS)") + Q_FBITS("XSTR(Q_FBITS)") != FIXED_POINT("XSTR(FIXED_POINT)")"
//     #error "Q_W/FBITS setting error"
// #endif

// #if (Q_FBITS >= FIXED_POINT-2)
//     #error "Q_FBITS is too large that some of Q.h operation will overflow"
// #endif




/* static int/float to Q macro */
#ifndef Q_ROUNDING
#define Q(x)        ((Q_t)((x) * (1<<Q_FBITS)))
#else
#define Q(x)        ((Q_t)(((x)>=0) ? ((x)*(1<<Q_FBITS) + 0.5) : ((x)*(1<<Q_FBITS) - 0.5)))
#endif

/* Constants */
#define Q_ONE        (1<<Q_FBITS)
#define Q_TWO        (2<<Q_FBITS)
#define Q_HALF       (Q_ONE>>1)
#define Q_SQRT2      Q(1.4142135623730951)
#define Q_PI         Q(3.141592653589793)
#define Q_HALF_PI    Q(1.5707963267948966)
#define Q_2_OVER_PI  Q(0.6366197723675814)

#define Q_FMAX       ((float)Q_IMAX / Q_ONE)
#define Q_FMIN       ((float)Q_IMIN / Q_ONE)

#define Q_FMASK	(((Q_t)1 << Q_FBITS) - 1)
#define Q_WMASK (~Q_FMASK)

// Runtime dtype convertion function
// TODO: QX_to/from_QY() (i.e. Q16.16 <=> Q24.8)

static inline Q_t Q_from_int(int x)
    { return (Q_t)(x << Q_FBITS);}

static inline Q_t Q_from_float(float x)
    { return (Q_t)(x * Q_ONE); }

static inline int Q_to_int(Q_t x)
    { return (int)(x >> Q_FBITS); }

static inline float Q_to_float(Q_t x)
    { return ((float)x / Q_ONE); }

/* ============================ Fixed point arithmetic ========================= */
static inline Q_t Q_add(Q_t x, Q_t y)
{   /* do overflow check before x+y, because signed overflow is undefined behavior*/
    CHECK_OVERFLOW ((y > 0) && (x > Q_IMAX - y), x, +, y);
    CHECK_UNDERFLOW((y < 0) && (x < Q_IMIN - y), x, +, y);
    return x + y;
}

static inline Q_t Q_sub(Q_t x, Q_t y)
{
    CHECK_OVERFLOW ((y > 0) && (x < Q_IMIN + y), x, -, y);
    CHECK_UNDERFLOW((y < 0) && (x > Q_IMAX + y), x, -, y);
    return x - y;
}

#if defined(NO_INT64)
/**
 * @brief     int32_t multiplication using 16x16 bits mul then converted to Q_t
 * @details   multiply higher/lower 16 bits separately:
 *  x = (A<<16) | B,  y = (C<<16) | D,  
 *  x * y = int64 = (A*C)<<32 + (A*D+C*B)<<16 + B*D
 *  int64_high_32bit = A*C + (A*D+C*B)>>16 (may carry if int64_lo overflow)
 *  int64_low_32bit =  B*D + (A*D+C*B)<<16 
 *  Q_mul(x,y) = int64 >> Q_FBITS = (int64_high_32bit<<32 + int64_low_32bit) >> Q_FBITS
 *             = int64_hi<<(32-Q_FBITS) + int64_lo>>Q_FBITS
 */
static inline Q_t Q_mul_kernel(Q_t x, Q_t y, uint8_t q_fbits)
{
    CHECK_OVERFLOW (((x>0 && y<0) || (x<0 && y>0)) || (x < Q_IMAX / y)); /* short circut */
    CHECK_UNDERFLOW(((x>0 && y>0) || (x<0 && y<0)) || (x > Q_IMIN / y));    
    y = x * y;
    x = y >> 31;
    x = x << (32-q_fbits);
    y = y >> q_fbits;
    return x | y;    
}
#else
static inline Q_t Q_mul_kernel(Q_t x, Q_t y, uint8_t q_fbits)
{
    Q_long product = (((Q_long)x) * y) >> q_fbits;

    CHECK_OVERFLOW((product > Q_IMAX), x, *, y);
    CHECK_UNDERFLOW((product < Q_IMIN), x, *, y);
    
    return (Q_t)product;
}
#endif
static inline Q_t Q_mul(Q_t x, Q_t y)
    { return Q_mul_kernel(x, y, Q_FBITS); }

#if defined(NO_INT64)
// Count leading zeros, using processor-specific instruction if available.
static uint8_t clz(uint32_t x)
{
	uint8_t result = 0;
	if (x == 0) return 32;
	while (!(x & 0xF0000000)) { result += 4; x <<= 4; }
	while (!(x & 0x80000000)) { result += 1; x <<= 1; }
	return result;
}

static inline Q_t Q_div(Q_t x, Q_t y)
{
    if (y==0) 
        { return (x>0) ? (Q_IMAX) : (Q_IMIN); }
    uint32_t remainder = (x>0) ? (x) : (-x);
    uint32_t divider = (y>0) ? (y) : (-y);
    uint32_t quotient = 0;
    int bit_pos = Q_FBITS + 1;

	// If the divider is divisible by 2^n, take advantage of it.
	while (!(divider & 0xF) && bit_pos >= 4)
	{
		divider >>= 4;
		bit_pos -= 4;
	}

    while (remainder && bit_pos >= 0)
	{
		// Shift remainder as much as we can without overflowing
		int shift = clz(remainder);
		if (shift > bit_pos) 
            { shift = bit_pos; }
		remainder <<= shift;
		bit_pos -= shift;
		
		uint32_t div = remainder / divider;
        remainder = remainder % divider;
        quotient += div << bit_pos;

        CHECK_OVERFLOW(div & ~(0xFFFFFFFF >> bit_pos),x,/,y);
		
		remainder <<= 1;
		bit_pos--;
	}

    Q_t result = quotient >> 1;

    if ((x^y) & 0x80000000) /* if negative */
    {
        result = -result-1;
    }
    return result;
}
#else
static inline Q_t Q_div(Q_t x, Q_t y)
{
    Q_long quo = ((Q_long)x << Q_FBITS) / (Q_long)y;

    CHECK_OVERFLOW((quo > Q_IMAX), x, /, y);
    CHECK_UNDERFLOW((quo < Q_IMIN), x, /, y);

    return (Q_t)quo;
}
#endif

/* =============================== Fixed point math.h ========================= */
static inline Q_t Q_mod(Q_t x, Q_t y)
    { return x % y; }

static inline Q_t Q_abs(Q_t x)
    { return ((x>0) ? (x) : (-x));}

// NOTE: floor() is rounding towards -inf
static inline Q_t Q_floor(Q_t x)
    { return (x & Q_WMASK); }

// NOTE: ceil() is rounding towards +inf
static inline Q_t Q_ceil(Q_t x)
    { return (x & Q_WMASK) + ((x & Q_FMASK) ? (Q_ONE) : (0)); }

// NOTE: nint() is rounding towards nearest integer
static inline Q_t Q_nint(Q_t x)
    { return (x > 0) ? (Q_floor(Q_add(x, Q_HALF))) : (-Q_floor(Q_add(-x, Q_HALF))); }
#define Q_round(x) Q_nint(x)

// NOTE: trunc() is rounding towards zero
static inline Q_t Q_trunc(Q_t x)
    { return ((x>0) ? (Q_floor(x)) : (Q_ceil(x))); }

// NOTE: away() is rounding away zero
static inline Q_t Q_away(Q_t x)
    { return ((x>0) ? (Q_ceil(x)) : (Q_floor(x))); }


/* Turkowski, Ken. "Fixed point square root." Apple Technical Report No. 96 (1994). */
/* use Q_sqrt on int32_t: 
    int32_t x = 123456;
    int32_t sqrt_Qx = (int32_t)Q_sqrt((Q_t)x); // sqrt_Qx = 89948 on Q_FBITS = 16

    float real_sqrt_Qx = (float)sqrt_Qx / (1<<(Q_FBITS/2)); // if Q_FBITS is even
    float real_sqrt_Qx = (float)sqrt_Qx / (1<<(Q_FBITS/2)) / sqrt(2); // if Q_FBITS is odd
*/
static Q_t Q_sqrt(Q_t x)
{
    uint32_t root = 0, remHi = 0, remLo = x, count = 15 + Q_FBITS/2 , testDiv = 0;
    do {
        remHi = (remHi << 2) | (remLo >> 30);
        remLo <<= 2;
        root <<= 1;
        testDiv = (root << 1) + 1;
        if (remHi >= testDiv)
        {
            remHi -= testDiv;
            root++;
        }
    } while (count-- != 0);
    return (Q_FBITS & 0x1) ? (Q_mul(root, Q_SQRT2)) : ((Q_t)root);
}



/* from https://github.com/dmoulding/log2fix
The MIT License (MIT)  Copyright (c) 2015 Dan Moulding

[1] C. S. Turner, "A Fast Binary Logarithm Algorithm", 
IEEE Signal Processing Mag., pp. 124,140, Sep. 2010. */

/* use Q_log on int32_t:
    int32_t x = 123456;
    int32_t log10_Qx = Q_log10(x); // log10_Qx = 18024 when Q_FBITS = 16
    float real_log10_Qx = (float)log10_Qx / (1<<Q_FBITS) + log10(1<<Q_FBITS);
*/
// #if (FIXED_POINT > 16)
#define INV_LOG2_E_Q1  0x58b90bfcULL // Inverse log base 2 of e
#define INV_LOG2_10_Q1 0x268826a1ULL // Inverse log base 2 of 10
// #else
//     #define INV_LOG2_E_Q1  22713U // Inverse log base 2 of e
//     #define INV_LOG2_10_Q1 9864U // Inverse log base 2 of 10
// #endif

static Q_t Q_log2(Q_t x)
{
    if (x<=0)
        return -1;
    int32_t b = Q_HALF;
    int32_t y = 0;

    if (x == 0) {
        return Q_IMIN; // represents negative infinity
    }

    while (x < Q_ONE) {
        x <<= 1;
        y -= Q_ONE;
    }

    while (x >= (Q_TWO)) {
        x >>= 1;
        y += Q_ONE;
    }

    Q_t z = x;

    for (int i = 0; i < Q_FBITS; i++) {
        z = Q_mul(z,z);
        if (z >= (2U << Q_FBITS)) {
            z >>= 1;
            y += b;
        }
        b >>= 1;
    }

    return y;
}

static Q_t Q_log (Q_t x)
{
    return Q_mul_kernel(Q_log2(x), INV_LOG2_E_Q1, 31);
}

static Q_t Q_log10 (Q_t x)
{
    return Q_mul_kernel(Q_log2(x), INV_LOG2_10_Q1, 31);
}

// /*- from https://sourceforge.net/projects/fixedptc/
//  * Copyright (c) 2010-2012 Ivan Voras <ivoras@freebsd.org>
//  * Copyright (c) 2012 Tim Hartrick <tim@edgecast.com> */
// #define LN2     Q(0.69314718055994530942)
// #define LN2_INV Q(1.4426950408889634074)
// #define EXP_P_0 Q(1.66666666666666019037e-01)
// #define EXP_P_1 Q(-2.77777777770155933842e-03)
// #define EXP_P_2 Q(6.61375632143793436117e-05)
// #define EXP_P_3 Q(-1.65339022054652515390e-06)
// #define EXP_P_4 Q(4.13813679705723846039e-08)

// static Q_t Q_exp(Q_t fp)
// {
// 	int32_t xabs, k, z, R, xp;

// 	if (fp == 0)
// 		return (Q_ONE);
// 	xabs = Q_abs(fp);
// 	k = Q_mul(xabs, LN2_INV);
// 	k += Q_HALF;
// 	k &= ~Q_FMASK;
// 	if (fp < 0)
// 		k = -k;
// 	fp -= Q_mul(k, LN2);
// 	z = Q_mul(fp, fp);
// 	/* Taylor */
// 	R = Q_TWO + Q_mul(
//         z,EXP_P_0 + Q_mul(
//             z,EXP_P_1 + Q_mul(
//                 z,EXP_P_2 + Q_mul(
//                     z,EXP_P_3 + Q_mul(
//                         z,EXP_P_4)))));
// 	xp = Q_ONE + Q_div(Q_mul(fp, (Q_TWO)), R - fp);
// 	if (k < 0)
// 		k = Q_ONE >> (-k >> Q_FBITS);
// 	else
// 		k = Q_ONE << (k >> Q_FBITS);
// 	return (Q_mul(k, xp));
// }

// static Q_t Q_pow(Q_t n, Q_t exp)
// {
// 	if (exp == 0)
// 		return (Q_ONE);
// 	if (n < 0)
// 		return 0;
// 	return (Q_exp(Q_mul(Q_log(n), exp)));
// }

// from https://www.nullhardware.com/blog/fixed-point-sine-and-cosine-for-embedded-systems/
// input x  = 0 ~ 2**n => 0 ~ pi/2
// output y = 0 ~ 2**a => 0 ~ 1
#define Q_SIN_A1 3370945099
#define Q_SIN_B1 2746362156
#define Q_SIN_C1 ((uint32_t)((1<<(3+32-Q_FBITS)) * 0.06971863420548807))

static inline int32_t Q_sin_kernel(int32_t x)
{
    uint32_t i = (uint32_t)x;

    uint32_t y = (Q_SIN_C1*i)>>Q_FBITS;
    y = Q_SIN_B1 - ((i*y)>>3);
    y = i * (y>>Q_FBITS);
    y = i * (y>>Q_FBITS);
    y = Q_SIN_A1 - (y>>(32-31));
    y = i * (y>>Q_FBITS);
    y = (y+(1UL<<(31-Q_FBITS-1)))>>(31-Q_FBITS); // Rounding

    return y;
}

static Q_t Q_sin(Q_t x)
{
    uint8_t neg = 0;
    if (x<0)
    {
        neg = 1;
        x = -x;
    }
    // rad = x * (2/pi)
    Q_t rad = Q_mul(x, Q_2_OVER_PI);
    rad %= Q_from_int(4);

    Q_t sin;
    if (rad < Q_ONE)
    {
        sin = Q_sin_kernel(rad);
    }
    else if (rad < Q_TWO)
    {
        sin = Q_sin_kernel(Q_TWO - rad);
    }
    else if (rad < Q_from_int(3))
    {
        sin = -Q_sin_kernel(rad - Q_from_int(2));
    }
    else
    {
        sin = -Q_sin_kernel(Q_from_int(4) - rad);
    }

    return (neg) ? (-sin) : (sin);
}

static Q_t Q_cos(Q_t x)
{
    return Q_sin(x + Q_HALF_PI);
}

#endif // __Q_H__