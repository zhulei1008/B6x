/**
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file      yifft_config.h.in
 * @brief     Configuration of YIFFT
 * 
 * Change Logs:
 * Date         Author      Version     Notes
 * 2021-12-28   Ge Jiahao   1.0         first release
 */

/*--------------------------------------------------------------------------
 * This file is auto-generated from yifft_config.h.in by Cmake.
 * If you need to change configuration, either: 
 * 1. directly change this file then manually compile. 
 * 2. use Cmake or other Cmake tool set these flags then run Cmake.
 * --------------------------------------------------------------------------*/

#ifndef __YIFFT_CONFIG_H__
#define __YIFFT_CONFIG_H__
#include "yc11xx.h"
/********************
 *   Config YIFFT   *
 ********************/

/* This should be always enabled unless you need custom complex FFT(see Custom YIFFT below) */
#define BUILD_CFFT

/* Enable this will compile YIRFFT submodule of YIFFT
   Disable this but enable BUILD_DCT will enable custom real FFT(see Custom YIFFT below)
   Disable this and BUILD_DCT will remove all real FFT/DCT code */
#define BUILD_RFFT 

/* Enable BUILD_DCT will compile YIDCT submodule of YIFFT, disable this will remove DCT code */
// #define BUILD_DCT


/* max length of radix, will take 8*MAX_FACTORS bytes memory in complex FFT plan. 
   note this should be large enough that YIFFT_factorize won't overflow but less than 32 */
#define MAX_FACTORS 5

/* CUSTOM_MALLOC will enable custom malloc function in "src/yifft_kernel.h",
   modify that if you need other than malloc() */
// #define CUSTOM_MALLOC

/*
    Enable FIXED_POINT will enable fixed point arithmetic of FFT, YI_t becomes integer,
    and all YI_xxx() macro will becomes fixed point function. 

    Disable it will use float(32bit single precision float) arithmetic 
    and <math.h> for math function.
 */
#define FFT_FIXED_POINT

/********************
 *   Custom YIFFT   *
 ********************
 * Natively, YIRFFT use YIFFT and YIDCT use YIRFFT. User can also make YIRFFT use custom
 * complex FFT instead of YIFFT, and make YIDCT use custom real FFT instead of YIRFFT.
 *
 *  To use custom complex FFT, one need disable BUILD_CFFT and override following: 
 *  1. `YIFFT_Memory` struct in "src/yifft_kernel.h", a custom struct 
 *      that hold information for your custom FFT. NOTE: `YIFFT_Plan` is
 *      always typedef-ed as pointer to `YIFFT_Memory`.
 *  2. `YIFFT_alloc` function in "src/yifft.c", an allocation and initialization
 *      function for your custom `YIFFT_Plan`/`YIFFT_Memory`.
 *  3. `YIFFT_free` function in "src/yifft.c", a free memory function to free
 *      your custom `YIFFT_Plan`.
 *  4. `YIFFT_cfft` function in "src/yifft.c", a warpper to your custom FFT.
 *      any parameters needed should be pass via `YIFFT_Plan`. 

 * 
 *  after correctly overriding, real FFT function `YIRFFT_2rfft`/`YIRFFT_r2c`/`YIRFFT_c2r`,
 *  will use your custom complex FFT. This allows a C-core run real FFT c code and use
 *  hardware FFT to boost speed.
 * 
 * 
 *  To use custom real FFT, one need disable BUILD_RFFT and override similar thing:
 *      `YIRFFT_Memory`/`YIRFFT_alloc`/`YIRFFT_free` and `YIRFFT_r2c`/`YIRFFT_c2r`.  
 *      `YIRFFT_2rfft` is not needed for DCT.
 *  After correctly overriding, YIDCT will use your custom real FFT. 
 *
 *  @note: When override functions, one need keep function signature the same.
 * 
 *  @note any `YIXFFT_update_xxx()` function only works for native YIFFT plan. 
 *  so when disable BUILD_XFFT, these function is not avaliable.
 */

#endif /* __YIFFT_CONFIG_H__ */
