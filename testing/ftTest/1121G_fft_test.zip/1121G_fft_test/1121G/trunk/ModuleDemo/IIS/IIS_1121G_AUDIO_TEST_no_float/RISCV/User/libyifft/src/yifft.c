/**
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file      yifft.c
 * @brief     Complex FFT code
 * 
 * Change Logs:
 * Date         Author      Version     Notes
 * 2021-12-01   Ge Jiahao   0.1         init
 * 2021-12-28   Ge Jiahao   1.0         first release
 */

#include "../include/yifft_config.h"
#include "../include/yifft.h"
#include "yifft_kernel.h"

#ifdef BUILD_CFFT

#include "yifft_bfly.h"

/* ============================== FFT Preparation ============================= */

// YIFFT_Plan YIFFT_alloc(
//    const uint32_t NFFT, const bool inverse, void *ext_mem, uint32_t *ext_mem_len)
// {
//     YIFFT_Plan cpx_plan = (YIFFT_Plan)ext_mem;
//     if (cpx_plan)
//     {
//         cpx_plan->NFFT = 576;
//         for (int i = 0; i < 10; i++)
//             cpx_plan->plan[i] = fixed_576_plan[i];
//         for (int i = 0; i < 288; i++)
//             cpx_plan->twiddles[i] = cpx_tw[i];
//     }
//     return cpx_plan;
// }

// void YIFFT_free(YIFFT_Plan *cpx_plan_ptr)
// {
//     if ((cpx_plan_ptr) && (*cpx_plan_ptr))
//     {
//         // free(*cpx_plan_ptr);
//         *cpx_plan_ptr = NULL;
//     }
// }

/* =========================== Complex FFT Work ============================== */

static void YIFFT_fft_work_DIT(
    const YIFFT_Plan cpx_plan, YIFFT_Complex *in, YIFFT_Complex *out, 
    const uint32_t f, uint32_t *plan)
{
    const uint32_t p = *plan++;
    const uint32_t m = *plan++;
    YIFFT_Complex *outptr = out;
    if (m == 1)
    {   
        for (int i = 0; i < p*m; i++)
        {   /* bit reverse is implicitly performed here */
            *out++ = *in;
            in += f; 
        }
    }
    else
    {
        for (int i = 0; i < p; i++)
        {   /* do FFT recursively for better cache utilization */
            YIFFT_fft_work_DIT(cpx_plan, in, out, p*f, plan);
            in += f;
            out += m;
        }
    }
    switch(p)
    {   /* radix other than 2/3/4/5/7 will do generic butterfly */
        case 2:  YIFFT_bfly2_DIT(cpx_plan, outptr, f, m);    break;
        case 3:  YIFFT_bfly3_DIT(cpx_plan, outptr, f, m);    break;
        case 4:  YIFFT_bfly4_DIT(cpx_plan, outptr, f, m);    break;
        // case 5:  YIFFT_bfly5_DIT(cpx_plan, outptr, f, m);    break;
        // case 7:  YIFFT_bfly7_DIT(cpx_plan, outptr, f, m);    break;
        // default: YIFFT_bflyP_DIT(cpx_plan, outptr, f, m, p); break; 
    }
}

/* TODO: when do mixed-radix TEM, when radix in the middle can be further factorize
        is there a way to FFT it using DIT? 
        (for example: radix=[a,b,(c*d),b,a], do DIT on [c,d] instead of big P=c*d bfly) */

void YIFFT_cfft(
    const YIFFT_Plan cpx_plan, YIFFT_Complex *in, YIFFT_Complex *out)
{    
    YIFFT_ASSERT(cpx_plan, VOID);
    YIFFT_fft_work_DIT(cpx_plan, in, out, 1, cpx_plan->plan);
}

#else /* BUILD_CFFT */

/*  override YIFFT_alloc/YIFFT_free/YIFFT_cfft to some custom FFT 
    but one should keep function signature and functionality same
*/

YIFFT_Plan YIFFT_alloc(
    uint32_t NFFT, bool inverse, void *ext_mem, uint32_t *ext_mem_len)
{
    YIFFT_Plan cpx_plan = YIFFT_MALLOC(sizeof(struct YIFFT_Memory));
    cpx_plan->NFFT = NFFT;
    cpx_plan->inverse = inverse;
    if (ext_mem_len)
        *ext_mem_len = 0;
    return cpx_plan;
}

static void naive_FFT(
    bool inverse, uint32_t NFFT, YIFFT_Complex *in, YIFFT_Complex *out)
{
    YI_t two_pi_over_NFFT = YI_div( /* ±2π/NFFT */
        YI_mul((inverse) ? (YC(2)): (YC(-2)), YI_PI), YI_from_int(NFFT));
    for (int k = 0; k < NFFT; k++)
    {
        C_ASSIGN(out[k], 0, 0);
        for (int n = 0; n < NFFT; n++)
        {
            YIFFT_Complex w = {0,0};
            C_EXP(w, YI_mul(YI_mul(two_pi_over_NFFT, n),k));/* w = exp(±2jπ/NFFT*n*k)*/
            C_IADD_MUL(out[k], in[n], w);
        }
    }
    return;
}

void YIFFT_cfft(
    const YIFFT_Plan cpx_plan, YIFFT_Complex *in, YIFFT_Complex *out)
{    
    /* put your custom FFT here */
    naive_FFT(cpx_plan->inverse, cpx_plan->NFFT, in, out);
}

void YIFFT_free(YIFFT_Plan *cpx_plan_ptr)
{
    if ((cpx_plan_ptr) && (*cpx_plan_ptr))
    {
        free(*cpx_plan_ptr);
        *cpx_plan_ptr = NULL;
    }
}

#endif /* BUILD_CFFT */