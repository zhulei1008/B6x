#ifndef __YICHIP_MEMORY__
#define __YICHIP_MEMORY__

#include <stdlib.h>
#include <stdio.h>

#define YI_MALLOC(size) malloc(size); printf("Allocate memory: [  %d bytes ]\n", size);

#define YI_FREE(ptr) do { if((ptr)) { free((ptr)); (ptr) = NULL; }} while(0)

#endif /* __YICHIP_MEMORY__ */