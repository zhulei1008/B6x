#ifndef __TIMEIT_H__
#define __TIMEIT_H__

#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

double timeit(int N, int L, void (*fun_ptr)(void))
{
    double average = 0, std = 0;
    double *cpu_time_used = (double *)calloc(N, sizeof(double));
    clock_t start, end;
    double scale = 1;
    char unit = ' ';

    for (int i = 0; i < N; i++)
    {
        start = clock();
        for (int j = 0; j < L; j++)
        {
            /* test function */
            (*fun_ptr)();    
        }
        end = clock();
        if ((end - start) == 0)
        {
            printf(" L=%d too small, elapsed time less than clock()'s precision (1ms)\n",L);
            return -1;
        }
        cpu_time_used[i] = ((double)(end - start))/CLOCKS_PER_SEC/L;
        average += cpu_time_used[i];
    }

    average /= N;
    for (int i = 0; i < N; i++)
    {
        std += (cpu_time_used[i] - average)*(cpu_time_used[i] - average);
    }
    std = sqrt(std/N);

    if (average < 1e-6)
    {
        scale = 1e9;
        unit = 'n';
    }
    else if (average < 1e-3)
    {
        scale = 1e6;
        unit = 'u';
    }else if (average < 1)
    {
        scale = 1e3;
        unit = 'm';
    }
    average *= scale;
    std *= scale;

    printf("\n  timeit(N=%d,L=%d): avg: %7.3f %cs std: %7.3f %cs \n", 
        N, L, average, unit, std, unit);
    return average;
}

#endif /* __TIMEIT_H__ */