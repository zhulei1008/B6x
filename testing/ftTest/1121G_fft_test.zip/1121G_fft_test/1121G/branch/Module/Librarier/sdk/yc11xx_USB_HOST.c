#include "hwreg.h"
#include <string.h>
#include "yc11xx_usb_host.h"

#define USB_PID_OUT		0xe1
#define USB_PID_IN		0x69
#define USB_PID_SETUP	0x2d
#define USB_PID_DATA0	0xc3
#define USB_PID_DATA1	0x4b

#define SET_ADDRESS			0x0500
#define SET_CONFIGURATION		0x0900
#define GET_DESCRIPTOR			0x0680
#define GET_HID_DESCRIPTOR		0x0681
#define GET_HID_REPORT			0x01a1
#define GET_HID_IDLE				0x02a1
#define GET_HID_PROTOCOL		0x03a1
#define SET_HID_REPORT			0x0921
#define SET_HID_IDLE				0x0a21
#define SET_HID_PROTOCOL		0x0b21
#define GET_MAX_LUN			0xfea1
#define CLEAR_FEATURE_END               0x0102

#define DESC_DEVICE			0x0100
#define DESC_CONFIG			0x0200
#define DESC_STRING0		0x0300
#define DESC_STRING1		0x0301
#define DESC_STRING2		0x0302
#define DESC_HID				0x21
#define DESC_HID_RPT		0x2200

#define UFICMD_INQUIRY          0x12
#define UFICMD_READCAP          0x25
#define UFICMD_READ                     0x28
#define UFICMD_WRITE            0x2A
#define UFICMD_REQUEST_SENSE                    0x03
#define UFICMD_MODE_SENSE                       0x5A
#define UFICMD_TEST_UNIT_READY                  0


#define PWORD(buf, v)		*(buf) = v, *(buf + 1) = v >> 8
#define PINT(buf, v)			*((int*)(buf)) = v
#define INC_RPTR(x)				INCPTR(usb_rxptr, x, usb_rxbuf)


byte usb_desc[18], usb_config[60], usb_str0[4], usb_str1[100], usb_str2[100], usb_hidrpt[300];
byte usb_ep1[30], usb_ep2[50], cbs_buf[13];
byte ufi_buf[2048];
byte *usb_rxptr;
byte usb_lun;
int usb_setup_address, usb_in_ep, usb_out_ep;
int cbw_seq, cbw_trlen, ufi_ptr;
int ep_seq[3];
uint8_t lbas, startsector, fatsector, fatlen, rdirsector;
byte usb_rxbuf[300], usb_txbuf[64];


void usb_isr()
{
}

byte usb_getbyte ()
{
    byte t;

    t = *usb_rxptr;
    INC_RPTR(1);
    return t;
}

word usb_getword()
{
    return usb_getbyte() | (int)usb_getbyte() << 8;
}

void usbcpy(void *dst, int len)
{
    byte *d, *s;
    for(d = (byte *)dst; len > 0; len--, d++)
    {
        *d = *usb_rxptr;
        INC_RPTR(1);
    }
}


void usb_init()
{
    int i;
    CLRBIT(core_clkoff + 1, 4);
    HWRITEW(core_usb_rx_saddr, &usb_rxbuf);
    HWRITEW(core_usb_rxptr, &usb_rxbuf);
    HWRITEW(core_usb_rx_buflen,  sizeof(usb_rxbuf));
    HWRITEW(core_usb_tx_saddr(i), &usb_txbuf);
    HWRITEW(core_usb_status, 0xffff);
    HWRITE(core_usb_hmode, 0xd);
    HWRITE(core_usb_config, 0x3c);
    HWRITE(core_usb_int_mask, 0x17);
}


void usb_sof(int enable)
{
    HWRITE(core_usb_hmode, enable ? 0xbd : 0xd);
}

void usb_waitfs()
{
    int i;
    for(i = 0; i < 100; i++)
        while((HREAD(core_usb_txbusy) & 0x30) != 0x20) i = 0;

}

void usb_host_reset()
{
    volatile int i;
    SETBIT(core_usb_hmode, 2);

    //	delay_us(300000);
    SysTick_DelayUs(300000);
    CLRBIT(core_usb_hmode, 2);
    //	delay_us(300000);
    SysTick_DelayUs(300000);
    usb_setup_address = 0;
}

void usb_wait_tx(byte ep)
{
    while(HREAD(core_usb_txbusy) & 1 << ep);
}

int usb_wait_ack()
{
    int i;
    for(i = 0; i < 600; i++)
        if(HREADW(core_usb_status) & USB_STATUS_ACK)
        {
            HWRITEW(0x4ff4, 2);
            return 1;

        }
    return 0;
}

void __attribute__((noinline)) usb_host_tx_int()
{
    HWRITE(0x4ff0, 0xff);
    HWRITE(core_usb_trig, 1);
    //	delay_us(20);
    SysTick_DelayUs(20);
    HWRITE(core_usb_stall, 0x80);
    usb_wait_tx(0);
    HWRITE(0x4ff0, 0xfc);
}

void __attribute__((noinline)) usb_host_tx()
{
    prefetch(usb_host_tx_int, usb_host_tx);
    usb_host_tx_int();
}


int usb_rx(byte *buf, int maxlen)
{
    int i, len = 0;
    if(HREADW(core_usb_status) & USB_STATUS_RXREADY)
    {
        usb_rxptr = (byte *)(HREADW(core_usb_rxptr) | 0x10010000);
        len = usb_getword() & 0xfff;
        usbcpy(buf, maxlen < len ? maxlen : len);
        if((int)usb_rxptr & 1) INC_RPTR(1);
        HWRITEW(core_usb_rxptr, usb_rxptr);
        HWRITEW(core_usb_status, USB_STATUS_RXREADY);
    }

    return len;
}

byte usb_host_out(int address, int ep, int seq, byte *buf, int len)
{
    int i;
    byte status;
    PWORD(usb_txbuf, len + 3);
    usb_txbuf[2] = USB_PID_OUT;
    usb_txbuf[3] = address | ep << 7;
    usb_txbuf[4] = ep >> 1;
    usb_txbuf[5] = seq ? USB_PID_DATA1 : USB_PID_DATA0;
    if(len > 0)
    {
        memcpy(usb_txbuf + 6, buf, len);
    }
    HWRITEW(core_usb_status, USB_STATUS_ACK);
    for(i = 0; i < 500; i++)
    {
        usb_host_tx();
        HWRITEW(0x4ff4, 1);
        if(usb_wait_ack()) break;
        SysTick_DelayMs(1);

    }
}

int usb_host_in(int address, int ep, byte *buf, int maxlen)
{
    int i;
    uint16_t status;
    //	delay_us(200);
    SysTick_DelayUs(200);
    PWORD(usb_txbuf, 2);
    usb_txbuf[0] = 2;
    usb_txbuf[2] = USB_PID_IN;
    usb_txbuf[3] = address | ep << 7;
    usb_txbuf[4] = ep >> 1;
    HWRITEW(core_usb_status, USB_STATUS_RXREADY | USB_STATUS_ACK | USB_STATUS_NAK);
    usb_host_tx();
    for(i = 0; i < 300; i++)
    {
        status = HREADW(core_usb_status);
        if(buf && (status & USB_STATUS_NAK))
        {
            return 0;
        }
        if(status & (buf ? USB_STATUS_RXREADY : USB_STATUS_ACK))
            break;
    }
    return buf ? usb_rx(buf, maxlen) : HREADW(core_usb_status) & USB_STATUS_ACK;
}

int usb_host_in0(byte *buf, int maxlen)
{
    int ret;
    if((ret = usb_host_in(usb_setup_address, 0, buf, maxlen)) && buf)
        usb_host_out(usb_setup_address, 0, 1, 0, 0);
    else
        SysTick_DelayUs(100);
    //delay_us(100);
    return ret;
}

void __attribute__((noinline)) usb_host_setup(word request, word value, word index, word len)
{
    //	delay_us(200);
    SysTick_DelayUs(200);
    PWORD(usb_txbuf, 11);
    usb_txbuf[2] = USB_PID_SETUP;
    usb_txbuf[3] = usb_setup_address;
    usb_txbuf[4] = 0;
    usb_txbuf[5] = USB_PID_DATA0;
    PWORD(usb_txbuf + 6, request);
    PWORD(usb_txbuf + 8, value);
    PWORD(usb_txbuf + 10, index);
    PWORD(usb_txbuf + 12, len);
    HWRITE(core_usb_clear_toggle, 1);
    usb_host_tx();
    //while(HREAD(0x8080) != 2);
}

void usb_host_setup_reply(word request, word value, word index, word len, byte *buf, int maxlen)
{
    usb_host_setup(request, value, index, len);
    while(!usb_host_in0(buf, maxlen));
}

void usb_host_setup_cmd(word request, word value, word index, word len)
{
    usb_host_setup(request, value, index, len);
    while(!usb_host_in0(0, 0));
}

byte usb_host_wait_cbs_in(byte *buff, int datalen)
{
    byte cbs_buf[13];
    int len = 0, count = 0, ufi_ptr = 0;
    byte errorflag = 0;

    HWRITE(0x4ffd, ufi_ptr);
    HWRITE(0x4ffe, datalen);



    while(1)
    {
        if(ufi_ptr < datalen)
        {
            if((len = usb_host_in(usb_setup_address, usb_in_ep,  buff + ufi_ptr, 1024)))
            {

                ufi_ptr += len;
                count = 0;
            }
            if(len  == 0)
            {
                count++;

                if(count > 60000)
                {

                    usb_host_setup_cmd(CLEAR_FEATURE_END, 0, 0x80 | usb_in_ep, 0);
                    ufi_ptr = datalen;
                    errorflag = 0x55;
                    return 0;
                }
            }

        }
        else
        {
            len = usb_host_in(usb_setup_address, usb_in_ep,  cbs_buf, sizeof(cbs_buf));
            HWRITE(0x4ffb, len);
            HWRITE(0x4ffc, cbs_buf[12]);
            if((len == 13) && (cbs_buf[12] == 0))
            {

                if(errorflag == 0x55) return 0;
                return 1;
            }
            else
            {
                count++;
                if(count > 70000)
                {
                    usb_host_setup_cmd(CLEAR_FEATURE_END, 0, 0x80 | usb_in_ep, 0);
                    return 0;
                }
            }
        }
    }

    return 1;
}

byte usb_host_wait_cbs_out(byte *buff, int datalen)
{
    byte cbs_buf[13];
    int len = 0, count = 0, ufi_ptr = 0;

    while(1)
    {
        if(ufi_ptr < datalen)
        {
            usb_host_out(usb_setup_address, usb_out_ep, ep_seq[2], buff, 64);
            ep_seq[2] = !ep_seq[2];
            ufi_ptr += 64;
            buff += 64;
        }
        else
        {
            len = usb_host_in(usb_setup_address, usb_in_ep,  cbs_buf, sizeof(cbs_buf));
            if((len == 13) && (cbs_buf[12] == 0))
            {
                //MyPrintf("second test\r\n");
                return 1;
            }
            else
            {
                count++;

                //MyPrintf("second test error len=%x\r\n",len);

                if(count > 500)
                {
                    //MyPrintf("second test error max\r\n");
                    usb_host_setup_cmd(CLEAR_FEATURE_END, 0, 0x80 | usb_in_ep, 0);
                    return 0;
                }
            }
        }
    }
    return 1;
}

byte usb_host_cbw(byte *buffer, int trlen, byte *cb, int len)
{
    int i;
    byte cbuf[31];
    PINT(cbuf, 0x43425355);
    PINT(cbuf + 4, cbw_seq);
    PINT(cbuf + 8, trlen);
    cbuf[12] = trlen ? 0x80 : 0;
    for(i = 13; i < 31; i++)
        cbuf[i] = 0;
    cbuf[14] = len;
    memcpy(cbuf + 15, cb, len);
    usb_host_out(usb_setup_address, usb_out_ep, ep_seq[2], cbuf, 31);
    ep_seq[2] = !ep_seq[2];
    cbw_seq++;
    cbw_trlen = trlen;
    ufi_ptr = 0;
    return usb_host_wait_cbs_in(buffer, trlen);
}


void usb_host_ufi_inquiry()
{
    byte ufi_buf[100];
    byte cmd[6];
    cmd[0] = UFICMD_INQUIRY;
    cmd[1] = cmd[2] = cmd[3] = cmd[5] = 0;
    cmd[4] = 0x24;
    usb_host_cbw(ufi_buf, 0x24, cmd, sizeof(cmd));
}

void usb_host_ufi_read_capacity()
{
    byte ufi_buf[18];
    byte cmd[10];
    cmd[0] = UFICMD_READCAP;
    memset(cmd + 1, 0, 9);
    usb_host_cbw(ufi_buf, 8, cmd, sizeof(cmd));
    HWRITE(0x4fff, 0x2b);
}

void usb_host_ufi_request_sense()
{
    byte ufi_buf[18];
    byte cmd[5];
    cmd[0] = UFICMD_REQUEST_SENSE;
    memset(cmd + 1, 0, 4);
    cmd[4] = 0X12;
    usb_host_cbw(ufi_buf, 0X12, cmd, sizeof(cmd));
}

void usb_host_ufi_test_unit_ready()
{
    byte ufi_buf[18];
    byte cmd[6];
    cmd[0] = UFICMD_TEST_UNIT_READY;
    memset(cmd + 1, 0, 5);
    usb_host_cbw(ufi_buf, 0, cmd, sizeof(cmd));
}

void usb_host_ufi_mode_sense()
{
    byte ufi_buf[18];
    byte cmd[5];

    cmd[0] = UFICMD_MODE_SENSE;
    memset(cmd + 1, 0, 4);

    cmd[4] = 0X12;
    usb_host_cbw(ufi_buf, 0X12, cmd, sizeof(cmd));
}

byte usb_host_ufi_first_read(unsigned char *buffer, unsigned int sector, unsigned char count)
{
    byte cmd[10];
    int i;
    byte cbuf[31];
    int trlen;

    //MyPrintf("buffer=%x,sector= %x,count=%x\r\n",buffer,sector,count);
    usb_host_ufi_test_unit_ready();

    cmd[0] = UFICMD_READ;
    memset(cmd + 1, 0, 9);
    cmd[2] = sector >> 24, cmd[3] = sector >> 16, cmd[4] = sector >> 8, cmd[5] = sector;
    cmd[8] = count;

    trlen = count * 512;
    PINT(cbuf, 0x43425355);
    PINT(cbuf + 4, cbw_seq);
    PINT(cbuf + 8, trlen);
    cbuf[12] = trlen ? 0x80 : 0;
    for(i = 13; i < 31; i++)
        cbuf[i] = 0;
    cbuf[14] = sizeof(cmd);
    memcpy(cbuf + 15, cmd, sizeof(cmd));
    if(usb_host_out(usb_setup_address, usb_out_ep, ep_seq[2], cbuf, 31) == 0)
    {
        //	     MyPrintf("host out timeout\r\n");
        usb_host_setup_cmd(CLEAR_FEATURE_END, 0, usb_out_ep, 0);
        return 0;
    }
    ep_seq[2] = !ep_seq[2];
    cbw_seq++;

    return(usb_host_wait_cbs_in(buffer, trlen));
}

byte usb_host_ufi_read(unsigned char *buffer, unsigned int sector, unsigned char count)
{
    byte cmd[10];
    int i;
    byte cbuf[31];
    int trlen;

    //MyPrintf("buffer=%x,sector= %x,count=%x\r\n",buffer,sector,count);
    usb_host_ufi_test_unit_ready();

    cmd[0] = UFICMD_READ;
    memset(cmd + 1, 0, 9);
    cmd[2] = sector >> 24, cmd[3] = sector >> 16, cmd[4] = sector >> 8, cmd[5] = sector;
    cmd[8] = count;

    trlen = count * 512;
    PINT(cbuf, 0x43425355);
    PINT(cbuf + 4, cbw_seq);
    PINT(cbuf + 8, trlen);
    cbuf[12] = trlen ? 0x80 : 0;
    for(i = 13; i < 31; i++)
        cbuf[i] = 0;
    cbuf[14] = sizeof(cmd);
    memcpy(cbuf + 15, cmd, sizeof(cmd));
    if(usb_host_out(usb_setup_address, usb_out_ep, ep_seq[2], cbuf, 31) == 0)
    {
        //	     MyPrintf("host out timeout\r\n");
        usb_host_setup_cmd(CLEAR_FEATURE_END, 0, usb_out_ep, 0);
        return 0;
    }
    ep_seq[2] = !ep_seq[2];
    cbw_seq++;

    return(usb_host_wait_cbs_in(buffer, trlen));
}

byte usb_host_read(unsigned char *buffer, unsigned int sector, unsigned char count)
{
    byte i;

    for(i = 0; i < 40; i++)
    {
        if(usb_host_ufi_read(buffer, sector, count) == 0)
        {
            usb_host_ufi_request_sense();
            //					MyPrintf("read_retry\r\n");
        }
        else
            break;
    }
    //	if(i)	MyPrintf("usb_host_read i=%x\r\n",i);
    if(i == 40)
        return 0;
    else
        return 1;
}

byte usb_host_ufi_write(unsigned char *buffer, unsigned int sector, unsigned char count)
{
    byte cmd[10];
    int i;
    byte cbuf[31];
    int trlen;

    //    MyPrintf("write sector= %x\r\n",sector);
    cmd[0] = UFICMD_WRITE;
    memset(cmd + 1, 0, 9);
    cmd[2] = sector >> 24, cmd[3] = sector >> 16, cmd[4] = sector >> 8, cmd[5] = sector;
    cmd[8] = count;

    trlen = count * 512;
    PINT(cbuf, 0x43425355);
    PINT(cbuf + 4, cbw_seq);
    PINT(cbuf + 8, trlen);
    cbuf[12] = 0;
    for(i = 13; i < 31; i++)
        cbuf[i] = 0;
    cbuf[14] = count;
    memcpy(cbuf + 15, cmd, sizeof(cmd));
    usb_host_out(usb_setup_address, usb_out_ep, ep_seq[2], cbuf, 31);
    ep_seq[2] = !ep_seq[2];
    cbw_seq++;

    return(usb_host_wait_cbs_out(buffer, trlen));
}

byte usb_host_write(unsigned char *buffer, unsigned int sector, unsigned char count)
{
    byte i;

    for(i = 0; i < 20; i++)
    {
        if(usb_host_ufi_write(buffer, sector, count) == 0)
        {
            usb_host_ufi_request_sense();
            //					MyPrintf("write_retry\r\n");
        }
        else
            break;
    }
    //	if(i)	MyPrintf("usb_host_write i=%x\r\n",i);
    if(i == 20)
        return 0;
    else
        return 1;
}



void usb_main()
{

    int i;
    volatile byte *st = (byte *)0x10011000;
    int *addr = (int *)0x10011004;
    *st = 0;
    *addr = 5;

    usb_init();
    usb_sof(0);
    usb_waitfs();
    MyPrintf("USB HID demo!\r\n");
    usb_host_reset();
    usb_sof(1);
    HWRITEW(core_usb_status, USB_STATUS_ACK);
    //	delay_us(100000);
    SysTick_DelayUs(100000);
    MyPrintf("USB HID demo!\r\n");
    //	while(HREAD(0x8080) != 1);

    usb_host_setup_reply(GET_DESCRIPTOR, DESC_DEVICE, 0, 18, usb_desc, sizeof(usb_desc));
    //	while(HREAD(0x8080) != 3);
    MyPrintf("USB HID demo!\r\n");
    MyPrintf("USB HID demo!\r\n");
    MyPrintf("USB HID demo!\r\n");
    usb_host_setup_cmd(SET_ADDRESS, 6, 0, 0);
    usb_setup_address = 6;
    usb_host_setup_reply(GET_DESCRIPTOR, DESC_DEVICE, 0, 18, usb_desc, sizeof(usb_desc));
    usb_host_setup_reply(GET_DESCRIPTOR, DESC_CONFIG, 0, 9, usb_config, sizeof(usb_config));
    usb_host_setup_reply(GET_DESCRIPTOR, DESC_CONFIG, 0, usb_config[2], usb_config, sizeof(usb_config));
    usb_host_setup_reply(GET_DESCRIPTOR, DESC_STRING0, 0, 255, usb_str0, sizeof(usb_str0));

    for (int w = 0; w < 20; w++)
    {
        ++w;
        usb_host_setup_reply(GET_MAX_LUN, 0, 0, 1, &usb_lun, 1);
    }
    //	while(1);

    usb_host_setup_reply(GET_DESCRIPTOR, DESC_STRING2, 0, 255, usb_str2, sizeof(usb_str2));
    usb_host_setup_reply(GET_DESCRIPTOR, DESC_STRING1, 0, 255, usb_str1, sizeof(usb_str1));
    usb_host_setup_cmd(SET_CONFIGURATION, 1, 0, 0);


    usb_in_ep = 0x82;
    usb_out_ep = 0x01;

    cbw_seq = 1;
    ep_seq[2] = 0;
    unsigned int sector;
    usb_host_ufi_inquiry();
    usb_host_ufi_read_capacity();
    lbas = BL(ufi_buf);
    while(1)
    {
        for(i = 0; i < 20; i++)
        {
            if(usb_host_ufi_read(ufi_buf, 0, 1) == 0)
            {
                usb_host_ufi_request_sense();
            }
            else
                break;
        }
        if (ufi_buf[0] == 0xE9 || ufi_buf[0] == 0xEB || ufi_buf[0] == 0xE8)
        {
            //MyPrintf("\r\n data read finsih\r\n");
            while(1);
        }
        sector = ufi_buf[0x1c6] + (ufi_buf[0x1c7] << 8) + (ufi_buf[0x1c8] << 16) + (ufi_buf[0x1c9] << 24)
                 memset(ufi_buf, 0, 512);
        for(i = 0; i < 20; i++)
        {
            if(usb_host_ufi_read(ufi_buf, sector, 1) == 0)
            {
                usb_host_ufi_request_sense();
            }
            else
                break;
        }
    }
}

