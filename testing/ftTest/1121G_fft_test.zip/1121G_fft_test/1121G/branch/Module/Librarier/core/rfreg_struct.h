#ifndef __RFREG_STRUCT_H
#define __RFREG_STRUCT_H

#define _IO	volatile
#define _O	volatile
#define _I	volatile


typedef struct
{
    _IO unsigned char da_codec_reg_pwr_sel		: 1;	//RW 0		//audio 3 ldo(adcldo/dacldo/hpldo) avss17 voltage selected, 1: when codec power supply> 3.6V; 0: when codec power supply <3.6V
    _IO unsigned char da_adc_pwrsw_en			: 1;	//RW 0		//audio adc power switch enable, 1: used power supply outside(codec_avdd), 0: used adc ldo inside
    _IO unsigned char da_ldo_daccore_en			: 1;	//RW 0		//audio dac core ldo enalbe
    _IO unsigned char da_ldohp_dacdrv_en		: 1;	//RW 0		//audio pa ldo enalbe
    _IO unsigned char da_adc_reg_en				: 1;	//RW 0		//audio adc ldo enable
    _IO unsigned char da_mic_reg_en				: 1;	//RW 0		//pga/micbias ldo enable
} __attribute__((packed)) codec_ldo_en0RegDef;		//CORE_codec_ldo_en0	0x8b00

typedef struct
{
    _IO unsigned char rg_mic_hvreg_vc			: 2;	//RW 1		//pga/micbias ldo voltage control
    _IO unsigned char rg_adc_reg_excap_en		: 1;	//RW 0		//audio adc ldo mode selected, 1: with external capacitor, 0: capless
    _IO unsigned char rg_adc_reg_vol_sel		: 3;	//RW 2		//audio adc ldo output voltage selected
    _IO unsigned char rg_adc_reg_ibias_sel		: 2;	//RW 1		//audio adc ldo bias current selected
} __attribute__((packed)) codec_ldo_cfg0RegDef;		//CORE_codec_ldo_cfg0	0x8b01

typedef struct
{
    _IO unsigned char rg_ibsel_hpldo			: 2;	//RW 1		//audio pa ldo bias current selected
    _IO unsigned char rg_ldo_excap_en			: 1;	//RW 0		//audio dac ldo mode selected, 1: with external capacitor, 0: capless
    _IO unsigned char rg_ldo_voutsel			: 3;	//RW 2		//audio dac ldo  output voltage selected
    _IO unsigned char rg_ibsel_ldo				: 2;	//RW 0		//audio dac ldo bias current selected
} __attribute__((packed)) codec_ldo_cfg1RegDef;		//CORE_codec_ldo_cfg1	0x8b02

typedef struct
{
    _IO unsigned char rg_ldohp_byp				: 1;	//RW 0		//audio pa ldo bypass enable
    _IO unsigned char rg_ldohp_excap_en			: 1;	//RW 0		//audio pa ldo external capacitor load enable: 0 wo external cap,1 wi external cap
    _IO unsigned char rg_ldohp_voutsel			: 3;	//RW 2		//audio pa ldo output voltage selected
    _IO unsigned char rg_ldohp_ocp_sel			: 1;	//RW 0		//audio pa ldo over current portection threshold selected: 0=80mA,1= 200mA
} __attribute__((packed)) codec_ldo_cfg2RegDef;		//CORE_codec_ldo_cfg2	0x8b04

typedef struct
{
    _IO unsigned char da_vmid_discharge			: 1;	//RW 1		//audio voltage reference discharge enable
    _IO unsigned char da_vmid_en				: 1;	//RW 0		//audio voltage reference enable, 1:charge to vmid, 0:discharge to gnd
    _IO unsigned char da_vmid_bias_en			: 1;	//RW 0		//audio reference generator bias enable
    _IO unsigned char da_vmid_lvd_en			: 1;	//RW 0		//audio power supply low voltage detect enable
    _IO unsigned char da_vmid_extcap_en			: 1;	//RW 0		//audio voltage reference operation mode selected, 1: with external capacitor; 0: without external capacitor
    _IO unsigned char da_vmid_bg_en				: 1;	//RW 0		//audio bandgap enable
    _IO unsigned char res                       : 2; //RW 0      //res
} __attribute__((packed)) codec_vmid_en0RegDef;		//CORE_codec_vmid_en0	0x8b05

typedef struct
{
    _IO unsigned char rg_vmid_isel_lsb			: 5;	//RW 0		//audio voltage reference charge/discharge current selection,coarse bit lsb
    _IO unsigned char rg_vmid_lvdsel			: 3;	//RW 0		//audio power supply low voltage detect threshold selected
} __attribute__((packed)) codec_vmid_cfg0RegDef;		//CORE_codec_vmid_cfg0	0x8b06

typedef struct
{
    _IO unsigned char rg_vmid_isel_msb			: 5;	//RW 0		//audio voltage reference charge/discharge current selection,coarse bit msb
    _IO unsigned char rg_vmid_discharge_cc		: 1;	//RW 1		//audio voltage reference discharge slew rate limited enable
    _IO unsigned char rg_vmid_discharge_auto	: 1;	//RW 1		//audio voltage reference auto discharge enable
    _IO unsigned char rg_vmid_lvd_vrefsel		: 1;	//RW 0		//audio power supply low voltage detect source selected, 1: codec_avdd; 0: buck output
} __attribute__((packed)) codec_vmid_cfg1RegDef;		//CORE_codec_vmid_cfg1	0x8b07

typedef struct
{
    _IO unsigned char rg_vmid_bg_fastsetting	: 1;	//RW 0		//audio bandgap start up fastsetting enable
    _IO unsigned char  rg_vmid_bg_man_st		: 1;	//RW 0		//audio bandgap manual start up enable
    _IO unsigned char rg_vmid_vref_sel			: 1;	//RW 1		//audio voltage reference mode selected, 1:from bandgap; 0:from codec_avdd through resistor divider
    _IO unsigned char rg_vmid_iadjust			: 4;	//RW 0		//audio voltage reference charge/discharge current selection,fine
    _IO unsigned char res                       : 1; //
} __attribute__((packed)) codec_vmid_cfg2RegDef;		//CORE_codec_vmid_cfg2	0x8b08

typedef struct
{
    _IO unsigned char rg_vmid_bg_trim			: 4;	//RW 4		//audio bandgap output voltage trimming
    _IO unsigned char rg_vmid_bg_rct			: 4;	//RW 8		//audio bandgap CTAT current trimming
} __attribute__((packed)) codec_vmid_cfg3RegDef;		//CORE_codec_vmid_cfg3	0x8b09

typedef struct
{
    _I unsigned char ad_vmid_low_12				: 1;	//RO nan		//audio reference discharging low indicator
    _I unsigned char ad_vmid_zero_12			: 1;	//RO nan		//audio reference discharging to ground finished indicator
    _I unsigned char ad_vmid_ok_12				: 1;	//RO nan		//audio reference charging finished indicator
    _I unsigned char ad_vmid_lvd_12				: 1;	//RO nan		//audio power supply low voltage indicator output
} __attribute__((packed)) codec_vmid_indRegDef;		//CORE_codec_vmid_ind	0x8b0a

typedef struct
{
    _IO unsigned char da_pga_dcoc_en			: 1;	//RW 0		//audio pga dc offset calibration enable
    _IO unsigned char da_pga_gm_en				: 1;	//RW 0		//audio pga gm stage enable
    _IO unsigned char da_pga_gm_fst_en			: 1;	//RW 0		//audio pga gm stage fastsetting enable
    _IO unsigned char da_pga_cz_en				: 1;	//RW 0		//audio pga crossing zero detected enable
    _IO unsigned char da_pga_gain_boost_en		: 1;	//RW 0		//audio pga gainboost enable, 1: +6dB; 0: +0dB
    _IO unsigned char da_sdm_dem_en				: 1;	//RW 1		//audio adc dynamic element match enable
    _IO unsigned char da_sdm_en					: 1;	//RW 0		//audio adc enable
    _IO unsigned char da_aadc_top_ibias_en		: 1;	//RW 0		//audio adc/pga bias current enable
} __attribute__((packed)) au_adc_en0RegDef;		//CORE_au_adc_en0	0x8b0b

typedef struct
{
    _IO unsigned char da_micbias_en				: 1;	//RW 0		//micbias generator enable
    _IO unsigned char da_pga_en					: 1;	//RW 0		//audio pga enable
    _IO unsigned char da_pga_diff_en			: 1;	//RW 0		//audio pga fully differential input enable, 1: differential input, 0: single ended input
    _IO unsigned char da_pga_rbias_en			: 1;	//RW 0		//audio pga inchip resistor(connect to micbias) path enable
} __attribute__((packed)) au_adc_en1RegDef;		//CORE_au_adc_en1	0x8b0c

typedef struct
{
    _IO unsigned char rg_sdm_cmp_isel			: 2;	//RW 1		//audio adc comparator bias current selected
    _IO unsigned char rg_sdm_ota1_isel			: 2;	//RW 1		//audio adc 1st integrator opa bias current selected
    _IO unsigned char rg_sdm_ota2_isel			: 2;	//RW 1		//audio adc 2nd integrator opa bias current selected
    _IO unsigned char rg_sdm_ref_isel			: 2;	//RW 1		//audio adc reference buffer bias current selected
} __attribute__((packed)) au_adc_cfg0RegDef;		//CORE_au_adc_cfg0	0x8b0d

typedef struct
{
    _IO unsigned char rg_pga_opa2_ibias_sel		: 2;	//RW 2		//audio pga signle ended opa bias current selected
    _IO unsigned char rg_pga_opa1_ibias_sel		: 2;	//RW 2		//audio pga fully differential opa bias current selected
    _IO unsigned char rg_pga_cz_ibias_sel		: 2;	//RW 1		//audio pga crossing-zero comparator bias current selected
    _IO unsigned char rg_pga_gm_ibias_sel		: 2;	//RW 1		//audio pga gm stage bias current selected
} __attribute__((packed)) au_adc_cfg1RegDef;		//CORE_au_adc_cfg1	0x8b0e

typedef struct
{
    _IO unsigned char rg_pga_gc					: 5;	//RW 4		//audio pga voltage gain control
    _IO unsigned char rg_auadc_clk_dly			: 3;	//RW 0		//audio adc clkin delay selected
} __attribute__((packed)) au_adc_cfg3RegDef;		//CORE_au_adc_cfg3	0x8b10

typedef struct
{
    _IO unsigned char rg_pga_rcfilt_coarse		: 2;	//RW 1		//pga capless input rc filter bandwitch coarse trimming selected
    _IO unsigned char rg_pga_dcoc_ibc			: 2;	//RW 1		//audio pga dc offset calibration bias current selected
} __attribute__((packed)) au_adc_cfg4RegDef;		//CORE_au_adc_cfg4	0x8b11

typedef struct
{
    _IO unsigned char rg_micbias_rc				: 3;	//RW 2		//micbias inchip resistor(connect to pga) control
    _IO unsigned char rg_micbias_ibias_sel		: 2;	//RW 1		//micbias bias current selected
    _IO unsigned char rg_pga_rcfilt_fine		: 3;	//RW 2		//pga capless input rc filter bandwitch fine trimming selected
} __attribute__((packed)) au_adc_cfg5RegDef;		//CORE_au_adc_cfg5	0x8b12

typedef struct
{
    _IO unsigned char rg_micbias_vc				: 6;	//RW 3a		//micbias output voltage control
    _IO unsigned char rg_micbias_mode			: 2;	//RW 0		//micbias operation mode selected
} __attribute__((packed)) au_adc_cfg6RegDef;		//CORE_au_adc_cfg4	0x8b13

typedef struct
{
    _IO unsigned char da_drv_single_end_l_en	: 1;	//RW 0		//audio pa single ended(virtual differential)output enable,left channel, 1:single ended output; 0:differential output
    _IO unsigned char da_drv_single_end_r_en	: 1;	//RW 0		//audio pa single ended(virtual differential)output enable,right channel, 1:single ended output; 0:differential output
    _IO unsigned char da_dac_ibias_en			: 1;	//RW 0		//audio dac current bias generator enable
    _IO unsigned char da_dcoc_pgapath_l_en		: 1;	//RW 0		//audio pa dc offset cancelled pga feedback path enable,left channel
    _IO unsigned char da_dcoc_pgapath_r_en		: 1;	//RW 0		//audio pa dc offset cancelled pga feedback path enable,right channel
    _IO unsigned char da_dcoc_pgapath_short		: 1;	//RW 0		//audio pga input short enable, effetive when  da_dcoc_pgapath_r/l_en=1
    _IO unsigned char da_dcoc_sarpath_en		: 1;	//RW 0		//audio pa dc offset cancelled saradc measure path enable,right channel
} __attribute__((packed)) au_dac_en0RegDef;		//CORE_au_dac_en0	0x8b14

typedef struct
{
    _IO unsigned char da_vrefgen_drv_r_en		: 1;	//RW 0		//audio pa vcm opa enable,right channel
    _IO unsigned char da_vrefgen_dac_r_en		: 1;	//RW 0		//audio dac reference generator enalbe, right channel
    _IO unsigned char da_dac_mute_r_en			: 1;	//RW 1		//audio dac mute enable,right channel(already deleted)
    _IO unsigned char da_drv_mute_r_en			: 1;	//RW 1		//audio pa mute enable,right channel
    _IO unsigned char da_drv_ostg_cc_r_en		: 1;	//RW 1		//audio pa output stage pulldown slew rate limited enable,right channel
    _IO unsigned char da_drv_ostg_r_en			: 1;	//RW 1		//audio pa output stage enable, 1: normal, 0:hpoutrn/hpoutrp pulldown to gnd,right channel
    _IO unsigned char da_dac_int_r_en			: 1;	//RW 0		//audio dac core enalbe,right channel
    _IO unsigned char da_drv_r_en				: 1;	//RW 0		//audio pa enalbe,right channel
} __attribute__((packed)) au_dac_en1RegDef;		//CORE_au_dac_en1	0x8b15

typedef struct
{
    _IO unsigned char da_vrefgen_drv_l_en		: 1;	//RW 0		//audio pa vcm opa enable,left channel
    _IO unsigned char da_vrefgen_dac_l_en		: 1;	//RW 0		//audio dac vcm/vrefp opa enable,left channel
    _IO unsigned char da_dac_mute_l_en			: 1;	//RW 1		//audio dac mute enable,left channel(already deleted)
    _IO unsigned char da_drv_mute_l_en			: 1;	//RW 1		//audio pa mute enable,left channel
    _IO unsigned char da_drv_ostg_cc_l_en		: 1;	//RW 1		//audio pa output stage pulldown slew rate limited enable,left channel
    _IO unsigned char da_drv_ostg_l_en			: 1;	//RW 1		//audio pa output stage enable, 1: normal, 0:hpoutrn/hpoutrp pulldown to gnd,left channel
    _IO unsigned char da_dac_int_l_en			: 1;	//RW 0		//audio dac core enalbe,left channel
    _IO unsigned char da_drv_l_en				: 1;	//RW 0		//audio pa enalbe,left channel
} __attribute__((packed)) au_dac_en2RegDef;		//CORE_au_dac_en2	0x8b16

typedef struct
{
    _IO unsigned char da_input_sel_l			: 2;	//RW 0		//audio pa input path selected, 01:dacin; 00: all disable, left channel
    _IO unsigned char da_input_sel_r			: 2;	//RW 0		//audio pa input path selected,  01:dacin; 00: all disable, right channel
    _IO unsigned char da_linein_l_en			: 1;	//RW 0		//audio pa linein input path(signle ended input) enable,left channel
    _IO unsigned char da_linein_r_en			: 1;	//RW 0		//audio pa linein input path(signle ended input) enable,right channel
    _IO unsigned char da_drv_r1_open			: 1;	//RW 1		//audio pa input resistor open (disconnect)
    _IO unsigned char da_drv_rf_open			: 1;	//RW 0		//audio pa feedback resistor open (disconnect)
} __attribute__((packed)) au_dac_en3RegDef;		//CORE_au_dac_en3	0x8b17

typedef struct
{
    _IO unsigned char rg_ibsel_dac				: 3;	//RW 2		//audio dac core bias current selected
    _IO unsigned char rg_ibsel_vref4u			: 3;	//RW 2		//audio dac vrefp generator bias current selected
    _IO unsigned char rg_ibsel_vref2u			: 2;	//RW 0		//audio dac/pa vcm generator bias current selected
} __attribute__((packed)) au_dac_cfg0RegDef;		//CORE_au_dac_cfg0	0x8b18

typedef struct
{
    _IO unsigned char rg_gc_dacin_l				: 2;	//RW 0		//audio dac gain control for left channel
    _IO unsigned char rg_gc_dacin_r				: 2;	//RW 0		//audio dac gain control for right channel
    _IO unsigned char rg_vrefp_res_sel			: 1;	//RW 0		//audio dac vrefp generator resistor selected
    _IO unsigned char rg_ibsel_drv				: 3;	//RW 2		//audio pa bias current selected
} __attribute__((packed)) au_dac_cfg1RegDef;		//CORE_au_dac_cfg1	0x8b19

typedef struct
{
    _IO unsigned char rg_tstdac_sel				: 2;	//RW 0		//audio dac test path selected
    _IO unsigned char rg_gc_linein_l			: 3;	//RW 2		//audio pa linein path gain control,left channel
    _IO unsigned char rg_gc_linein_r			: 3;	//RW 2		//audio pa linein path gain control,right channel
} __attribute__((packed)) au_dac_cfg2RegDef;		//CORE_au_dac_cfg2	0x8b1a

typedef struct
{
    _IO unsigned char rg_vrefgen_ccsel_int      : 1; //RW 0      //audio dac vrefp opa miller compensation capacitor selected
    _IO unsigned char rg_vrefgen_ccsel_intopa   : 1; //RW 1      //audio dac vcm opa miller compensation capacitor selected
    _IO unsigned char rg_vrefgen_ccsel_drv      : 1; //RW 1      //audio pa vcm opa miller compensation capacitor selected
    _IO unsigned char rg_drv_ccn_sel            : 2; //RW 0      //audio pa nmos (pull)miller compensation capacitor selected
    _IO unsigned char rg_drv_ccp_sel            : 2; //RW 3      //audio pa pmos(push) miller compensation capacitor selected
    _IO unsigned char rg_tstdac_en              : 1; //RW 0      //audio dac test path enable
} __attribute__((packed)) au_dac_cfg3RegDef;    //CORE_au_dac_cfg3  0x8b1b

#endif
