/*
		 * Copyright (c) 2006-2021, YICHIP Development Team
		 * @file     YC_STM32_iwdg.c
		 * @brief    source file for setting wdg
		 *
		 * Change Logs:
		 * Date           Author      	Version        Notes
		 * 2021-02-08     Yichip 	V1.0.0         the first version
		 */
/* Includes ------------------------------------------------------------------*/
#include "yc11xx_iwdg.h"
#include "reg_addr.h"
#include "MyPrintf.h"
IWDG_InitTypeDef *gpWdtInit;
/* ---------------------- IWDG registers bit mask ----------------------------*/

/**
 * @brief  Initialize the WDT.
 * @param  WDTx: Select the WDT.WDT,WDT2
 *         mode: Reset and interrupt modes.RESET_MODE,INTR_MODE
 *         setload: Different time intervals.
 * @return None
 */
void IWDG_Init(IWDG_InitTypeDef *IWDG_init_struct)
{
    uint8_t en_rst;

    gpWdtInit = IWDG_init_struct;

    en_rst = HREAD(CORE_SYSTEM_CTRL);
    //	MyPrintf("en_rest = %x \r\n",en_rst);
    //	MyPrintf("mode = %x \r\n",IWDG_init_struct->mode);
    if (RESET_MODE == IWDG_init_struct->mode)
    {
        en_rst &= ~(BIT_1);
        if (WDT == IWDG_init_struct->WDTx)
            HWRITE(CORE_WATCH_DOG, IWDG_init_struct->setload);
        else if (WDT2 == IWDG_init_struct->WDTx)
            HWRITE(CORE_WATCH_DOG2, IWDG_init_struct->setload);
    }
    else if (INTR_MODE == IWDG_init_struct->mode)
    {
        en_rst |= BIT_1;
        if (WDT == IWDG_init_struct->WDTx)
            HWRITE(CORE_WATCH_DOG, IWDG_init_struct->setload);
        else if (WDT2 == IWDG_init_struct->WDTx)
            HWRITE(CORE_WATCH_DOG2, IWDG_init_struct->setload);
    }
    HWRITE(CORE_SYSTEM_CTRL, en_rst);
    //	MyPrintf("en_rest22 = %x \r\n",HREAD(CORE_SYSTEM_CTRL));
}

/**
 * @brief  set IWDG Reload value
 * @param  Reload:Invalid parameter
 * @return None
 */
void IWDG_SetReload(uint16_t Reload)
{
    IWDG_InitTypeDef *IWDG_init_struct = gpWdtInit;
    if(IWDG_init_struct == 0)
    {
        return;
    }
    IWDG_Enable(IWDG_init_struct);
    if (WDT == IWDG_init_struct->WDTx)
        HWRITE(CORE_WATCH_DOG, IWDG_init_struct->setload);
    else if (WDT2 == IWDG_init_struct->WDTx)
        HWRITE(CORE_WATCH_DOG2, IWDG_init_struct->setload);
}

/**
 * @brief  feeding watchdog.
 * @param  None
 * @return None
 */
void IWDG_ReloadCounter(void)
{
    IWDG_SetReload(0);
}

/**
 * @brief  enable WDT.
 * @param  IWDG_init_struct:init
 * @return None
 */
void IWDG_Enable(IWDG_InitTypeDef *IWDG_init_struct)
{
    uint32_t Temp = 0;
    Temp = CoreReg_LpmGetIceWdtLongRst();
    //    Temp = HREAD(0x83a8);
    if (WDT2 == IWDG_init_struct->WDTx)
    {
        Temp |= BIT2;//open CM0 WDT
    }
    else if (WDT == IWDG_init_struct->WDTx)
    {
        Temp |= BIT1;//open BT WDT
    }
    CoreReg_LpmWrite2IceWdtLongRst(Temp);
}
/**
 * @brief  disable WDT.
 * @param  IWDG_NumTypeDef:WDTx
 * @return None
 */
void IWDG_Disable(IWDG_NumTypeDef WDTx)
{
    uint32_t Temp;
    Temp = CoreReg_LpmGetIceWdtLongRst();
    if (WDT2 == WDTx)
    {
        Temp &= ~(BIT2);//open CM0 WDT
    }
    else if (WDT == WDTx)
    {
        Temp &= ~(BIT1);//open BT WDT
    }
    CoreReg_LpmWrite2IceWdtLongRst(Temp);
}

/**
 * @brief  start watchdog.
 * @param  WDT_init_struct:init
 * @return None
 */
void IWDG_Start(IWDG_InitTypeDef *IWDG_init_struct)
{
    //	IWDG_ReloadCounter();
    //	IWDG_Disable(WDT2);
    //	WDT_NVIC_Clear(WDT2);
    IWDG_Disable(IWDG_init_struct->WDTx);
    WDT_NVIC_Clear(IWDG_init_struct->WDTx);

    IWDG_Init(IWDG_init_struct);
    //	while(HREAD(0x8083)!=0x01);
    IWDG_Enable(IWDG_init_struct);
}


/**
  * @brief  Checks whether the specified IWDG flag is set or not.
  * @param  IWDG_FLAG: specifies the flag to check.
  *   This parameter can be one of the following values:
  *     @arg IWDG_FLAG_PVU: Prescaler Value Update on going
  *     @arg IWDG_FLAG_RVU: Reload Value Update on going
  * @return The new state of IWDG_FLAG (SET or RESET).
  */
void WDT_NVIC_Clear(IWDG_NumTypeDef WDTx)
{
    uint8_t wdt_en;
    wdt_en = HREAD((CORE_SYS_EVENT_CLEAN));
    if (WDT2 == WDTx)
    {
        wdt_en &= 0xfd;//open CM0 WDT
    }
    else if (WDT == WDTx)
    {
        wdt_en &= 0xfe;//open BT WDT
    }
    HWRITE((CORE_SYS_EVENT_CLEAN), wdt_en);
    wdt_en = HREAD((CORE_SYS_EVENT_CLEAN));
}

/**
  * @brief  Watchdog interrupt mode enable.
  * @param  None
  * @return None
  */

void WDT_NVIC_Out(void)
{
    uint8_t Enrst;

    Enrst = HREAD(CORE_SYSTEM_CTRL);

    Enrst &= ~ BIT_1;

    HWRITE(CORE_SYSTEM_CTRL, Enrst);
}


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
