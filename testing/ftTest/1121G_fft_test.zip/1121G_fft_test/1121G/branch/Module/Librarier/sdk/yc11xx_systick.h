/**
* Copyright 2016, yichip Semiconductor(shenzhen office)
* All Rights Reserved.
*
* This is UNPUBLISHED PROPRIETARY SOURCE CODE of Yichip Semiconductor;
* the contents of this file may not be disclosed to third parties, copied
* or duplicated in any form, in whole or in part, without the prior
* written permission of Yichip Semiconductor.
*/

/**
  *@file timer.h
  *@brief timer support for application.
  */
#ifndef _YC11XX_SYSTICK_H_
#define _YC11XX_SYSTICK_H_

#include "yc11xx.h"
/**
  *@brief system tick.
  */
//#define SYSTEM_CLOCK_48M  (36) // In FPGA.
#define SYSTEM_CLOCK_48M  (48)
#define SYSTEM_CLOCK_64M  (64)
#define SYSTEM_CLOCK_96M  (96)
#define SYSTEM_CLOCK_192M  (192)
#define CLOCK_48M_multiple  0
#define CLOCK_64M_multiple  1
#define CLOCK_96M_multiple  2
#define CLOCK_192M_multiple  3


/**
  *@brief Keypad event callback function.
  */
typedef void (* SysTickIRQ_CB_Handle)(int params);

void SysTick_Init(uint32_t systemClk, uint32_t uintUs, SysTickIRQ_CB_Handle callback);
uint32_t SysTick_Config(uint32_t ReloadValue);
BOOL SysTick_CheckInFastDpll(void);
void SysTick_ChangeDPLL(uint8_t systemClk);
void SysTick_ChangeToFastDPLL(void);
void SysTick_ChangeToNormalDPLL(void);
void SysTick_DelayMs(uint32_t nms);
void SysTick_DelayUs(uint32_t nus);



#endif
