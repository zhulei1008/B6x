/**
***************************************************************************
* @file:  yc11xx_iis.c
* @Date:  2021-6-15-17:35:29
* @brief:   I2S driver
**************************************************************************
*/

#include "yc11xx_iis.h"

/**
 * @Description:Write receive buff address
 * @param {uint8_t} *val:buff address
 * @return {*}None
 */
void IIS_SetDmaRxSaddr (uint8_t *val)
{
    if(val == NULL)
    {
        return;
    }
    HWRITEW(CORE_I2S_RX_SADDR, val);
}

/**
 * @Description: Output buff address
 * @param {uint8_t} *val:buff address
 * @return {*}None
 */
void IIS_SetDmaTxSaddr (uint8_t *val)
{
    if(val == NULL)
    {
        return;
    }
    HWRITEW(CORE_I2S_TX_SADDR, val);
    HWRITEW(CORE_IIS_TX_WRPTR, val);
}

/**
 * @brief       IIS DMA max length, need minus 1
 * @param    val:buff len
 * @return     None
 */
void IIS_SetDmaLen (unsigned short val)
{

    HWRITEW(CORE_I2S_LEN, val);
}



/**
 * @brief    I2S initialization function, need to pass in the structure IIS_ConfigDev, configure TX BUFF or RX BUFF, if not needed, configure it to NULL. Standard mode, left-justified mode, right-justified mode transmits two-channel audio, and PCM mode transmits mono audio. In the buff address, if the address is 0x1000xxxx, it is the CM0 core address, and if the address is 0x1000xxxx, it is the BT core address.
 * @param    Config:IIS mode Config
                       TxRxMode:IIS_TxEnable/IIS_RxEnable
                       IISMode:IIS_StandardMode/IIS_PcmMode/IIS_LeftMode/IIS_RightMode
                       BitModeSel:IIS_16Bit/IIS_24Bit/IIS_32Bit/IIS_64Bit
                       SignificantBit:IIS_SourceData16Bit/I2S_SourceData24Bit
                       MSMode:IIS_SlaveMode/IIS_MasterMode
                       BaudRate:IIS_BaudRate8K/IIS_BaudRate11p025K/IIS_BaudRate12K/IIS_BaudRate16K/IIS_BaudRate22p05K/
                                IIS_BaudRate24K/IIS_BaudRate44p1K/IIS_BaudRate48K
                       BufferaddrTx:IIS send pointer
                       BufferaddrRx:IIS receive pointer
                       Bufferlen:buff len
                       IsWptrMode:IIS_CyclicMode/IIS_WptrMode
 * @return  None
 */

void IIS_Init(IIS_ConfigDev config)
{
    if((config.BufferAddrTx == NULL && config.BufferAddrRx == NULL) || config.BufferLen == 0 || config.TxRxMode == 0)
    {
        I2S_CTRLRegDef iisCtrl;
        HREAD_STRUCT(CORE_I2S_CTRL, &iisCtrl);
        iisCtrl.i2s_en = 0;
        iisCtrl.i2s_rx_en = 0;
        HWRITE_STRUCT(CORE_I2S_CTRL, &iisCtrl);
        return;
    }
    uint8_t soundtrack = 0;
    if(config.IisMode != IIS_PcmMode)
    {
        soundtrack = 2;
    }
    else
    {
        soundtrack = 1;
    }
    I2S_MRAM_SELRegDef iisMramSel;
    I2S_CTRLRegDef iisCtrl;
    AUDIO_DIV_CLK_SELRegDef iisClkDiv;
    AUDIO_CLKSELDef iisClkSource;


    CoreReg_ClkControl(REG_CLOCK_OFF_I2S, true);

    HREAD_STRUCT(CORE_I2S_MRAM_SEL, &iisMramSel);
    if(config.IisMode != IIS_PcmMode)
    {
        iisMramSel.pcm_one_channel = 0;
    }
    else
    {
        iisMramSel.pcm_one_channel = 1;
    }
    if((reg_check_ram_m0(config.BufferAddrTx)) || (reg_check_ram_m0(config.BufferAddrRx)) )
    {
        iisMramSel.i2s_mram_sel = 1;
    }
    else
    {
        iisMramSel.i2s_mram_sel = 0;
    }
    if(config.IsWptrMode == IIS_WptrMode)
    {
        iisMramSel.fifo_mode = 1;
    }
    else
    {
        iisMramSel.fifo_mode = 0;
    }
    HWRITE_STRUCT(CORE_I2S_MRAM_SEL, &iisMramSel);


    HREAD_STRUCT(CORE_I2S_CTRL, &iisCtrl);
    if(config.IisMode == IIS_StandardMode)
        iisCtrl.i2s_mode_sel = IIS_StandardMode;
    else if(config.IisMode == IIS_PcmMode)
        iisCtrl.i2s_mode_sel = IIS_PcmMode;
    else if(config.IisMode == IIS_LeftMode)
        iisCtrl.i2s_mode_sel = IIS_LeftMode;
    else
        iisCtrl.i2s_mode_sel = IIS_RightMode;

    if(config.BitModeSel == IIS_16Bit)
        iisCtrl.i2s_bit_mode_sel = 0; //IIS_16Bit;
    else if(config.BitModeSel == IIS_24Bit)
        iisCtrl.i2s_bit_mode_sel = 1; //IIS_24Bit;
    else if(config.BitModeSel == IIS_32Bit)
        iisCtrl.i2s_bit_mode_sel = 2; //IIS_32Bit;
    else
        iisCtrl.i2s_bit_mode_sel = 3; //IIS_64Bit;

    if(config.SignificantBit == IIS_SourceData16Bit)
    {
        iisCtrl.i2s_24bit_mode = 0;
    }
    else
    {
        iisCtrl.i2s_24bit_mode = 1;
    }
    if(config.MSMode == IIS_MasterMode)
        iisCtrl.i2s_master_mode = IIS_MasterMode;


    HREAD_STRUCT(CORE_AUDIO_DIV_CLK_SEL, &iisClkDiv);
    HREADW_STRUCT(CORE_AUDIO_CLKSEL, &iisClkSource);
#ifndef CLOCK_HALVED
    if( config.BaudRate * config.BitModeSel * soundtrack == 128 )
    {
        iisClkSource.i2s_clksel = IIS_Clk6p144M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide3;
        HWRITE(CORE_I2S_CLKDIV, 15);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 176 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 63);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 192 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide2;
        HWRITE(CORE_I2S_CLKDIV, 31);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 256 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide3;
        HWRITE(CORE_I2S_CLKDIV, 15);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 288 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,23);
    //    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 352 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 31);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 384 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide2;
        HWRITE(CORE_I2S_CLKDIV, 15);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 512 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide3;
        HWRITE(CORE_I2S_CLKDIV, 7);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 576 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,11);
    //    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 704 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 15);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 768 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide2;
        HWRITE(CORE_I2S_CLKDIV, 7);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 1024 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide3;
        HWRITE(CORE_I2S_CLKDIV, 3);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 1056 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,5);
    //    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 1152 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,5);
    //    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 1408 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 7);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 1536 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide2;
        HWRITE(CORE_I2S_CLKDIV, 3);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 2048 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide2;
        HWRITE(CORE_I2S_CLKDIV, 2);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 2112 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide2;
    //        HWRITE(CORE_I2S_CLKDIV,1);
    //    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 2304 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide2;
    //        HWRITE(CORE_I2S_CLKDIV,1);
    //    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 2816 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 3);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 3072 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide2;
        HWRITE(CORE_I2S_CLKDIV, 1);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 5632 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 1);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 6144 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 1);
    }
#else
    if( config.BaudRate * config.BitModeSel * soundtrack == 128 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide3;
        HWRITE(CORE_I2S_CLKDIV, 15);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 176 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 31);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 192 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 31);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 256 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide3;
        HWRITE(CORE_I2S_CLKDIV, 7);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 288 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,23);
    //    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 352 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 15);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 384 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 15);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 512 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide3;
        HWRITE(CORE_I2S_CLKDIV, 3);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 576 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,11);
    //    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 704 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 7);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 768 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 7);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 1024 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide2;
        HWRITE(CORE_I2S_CLKDIV, 2);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 1056 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,5);
    //    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 1152 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,5);
    //    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 1408 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 3);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 1536 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 3);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 2048 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 2);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 2112 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide2;
    //        HWRITE(CORE_I2S_CLKDIV,1);
    //    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 2304 )
    //    {
    //        iisClkSource.i2s_clksel=IISClk6p144M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide2;
    //        HWRITE(CORE_I2S_CLKDIV,1);
    //    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 2816 )
    {
        iisClkSource.i2s_clksel = IIS_Clk11p2896M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 1);
    }
    else if( config.BaudRate * config.BitModeSel * soundtrack == 3072 )
    {
        iisClkSource.i2s_clksel = IIS_Clk12p288M;
        iisClkDiv.i2s_divclk_sel = IIS_ClkDivide1;
        HWRITE(CORE_I2S_CLKDIV, 1);
    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 5632 )
    //    {
    //        iisClkSource.i2s_clksel=IIS_Clk11p2896M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,1);
    //    }
    //    else if( config.BaudRate * config.BitModeSel *soundtrack == 6144 )
    //    {
    //        iisClkSource.i2s_clksel=IIS_Clk12p288M;
    //        iisClkDiv.i2s_divclk_sel=IIS_ClkDivide1;
    //        HWRITE(CORE_I2S_CLKDIV,0);
    //    }
#endif
    HWRITE_STRUCT(CORE_AUDIO_DIV_CLK_SEL, &iisClkDiv);
    HWRITEW_STRUCT(CORE_AUDIO_CLKSEL, &iisClkSource);
    IIS_SetDmaLen(config.BufferLen - 1);

    IIS_SetDmaRxSaddr(config.BufferAddrRx);
    IIS_SetDmaTxSaddr(config.BufferAddrTx);
    HWRITE_STRUCT(CORE_I2S_CTRL, &iisCtrl);
    IIS_Enable(config);
}


/**
 * @brief  I2S enable function. When TX is turned on, only data is sent. If RX is enabled, both TX and RX are enabled, and the size of TX BUFF is equal to RX BUFF. You can set the TX BUFF address to NULL
 * @param  config IIS enable
 *                  TxRxMode:IIS_TxEnable/IIS_RxEnable
 */
void IIS_Enable(IIS_ConfigDev config)
{
    I2S_CTRLRegDef iisCtrl;
    HREAD_STRUCT(CORE_I2S_CTRL, &iisCtrl);
    if(config.TxRxMode == IIS_TxEnable)
    {
        iisCtrl.i2s_en = 1;
    }
    else if(config.TxRxMode == IIS_RxEnable)
    {
        iisCtrl.i2s_en = 1;
        iisCtrl.i2s_rx_en = 1;
    }
    HWRITE_STRUCT(CORE_I2S_CTRL, &iisCtrl);
}

/**
 * @brief  IIS is used when writing the pointer to determine whether the IIS data has been sent. Return true when finished.
 * @return BOOL
 */
BOOL IIS_IsSendComplete(void)
{
    return HREADW(CORE_IIS_TX_WRPTR) == HREADW(CORE_I2S_RDPTR);
}

/**
 * @brief  Get the length of unsent data
 * @return buff size
 */
uint16_t IIS_GetBufferSize(void)
{
    uint16_t rPtr, wPtr;

    // Check adc buffer already for cvsd work
    rPtr = HREADW(CORE_I2S_RDPTR);
    wPtr = HREADW((CORE_IIS_TX_WRPTR));
    if(wPtr >= rPtr)
    {
        return (wPtr - rPtr);
    }
    else
    {
        return (HREADW(CORE_I2S_LEN) + 1 - (rPtr  - wPtr));
    }
}

/**
 * @brief get remind buffer size
 * @return buff size
 */
uint16_t IIS_GetRemindBufferSize(void)
{
    return HREADW(CORE_I2S_LEN) + 1 - IIS_GetBufferSize();
}

/**
 * @brief set IIS write ptr
 * @return None
 */
void IIS_SetTxBuff (uint8_t *val)
{
    HWRITEW(CORE_IIS_TX_WRPTR, val);
}

/**
 * @brief get IIS write ptr
 * @return None
 */
uint16_t IIS_GetWptr(void)
{
    return HREADW(CORE_I2S_WRPTR);
}

/**
 * @brief get IIS read ptr
 * @return None
 */
uint16_t IIS_GetRprt(void)
{
    return HREADW(CORE_I2S_RDPTR);
}
