/*
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file     usb_dcd_init.c
 * @brief    source file for setting xxx
 *
 * Change Logs:
 * Date           Author      Version        Notes
 * 2021-04-27     zhangming V1.0.0         the first version
 */

/* Include ------------------------------------------------------------------*/
#include "usb_dcd_int.h"
#include "usb_defines.h"
#include "usbd_usr.h"
#include "usb_main.h"
#include "usbd_cdc_core.h"
#include "yc11xx.h"
#ifdef HID_AUDIO_DEMO
#include "app_common.h"
#include "reg_addr.h"
#include "app_config.h"
#include "yc_debug.h"
#endif
/** @addtogroup USB_OTG_DRIVER
* @{
*/

/** @defgroup USB_DCD_INT
* @brief This file contains the interrupt subroutines for the Device mode.
* @{
*/

/** @defgroup USB_DCD_INT_Private_Defines
* @{
*/
/**
* @}
*/

/* Interrupt Handlers */
static uint32_t DCD_HandleInEP_ISR(USB_OTG_CORE_HANDLE *pdev,
                                   uint16_t ep_intr);
uint32_t DCD_HandleOutEP_ISR(USB_OTG_CORE_HANDLE *pdev, uint8_t ep_intr);
uint32_t DCD_HandleUsbReset_ISR();
void _delay_(uint32_t t)
{
    ((void (*)())(0xc6 + 1))(t);
}

/**
* @brief  USBD_OTG_ISR_Handler
*         handles all USB Interrupts
* @param  pdev: device instance
* @retval status
*/
volatile uint8_t *usb_rxptr;


extern USBD_DCD_INT_cb_TypeDef USBD_DCD_INT_cb;

uint8_t setup_cnt = 0;
uint8_t SetAddress_Flag = 0;
volatile uint8_t Address_Value = 0;
uint16_t rx_DataLength = 0;
#ifdef HID_AUDIO_DEMO
uint8_t AudioIn_Data_Buf[100];
#endif

extern uint8_t  AudioCtl[64];
extern uint8_t  AudioCtlCmd;
uint32_t USBD_OTG_ISR_Handler(USB_OTG_CORE_HANDLE *pdev)
{
    USB_OTG_IRQ_TypeDef gintr_status;
    USB_OTG_trig_TypeDef trig;
    uint32_t retval = 0, rxdmaw, rxdmar;
    uint16_t rx_ep, rx_ep1, test_len;
    uint8_t ep_num, i, rxcnt;
    uint8_t j[100];

    rx_DataLength = 0;
    if (USB_OTG_IsDeviceMode(pdev))     /* ensure that we are in device mode */
    {
        gintr_status.d16 = HREADW(core_usb_status);  /* get USB_STATUS value */

        if (!gintr_status.d16)
            return 0;
        HWRITEW(core_usb_status, gintr_status.d16); /* clear USB_STATUS value */
        if (gintr_status.b.reset)
        {
            HWRITE(0x8082, 1);
            retval |= DCD_HandleUsbReset_ISR(pdev);
        }
        if(gintr_status.b.clkcal)
        {
            //usb_clkcal_done();
        }
        if (gintr_status.b.rx_full)
        {
#ifdef HID_AUDIO_DEMO
            DEBUG_LOG_STRING("gintr_status.b.rx_full = \r\n");
#endif
        }
        /*every packet into rx_dma,USB_RXCNT +1 */
        for (i = 0, rxcnt = HREAD(core_usb_rx_cnt); gintr_status.b.rx_ready; i++)
        {
            //DEBUG_LOG_STRING("rxcnt = 0x%x, last_rxcnt: 0x%x, i = %d\r\n",rxcnt, pdev->dev.last_rxcnt, i);

            if (rxcnt == (i + pdev->dev.last_rxcnt & 0xff))
            {
                pdev->dev.rxcnt = rxcnt;
                pdev->dev.last_rxcnt += i;
                break;
            }
#ifndef USB_USER_MRAM
            usb_rxptr = (byte *)(HREADW(core_usb_rxptr) | 0x10000000);
#else
            usb_rxptr = (byte *)(HREADW(core_usb_rxptr) | 0x10010000);
#endif

            rx_ep = usb_getword();          /*16bit = 4bit ep_num + 12bit data_len*/
            //  MyPrintf("usb_rxptr = %p\r\n",usb_rxptr);
            //  MyPrintf("rx_ep = %x\r\n",rx_ep);
            rx_DataLength = rx_ep & 0xfff;
            ep_num = (uint8_t)(rx_ep >> 12);

            if (ep_num == 0)
            {
                if (SetAddress_Flag)
                {
                    //USB_ADDR |= 0x80;      /*set 1,disable address 0 packet receive*/
                    SetAddress_Flag = 0;
                }
                if(pdev->dev.device_SETUP_OUT == 1)
                {
                    usb0_control_data(pdev, rx_DataLength);
                    pdev->dev.device_SETUP_OUT = 0;
                }
                else
                {
                    /*must in*/
                    if ((rx_DataLength < pdev->dev.out_ep[0].maxpacket) ||
                            (pdev->dev.out_ep[0].xfer_count + rx_DataLength ==
                             pdev->dev.out_ep[0].xfer_len))
                    {

                        pdev->dev.out_ep[0].xfer_buff = pdev->dev.setup_packet;
                        pdev->dev.out_ep[0].xfer_count = 0;
                        pdev->dev.out_ep[0].xfer_len = 8;
                    }

                    USB_OTG_ReadPacket(pdev,
                                       pdev->dev.out_ep[0].xfer_buff +
                                       pdev->dev.out_ep[0].xfer_count, 0,
                                       rx_DataLength);
                    /* deal with receive setup packet */
                    USBD_DCD_INT_fops->SetupStage(pdev);
                }
            }
            else
            {
                retval |= DCD_HandleOutEP_ISR(pdev, ep_num);
            }
        }
        if (gintr_status.b.tx_done0)
        {
            retval |= DCD_HandleInEP_ISR(pdev, USB_EPM0);
        }
        if (gintr_status.b.tx_done1)
        {
            retval |= DCD_HandleInEP_ISR(pdev, USB_EPM1);
        }
        if (gintr_status.b.tx_done2)
        {
            retval |= DCD_HandleInEP_ISR(pdev, USB_EPM2);
        }
        if (gintr_status.b.tx_done3)
        {
            retval |= DCD_HandleInEP_ISR(pdev, USB_EPM3);
        }
    }

    return retval;
}

extern uint8_t clear_ep0_out_nak;
/**
* @brief  DCD_HandleInEP_ISR
*         Indicates that an IN EP has a pending Interrupt
* @param  pdev: device instance
* @retval status
*/
static uint32_t DCD_HandleInEP_ISR(USB_OTG_CORE_HANDLE *pdev,
                                   uint16_t ep_intr)
{
    USB_OTG_EP *ep;
    uint16_t epnum = ep_intr;
    int i = 0;
    //DEBUG_LOG(LOG_LEVEL_CORE, "UI" ,"Bt_Reset: 0x%04X", 0xe00f, ep_intr);
    ep = &pdev->dev.in_ep[epnum];

    /* Setup and start the Transfer */
    ep->is_in = 1;
    ep->num = epnum;
    if (pdev->dev.in_ep[epnum].rem_data_len == 0)
    {
        usb0_clear_out_nak();
        if (epnum == 1)
        {
            //                    if ((pdev->dev.zero_replay_flag) & 1 << ep->num)
            //                    {
            //   USB_OTG_EPReply_Zerolen(pdev, ep);
            //  pdev->dev.zero_replay_flag = 0;
            //                    }
        }
#ifdef HID_AUDIO_DEMO
        else if(epnum == (AUDIO_IN_EP & 0x7f))
        {
            extern AUDIO_INFO gaudio;
            AUDIO_INFO *prxDacFifo = &gaudio;
            if (HREAD(core_usb_txbusy) & 0x04)
            {
                DEBUG_LOG(LOG_LEVEL_CORE, "UI", "Bt_Reset: 0x%04X", 0xe031, HREAD(core_usb_txbusy));
                return 1;
            }
#if 1
            uint16_t bufferSize = ADCGetSize();
            //DEBUG_LOG_STRING("Handle In isr, sta: %d, flag: %d, size: 0x%d\r\n"
            //    , prxDacFifo->gAudioAdcState, prxDacFifo ->gAdcflag, bufferSize);
            if(prxDacFifo->gAudioAdcState == AUDIO_ADC_CONTINUE)
            {
                if(prxDacFifo ->gAdcflag == 1) // Cache buffer
                {
                    if(bufferSize < (AUDIO_ADC_48K_LEN * 2))
                    {
                        USB_OTG_WritePacket(pdev, AudioIn_Data_Buf, 0x02, AUDIO_ADC_48K_TXLEN);
                        return 1;
                    }
                }
                prxDacFifo ->gAdcflag = 0;
                if(bufferSize > AUDIO_ADC_48K_TXLEN)
                {
                    USB_OTG_WritePacket(pdev, (uint8_t *) & (prxDacFifo->gUSBadcbuf[prxDacFifo->gUSBadcRptr]), 0x02, AUDIO_ADC_48K_TXLEN);
                    gaudio.gUSBadcRptr += AUDIO_ADC_48K_TXLEN;
                    if(gaudio.gUSBadcRptr >= AUDIO_ADC_BUF_48KSIZE)
                    {
                        gaudio.gUSBadcRptr = 0;
                    }
                }
                else
                {
                    USB_OTG_WritePacket(pdev, AudioIn_Data_Buf, 0x02, AUDIO_ADC_48K_TXLEN);
                }
            }
#endif
            return 1;
        }
#endif
    }
    else
    {
        if (pdev->dev.in_ep[epnum].xfer_len -
                pdev->dev.in_ep[epnum].xfer_count ==
                pdev->dev.in_ep[epnum].maxpacket)
        {
            USB_OTG_WritePacket(pdev,
                                pdev->dev.in_ep[epnum].xfer_buff +
                                pdev->dev.in_ep[epnum].xfer_count, epnum,
                                pdev->dev.in_ep[epnum].maxpacket);

            pdev->dev.in_ep[epnum].xfer_count = pdev->dev.in_ep[epnum].xfer_len;
            pdev->dev.in_ep[epnum].rem_data_len = 0;
            pdev->dev.zero_replay_flag = 1 << ep->num;
            //  usb_clear_nak(epnum,0);
        }

        else if (pdev->dev.in_ep[epnum].xfer_len -
                 pdev->dev.in_ep[epnum].xfer_count >
                 pdev->dev.in_ep[epnum].maxpacket)
        {
            USB_OTG_WritePacket(pdev,
                                pdev->dev.in_ep[epnum].xfer_buff +
                                pdev->dev.in_ep[epnum].xfer_count, epnum,
                                pdev->dev.in_ep[epnum].maxpacket);

            pdev->dev.in_ep[epnum].xfer_count +=
                pdev->dev.in_ep[epnum].maxpacket;
            pdev->dev.in_ep[epnum].rem_data_len =
                pdev->dev.in_ep[epnum].xfer_len -
                pdev->dev.in_ep[epnum].xfer_count;
        }

        else
        {
            USB_OTG_WritePacket(pdev,
                                pdev->dev.in_ep[epnum].xfer_buff +
                                pdev->dev.in_ep[epnum].xfer_count, epnum,
                                pdev->dev.in_ep[epnum].xfer_len -
                                pdev->dev.in_ep[epnum].xfer_count);

            pdev->dev.in_ep[epnum].xfer_count = pdev->dev.in_ep[epnum].xfer_len;
            pdev->dev.in_ep[epnum].rem_data_len = 0;

            /****prepare receive outpacket *****/
            usb0_clear_out_nak();
            //HWRITE(core_usb_trig,0x10 << 0);

            /* TX COMPLETE */
            USBD_DCD_INT_fops->DataInStage(pdev, epnum);
            pdev->dev.zero_replay_flag = 0;
        }
    }
    return 1;
}

#ifdef USB_SOFT_DMA_WORK
uint8_t gIsFirstBufferCache = 10;
extern volatile uint8_t   usb_rxbuf[800] ;
extern volatile uint8_t   usb_txbuf0[100] ;
extern volatile uint8_t   usb_txbuf1[100] ;
extern volatile uint8_t   usb_txbuf2[100] ;
extern volatile uint8_t   usb_txbuf3[100];

void usbcpy_wrap(void *dst, int len, void *dst_start, int dst_len)
{
    dmacpy_wrap(dst, usb_rxptr, len, dst_start, dst_len, usb_rxbuf, sizeof (usb_rxbuf));
}

void usbcpy(void *dst, int len)
{
    dmacpy_wrap(dst, usb_rxptr, len, 0, -1, usb_rxbuf, sizeof (usb_rxbuf));
}
#define INCPTR(p, inc, buf)		if((p += inc) >= buf + sizeof(buf)) p -= sizeof(buf)
#define INC_RPTR(x)				INCPTR(usb_rxptr, x, usb_rxbuf)
#endif
/**
* @brief  DCD_HandleOutEP_ISR
*         Indicates that an OUT EP has a pending Interrupt
* @param  pdev: device instance
* @retval status
*/
uint32_t DCD_HandleOutEP_ISR(USB_OTG_CORE_HANDLE *pdev, uint8_t ep_intr)
{
#if 0 //this use for test read zcode
    if(HREAD(0X4FF3) == 1)
    {
        if (rx_DataLength  == 6)
        {
            uint8_t test_buf[6] = {0};
            USB_OTG_ReadPacket(pdev,
                               test_buf, 1,
                               rx_DataLength);
            for (int w = 0 ; w < rx_DataLength; w++)
            {
                if(test_buf[w] != 0xaa)
                {
                    while(1);
                }
            }
            //USBD_DCD_INT_fops->DataOutStage(pdev, ep_intr);
        }

    }
    else

#endif
    {
        USBD_DCD_INT_fops->DataOutStage(pdev, ep_intr);
    }
#ifdef HID_AUDIO_DEMO
    extern AUDIO_INFO gaudio;
    volatile AUDIO_INFO *prxDacFifo = &gaudio;
    //DEBUG_LOG_STRING("DCD_HandleOutEP_ISR ep_intr: %d, rx_DataLength: %d\r\n", ep_intr, rx_DataLength);
    if(ep_intr == HID_OUT_EP)
    {
        if (rx_DataLength)
        {
            USBD_DCD_INT_fops->DataOutStage(pdev, ep_intr);
        }
    }
    else if(ep_intr == AUDIO_OUT_EP)
    {
        uint16_t rxLen = rx_DataLength;
        //DEBUG_LOG_STRING("rptr: 0x%x\r\n", prxDacFifo->gdacRptr);
#ifdef USB_SOFT_DMA_WORK
        usbcpy_wrap(prxDacFifo->gdacRptr, rx_DataLength
                    , prxDacFifo->gAudiodacbuf, sizeof(prxDacFifo->gAudiodacbuf));
        INC_RPTR(rx_DataLength);
        //HWRITEW(core_usb_rxptr, (int)usb_rxptr);
        if(rx_DataLength & 0x01)
        {
            usb_rxptr++;
            HWRITEW(core_usb_rxptr, usb_rxptr);
        }
        else
        {
            HWRITEW(core_usb_rxptr, usb_rxptr);
        }
        rx_DataLength = 0;
#else
        DCD_EP_PrepareRx(pdev,
                         AUDIO_OUT_EP,
                         (uint8_t *) prxDacFifo->gdacRptr,
                         rx_DataLength);
#endif
        // monitor dac empty work.
        if(HREAD(0x4ff0) == 1)
        {
            return 1;
        }

#ifdef FUNCTION_IIS_MODE
        if(Audio_IISCheckEmpty())
        {
            DEBUG_LOG_STRING("dac play empty: 0x%x\r\n", HREADW(CORE_IIS_TX_WRPTR));
        }
        uint16_t bufferRemind = Audio_IISGetRemindBufferSize();
        uint16_t totalBufferSize = HREADW(CORE_I2S_LEN) + 1;
#ifdef FUNCTION_ADJUST_FREQ_BY_BUFFER
        if(bufferRemind > ((totalBufferSize >> 1) + 0x100))
        {
            DEBUG_LOG_STRING("S R: %x, r: %x, w: %x\r\n", bufferRemind, HREADW(CORE_I2S_RDPTR), HREADW(CORE_IIS_TX_WRPTR));
            dsmdiv_12m_adjust_value(32);//slow down
        }
        else if(bufferRemind < ((totalBufferSize >> 1) - 0x100))
        {
            DEBUG_LOG_STRING("F R: %x, r: %x, w: %x\r\n", bufferRemind, HREADW(CORE_I2S_RDPTR), HREADW(CORE_IIS_TX_WRPTR));
            dsmdiv_12m_adjust_value(-32);//be quick
        }
#endif
        if(Audio_IISGetRemindBufferSize() < rxLen + 100)
        {
            DEBUG_LOG_STRING("Remind not enough, R: %x, r: %x, w: %x\r\n", bufferRemind, HREADW(CORE_I2S_RDPTR), HREADW(CORE_IIS_TX_WRPTR));
            return 1;
        }
        prxDacFifo->gdacRptr += rxLen;
        if( prxDacFifo->gdacRptr >= (uint32_t)(prxDacFifo->gAudiodacbuf + sizeof(prxDacFifo->gAudiodacbuf)))
            prxDacFifo->gdacRptr = (uint32_t)(&prxDacFifo->gAudiodacbuf[0]);
        // Cache buffer
        if(gIsFirstBufferCache != 0)
        {
            gIsFirstBufferCache--;
            return 1;
        }
        HWRITEW(CORE_IIS_TX_WRPTR, prxDacFifo->gdacRptr);
        DEBUG_LOG_STRING("Set: %x\r\n", prxDacFifo->gdacRptr);
#else
        if(Audio_DacCheckEmpty())
        {
            DEBUG_LOG_STRING("dac play empty: 0x%x\r\n", prxDacFifo->gdacRptr);
        }
        if(Audio_DacGetRemindBufferSize() < AUDIO_DAC_48K_LEN)
        {
            DEBUG_LOG_STRING("remain not enough.\r\n");
            return 1;
        }
        prxDacFifo->gdacRptr += rxLen;
        if( prxDacFifo->gdacRptr >= (uint32_t)(prxDacFifo->gAudiodacbuf + sizeof(prxDacFifo->gAudiodacbuf)))
            prxDacFifo->gdacRptr = (uint32_t)(&prxDacFifo->gAudiodacbuf[0]);
        HWRITEW(CORE_DAC_WPTR, prxDacFifo->gdacRptr);
#endif
        //DEBUG_LOG_STRING("rptr1: 0x%x\r\n", prxDacFifo->gdacRptr);
    }
#else

#endif

    return 1;
}

#ifdef HID_AUDIO_DEMO
void usb0_control_data(USB_OTG_CORE_HANDLE *pdev, uint16_t len)
{
    if(AudioCtlCmd == 0x01 && len > 0)
    {
        USB_OTG_ReadPacket(pdev,
                           AudioCtl,
                           0,
                           len);
        AudioCtlCmd = 0;
    }
    usb0_clear_in_nak();
}
#endif

#ifdef CCID_DEMO
void usb0_control_data(USB_OTG_CORE_HANDLE *pdev, uint16_t len)
{
}
#endif
/**
* @brief  DCD_HandleUsbReset_ISR
*         This interrupt occurs when a USB Reset is detected
* @param  pdev: device instance
* @retval status
*/
/**
 * @method usb_reset
 * @brief  None
 * @param  None
 * @retval None
 */
void usb_reset()
{
    NVIC_Configuration(USB_IRQn, 1, DISABLE);
    HWRITE(core_usb_hmode, 0x00);
    HWRITE(core_usb_clear, 0x70);
    HWRITEW(core_usb_status, 0x7ff);



    usb_main();

}
extern USB_OTG_CORE_HANDLE USB_OTG_dev;
uint32_t DCD_HandleUsbReset_ISR()
{
    usb_reset();
    return 1;
}

void usb_clkcal_done()
{
#ifdef FUNCTION_ADJUST_FREQ_BY_USB
    dsmdiv_12m_adjust_by_usb_sof(HREADW(core_usb_ccnt));
#endif
}

/************************ (C) COPYRIGHT Yichip Microelectronics *****END OF FILE****/
