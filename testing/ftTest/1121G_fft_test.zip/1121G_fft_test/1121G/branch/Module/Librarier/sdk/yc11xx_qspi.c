/**
 * @file yc11xx_qspi.c
 * @author duanchu.he
 * @brief QSPI driver
 * @version 0.1
 * @date 2021-07-06
 *
 *
 */
#include "yc11xx_qspi.h"
#include "MyPrintf.h"
#include "reg_addr.h"
#include "reg_struct.h"

/**
 * @brief Configure qspi addr function
 *
 * @param qspix QSPI1 or QSPI2
 * @param qspi_handle 	qspi config structure
 */
void QSPI_AddrConfig(QSPI_NUM qspix, QSPI_AddrTypeDef *qspi_handle)
{
    QSPI_TX_CTRL_ADDRRegDef		qspi_TxCtrlHandle;
    QSPI_RX_CTRL_ADDRRegDef		qspi_RxCtrlHandle;
    QSPI_CTRL_ADDRRegDef		qspi_CtrlHandle;
    QSPI_CMD_CTRL_ADDRRegDef	qspi_CmdCtrlHandle;

    if(qspix != QSPI2)
    {
        qspi_TxCtrlHandle.qspi_txaddr = qspi_handle->txaddr;
        qspi_TxCtrlHandle.qspi_txlen = qspi_handle->txlen;
        HWRITEL_STRUCT(CORE_QSPI1_TX_CTRL, &qspi_TxCtrlHandle);

        qspi_RxCtrlHandle.qspi_rxaddr = qspi_handle->rxaddr;
        qspi_RxCtrlHandle.qspi_rxlen = qspi_handle->rxlen;
        HWRITEL_STRUCT(CORE_QSPI1_RX_CTRL, &qspi_RxCtrlHandle);

        qspi_CmdCtrlHandle.qspi_cmdaddr = qspi_handle->cmdaddr;
        qspi_CmdCtrlHandle.qspi_cmdlen = qspi_handle->cmdlen;
        HWRITEL_STRUCT(CORE_QSPI1_CMD_CTRL, &qspi_CmdCtrlHandle);

        HREADW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.wslen = qspi_handle->ws_len;
        HWRITEW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
    }
    else
    {
        qspi_TxCtrlHandle.qspi_txaddr = qspi_handle->txaddr;
        qspi_TxCtrlHandle.qspi_txlen = qspi_handle->txlen;
        HWRITEL_STRUCT(CORE_QSPI2_TX_CTRL, &qspi_TxCtrlHandle);

        qspi_RxCtrlHandle.qspi_rxaddr = qspi_handle->rxaddr;
        qspi_RxCtrlHandle.qspi_rxlen = qspi_handle->rxlen;
        HWRITEL_STRUCT(CORE_QSPI2_RX_CTRL, &qspi_RxCtrlHandle);

        qspi_CmdCtrlHandle.qspi_cmdaddr = qspi_handle->cmdaddr;
        qspi_CmdCtrlHandle.qspi_cmdlen = qspi_handle->cmdlen;
        HWRITEL_STRUCT(CORE_QSPI2_CMD_CTRL, &qspi_CmdCtrlHandle);

        HREADW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.wslen = qspi_handle->ws_len;
        HWRITEW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
    }
}

/**
 * @brief Qspi set mode function
 *
 * @param qspix QSPI1 or QSPI2
 * @param val 0-stand 1-dual -quad
 */
void QSPI_SetMode (QSPI_NUM qspix, uint8_t val)
{
    QSPI_CTRL_ADDRRegDef		qspi_CtrlHandle;

    if(qspix != QSPI2)
    {
        HREADW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.mode_sel = val;
        HWRITEW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
    }
    else
    {
        HREADW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.mode_sel = val;
        HWRITEW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
    }
}

/**
 * @brief Qspi clear interrupt flag function
 *
 * @param qspix QSPI1 or QSPI2
 * @param state DISABLE or ENABLE
 */
void QSPI_SetInc (QSPI_NUM qspix, FunctionalState state)
{
    QSPI_CTRL_ADDRRegDef		qspi_CtrlHandle;

    if(qspix != QSPI2)
    {
        HREADW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.intr_clr = state;
        HWRITEW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
    }
    else
    {
        HREADW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.intr_clr = state;
        HWRITEW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
    }
}

/**
 * @brief Qspi open clock function
 *
 * @param qspix QSPI1 or QSPI2
 * @param state DISABLE or ENABLE
 */
void QSPI_SetClk (QSPI_NUM qspix, FunctionalState state)
{
    QSPI_CTRL_ADDRRegDef		qspi_CtrlHandle;

    if(qspix != QSPI2)
    {
        HREADW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.clk_en = state;
        HWRITEW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
    }
    else
    {
        HREADW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.clk_en = state;
        HWRITEW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
    }
}

/**
 * @brief Qspi enable interrupt  function
 *
 * @param qspix QSPI1 or QSPI2
 * @param state DISABLE or ENABLE
 */
void QSPI_SetInterrupt(QSPI_NUM qspix, FunctionalState state)
{
    QSPI_CTRL_ADDRRegDef	qspi_CtrlHandle;

    if(qspix != QSPI2)
    {
        HREADW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.intr_en = state;
        HWRITEW_STRUCT(CORE_QSPI1_CTRL, &qspi_CtrlHandle);
    }
    else
    {
        HREADW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
        qspi_CtrlHandle.intr_en = state;
        HWRITEW_STRUCT(CORE_QSPI2_CTRL, &qspi_CtrlHandle);
    }
}



/**
 * @brief Qspi start dma  function
 *
 * @param qspix QSPI1 or QSPI2
 * @param state DISABLE or ENABLE
 */
void QSPI_SetStart (QSPI_NUM qspix,  FunctionalState state)
{
    if(qspix != QSPI2)
    {
        if(state != DISABLE)
            HWOR(CORE_QSPI1_START, 1 << 0);
        else
            HWCOR(CORE_QSPI1_START, 1 << 0);
    }
    else
    {
        if(state != DISABLE)
            HWOR(CORE_QSPI2_START, 1 << 0);
        else
            HWCOR(CORE_QSPI2_START, 1 << 0);
    }
}

/**
 * @brief
 *
 * @param qspix QSPI1 or QSPI2
 */
void QSPI_WaitDone (QSPI_NUM qspix)
{
    uint8_t tmp = 0;
    int timeout = 0;

    while (1)
    {
        timeout++;

        if(qspix != QSPI2)
            tmp = HREAD(CORE_QSPI1_STATUS);
        else
            tmp = HREAD(CORE_QSPI2_STATUS);

        tmp = tmp & 0x01;
        if ((tmp == 0x01) || (timeout > QSPI_WAITTIMEOUT))
            break;
    }
}


