#ifndef _YC11XX_CVSD_H_
#define _YC11XX_CVSD_H_

#include "yc11xx.h"
#include "reg_addr.h"
#include "reg_struct.h"

void Audio_CvsdClkEnable(void);
void Audio_CvsdClkDisable(void);
void Audio_CvsdWaitCvsdFilterClrDone(void);
void Audio_CvsdCoefInit(void);
void Audio_CvsdStart(void);
void Audio_CvsdStop(void);
void Audio_CvsdOutInit(uint32_t cvsdOutBufferAddr, uint16_t cvsdOutBufferSize
                       , uint32_t cvsdPcmInBufferAddr, uint16_t cvsdPcmInBufferSize);
void Audio_CvsdInInit(uint32_t cvsdInBufferAddr, uint16_t cvsdInBufferSize
                      , uint32_t cvsdPcmOutBufferAddr, uint16_t cvsdPcmOutBufferSize);
void Audio_CvsdInit(uint32_t cvsdInBufferAddr, uint16_t cvsdInBufferSize
                    , uint32_t cvsdPcmOutBufferAddr, uint16_t cvsdPcmOutBufferSize
                    , uint32_t cvsdOutBufferAddr, uint16_t cvsdOutBufferSize
                    , uint32_t cvsdPcmInBufferAddr, uint16_t cvsdPcmInBufferSize
                    , uint16_t cvsdGrpLength);
BOOL Audio_CvsdCheckEnable(void);
BOOL Audio_CvsdCheckWorkStart(void);
BOOL Audio_CvsdCheckWorkInprocess(void);
BOOL Audio_CvsdCheckInUseMRam(void);
BOOL Audio_CvsdCheckOutUseMRam(void);
uint32_t Audio_CvsdGetInAddr(void);
void Audio_CvsdWorkEnable(void);
void Audio_CvsdWorkDisable(void);


#endif
