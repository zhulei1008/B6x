#ifndef __YC11XX_SD_H_
#define __YC11XX_SD_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "yc11xx.h"
#include "MyPrintf.h"
//#include "yc_drv_common.h"
#include "yc11xx_sdio.h"

#define SUPPORT_SD													0

// CARD_TYPE
#define SDSC_V1 														0
#define SDSC_V2V3 													1
#define SDHC_SDXC 													2

#define NOT_HIGH_CAPACITY_CARD							0
#define HIGH_CAPACITY_CARD									1

//Response of ACMD41
#define BUSY																0
#define NOT_BUSY														1

// var
#define BLOCKSIZE														0x0200	//512�ֽ�
#define DMALENGTH														0x400	//1024

//card bus width
#define CARD_BUS_WIDTH_1_BIT         				0
#define CARD_BUS_WIDTH_4_BIT        			  2

//mode select
#define SINGLE_BLOCK_MODE										0
#define MULTI_BLOCK_MODE										1

//READ/WRITE_BLOCKS
#define SD_RD_SINGLE_BLOCK_FAIL							0
#define SD_RD_SINGLE_BLOCK_SUCCESS					1
#define SD_WR_SINGLE_BLOCK_FAIL							0
#define SD_WR_SINGLE_BLOCK_SUCCESS					1
#define SD_RD_BLOCKS_FAIL										0
#define SD_RD_BLOCKS_SUCCESS								1
#define SD_WR_BLOCKS_FAIL										0
#define SD_WR_BLOCKS_SUCCESS								1

//SD_CARD_Current_State
#define SD_IDLE_STATE												0
#define SD_READY_STATE											1
#define SD_IDENT_STATE											2
#define SD_STBY_STATE												3
#define SD_TRAN_STATE												4
#define SD_DATA_STATE												5
#define SD_RCV_STATE												6
#define SD_PRG_STATE												7
#define SD_DIS_STATE												8
// DMA_CTRL
#define DMA_SW_START_ON         0x01
#define DMA_SW_START_OFF        0x00
#define MRAM_SEL_ON             0x10
#define MRAM_SEL_OFF            0x00
#define DMA_RST_ON              0x02
#define DMA_RST_OFF             0x00
#define DMA_HW_START_ON         0x01
#define DMA_HW_START_OFF        0x00

/** @addtogroup SDIO
  * @{
  */
// sd internal reg
#define SD_BLK_SIZE_L           						0
#define SD_BLK_SIZE_H           						1
#define SD_BLK_CNT_L            						2
#define SD_BLK_CNT_H            						3
#define SD_CMD_ARG_B0           						4
#define SD_CMD_ARG_B1           						5
#define SD_CMD_ARG_B2           						6
#define SD_CMD_ARG_B3           						7
#define SD_TRANS_MODE           						8
#define SD_COMMAND              						9
#define SD_RSP_B0               						10
#define SD_RSP_B1               						11
#define SD_RSP_B2               						12
#define SD_RSP_B3               						13
#define SD_RSP_B4               						14
#define SD_RSP_B5               						15
#define SD_RSP_B6               						16
#define SD_RSP_B7               						17
#define SD_RSP_B8               						18
#define SD_RSP_B9               						19
#define SD_RSP_B10              						20
#define SD_RSP_B11              						21
#define SD_RSP_B12              						22
#define SD_RSP_B13              						23
#define SD_RSP_B14              						24
#define SD_RSP_IDX              						25
#define SD_RSP_CRC              						26
#define SD_BLK_GAP              						27
#define SD_CLK_CTRL             						28
#define SD_CLK_DIV              						29
#define SD_TIMEOUT_CNT          						30
#define SD_SW_RST               						31
#define SD_NORM_IRQ             						32
#define SD_ERR_IRQ              						33
#define SD_NORM_IRQ_EN          						34
#define SD_ERR_IRQ_EN           						35
#define SD_CMD_STATUS           						36
#define SD_DAT_STATUS           						37
#define SD_PAD_STATE1           						38
#define SD_PAD_STATE2           						39
#define SD_DMA_SW_START         						128
#define SD_DMA_CTRL             						129
#define SD_DMA_SADDR_L          						130
#define SD_DMA_SADDR_H          						131
#define SD_DMA_LEN_L            						132
#define SD_DMA_LEN_H            						133
#define SD_DMA_ADDR_L           						134
#define SD_DMA_ADDR_H           						135
#define SD_DMA_STATUS           						136

// TRANS_MODE
#define BUS_WIDTH_1_BIT         						0x00
#define BUS_WIDTH_4_BIT        						  0x40
#define TRANS_DIR_WR            						0x00
#define TRANS_DIR_RD            						0x20
#define DAT_PRES_OFF           						  0x00
#define DAT_PRES_ON            						  0x10
#define CMD_IDX_CHK_OFF        						  0x00
#define CMD_IDX_CHK_ON          						0x08
#define CMD_CRC_CHK_OFF         						0x00
#define CMD_CRC_CHK_ON          						0x04
#define RESP_TYPE_NONE          						0x00
#define RESP_TYPE_136           						0x01
#define RESP_TYPE_48            						0x02
#define RESP_TYPE_48_BUSY       						0x03

// error code
#define ERR_NONE														0x00
#define ERR_CMD															0x01
#define ERR_CMD_TIMEOUT											0x02
#define ERR_DAT															0x10
#define ERR_DAT_TIMEOUT         						0x20
#define ERR_DAT_CRC													0x40
#define ERR_DAT_ENDBIT											0x80

// init_return_flag
#define SD_INIT_SUCCESS											0
#define SD_INIT_TIMEOUT											1
#define UNUSABLE_SD_CARD										2
#define NOT_SD_CARD													3

// SD_CMD
#define CMD0_RESET    											0   //����λ  (Ӧ���ʽ��R1)
#define CMD2_GET_CID												2		//��ȡ����CID��Ϣ(��Ƭʶ��)		(Ӧ���ʽ��R2)
#define CMD3_CARD_SEND_RCA    							3		//Ҫ��ÿ�����һ���µ���Ե�ַ(RCA)		(Ӧ���ʽ��R6)
#define CMD7_SELECT_CARD    								7		//���ݻ�ȡָ����RCA,ѡ��SD����
//�����ѡ��һ������״̬��,��ѡ�������Ŀ�,��ô֮ǰ�Ŀ����Զ�ȡ��ѡ�У�
//������͵�ַ0,���ʾȡ��ѡ��ȫ����
#define CMD8_HIGH_CAPACITY_MEMCARD					8     	//ʶ�𿨵İ汾		(Ӧ���ʽ��R7)
#define CMD9_GET_MEM_INFO    								9    	//��ȡSD��صĴ洢��Ϣ,����С,������  (Ӧ���ʽ��R2)
#define CMD10_READ_CID				   						10    	//��CID����   (Ӧ���ʽ��R2)
#define CMD11_VOLTAGE_SWITCH								11		//�л���1.8V���������	(Ӧ���ʽ��R1)
#define CMD12_STOP_MULTI_BLOCKS		   				12      //ֹͣ��鴫�����    (Ӧ���ʽ��R1b)
#define CMD13_GET_CARD_STATUS								13		//��ȡ����״̬		(Ӧ���ʽ��R1)
#define CMD15_INACTIVE_CARD									15		//HOST���ÿ�		��Ӧ��
#define CMD16_SET_BLOCK_SIZE	  						16      //����SD���Ŀ��С,CSD�Ĵ���������   (Ӧ���ʽ��R1)
#define CMD17_READ_SINGLE_BLOCK		   				17      //ʹSD�����봫��״̬,��ȡ������    (Ӧ���ʽ��R1)
#define CMD18_READ_MULTI_BLOCKS  						18      //ʹSD�����봫��״̬,��ȡ�����,ֱ���յ�CMD12Ϊֹ    (Ӧ���ʽ��R1)
#define CMD19_SEND_TUNING_BLOCK							19
#define CMD20_SPEED_CLASS_CONTROL						20
#define CMD23_SET_BLOCK_COUNT	  						23      //ָ��CMD18��CMD25�Ŀ�����    (Ӧ���ʽ��R1)
#define CMD24_WRITE_SINGLE_BLOCK   					24      //ʹSD�����봫��״̬,д�뵥����    (Ӧ���ʽ��R1)
#define CMD25_WRITE_MULTI_BLOCKS	   				25      //ʹSD�����봫��״̬,д������    (Ӧ���ʽ��R1)
#define CMD27_SET_CSD				   							27      //����CSD�ɲ���λ    (Ӧ���ʽ��R1)
#define CMD28_SET_WRITE_PROT								28
#define CMD29_CLR_WRITE_PROT								29
#define CMD30_SEND_WRITE_PROT								30
#define CMD32_ERASE_WR_BLK_START						32	//����Ҫ�����������ʼ����
#define CMD33_ERASE_WR_BLK_END							33	//����Ҫ��������Ľ�������
#define CMD38_ERASE													38	//��ʼ����
#define CMD40_SINGLE_BLOCK_READ_TYPE				40
#define CMD42_LOCK_UNLOCK										42
#define CMD55_REPRENSENT_SPECIFIC_CMD   		55      //ָʾ������һ���������ض���Ӧ�ó������������Ǳ�׼����		(Ӧ���ʽ��R1)
#define CMD56_GEN_CMD												56
#define CMD58_READ_OCR   										58      //��OCR��Ϣ     (Ӧ���ʽ��R1)
#define CMD59_ENABLE_DISABLE_CRC   					59      //ʹ��/��ֹCRC��Ӧ����0x00    (Ӧ���ʽ��R1)

#define ACMD6_SET_BUS_WIDTH		  						6      	//�����������ݴ�����������߿���(00=1bit��10=4bit)    (Ӧ���ʽ��R1)
#define ACMD13_SEND_SD_STATUS								13
#define ACMD22_SEND_NUM_WR_BLOCKS						22
#define ACMD23_SET_WR_BLK_ERASE_COUNT				23
#define ACMD41_GET_VOLTAGE			  					41      //��ȡSD��ѹֵ    (Ӧ���ʽ��R3)
#define ACMD42_SET_CLR_CARD_DETECT					42
#define ACMD51_SEND_SCR											51

uint8_t SD_Init (void);
void SD_SetAbortCmd (void);
uint8_t SD_WriteMultipleBlock (const uint8_t *buffer, uint32_t sector, uint16_t count);
uint8_t SD_ReadMultipleBlock (uint8_t *buffer, uint32_t sector, uint16_t count);
void SD_SwitchCardType(FunctionalState cmd);
void SD_SetClkCmd (FunctionalState cmd) ;

void SD_SetTxSample (FunctionalState cmd);
void SD_SetRxSample (FunctionalState cmd);
//void sd_set_clk_div (SDCLK_Fre_InitTypeDef SDCLK_Frequency);
void SD_SetTranstionMode (uint8_t val);
uint8_t SD_SendCmd(uint8_t cmd, uint32_t arg, uint8_t resp_type);
void SD_SetCmdArg (uint32_t val);
void SD_SetResponseType (uint8_t val);
void SD_GetNormalInterupt (uint8_t *vp);
void SD_GetErrorInterrupt (uint8_t *vp);
uint8_t SD_WaitResponseCmd (void);
void SD_GetCmdStatus (uint8_t *vp);
void SD_SoftwareReset (void);
void SD_SetCmdIndexChk (uint8_t val);
void SD_SetCmdCRCChk (uint8_t val);
uint16_t SD_GetVoltageWindows (void);
void SD_GetResponse32 (uint8_t *vp);
uint8_t SD_GetBusyStatus (void);
uint8_t SD_GetResponseS18R (void);
void SD_CheckCardCapaticy (void);
uint16_t SD_GetRCA (void);
void SD_SelectCard (void);
void SD_SetTranstioDir (uint8_t val);
void SD_SetDatResponse (uint8_t val);
void SD_SetTimeoutCount (uint8_t val);
void SD_SetBlockSize (uint16_t val);
void SD_SetBusWidth (uint8_t val);
//void sd_rw_block_config (uint16_t card_bus_width, SDCLK_Fre_InitTypeDef SDCLK_frequency, uint8_t block_mode);
//uint8_t SD_Init (void);
void SD_SetDmaStartAddress (uint16_t val);
void SD_SetDmaBufferLength (uint16_t val);
uint8_t SD_ReadSingleBlock (uint8_t *buffer, uint32_t sector);
void SD_SetWtiteDmaStart (FunctionalState cmd);
void SD_SetSelectMram (FunctionalState cmd);
void SD_SetBlockCount (uint16_t val);
void SD_GetDataStatus (uint8_t *vp);
uint8_t SD_WaitResponseData (void);
uint8_t SD_SetCurrentStatus(void);
void SD_EarseBlock (uint32_t sector, uint32_t count);
uint8_t SD_WriteSingleBlock (uint32_t *buffer, uint32_t sector);

void SD_RccClockCmd(RCC_CLOCK_InitTypeDef RCC_CLOCK, FunctionalState cmd);
void SD_WriteReg(uint8_t addr, uint8_t val);
uint8_t SD_ReadReg (uint8_t addr);

#endif
