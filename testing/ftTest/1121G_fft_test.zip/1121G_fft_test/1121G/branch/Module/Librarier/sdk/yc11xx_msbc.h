#ifndef _YC11XX_MSBC_H_
#define _YC11XX_MSBC_H_

#include "yc11xx.h"


uint8_t MSBC_UpdateCacheWait(void);
uint8_t MSBC_LoadCacheWait(void);
void MSBC_EncDecStop(void);
void MSBC_EncodeStart(uint32_t sbcOutAddr, uint16_t sbcOutSize
                      , uint32_t pcmInPtr, uint16_t pcmInSize
                      , uint32_t cacheBufferAddr);
void MSBC_DecodeStart(uint32_t sbcInAddr, uint16_t sbcInSize
                      , uint32_t pcmOutPtr, uint16_t pcmOutSize
                      , uint32_t cacheBufferAddr);
void MSBC_Stop(void);

void MSBC_ClockOn(void);

void MSBC_ClockOff(void);

void MSBC_BusyEait(void);



#endif





