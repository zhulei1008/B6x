/**
* @file yc11xx_gpio.h
* @author duanchu.he
* @brief GPIO driver
* @version 0.1
* @date 2021-07-06
*
*
*/
#ifndef __YC11XX_GPIO_H_
#define __YC11XX_GPIO_H_


#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "yc11xx.h"

#define GPIO_TRANSNUM(x, y)								(((uint32_t)(x) * (8)) + (y))

typedef struct
{
    uint8_t CRH;
} GPIO_TypeDef;

#define GPIOA											((GPIO_TypeDef *)0x0000)
#define GPIOB											((GPIO_TypeDef *)0x0001)
#define GPIOC											((GPIO_TypeDef *)0x0002)
#define GPIOD											((GPIO_TypeDef *)0x0003)
#define GPIOE											((GPIO_TypeDef *)0x0004)

#define IS_GPIO(GPIOX) 									(((GPIOX) == GPIOA) || \
														((GPIOX) == GPIOB)  || \
														((GPIOX) == GPIOC)  || \
														((GPIOX) == GPIOD)  || \
														((GPIOX) == GPIOE))
/**
 * @brief gpio speed selection
 *
 */
typedef enum
{
    GPIO_Speed_10MHz = 1,
    GPIO_Speed_2MHz,
    GPIO_Speed_50MHz,
} GPIOSpeed_TypeDef;

#define IS_GPIO_SPEED(SPEED) 							(((SPEED) == GPIO_Speed_10MHz)  || \
														((SPEED) == GPIO_Speed_2MHz) 	|| \
														((SPEED) == GPIO_Speed_50MHz))
/**
 * @brief Configuration Mode enumeration
 *
 */
typedef enum
{
    GPIO_Mode_Deinit = 0x00,
    GPIO_Mode_QSPI_Ncs = 0x02,
    GPIO_Mode_Qspi_Sck,
    GPIO_Mode_Qspi_Io0,
    GPIO_Mode_Qspi_Io1,
    GPIO_Mode_Qspi_Io2,
    GPIO_Mode_Qspi_Io3,
    GPIO_Mode_Uart_Txd,
    GPIO_Mode_Uart_Rxd,
    GPIO_Mode_Uart_Rts,
    GPIO_Mode_Uart_Cts,
    GPIO_Mode_Uartb_Txd,
    GPIO_Mode_Uartb_Rxd,
    GPIO_Mode_Uartb_Rts,
    GPIO_Mode_Uartb_Cts,
    GPIO_Mode_Pwm_Out0,
    GPIO_mode_Nec_Gpioi = 0x11,
    GPIO_Mode_Qspi1_Ncs = 0x12,
    GPIO_Mode_Qspi1_Sck,
    GPIO_Mode_Qspi1_Io0,
    GPIO_Mode_Qspi1_Io1,
    GPIO_Mode_Qspi1_Io2,
    GPIO_Mode_Qspi1_Io3,
    GPIO_Mode_I2s_Dout,
    GPIO_Mode_I2s_Lrckout,
    GPIO_Mode_I2s_Bclkout,
    GPIO_Mode_I2s_Mclkout,
    GPIO_Mode_I2s_Din,
    GPIO_Mode_I2s_Lrckin,
    GPIO_Mode_I2s_Bclkin,
    GPIO_Mode_Spid_Miso,
    GPIO_Mode_Spid_Ncs,
    GPIO_Mode_Spid_Sck,
    GPIO_Mode_Spid_Mosi,
    GPIO_Mode_Spid_Mosi_Miso,
    GPIO_Mode_Spid_Ncsi,
    GPIO_Mode_Spid_Scki,
    GPIO_Mode_Sd_Pad_Clk,
    GPIO_Mode_Sd_Pad_Cmd,
    GPIO_Mode_Sd_Pad_Data0,
    GPIO_Mode_Sd_Pad_Data1,
    GPIO_Mode_Sd_Pad_Data2,
    GPIO_Mode_Sd_Pad_Data3,
    GPIO_Mode_Iic_Scl,
    GPIO_Mode_Iic_Sda,
    GPIO_Mode_Jtag_Tck,
    GPIO_Mode_Test_Audio_Gpio2,
    GPIO_Mode_Test_Audio_Gpio,
    GPIO_Mode_Clk_Gpio,
    GPIO_Mode_Clk_Dpll_38M4,
    GPIO_Mode_Bit_Send,
    GPIO_Mode_Micclk_Pdm,
    GPIO_Mode_Micdat_Pdm,
    GPIO_Mode_Qspi2_Ncs,
    GPIO_Mode_Qspi2_Sck,
    GPIO_Mode_Qspi2_Io0,
    GPIO_Mode_Qspi2_Io1,
    GPIO_Mode_Qspi2_Io2,
    GPIO_Mode_Qspi2_Io3,
    GPIO_Mode_Iic_Scl1,
    GPIO_Mode_Iic_Sda1,
    GPIO_Mode_Out_Low,
    GPIO_Mode_Out_High,
    GPIO_Mode_In_Up,
    GPIO_Mode_In_Down = 0x80,
    GPIO_Mode_Analog = 0xc0,
} GPIOMode_TypeDef;

/**
 * @brief gpio speed selection
 *
 */
typedef enum
{
    GPIO_WakeUpLow = 0,
    GPIO_WakeUpHigh,
} GPIOWakeUp_TypeDef;

/**
 * @brief GPIO Init structure definition
 *
 */
typedef struct
{
    uint16_t GPIO_Pin;				/* gpio pin select */
    GPIOMode_TypeDef GPIO_Mode; 	/* gpio mode select */
    GPIOSpeed_TypeDef GPIO_Speed;	/* gpio speed select */
} GPIO_InitTypeDef;



/**
 * @brief Bit_SET and Bit_RESET enumeration
 *
 */
typedef enum
{
    Bit_RESET = 0,
    Bit_SET,
} BitAction;

#define IS_BITACTION(BITACTION) 					(((BITACTION) == Bit_RESET) || \
													  ((BITACTION) == Bit_SET))

/**
 * @brief gpio long press reset time config
 *
 */
typedef enum
{
    LongPress_TimeOut_64S = 0,
    LongPress_TimeOut_56S,
    LongPress_TimeOut_48S,
    LongPress_TimeOut_40S,
    LongPress_TimeOut_32S,
    LongPress_TimeOut_24S,
    LongPress_TimeOut_16S,
    LongPress_TimeOut_8S,
} GPIO_LongPress_TimeOut;

#define IS_GPIO_LongPress_TimeOut(LongPress_TimeOut) 	(((LongPress_TimeOut) == LONG_PRESS_TIMEOUT_64S) || \
														((LongPress_TimeOut) == LONG_PRESS_TIMEOUT_56S) || \
														((LongPress_TimeOut) == LONG_PRESS_TIMEOUT_48S) || \
														((LongPress_TimeOut) == LONG_PRESS_TIMEOUT_40S) || \
														((LongPress_TimeOut) == LONG_PRESS_TIMEOUT_32S) || \
														((LongPress_TimeOut) == LONG_PRESS_TIMEOUT_24S) || \
														((LongPress_TimeOut) == LONG_PRESS_TIMEOUT_16S) || \
														((LongPress_TimeOut) == LONG_PRESS_TIMEOUT_8S))

/**
 * @brief gpio long press reset select
 *
 */
typedef enum
{
    TOUCH_0_Long_Press_Reset = 3,
    TOUCH_1_Long_Press_Reset,
    GPIO_11_Long_Press_Reset,
    GPIO_33_Long_Press_Reset,
    GPIO_35_Long_Press_Reset,
} GPIO_LongPress_Reset;

#define IS_GPIO_LongPress_Reset(LongPress_Reset) 	(((LongPress_Reset) == GPIO_11_Long_Press_Reset) || \
													((LongPress_Reset) == GPIO_33_Long_Press_Reset) || \
													((LongPress_Reset) == GPIO_35_Long_Press_Reset))

/**
 * @brief gpio interrupt type
 *
 */
typedef enum
{
    Low_Interrupt = 0,
    High_Interrupt,
    Rising_Interrupt,
    Fall_Interrupt = 4,
} Interrupt_TypeDef;

#define IS_INTERRUPT(Interrupt_Trigger) 			(((Interrupt_Trigger) == Low_Interrupt) 		|| \
													((Interrupt_Trigger) == High_Interrupt) 		|| \
													((Interrupt_Trigger) == Rising_Interrupt) 	|| \
													((Interrupt_Trigger) == (Rising_Interrupt | Fall_Interrupt)) 	|| \
													((Interrupt_Trigger) == Fall_Interrupt))


/**
 * @brief  GPIO_pins_define
 *
 */
#define GPIO_Pin_0                 					((uint16_t)0x0000)  /*!< Pin 0 selected */
#define GPIO_Pin_1                 					((uint16_t)0x0001)  /*!< Pin 1 selected */
#define GPIO_Pin_2                 					((uint16_t)0x0002)  /*!< Pin 2 selected */
#define GPIO_Pin_3                 					((uint16_t)0x0003)  /*!< Pin 3 selected */
#define GPIO_Pin_4                 					((uint16_t)0x0004)  /*!< Pin 4 selected */
#define GPIO_Pin_5                 					((uint16_t)0x0005)  /*!< Pin 5 selected */
#define GPIO_Pin_6                					((uint16_t)0x0006)  /*!< Pin 6 selected */
#define GPIO_Pin_7                 					((uint16_t)0x0007)  /*!< Pin 7 selected */


#define IS_GPIO_PIN(PIN) 							(((PIN) == GPIO_Pin_0) 	|| \
												  	((PIN) == GPIO_Pin_1) || \
												    ((PIN) == GPIO_Pin_2) || \
												    ((PIN) == GPIO_Pin_3) || \
												    ((PIN) == GPIO_Pin_4) || \
												    ((PIN) == GPIO_Pin_5) || \
												    ((PIN) == GPIO_Pin_6) || \
												    ((PIN) == GPIO_Pin_7))


/**
 * @brief gpio interrupt reg addr
 *
 */

void GPIO_DeInit(GPIO_TypeDef *gpiox);
void GPIO_Init(GPIO_TypeDef *gpiox, GPIO_InitTypeDef *gpio_InitStruct);
uint8_t GPIO_ReadDataBit(GPIO_TypeDef *gpiox, uint16_t gpio_pin);
uint8_t GPIO_ReadData(GPIO_TypeDef *gpiox);
void GPIO_SetBits(GPIO_TypeDef *gpiox, uint16_t gpio_pin);
void GPIO_ResetBits(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void GPIO_WriteBit(GPIO_TypeDef *gpiox, uint16_t gpio_pin, BitAction bitaction);
void GPIO_Write(GPIO_TypeDef *gpiox, uint16_t portval);
bool  GPIO_InterruptStatus(GPIO_TypeDef *gpiox, uint16_t gpio_pin);
void GPIO_SetInterrupt(GPIO_TypeDef *gpiox, uint16_t gpio_pin, Interrupt_TypeDef interrupt_type);
void GPIO_ClearAllInterrupt(void);
void  GPIO_ClearInterrupt(GPIO_TypeDef *gpiox, uint16_t gpio_pin);
void GPIOx_LongPressReset(GPIO_LongPress_Reset GPIO_Pinx_Reset, FunctionalState newstate);
void GPIOx_LongPressTimeOut(GPIO_LongPress_TimeOut longpress_timeout);
void GPIOx_WakeUp(GPIO_TypeDef *gpiox, uint16_t gpio_pin, GPIOWakeUp_TypeDef wakeuptype);

#ifdef __cplusplus
}
#endif

#endif

/**
  * @}
  */


/******************************************************************END OF FILE****/
