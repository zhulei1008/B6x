/**
 * @file yc11xx_nec.c
 * @brief NEC driver
 * @date 2021-08-07
 */
#include "yc11xx_nec.h"

/**
 * @Description: NEC init
 * @param {NEC_Config} config:Initial configuration
 *                      StartBuff : Configure NEC to learn the initial addresss
 *                      EndBuff   :Configure NEC learning end address
 *                      ReadPtr   :Configure NEC to learn the read pointer address
 *                      ClkDivNum :nec detect clk divide number, 7 effective data bits
 *                      DetectEn  :    NEC_Disable/NEC_enable
 * @return {*} None
 */
void NEC_RxLearnInit(NEC_Config config)
{
    HWRITEW(CORE_NEC_STARTADDR, config.StartBuff);
    HWRITEW(CORE_NEC_ENDADDR, config.EndBuff);
    HWRITEW(CORE_NEC_RPTR, config.ReadPtr);

    NEC_CONTROLRegDef necControl;
    HREAD_STRUCT(CORE_NEC_CONTROL, &necControl);
    necControl.nec_clkdiv_num = config.ClkDivNum;
    necControl.nec_en = config.DetectEn;
    HWRITE_STRUCT(CORE_NEC_CONTROL, &necControl);
}

/**
 * @Description: nec buffer items
 * @param {*}None
 * @return {*} The size of the parsed data
 */
uint16_t NEC_RxBuffLen()
{
    return HREADW(CORE_NEC_ITEMS);
}

/**
 * @Description: Update NEC read pointer position
 * @param {uint16_t} *ptr : The position of the new read pointer
 * @return {*}None
 */
void NEC_SetReadPtr(uint16_t *ptr)
{
    HWRITEW(CORE_NEC_RPTR, ptr);
}
