#ifndef _YC11XX_H_
#define _YC11XX_H_
#include <string.h>



#ifdef __cplusplus
extern "C" {
#endif
//#define FUNCTION_FPGA_WORK
/* ToDo: add here your device specific peripheral access structure typedefs
         following is an example for a timer                                  */
#define BIT0        (0x00000001U)
#define BIT1        (0x00000002U)
#define BIT2        (0x00000004U)
#define BIT3        (0x00000008U)
#define BIT4        (0x00000010U)
#define BIT5        (0x00000020U)
#define BIT6        (0x00000040U)
#define BIT7        (0x00000080U)
#define BIT8        (0x00000100U)
#define BIT9        (0x00000200U)
#define BIT10       (0x00000400U)
#define BIT11       (0x00000800U)
#define BIT12       (0x00001000U)
#define BIT13       (0x00002000U)
#define BIT14       (0x00004000U)
#define BIT15       (0x00008000U)
#define BIT16       (0x00010000U)
#define BIT17       (0x00020000U)
#define BIT18       (0x00040000U)
#define BIT19       (0x00080000U)
#define BIT20       (0x00100000U)
#define BIT21       (0x00200000U)
#define BIT22       (0x00400000U)
#define BIT23       (0x00800000U)
#define BIT24       (0x01000000U)
#define BIT25       (0x02000000U)
#define BIT26       (0x04000000U)
#define BIT27       (0x08000000U)
#define BIT28       (0x10000000U)
#define BIT29       (0x20000000U)
#define BIT30       (0x40000000U)
#define BIT31       (0x80000000U)

typedef enum
{
    RAM_UseBTSRam = 0,
    RAM_UseM0MRam,
} RAM_RegionUse;
    
#ifndef _UINT8_T_DECLARED
    typedef unsigned char       uint8_t;
#define _UINT8_T_DECLARED
#endif
#ifndef _UINT16_T_DECLARED
    typedef unsigned short      uint16_t;
#define _UINT16_T_DECLARED
#endif
#ifndef _UINT32_T_DECLARED
    typedef unsigned int        uint32_t;
#define _UINT32_T_DECLARED
#endif
#ifndef _UINT64_T_DECLARED
    typedef unsigned long long  uint64_t;
#define _UINT64_T_DECLARED
#endif
#ifndef _BYTE_T_DECLARED
    typedef unsigned char       byte;
#define _BYTE_T_DECLARED
#endif
#ifndef _WORD_T_DECLARED
    typedef unsigned short      word;
#define _WORD_T_DECLARED
#endif
#ifndef _UINT_T_DECLARED
    typedef unsigned int uint;
#define _UINT_T_DECLARED
#endif
#ifndef _ULL_T_DECLARED
    typedef unsigned long long ull;
#define _ULL_T_DECLARED
#endif
    
#ifndef _INT8_T_DECLARED
    typedef signed char         int8_t;
#define _INT8_T_DECLARED
#endif
#ifndef _INT16_T_DECLARED
    typedef signed short    int16_t;
#define _INT16_T_DECLARED
#endif
#ifndef _INT32_T_DECLARED
    typedef signed int      int32_t;
#define _INT32_T_DECLARED
#endif
#ifndef _INT64_T_DECLARED
    typedef signed long long    int64_t;
#define _INT64_T_DECLARED
#endif
    
    
#ifndef BOOL
    typedef unsigned char       BOOL;
#endif
    
#ifndef bool
    typedef enum {false = 0, true =1} bool;
#endif
    
    
#define     __O     volatile                  /*!< defines 'write only' permissions     */
#define     __IO    volatile                  /*!< defines 'read / write' permissions   */
#define     __I    	const volatile            /*!< defines 'read only' permissions   */
    
#ifndef Boolean
#ifndef IS_BOOLEAN
    typedef enum {FALSE = 0, TRUE =1} Boolean;
#define IS_BOOLEAN(bool) ((bool == FALSE) || (bool == TRUE))
#endif
#endif
    
    
#ifndef FunctionalState
#ifndef IS_FUNCTIONAL_STATE
    typedef enum {DISABLE = 0, ENABLE =1} FunctionalState;
#define IS_FUNCTIONAL_STATE(state) ((state== DISABLE) || (state == ENABLE))
#endif
#endif
    
#ifndef FunctionalState
    typedef enum {ERROR = 0, SUCCESS = 1} ErrorStatus;
#define IS_ERROR_STATE(status) ((status== ERROR) || (status == SUCCESS))
#endif
    
#ifndef FlagStatus
#ifndef IS_FLAG_STATUS_RESET
    typedef enum {RESET = 0, SET = !RESET} FlagStatus, ITStatus;
#define IS_FLAG_STATUS_RESET(state) ((state== RESET) || (state == RESET))
#endif
#endif



#ifndef  OS_ENTER_CRITICAL
extern uint16_t gOsEnterCriticalCnt;
extern void disable_mie(void);
extern void enable_mie(void);
#define OS_INITIAL_CRITICAL() {gOsEnterCriticalCnt = 0;}
#define OS_ENTER_CRITICAL() {__asm("csrc mstatus, 0x00000008"); gOsEnterCriticalCnt++;}
#define OS_EXIT_CRITICAL() {if((--gOsEnterCriticalCnt) == 0) { __asm("csrs mstatus, 0x00000008");}}
#endif

#define WFI() __asm("wfi");


typedef struct
{
    unsigned int buck_setting_area			: 28;	//User should not change this area

    unsigned int user_bit_second_power_on			: 1;	//R 0		//For Check First Power On
    unsigned int user_bit_charge_power_off			: 1;	//R 0		//For Check Last is charge Power Off
    unsigned int user_bit_reserved					: 2;	//R 0		//For Future Use
} LPM_AppCtrlRegDef;		//LPM_CTRL	0x833e


/* -------------------------  Interrupt Number Definition  ------------------------ */


/** @addtogroup Configuration_of_CMSIS
  * @{
  */


/* ================================================================================ */
/* ================      Processor and Core Peripheral Section     ================ */
/* ================================================================================ */


/** @} */ /* End of group Configuration_of_CMSIS */
typedef enum
{
    /* -------------------  Cortex-M0 Processor Exceptions Numbers  -------------------                                                                 */
    Reset_IRQn                    = -15,              /*!<   1  Reset Vector, invoked on Power up and warm reset                  */
    NonMaskableInt_IRQn           = -14,              /*!<   2  Non maskable Interrupt, cannot be stopped or preempted         */
    HardFault_IRQn                = -13,              /*!<   3  Hard Fault, all classes of Fault                                                 */
    SVCall_IRQn                   =  -5,              /*!<  11  System Service Call via SVC instruction                                  */
    DebugMonitor_IRQn             =  -4,              /*!<  12  Debug Monitor    	*/
    PendSV_IRQn                   =  -2,              /*!<  14  Pendable request for system service                                       */
    /* ---------------------  xx Specific Interrupt Numbers  --------------------                                                                     */
    USB_IRQn              =   16,
    iicd_IRQn             =   17,
    qspi_IRQn             =   18,
    spid_IRQn             =   19,
    uart_IRQn             =   20,
    uartb_IRQn            =   21,
    adcd_IRQn             =   22,
    i2s_IRQn              =   23,
    bt_IRQn               =   24,
    host_IRQn            =   25,
    gpio_IRQn              =   26,
    sbc0_IRQn             =   27,
    sbc1_IRQn             =   28,
    fft_IRQn              =   29,
    dma_IRQn              =   30,
    sdio_IRQn             =   31,
    pwm0_IRQn           =   32,
    pwm1_IRQn           =   33,
    pwm2_IRQn           =   34,
    pwm3_IRQn           =   35,
    pwm4_IRQn           =   36,
    pwm5_IRQn           =   37,
    pwm6_IRQn           =   38,
    pwm7_IRQn           =   39,
    wdt2_IRQn             =   40,
    wdt_IRQn             =   41,
    deb_IRQn			= 42,
    iicd1_IRQn			= 43,
    sdma_intr			= 44,
    rv_tm_IRQn			= 48,
    qspi1_IRQn			= 49,
    qspi2_IRQn			= 50,
} IRQn_Type;

//*************************************************************************************
//interrupt id
//*************************************************************************************
#define	USB_INTID		0
#define	IICD_INTID		1
#define	QSPI_INTID		2
#define	SPID_INTID		3
#define	UART_INTID		4
#define	UARTB_INTID		5
#define	ADCD_INTID		6
#define	I2S_INTID		7
#define	BT_INTID		8
#define GPIO_INTID		9
#define OTP_INTID		10
#define SBC0_INTID		11
#define SBC1_INTID		12
#define FFT_INTID		13
#define DMA_INTID		14
#define SDIO_INTID		15
#define TIMER0_INTID	16
#define TIMER1_INTID	17
#define TIMER2_INTID	18
#define TIMER3_INTID	19
#define TIMER4_INTID	20
#define TIMER5_INTID	21
#define TIMER6_INTID	22
#define TIMER7_INTID	23

#define WDT2_INTID		24
#define WDT_INTID		25

//*************************************************************************************
//end interrupt id
//*************************************************************************************
#define reg_check_ram_m0(reg)				(((int)(reg) & 0x00010000) != 0)
#define reg_map(reg)						((int)(reg) | 0x10000000)
#define reg_map_m0(reg)						((int)(reg) | 0x10010000)
#define reg_map2(reg)						((int)(reg) | 0x1001c000)
#define reg_map_rv(reg)						((int)(reg) | 0x1001f000)
#define PREFETCH_LINE(addr)					*(volatile int*)addr = 0
#define des_ctrl							*(volatile uint8_t*)0x30000002
#define des_key(x)							*(volatile uint8_t*)(0x30000003 + x)
#define des_in(x)							*(volatile uint8_t*)(0x30000018 + x)
#define crypt_status						*(volatile uint8_t*)0x30010000
#define des_out(x)							*(volatile uint8_t*)(0x30010004 + x)
#define des_start							*(volatile uint8_t*)0x30008000
#define rsa_exp(x)							*(volatile int32_t*)(0x30020000 + x*4)
#define rsa_out(x)							*(volatile int32_t*)(0x30020000 + x*4)
#define rsa_in(x)							*(volatile int32_t*)(0x30020080 + x*4)
#define rsa_mod(x)							*(volatile int32_t*)(0x30020100 + x*4)
#define rsa_ctrl							*(volatile int32_t*)0x30020180


#define YC1121G_RV_BASE                          (0x0001f000)   /* RV Base Address */

#define RV_IRQ_PRIO_BASEADDR                    (YC1121G_RV_BASE + 0x0400) //0x1f400
#define RV_IRQ_PEND_BASEADDR                    (YC1121G_RV_BASE + 0x0800) //0x1f800
#define RV_IRQ_ENAB_BASEADDR                    (YC1121G_RV_BASE + 0x0a00) //0x1fa00
#define RV_IRQ_THRD_BASEADDR                    (YC1121G_RV_BASE + 0x0c00) //0x1fc00
#define RV_IRQ_CLAM_BASEADDR                    (YC1121G_RV_BASE + 0x0c04) //0x1fc04

#define RV_IRQ_PRIO(x)				*(volatile uint8_t*)(RV_IRQ_PRIO_BASEADDR + ((uint8_t)((uint8_t)(x)/2)))
#define RV_IRQ_PEND(x)				*(volatile uint8_t*)(RV_IRQ_PEND_BASEADDR + ((uint8_t)((uint8_t)(x)/8)))
#define RV_IRQ_ENAB(x)				*(volatile uint8_t*)(RV_IRQ_ENAB_BASEADDR + ((uint8_t)((uint8_t)(x)/8)))
#define RV_IRQ_THOD					*(volatile int*)(RV_IRQ_THRD_BASEADDR)
#define RV_IRQ_CLAM					*(volatile int*)(RV_IRQ_CLAM_BASEADDR)

#define TRACE_FIFO				            *(volatile int*)0xe0002020
#define NVIC_ISER				            *(volatile int*)0xe000e100
#define NVIC_ICER				            *(volatile int*)0xe000e180

static inline void enable_intr(int intid)
{
    NVIC_ISER |= 1 << intid;
}
static inline void disable_intr(int intid)
{
    NVIC_ICER  = 1 << intid;
}
#define CPU_MHZ        (24*1000000)
/* SysTick registers */
/* SysTick control & status */
#define INITCPU_SYST_CSR     ((volatile unsigned int *)0x1001f000)
/* SysTick Reload value */
#define INITCPU_SYST_RVR     ((volatile unsigned int *)0x1001f008)
/* SysTick Current value */
#define INITCPU_SYST_CVR     ((volatile unsigned int *)0x1001f00c)
/* SysTick CSR register bits */
#define INITCPU_SYST_CSR_COUNTFLAG 16
#define INITCPU_SYST_CSR_CLKSOURCE 8
#define INITCPU_SYST_CSR_TICKINT   1
#define INITCPU_SYST_CSR_ENABLE    3
#define INITCPU_SYSTICK_SYSCLOCK		  0xFF
#define INITCPU_SYSTICK_HALF_SYSCLOCK	   0


//void _nop(void) __attribute__((optimize("O0")));

#define TO_16BIT_ADDR(A) (((int)A)&0xFFFF)


#define HREAD(reg)			*(volatile byte*)(reg_map(reg))
#define HREAD2(reg)			*(volatile byte*)(reg_map2(reg))
#define HREADRV(reg)			*(volatile int*)(reg_map_rv(reg))
#define HREAD3(reg)			*(volatile byte*)(reg_map_m0(reg))
#define HREAD4(reg)			*(volatile int*)(reg_map_m0(reg))
#define HREADM(addr)		*(volatile byte*)(addr)
#define HREADW(reg)			(HREAD(reg) | HREAD(reg + 1) << 8)
#define HREAD24BIT(reg)			((int)(HREAD(reg)) | (HREAD(reg + 1) << 8)| (HREAD(reg + 2) << 16))
#define HREADADDR3(reg)			((int)(HREAD(reg)) | (HREAD(reg + 1) << 8)| (HREAD(reg + 2) << 16))
#define HWRITE(reg,val)  do {(HREAD(reg) = (byte)(val));}while(0)
#define HWRITEW(reg, val)	do { HWRITE(reg, (int)(val));HWRITE(reg + 1, (int)(val) >> 8); }while(0)

#define HREADL(reg)		(int)(HREAD(reg)) | (HREAD(reg + 1) << 8)| (HREAD(reg + 2) << 16)| (HREAD(reg + 3) << 24)
#define HWRITEL(reg, val)	do { HWRITE(reg, (int)(val));HWRITE(reg + 1, (int)(val) >> 8);HWRITE(reg + 2, (int)(val) >> 16);HWRITE(reg + 3, (int)(val) >> 24); }while(0)
#define HWRITE_INLINE(reg,val)			do {(HREAD(reg) = (byte)(val));}while(0)
#define HWRITEW_INLINE(reg,val)			do { HWRITE_INLINE(reg, (int)(val));HWRITE_INLINE(reg + 1, (int)(val) >> 8); }while(0)
#define HREAD_INLINE(reg)			((HREAD(reg)))

#define HWRITE2(reg,val) 	do {HREAD2(reg)=(byte)(val); volatile int n = 1; while(n--);}while(0)
#define HWRITERV(reg,val) 	do {HREADRV(reg)=(int)(val); volatile int n = 1; while(n--);}while(0)
#define HWRITE3(reg,val) 	do {HREAD3(reg)=(byte)(val); volatile int n = 1; while(n--);}while(0)
#define HWRITE4(reg,val) 	do {HREAD4(reg)=(int)(val); volatile int n = 1; while(n--);}while(0)
#define HWRITEM(addr,val) do {HREADM(addr)=(byte)val;  volatile int n = 1; while(n--);} while(0)
#define HWRITE24BIT(reg,val) do { HWRITE(reg, (int)(val));HWRITE(reg + 1, (int)(val) >> 8); HWRITE(reg + 2, (int)(val) >> 16); }while(0)
//#define HWOR(reg, val)	HWRITE(reg, HREAD(reg) | (val))

#define HWOR(reg, val)	HWRITE(reg, ((HREAD(reg) )| (val)))
#define HWCOR(reg, val)	HWRITE(reg, HREAD(reg) & ~(val))

#define HWORW(reg, val)	HWRITEW(reg, ((HREADW(reg) )| (val)))
#define HWCORW(reg, val)	HWRITEW(reg, HREADW(reg) & ~(val))

//#define SETBIT(reg, val)	HWRITE(reg, HREAD(reg) | (val))
//#define CLRBIT(reg, val)	HWRITE(reg, HREAD(reg) & ~(val))

#define BW(addr) (int)*(addr) << 24 | (int)*(addr + 1) << 16 | (int)*(addr + 2) << 8 | *(addr + 3)

#define HREAD_STRUCT(reg, stc)  (*(uint8_t*)stc = *(volatile byte*)(reg_map(reg)))
#define HWRITE_STRUCT(reg, stc)  (*(volatile byte*)(reg_map(reg)) = *(uint8_t*)(stc))

#define HREADW_STRUCT(reg, stc)  (*(uint16_t*)stc = HREADW(reg))
#define HWRITEW_STRUCT(reg, stc)  HWRITEW(reg, *(uint16_t*)(stc))

#define HREAD24BIT_STRUCT(reg, stc)  (*(uint32_t*)stc = HREAD24BIT(reg))
#define HWRITE24BIT_STRUCT(reg, stc)  HWRITE24BIT(reg, *(uint32_t*)(stc))

#define HREADL_STRUCT(reg, stc)  (*(uint32_t*)stc = HREADL(reg))
#define HWRITEL_STRUCT(reg, stc)  HWRITEL(reg, *(uint32_t*)(stc))

#define RB_UPDATE_PTR(p,s,e) ((p) == (e))?((p)=(s)):((p)++)

/********************************************************************************
** Macros to get and put bytes to and from a stream (small Endian format)
*/
#define STREAM_TO_UINT8(u8, p)   {u8 = (uint8_t)(*(p)); (p) += 1;}
#define STREAM_TO_UINT16(u16, p) {u16 = ((uint16_t)(*(p)) + (((uint16_t)(*((p) + 1))) << 8)); (p) += 2;}
#define STREAM_TO_UINT24(u32, p) {u32 = (((uint32_t)(*(p))) + ((((uint32_t)(*((p) + 1)))) << 8) + ((((uint32_t)(*((p) + 2)))) << 16) ); (p) += 3;}
#define STREAM_TO_UINT32(u32, p) {u32 = (((uint32_t)(*(p))) + ((((uint32_t)(*((p) + 1)))) << 8) + ((((uint32_t)(*((p) + 2)))) << 16) + ((((uint32_t)(*((p) + 3)))) << 24)); (p) += 4;}

/********************************************************************************
** Macros to get and put bytes to and from a stream (Big Endian format)
*/
#define BE_STREAM_TO_UINT8(u8, p)   {u8 = (uint8_t)(*(p)); (p) += 1;}
#define BE_STREAM_TO_UINT16(u16, p) {u16 = (uint16_t)(((uint16_t)(*(p)) << 8) + (uint16_t)(*((p) + 1))); (p) += 2;}
#define BE_STREAM_TO_UINT24(u32, p) {u32 = (((uint32_t)(*((p) + 2))) + ((uint32_t)(*((p) + 1)) << 8) + ((uint32_t)(*(p)) << 16)); (p) += 3;}
#define BE_STREAM_TO_UINT32(u32, p) {u32 = ((uint32_t)(*((p) + 3)) + ((uint32_t)(*((p) + 2)) << 8) + ((uint32_t)(*((p) + 1)) << 16) + ((uint32_t)(*(p)) << 24)); (p) += 4;}



static inline void hw_delay()
{
    __asm__ __volatile__("nop");
    __asm__ __volatile__("nop");
    __asm__ __volatile__("nop");
    __asm__ __volatile__("nop");
    __asm__ __volatile__("nop");
}

/***********************************core_clkoff*************************************************/
typedef enum
{
    REG_CLOCK_OFF_AUTH_ROM		= 0x0001,
    REG_CLOCK_OFF_EFUSE			= 0x0002,
    REG_CLOCK_OFF_DEBUG_UART	= 0x0004,
    REG_CLOCK_OFF_ITRACE		= 0x0008,
    REG_CLOCK_OFF_QSPI			= 0x0010,
    REG_CLOCK_OFF_AUDIO_DAC		= 0x0020,
    REG_CLOCK_OFF_VOICE_FILTER	= 0x0040,
    REG_CLOCK_OFF_I2C			= 0x0080,
    REG_CLOCK_OFF_CM0 			= 0x0100,
    REG_CLOCK_OFF_MRAM			= 0x0200,
    REG_CLOCK_OFF_USB			= 0x0400,
    REG_CLOCK_OFF_SBC			= 0x0800,
    REG_CLOCK_OFF_SPI			= 0x1000,
    REG_CLOCK_OFF_SDIO			= 0x2000,
    REG_CLOCK_OFF_I2S			= 0x4000,
    REG_CLOCK_OFF_UART			= 0x8000,
} CORE_ClockOffEnumDef;

#define BIT_0  0x0001
#define BIT_1  0x0002
#define BIT_2  0x0004
#define BIT_3  0x0008
#define BIT_4  0x0010
#define BIT_5  0x0020
#define BIT_6  0x0040
#define BIT_7  0x0080
#define BIT_8  0x0100
#define BIT_9  0x0200
#define BIT_10  0x0400
#define BIT_11  0x0800
#define BIT_12  0x1000
#define BIT_13  0x2000
#define BIT_14  0x4000
#define BIT_15  0x8000


#define NONE_LPM_FLAG 0x00
#define KEY_LPM_FLAG 0x01
#define VP_LPM_FLAG 0x02
#define LED_LPM_FLAG 0x04
#define LINK_LPM_FLAG 0x10
#define CHARGER_LPM_FLAG 0x20
#define M0_LPM_FLAG 0x40
#define HIBER_LPM_FLAG 0x80
#define IGNORE_LPM_FLAG (BT_POWERON_LINK_PERFORMANCE_LPM_FLAG|LINK_LPM_FLAG|HIBER_LPM_FLAG)
#define PWM_LPM_FLAG 0x100
#define TWS_SYNC_PWR_OFF_LPM_FLAG 0x200
#define IPHONE_INSTORAGE_LPM_FLAG 0x400
#define OAL_LPM_FLAG	0x800
#define BT_POWERON_LINK_PERFORMANCE_LPM_FLAG	0x1000
#define APP_FIRST_POWERON_LPM_FLAG	0x2000

#define M0_LPM_REG  mem_m0_lpm_flag



void xmemcpy(uint8_t *dest, const uint8_t *src, uint16_t len);
uint16_t xstrlen(const char *s);
void error_handle(void);

void Lpm_LockLpm(uint16_t lpmNum);
void Lpm_unLockLpm(uint16_t lpmNum);
BOOL Lpm_CheckLpmFlag(void);
void whileDelay(int delayValue);
void whileDelayshort(int delayValue);

BOOL xramcmp(volatile uint8_t *op1, volatile uint8_t *op2, int len);
void xramcpy(volatile uint8_t *des, volatile uint8_t *src, int len);
uint32_t math_abs(int32_t value);
uint32_t CoreReg_ClkControl(CORE_ClockOffEnumDef clkIndex, BOOL isEnable);


void CoreReg_LpmWriteCommon(uint32_t writeVal, uint16_t writeLpmReg, uint8_t writeLpmVal);
void CoreReg_LpmWrite(uint32_t writeVal, uint8_t writeLpmVal);
void CoreReg_LpmWriteCtrl(uint32_t writeVal);
void CoreReg_LpmWriteCtrl2(uint32_t writeVal);
void CoreReg_LpmWriteGpioLowWake(uint32_t writeVal);
void CoreReg_LpmWriteGpioHighWake(uint32_t writeVal);
void CoreReg_LpmWriteCounter(uint32_t writeVal);
void CoreReg_LpmWriteBuckCfg(uint32_t writeVal);
void CoreReg_LpmWriteChargeCtrl(uint32_t writeVal);


void CoreReg_LpmWrite2(uint32_t writeVal, uint8_t writeLpmVal);
void CoreReg_LpmWrite2EnterScanMode(uint32_t writeVal);
void CoreReg_LpmWrite2ChargeLowHighWakeup(uint32_t writeVal);
void CoreReg_LpmWrite2LdoControl(uint32_t writeVal);
void CoreReg_LpmWrite2Gpio2TouchWake(uint32_t writeVal);
void CoreReg_LpmWrite2IceWdtLongRst(uint32_t writeVal);
uint32_t CoreReg_LpmGetIceWdtLongRst(void);

void CoreReg_LpmAppRegRead(LPM_AppCtrlRegDef *lpmCtrl);
void CoreReg_LpmAppRegWrite(LPM_AppCtrlRegDef *lpmCtrl);
void CoreReg_LpmAppRegFirstPowerOnControl(BOOL isPowerOn);
void CoreReg_LpmAppRegChargePowerOffControl(BOOL isChargePowerOff);

void Audio_AdcDSMDIV_12MConfig(short init, int frac);
void Audio_AdcDSMDIV_12MEnable(short en, short dither_en, short div2);
void Audio_AdcDSMDIV_11MConfig(short init, int frac);
void Audio_AdcDSMDIV_11MEnable(short en, short dither_en, short div2);
void Audio_ClkInit(void);

void __attribute__((noinline)) SetLockLpmWriteReg(void);
void __attribute__((noinline)) SetReleaseLpmWriteReg(void);
#endif //_YC11XX_H

