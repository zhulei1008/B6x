/**
***************************************************************************
* @file:  yc11xx_msbc.c
* @Date:  2021-8-10-11:15:58
* @brief:  MSBC basic driver
**************************************************************************
*/

#include "yc11xx_msbc.h"
#include "btreg.h"
#include "yc11xx.h"
#include "reg_addr.h"
#include "reg_struct.h"
#include "yc11xx_sbc.h"
/**
 * @brief  :Check to see if decoding is complete and update status
 * @param    void
 * @return  :1:sbc decoder is busy
 */
uint8_t MSBC_UpdateCacheWait(void)
{
    MISC_STATUSRegDef miscStatus;
    HREAD_STRUCT(CORE_MISC_STATUS, &miscStatus);
    return miscStatus.sbc_decoder_busy;
}
/**
 * @brief  :Load the data in the buffer
 * @param    void
 * @return  :
 */
uint8_t MSBC_LoadCacheWait(void)
{
    if(((HREADW(CORE_SBC_SWP)) == (HREADW(CORE_SBC_SOURCE_READ_PTR))))
        return 0;
    else
        return 1;
}
/**
 * @brief  :MSBC encode/decode stop
 * @param    void
 * @return  None
 */
void MSBC_EncDecStop(void)
{

    SBC_SCTRLRegDef sbcSctrl;
    HWRITE(CORE_SBC_CTRL, 0 );

    HREAD_STRUCT(CORE_SBC_SCTRL, &sbcSctrl);
    sbcSctrl.sbc_sctrl_reserved = 0;
    sbcSctrl.cache_ctrl = 0;
    sbcSctrl.sbc_ff_48k_en = 0;
    sbcSctrl.msbc_dec_en = 0;
    sbcSctrl.sbc_eq_en = 0;
    HWRITE_STRUCT(CORE_SBC_CTRL, &sbcSctrl);

    HWRITEW(CORE_SBC_SWP, 0 );
}

/**
 * @brief  :MSBC starts coding
 * @param    sbcOutAddr : The start address of the SBC data after the MSBC coding is complete
 * @param    sbcOutSize :MSBC Length of SBC data after encoding
 * @param    pcmInPtr :The start address of the PCM data to be encoded
 * @param    pcmInSize:Length of PCM data to be encoded
 * @param    cacheBufferAddr  :MSBC code is buffer space
 * @return  :NONE
 */
void MSBC_EncodeStart(uint32_t sbcOutAddr, uint16_t sbcOutSize
                      , uint32_t pcmInPtr, uint16_t pcmInSize
                      , uint32_t cacheBufferAddr
                     )
{

    SBC_CTRLRegDef sbcCtrl = {0};
    BOOL isOutMRAM = reg_check_ram_m0(sbcOutAddr);
    BOOL isPCMInMRAM = reg_check_ram_m0(pcmInPtr);
    BOOL isCacheInMRAM = reg_check_ram_m0(cacheBufferAddr);

    HWRITEW(CORE_SBC_SRC_START, (pcmInPtr & 0x0000ffff));
    HWRITEW(CORE_SBC_DST_START, (sbcOutAddr & 0x0000ffff));

    HREAD_STRUCT(CORE_SBC_CTRL, &sbcCtrl);
    sbcCtrl.sbc_src_bit16 = isPCMInMRAM;
    sbcCtrl.sbc_dst_bit16 = isOutMRAM;
    sbcCtrl.msbc_en = 1;
    HWRITE_STRUCT(CORE_SBC_CTRL, &sbcCtrl);


    HWRITEW(CORE_SBC_SRC_LEN, pcmInSize + 1);
    HWRITEW(CORE_SBC_DST_LEN, sbcOutSize);

    SBC_CLEARRegDef sbcClearReg = {0};

    HREAD_STRUCT(CORE_SBC_CLEAR, &sbcClearReg);
    sbcClearReg.sbc_src_addr_clr = 1;
    sbcClearReg.sbc_dst_addr_clr = 1;
    HWRITE_STRUCT(CORE_SBC_CLEAR, &sbcClearReg);


    HWRITE(CORE_SBC_CLEAR, 0);


    HREAD_STRUCT(CORE_SBC_CTRL, &sbcCtrl);
    sbcCtrl.sbc_block_en = 1;
    HWRITE_STRUCT(CORE_SBC_CTRL, &sbcCtrl);
    //DEBUG_LOG(LOG_LEVEL_CORE, "IPC" ,"xxx: 0x%04X", 0xe055, temp);

    // Load data
    HWRITEW(CORE_SBC_CACHE_CFG0, cacheBufferAddr);

    SBC_CTRL2RegDef sbcCtrl2 = {0};

    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cache_addr = isCacheInMRAM;
    sbcCtrl2.sbc_cache_load = 1;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);

    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cache_load = 0;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);// generate signal

    while(MSBC_UpdateCacheWait());

    HWRITEW(CORE_SBC_SWP, (pcmInSize));
    while(MSBC_LoadCacheWait());

    // Update data
    HWRITEW(CORE_SBC_CACHE_CFG0, cacheBufferAddr);

    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cache_update = 1;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);

    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cache_update = 0;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);// generate signal

    while(MSBC_UpdateCacheWait());
    //DEBUG_LOG_STRING("**********mSBC encode end*******************\r\n");
    MSBC_EncDecStop();
}

/**
 * @brief  :MSBC starts decoding
 * @param    sbcInAddr : The start address of the SBC data to be decoded
 * @param    sbcInSize :Length of SBC data to decode
 * @param    pcmOutPtr :Start address of PCM data output after MSBC decoding
 * @param    pcmOutSize:Length of PCM data after MSBC decoding
 * @param    cacheBufferAddr  :MSBC decode is buffer space
 * @return  :NONE
 */
void MSBC_DecodeStart(uint32_t sbcInAddr, uint16_t sbcInSize
                      , uint32_t pcmOutPtr, uint16_t pcmOutSize
                      , uint32_t cacheBufferAddr)
{
    SBC_CTRLRegDef sbcCtrl = {0};
    BOOL isInMRAM = reg_check_ram_m0(sbcInAddr);
    BOOL isPCMOutMRAM = reg_check_ram_m0(pcmOutPtr);
    BOOL isCacheInMRAM = reg_check_ram_m0(cacheBufferAddr);

    HWRITEW(CORE_SBC_SRC_START, sbcInAddr);
    HWRITEW(CORE_SBC_DST_START, pcmOutPtr);

    HREAD_STRUCT(CORE_SBC_CTRL, &sbcCtrl);
    sbcCtrl.sbc_src_bit16 = isInMRAM;
    sbcCtrl.sbc_dst_bit16 = isPCMOutMRAM;
    HWRITE_STRUCT(CORE_SBC_CTRL, &sbcCtrl);

    HWRITEW(CORE_SBC_SRC_LEN, sbcInSize + 1);
    HWRITEW(CORE_SBC_DST_LEN, pcmOutSize);

    SBC_CLEARRegDef sbcClearReg = {0};

    HREAD_STRUCT(CORE_SBC_CLEAR, &sbcClearReg);
    sbcClearReg.sbc_src_addr_clr = 1;
    sbcClearReg.sbc_dst_addr_clr = 1;
    HWRITE_STRUCT(CORE_SBC_CLEAR, &sbcClearReg);
    HWRITE(CORE_SBC_CLEAR, 0);

    SBC_SCTRLRegDef sbcSctrl;
    HREAD_STRUCT(CORE_SBC_SCTRL, &sbcSctrl);
    sbcSctrl.msbc_dec_en = 1;
    HWRITE_STRUCT(CORE_SBC_SCTRL, &sbcSctrl);

    HREAD_STRUCT(CORE_SBC_CTRL, &sbcCtrl);////////////////
    sbcCtrl.sbc_block_en = 1;
    HWRITE_STRUCT(CORE_SBC_CTRL, &sbcCtrl);
    //DEBUG_LOG(LOG_LEVEL_CORE, "IPC" ,"xxx: 0x%04X", 0xe055, temp);

    // Load data
    HWRITEW(CORE_SBC_CACHE_CFG0, cacheBufferAddr );

    SBC_CTRL2RegDef sbcCtrl2 = {0};

    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cache_addr = isCacheInMRAM;
    sbcCtrl2.sbc_cache_load = 1;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);

    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cache_load = 0;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);// generate signal

    while(MSBC_UpdateCacheWait());

    // Wait sbc ready
    HWRITEW(CORE_SBC_SWP, sbcInSize);
    while(MSBC_LoadCacheWait())
    {
        SBC_STATUSRegDef sbcStatus;
        HREAD_STRUCT(CORE_SBC_STATUS, &sbcStatus);
        if(sbcStatus.sbc_error != 0)
        {
            break;
        }
    }

    // Update data
    HWRITEW(CORE_SBC_CACHE_CFG0, cacheBufferAddr);

    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cache_update = 1;
    sbcCtrl2.sbc_cache_addr = 1;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);

    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cache_update = 0;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);// generate signal
    while(MSBC_UpdateCacheWait());
    //DEBUG_LOG_STRING("**********mSBC encode end*******************\r\n");
    MSBC_EncDecStop();

}

/**
 * @brief  :open SBC clock
 * @param    void
 * @return  None
 */
void MSBC_ClockOn(void)
{
    CoreReg_ClkControl(REG_CLOCK_OFF_SBC, ENABLE); //open voice clock
}
/**
 * @brief  :close sbc clock
 * @param    void
 * @return  None
 */
void MSBC_ClockOff(void)
{
    CoreReg_ClkControl(REG_CLOCK_OFF_SBC, DISABLE); //open voice clock
}
/**
 * @brief  :msbc work stop
 * @param    void
 * @return  None
 */
void MSBC_Stop(void)
{

}
/**
 * @brief  :Check whether the MSBC is busy
 * @param    void
 * @return  None
 */
void MSBC_BusyEait(void)
{
    while(((HREAD(CORE_MISC_STATUS)) & BIT_4) != 0);
}









