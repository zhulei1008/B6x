#include "yc11xx_timer.h"
#include "yc11xx_gpio.h"

void PWM_Config(GPIO_TypeDef *GPIOx, uint16_t pin, uint16_t pcnt, uint16_t ncnt);
void PWM_DisConfig(GPIO_TypeDef *GPIOx, uint16_t pin);
void PWM_Config_Sync(GPIO_TypeDef *GPIOx, uint16_t pin, uint16_t pcnt, uint16_t ncnt);
