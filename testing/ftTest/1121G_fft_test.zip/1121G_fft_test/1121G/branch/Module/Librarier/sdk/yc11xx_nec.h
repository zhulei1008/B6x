
#ifndef _YC11XX_NEC_H_
#define _YC11XX_NEC_H_

#include "yc11xx.h"
#include "reg_addr.h"
#include "reg_struct.h"

typedef enum
{
    NEC_Disable,
    NEC_enable
} NEC_IsDetectEnable;

typedef struct
{
    uint32_t StartBuff;                 /*!< nec start address. */
    uint32_t EndBuff;                   /*!< nec end address. */
    uint32_t  ReadPtr;                   /*!< nec read pointer. */
    uint8_t ClkDivNum;                  /*!< nec detect clk divide number. */
    NEC_IsDetectEnable DetectEn;        /*!< nec detect enable. */
} NEC_Config;

void NEC_RxLearnInit(NEC_Config config);
uint16_t NEC_RxBuffLen();
void NEC_SetReadPtr(uint16_t *ptr);

#endif //_YC11XX_NEC_H_
