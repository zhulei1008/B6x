/*
 * Copyright (c) 2006-2020, YICHIP Development Team
 * @file     yc_timer.c
 * @brief    source file for setting timer
 *
 * Change Logs:
 * Date            Author             Version        Notes
 * 2021-3-15       zhouduo            V1.0.0         the first version
 * 2021-07-15      Lichengrun         V1.1.0         the formal version
 * note:  temporary version,under revision
 */

#include "yc11xx_systick.h"
#include "reg_addr.h"
#include "yc_nvic.h"

static SysTickIRQ_CB_Handle gSysTickIrqCallback;
static uint32_t gSysTickUnitUs;

/**
 * @brief  systick enable,interrupt enable ,load value
 * @param    reloadvalue
 * @return
 */
uint32_t SysTick_Config(uint32_t reloadvalue)
{
    reloadvalue -= 1;
    //if(!IS_RELOAD_VALUE(ReloadValue))	return 1;
    *INITCPU_SYST_CSR &= ~ (((uint32_t)1) << INITCPU_SYST_CSR_ENABLE);
    *INITCPU_SYST_CVR = reloadvalue; //clear the current value

    *INITCPU_SYST_CSR |= \
                         ((INITCPU_SYSTICK_SYSCLOCK << INITCPU_SYST_CSR_CLKSOURCE) | \
                          (1 << INITCPU_SYST_CSR_ENABLE) | (1 << INITCPU_SYST_CSR_TICKINT));
    return 0;
}

/**
 * @brief  change the system DPLL to normal  DPLL
 * @param  None
 * @return None
 */
uint32_t SysTick_TimerGet1usTicks(void)
{
    uint8_t tmp = HREAD(CORE_CLOCK_CTRL);
    uint8_t tmpVal = (tmp >> 1) & 0x03;
    uint8_t rtnVal = 0;
    switch(tmpVal)
    {
    case CLOCK_48M_multiple:
    {
        rtnVal = SYSTEM_CLOCK_48M;
        break;
    }
    case CLOCK_64M_multiple:
    {
        rtnVal = SYSTEM_CLOCK_64M;
        break;
    }
    case CLOCK_96M_multiple:
    {
        rtnVal = SYSTEM_CLOCK_96M;
        break;
    }
    case CLOCK_192M_multiple:
    {
        rtnVal = SYSTEM_CLOCK_192M;
        break;
    }
    default:
        break;
    }
    return rtnVal;
}

/**
 * @brief  Initialize the system clock.
 * @param  systemClk can be CLOCK_48M_multiple.
 * @param  uintUs: One interrupt  in a period of us.
 * @param  callback: function pointer.
 * @return None
 */
void SysTick_Init(uint32_t systemClk, uint32_t uintUs, SysTickIRQ_CB_Handle callback)
{
    gSysTickIrqCallback = callback;
    gSysTickUnitUs = uintUs;
    SysTick_ChangeDPLL(systemClk);
    if(gSysTickIrqCallback != 0)
    {
        NVIC_Configuration(rv_tm_IRQn, 2, ENABLE);
    }
}

BOOL SysTick_CheckInFastDpll(void)
{
    uint8_t tmp = HREAD(CORE_CLOCK_CTRL);
    uint8_t systemClk = (tmp >> 1) & 0x03;

    return (systemClk != CLOCK_48M_multiple);
}

/**
 * @brief  Modify the system DPLL.
 * @param  systemClk: system DPLL only can be  CLOCK_48M_multiple.
 * @return None
 */
void SysTick_ChangeDPLL(uint8_t systemClk)
{
    uint8_t tmp = HREAD(CORE_CLOCK_CTRL);

    uint8_t tmpVal = systemClk;
    tmp &= 0xf9;
    tmp |= tmpVal << 1;
    HWRITE(CORE_CLOCK_CTRL, tmp);

    SysTick_Config(SysTick_TimerGet1usTicks() * gSysTickUnitUs);
}

/**
 * @brief  change the system DPLL to highspeed  DPLL.
 * @param  None
 * @return None
 */
void SysTick_ChangeToFastDPLL(void)
{
    SysTick_ChangeDPLL(CLOCK_192M_multiple);
    hw_delay(); //Delay a while for work stable
}

/**
 * @brief  change the system DPLL to normal  DPLL.
 * @param  None
 * @return None
 */
void SysTick_ChangeToNormalDPLL(void)
{
    SysTick_ChangeDPLL(CLOCK_48M_multiple);
    hw_delay(); //Delay a while for work stable
}



void SysTick_DelayMs(uint32_t nms)
{
    SysTick_DelayUs(nms * 1000);
}

/**
  * @brief  Perform a certain amount of time delay.
  * @param  nus:Prescribed length.
  * @return None
  */
void SysTick_DelayUs(uint32_t nus)
{
    uint32_t ticks = 0;
    uint32_t told = 0, tnow = 0, tcnt = 0;
    ticks = nus * SysTick_TimerGet1usTicks();
    uint32_t reload = (SysTick_TimerGet1usTicks() * gSysTickUnitUs) - 1;
    told = *(INITCPU_SYST_CVR);
    while(1)
    {
        tnow = *(INITCPU_SYST_CVR);
        if(tnow != told)
        {
            if(tnow < told)
            {
                tcnt += told - tnow;
            }
            else
            {
                tcnt += reload - tnow + told;
            }
            told = tnow;
            if(tcnt >= ticks)
            {
                break;
            }
        }
    }
}

/**
  * @brief  Interrupt handler function.
  * @param  None
  * @return None
  */
void RV_TM_IRQHandler(void)
{
    if(gSysTickIrqCallback != NULL)
    {
        gSysTickIrqCallback(0);
    }
}






