/**
 * @file yc11xx_cvsd.c
 * @brief
 * @date 2021-08-11
 */
#include "yc11xx_cvsd.h"

const int coef_cvsd[41] =
{
    0x000c, 0x0012, 0x001b, 0x0024, 0x0029, 0x0028, 0x001d, 0x0007,
    0xffe4, 0xffb9, 0xff8a, 0xff5f, 0xff42, 0xff3c, 0xff53, 0xff8c,
    0xffe4, 0x0050, 0x00c2, 0x0125, 0x0163, 0x0168, 0x0127, 0x009d,
    0xffd5, 0xfee7, 0xfdf7, 0xfd33, 0xfccb, 0xfcea, 0xfdaf, 0xff27,
    0x0149, 0x03f3, 0x06ee, 0x09f6, 0x0cbd, 0x0ef9, 0x106b, 0x10eb, 0x0000
};

/**
 * @Description: CVSD enable
 * @param {*}None
 * @return {*}None
 */
void Audio_CvsdClkEnable(void)
{
    HWCORW(CORE_CLOCK_OFF, REG_CLOCK_OFF_VOICE_FILTER);
    //	HWCORW(CORE_CLOCK_OFF, REG_CLOCK_OFF_SBC);// Only need for 64K to 48K farrow filter init(8K -> 64K -> 48K)
}

/**
 * @Description: CVSD disenable
 * @param {*}None
 * @return {*}None
 */
void Audio_CvsdClkDisable(void)
{
    CVSD_CONTROLRegDef cvsdCtrl;
    HREAD_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
    cvsdCtrl.cvsd_grp_en = 0;
    HWRITE_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
}

/**
 * @Description: Wait to clear the filter parameters
 * @param {*}
 * @return {*}
 */
void Audio_CvsdWaitCvsdFilterClrDone(void)
{
    PERIPHERAL_STATUSRegDef statusReg;
    do
    {
        HREAD_STRUCT(CORE_PERIPHERAL_STATUS, &statusReg);
    }
    while(statusReg.cvsd_filt_clr_done == 0);
}

/**
 * @Description: Initialization function
 * @param {*}
 * @return {*}
 */
void Audio_CvsdCoefInit(void)
{
    uint16_t temp_16, i;
    CVSD_CONTROLRegDef cvsdCtrl;
    HREAD_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
    cvsdCtrl.cvsd_filter_clr = 1;
    HWRITE_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);

    ADDA_COEF_WR_CTRLRegDef coefWrCtrl = {0};
    coefWrCtrl.cvsd_coef_wr_en = 1;
    HWRITE_STRUCT(CORE_ADDA_COEF_WR_CTRL, &coefWrCtrl);
    for(i = 0; i < 41; i ++)
    {
        HWRITEW(CORE_ADDA_COEF_WDATA_0, coef_cvsd[i]);

        coefWrCtrl.cvsd_coef_strobe = 1;
        HWRITE_STRUCT(CORE_ADDA_COEF_WR_CTRL, &coefWrCtrl);
        coefWrCtrl.cvsd_coef_strobe = 0;
        HWRITE_STRUCT(CORE_ADDA_COEF_WR_CTRL, &coefWrCtrl);
    }
    coefWrCtrl.cvsd_coef_wr_en = 0;
    coefWrCtrl.cvsd_coef_strobe = 0;
    HWRITE_STRUCT(CORE_ADDA_COEF_WR_CTRL, &coefWrCtrl);
    Audio_CvsdWaitCvsdFilterClrDone();
}

/**
 * @Description: start-up
 * @param {*}
 * @return {*}
 */
void Audio_CvsdStart(void)
{
    CVSD_CONTROLRegDef cvsdCtrl;
    HREAD_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);

    cvsdCtrl.cvsd_dec_8k_mode_en = 1;
#ifdef FUNCTION_CVSD_OVER_SOFT_8KTO48K
    cvsdCtrl.cvsd_dec_48k_mode_en = 1;
    cvsdCtrl.cvsd_ff_64to48k_en = 1;
#else
    cvsdCtrl.cvsd_dec_48k_mode_en = 0;
    cvsdCtrl.cvsd_ff_64to48k_en = 0;
#endif
    cvsdCtrl.cvsd_filter_clr = 0;
    cvsdCtrl.cvsd_dma_en = 1;
    HWRITE_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
}

/**
 * @Description:CVSD register clear
 * @param {*}
 * @return {*}
 */
void Audio_CvsdStop(void)
{
    HWRITE(CORE_CVSD_CONTROL, 0);
}

/**
 * @Description: Configure CVSD buff address
 * @param {uint32_t} cvsdOutBufferAddr:CVSD coded output address
 * @param {uint16_t} cvsdOutBufferSize:Output buff size after CVSD encoding
 * @param {uint32_t} cvsdPcmInBufferAddr:Address to be CVSD encoded
 * @param {uint16_t} cvsdPcmInBufferSize:The size of the data to be CVSD encoded
 * @return {*}None
 */
void Audio_CvsdOutInit(uint32_t cvsdOutBufferAddr, uint16_t cvsdOutBufferSize, uint32_t cvsdPcmInBufferAddr, uint16_t cvsdPcmInBufferSize)
{
    BOOL pcmInMramFlag = reg_check_ram_m0(cvsdPcmInBufferAddr);
    BOOL cvsdOutMramFlag = reg_check_ram_m0(cvsdOutBufferAddr);
    // PCM In Setting
    HWRITEW(CORE_PCM_SOURCE_ADDRESS, (uint16_t) cvsdPcmInBufferAddr);

    CVSD_CTRL1RegDef cvsdCtrl1;
    HREAD_STRUCT(CORE_CVSD_CTRL1, &cvsdCtrl1);
    cvsdCtrl1.cvsd_pcmin_mram_sel = pcmInMramFlag;
    cvsdCtrl1.cvsd_cvsdout_mram_sel = cvsdOutMramFlag;
    HWRITE_STRUCT(CORE_CVSD_CTRL1, &cvsdCtrl1);

    HWRITEW(CORE_CVSD_DEST_ADDRESS, cvsdOutBufferAddr);
}

/**
 * @Description: Configure CVSD buff address
 * @param {uint32_t} cvsdInBufferAddr:CVSD data address to decode
 * @param {uint16_t} cvsdInBufferSize:CVSD data size to decode
 * @param {uint32_t} cvsdPcmOutBufferAddr:Data buff address after CVSD decoding
 * @param {uint16_t} cvsdPcmOutBufferSize:Data buff size after CVSD decoding
 * @return {*}None
 */
void Audio_CvsdInInit(uint32_t cvsdInBufferAddr, uint16_t cvsdInBufferSize, uint32_t cvsdPcmOutBufferAddr, uint16_t cvsdPcmOutBufferSize)
{
    BOOL pcmOutMramFlag = reg_check_ram_m0(cvsdPcmOutBufferAddr);
    BOOL cvsdInMramFlag = reg_check_ram_m0(cvsdInBufferAddr);


    // Init cvsd in buffer addr
    HWRITEW(CORE_CVSD_SOURCE_ADDRESS, (uint16_t)cvsdInBufferAddr);

    CVSD_CTRL1RegDef cvsdCtrl1;
    HREAD_STRUCT(CORE_CVSD_CTRL1, &cvsdCtrl1);
    cvsdCtrl1.cvsd_8kpcmout_mram_sel = pcmOutMramFlag;
    cvsdCtrl1.cvsd_cvsdin_mram_sel = cvsdInMramFlag;
    HWRITE_STRUCT(CORE_CVSD_CTRL1, &cvsdCtrl1);

    // In cvsd, it have 8K and 48K out
    HWRITEW(CORE_PCM_8K_DEST_ADDRESS, (uint16_t)cvsdPcmOutBufferAddr);
}

/**
 * @Description:Cvsd encoding and decoding initialization function, encoding and decoding at the same time
 * @param {uint32_t} cvsdInBufferAddr:Buff address before decoding
 * @param {uint16_t} cvsdInBufferSize:The size of the data to be decoded
 * @param {uint32_t} cvsdPcmOutBufferAddr:The decoded buff address
 * @param {uint16_t} cvsdPcmOutBufferSize:The decoded buff size
 * @param {uint32_t} cvsdOutBufferAddr:Buff address after CVSD encoding
 * @param {uint16_t} cvsdOutBufferSize:The size of the encoded data
 * @param {uint32_t} cvsdPcmInBufferAddr:Raw data to be encoded
 * @param {uint16_t} cvsdPcmInBufferSize:The size of the original data to be encoded
 * @param {uint8_t} vsdGrpLength:Group length
 * @return {*}None
 */
void Audio_CvsdInit(uint32_t cvsdInBufferAddr, uint16_t cvsdInBufferSize, uint32_t cvsdPcmOutBufferAddr, uint16_t cvsdPcmOutBufferSize, uint32_t cvsdOutBufferAddr, uint16_t cvsdOutBufferSize, uint32_t cvsdPcmInBufferAddr, uint16_t cvsdPcmInBufferSize, uint16_t cvsdGrpLength)
{
    // Enable clock
    Audio_CvsdClkEnable();

    // Init cvsd out, pcm in buffer, and init adc
    Audio_CvsdOutInit(cvsdOutBufferAddr, cvsdOutBufferSize
                      , cvsdPcmInBufferAddr, cvsdPcmInBufferSize);
    Audio_CvsdInInit(cvsdInBufferAddr, cvsdInBufferSize
                     , cvsdPcmOutBufferAddr, cvsdPcmOutBufferSize);
    HWRITEW(CORE_CVSD_BUFFER_LEN, cvsdOutBufferSize - 1);

    //cvsd filter enable, it will reuse sbc resource. 1: for cvsd; 0: for sbc/msbc
    SBC_CTRL2RegDef sbcCtrl2;
    HREAD_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);
    sbcCtrl2.sbc_cvsd_mux_en = 1;
    HWRITE_STRUCT(CORE_SBC_CTRL2, &sbcCtrl2);

    // clear and init cvsd filter
    Audio_CvsdCoefInit();

    // cvsd encode and decode will work with the length
    HWRITEW(CORE_CVSD_GROUP_LENGTH, cvsdGrpLength);

    Audio_CvsdStart();
}

/**
 * @Description:Check if the CVSD module is working
 * @param {*}None
 * @return {BOOL} Is working return true
 */
BOOL Audio_CvsdCheckEnable(void)
{
    CVSD_CONTROLRegDef cvsdCtrl;
    HREAD_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
    return cvsdCtrl.cvsd_grp_en;
}

/**
 * @Description: Check if dma is working in CVSD
 * @param {*}None
 * @return {BOOL}Is working return true
 */
BOOL Audio_CvsdCheckWorkStart(void)
{
    CVSD_CONTROLRegDef cvsdCtrl;
    HREAD_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
    return cvsdCtrl.cvsd_dma_en;
}

/**
 * @Description: Check whether the CVSD work is completed
 * @param {*}None
 * @return {BOOL}Return true when work is complete
 */
BOOL Audio_CvsdCheckWorkInprocess(void)
{
    PERIPHERAL_STATUSRegDef statusReg;
    HREAD_STRUCT(CORE_PERIPHERAL_STATUS, &statusReg);
    return (statusReg.cvsd_grp_done == 0);
}

/**
 * @Description: Is the data to be decoded in sram or mram
 * @param {*}None
 * @return {BOOL}mram returns true
 */
BOOL Audio_CvsdCheckInUseMRam(void)
{
    CVSD_CTRL1RegDef cvsdCtrl1;
    HREAD_STRUCT(CORE_CVSD_CTRL1, &cvsdCtrl1);
    return cvsdCtrl1.cvsd_cvsdin_mram_sel;
}

/**
 * @Description: Cvsd encoding output ram selection
 * @param {*}None
 * @return {BOOL}mram returns true
 */
BOOL Audio_CvsdCheckOutUseMRam(void)
{
    CVSD_CTRL1RegDef cvsdCtrl1;
    HREAD_STRUCT(CORE_CVSD_CTRL1, &cvsdCtrl1);
    return cvsdCtrl1.cvsd_cvsdout_mram_sel;
}

/**
 * @Description: Get the buff address that needs to be decoded
 * @param {*}None
 * @return {uint32_t}Get the buff address that needs to be decoded
 */
uint32_t Audio_CvsdGetInAddr(void)
{
    uint32_t cvsdInDataPtr;
    CVSD_CTRL1RegDef cvsdCtrl1;
    HREAD_STRUCT(CORE_CVSD_CTRL1, &cvsdCtrl1);

    cvsdInDataPtr = HREADW(CORE_CVSD_SOURCE_ADDRESS);
    if(cvsdCtrl1.cvsd_cvsdin_mram_sel)
    {
        cvsdInDataPtr = reg_map_m0(cvsdInDataPtr);
    }
    else
    {
        cvsdInDataPtr = reg_map(cvsdInDataPtr);
    }
    return cvsdInDataPtr;
}

/**
 * @Description: Get the encoded buff address
 * @param {*}None
 * @return {uint32_t}Get the encoded buff address
 */
uint32_t Audio_CvsdGetOutAddr(void)
{
    uint32_t cvsdOutDataPtr;
    CVSD_CTRL1RegDef cvsdCtrl1;
    HREAD_STRUCT(CORE_CVSD_CTRL1, &cvsdCtrl1);

    cvsdOutDataPtr = HREADW(CORE_CVSD_DEST_ADDRESS);
    if(cvsdCtrl1.cvsd_cvsdout_mram_sel)
    {
        cvsdOutDataPtr = reg_map_m0(cvsdOutDataPtr);
    }
    else
    {
        cvsdOutDataPtr = reg_map(cvsdOutDataPtr);
    }
    return cvsdOutDataPtr;
}

/**
 * @Description: CVSD starts to work
 * @param {*}None
 * @return {*}None
 */
void Audio_CvsdWorkEnable(void)
{
    CVSD_CONTROLRegDef cvsdCtrl;
    HREAD_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
    cvsdCtrl.cvsd_grp_en = 1;
    HWRITE_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
}

/**
 * @Description: CVSD disable
 * @param {*}None
 * @return {*}None
 */
void Audio_CvsdWorkDisable(void)
{
    CVSD_CONTROLRegDef cvsdCtrl;
    HREAD_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
    cvsdCtrl.cvsd_grp_en = 0;
    HWRITE_STRUCT(CORE_CVSD_CONTROL, &cvsdCtrl);
}
