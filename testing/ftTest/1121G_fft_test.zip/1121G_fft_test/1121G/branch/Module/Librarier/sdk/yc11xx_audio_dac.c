/**
 * @file yc11xx_audio_dac.c
 * @brief Only 12.288M and 11.2896M frequencies are allowed in DAC frequency selection
 * @date 2021-07-06
 */

#include "yc11xx_audio_dac.h"
#include "reg_addr.h"
#include "reg_struct.h"
#include "yc11xx_systick.h"
#include "board_config.h"
#include "reg_struct.h"
#include "rfreg_addr.h"
#include "rfreg_struct.h"

const int coef_hbf1[33] =
{
    -1, 4, -8, 17, -31, 53, -87,
        137, -209, 308, -444, 626, -865, 1173,
        -1566, 2061, -2677, 3437, -4370, 5506, -6887,
        8567, -10618, 13143, -16299, 20336, -25691, 33184,
        -44586, 64510, -109897, 333316, 524287
    };
const int coef_hbf2[16] =
{
    10, -47, 149, -383, 857, -1725,
    3202, -5577, 9236, -14737, 22989, -35790,
    57717, -105603, 331847, 524287
};
const int coef_cic_comp[6] = {1311, 224, -9738, -4407, 41196, 73902};

static uint8_t DAC_ChkSum = 0;

/**
 * @brief DAC initialization function, you need to configure the initialization structure DAC to start
 * @param  dacParam:DAC mode config
 *                      SoundTrack:stereo/mono
 *                      LeftChannelConfig:DAC_LChannelSelLeft/DAC_LChannelSelRight/DAC_LChannelSelLeftRightMix/DAC_LChannelSelLeftRightNegation/DAC_LChannelClose
 *                      RightChannelConfig:DAC_RChannelSelLeft/DAC_RChannelSelRight/DAC_RChannelSelLeftRightMix/DAC_RChannelSelLeftRightNegation/DAC_RChannelClose
 *                      DacClk:DAC_Clk8k/DAC_Clk16k/DAC_Clk24k/DAC_Clk44p1k/DAC_Clk48k
 *                      DacStartAddr:Enter the start address of DAC playback
 *                      DacBufferSize:BUFF LEN
 *                      DacWorkMode:DAC_WorkContinuous/DAC_WorkWptr
 *                      DacDsmDitherEn:DAC_DSMDitherDisable/DAC_DSMDitherEnable
 *                      DSMOutdisMode:DAC_DSMModeNormal/DAC_DSMModeByNumSel
 *                      DacZeroNumSel:0~7
 *                      DateMode:DAC_Date16Bit\DAC_Date24Bit
 *                      DWAEn:DAC_ScrambleDWADisable/DAC_ScrambleDWAEnable
 *                      DWAMode:DAC_ScrambleDWANormal/DAC_ScrambleDWARandom/DAC_ScrambleDWARButterfly
 *                      FadeEn:DAC_FadeEnable/DAC_FadeDisable
 *                      FadeStep:dac vol step of Channel LR
 *                      Vol:0~10
 */
void AUDIO_DacInit(DAC_InitParamDef dacParam)
{
    if(dacParam.DacBufferSize <= 1 || dacParam.DacStartAddr == NULL || dacParam.Vol > 10 || dacParam.DacZeroNumSel > 7)
    {
        return;
    }
    CoreReg_ClkControl(REG_CLOCK_OFF_AUDIO_DAC, TRUE);
    DAC_SELRegDef dacSel;
    AUDIO_CLKSELDef dacClkSource;
    AUDIO_DIV_CLK_SELRegDef dacClkDiv;
    DAC_CTRLRegDef dacCtrl;
    HREADW_STRUCT(CORE_AUDIO_CLKSEL, &dacClkSource);
    HREAD_STRUCT(CORE_AUDIO_DIV_CLK_SEL, &dacClkDiv);
    HREADW_STRUCT(CORE_DAC_SEL, &dacSel);
#ifndef CLOCK_HALVED
    if(dacParam.DacClk == DAC_Clk8k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide3;
        dacSel.dac_clk_sel = DAC_Mclk4;
    }
    else if(dacParam.DacClk == DAC_Clk11p025)
    {
        dacClkSource.dac_clksel = DAC_Clk11p2896M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide2;
        dacSel.dac_clk_sel = DAC_Mclk4;
    }
    else if(dacParam.DacClk == DAC_Clk12)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide2;
        dacSel.dac_clk_sel = DAC_Mclk4;
    }
    else if(dacParam.DacClk == DAC_Clk16k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide3;
        dacSel.dac_clk_sel = DAC_Mclk2;
    }
    else if(dacParam.DacClk == DAC_Clk22p05)
    {
        dacClkSource.dac_clksel = DAC_Clk11p2896M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide1;
        dacSel.dac_clk_sel = DAC_Mclk4;
    }
    else if(dacParam.DacClk == DAC_Clk24k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide1;
        dacSel.dac_clk_sel = DAC_Mclk4;
    }
    else if(dacParam.DacClk == DAC_Clk32k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide3;
        dacSel.dac_clk_sel = DAC_Mclk;
    }
    else if(dacParam.DacClk == DAC_Clk44p1k)
    {
        dacClkSource.dac_clksel = DAC_Clk11p2896M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide1;
        dacSel.dac_clk_sel = DAC_Mclk2;
    }
    else if(dacParam.DacClk == DAC_Clk48k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide2;
        dacSel.dac_clk_sel = DAC_Mclk;
    }
#else
    if(dacParam.DacClk == DAC_Clk8k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide3;
        dacSel.dac_clk_sel = DAC_Mclk2;
    }
    else if(dacParam.DacClk == DAC_Clk11p025)
    {
        dacClkSource.dac_clksel = DAC_Clk11p2896M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide2;
        dacSel.dac_clk_sel = DAC_Mclk2;
    }
    else if(dacParam.DacClk == DAC_Clk12)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide2;
        dacSel.dac_clk_sel = DAC_Mclk2;
    }
    else if(dacParam.DacClk == DAC_Clk16k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide3;
        dacSel.dac_clk_sel = DAC_Mclk;
    }
    else if(dacParam.DacClk == DAC_Clk22p05)
    {
        dacClkSource.dac_clksel = DAC_Clk11p2896M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide1;
        dacSel.dac_clk_sel = DAC_Mclk2;
    }
    else if(dacParam.DacClk == DAC_Clk24k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide1;
        dacSel.dac_clk_sel = DAC_Mclk2;
    }
    //    else if(dacParam.DacClk==DAC_Clk32k)
    //    {
    //        dacClkSource.dac_clksel=DAC_Clk12p288M;
    //        dacClkDiv.dac_divclk_sel=DAC_ClkDivide3;
    //        dacSel.dac_clk_sel=DAC_Mclk;
    //    }
    else if(dacParam.DacClk == DAC_Clk44p1k)
    {
        dacClkSource.dac_clksel = DAC_Clk11p2896M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide1;
        dacSel.dac_clk_sel = DAC_Mclk;
    }
    else if(dacParam.DacClk == DAC_Clk48k)
    {
        dacClkSource.dac_clksel = DAC_Clk12p288M;
        dacClkDiv.dac_divclk_sel = DAC_ClkDivide1;
        dacSel.dac_clk_sel = DAC_Mclk;
    }
#endif
    HWRITE_STRUCT(CORE_AUDIO_DIV_CLK_SEL, &dacClkDiv);
    HWRITEW_STRUCT(CORE_AUDIO_CLKSEL, &dacClkSource);
    HWRITEW_STRUCT(CORE_DAC_SEL, &dacSel);

    AUDIO_DacCoefConfig();

    DAC_VOL_LRegDef DAC_VolL;
    HREAD24BIT_STRUCT(CORE_DAC_VOL_L, &DAC_VolL);
    DAC_VolL.dac_vol_step_l = dacParam.FadeStep;
    DAC_VolL.dac_vol_target_val_l = 0;
    HWRITE24BIT_STRUCT(CORE_DAC_VOL_L, &DAC_VolL);

    DAC_VOL_RRegDef DAC_VolR;
    HREAD24BIT_STRUCT(CORE_DAC_VOL_R, &DAC_VolR);
    DAC_VolR.dac_vol_step_r = dacParam.FadeStep;
    DAC_VolR.dac_vol_target_val_r = 0;
    HWRITE24BIT_STRUCT(CORE_DAC_VOL_R, &DAC_VolR);

    DAC_VOL_PRegDef DAC_VolP;
    HREAD24BIT_STRUCT(CORE_DAC_VOL_P, &DAC_VolP);
    DAC_VolP.dac_vol_step_p = dacParam.FadeStep;
    DAC_VolP.dac_voll_target_val_p = 0;
    HWRITE24BIT_STRUCT(CORE_DAC_VOL_P, &DAC_VolP);

    DAC_DITHER_POWRegDef DAC_Dither;
    HREAD24BIT_STRUCT(CORE_DAC_DITHER_POW, &DAC_Dither);
    DAC_Dither.dac_dither_power = 0x4FFDF3;
    HWRITE24BIT_STRUCT(CORE_DAC_DITHER_POW, &DAC_Dither);

    AUDIO_DacSelectChannel(dacParam);
    AUDIO_DacMonoSteroConfig(dacParam.SoundTrack);
    HREAD_STRUCT(CORE_DAC_CTRL, &dacCtrl);
    if(reg_check_ram_m0(dacParam.DacStartAddr))
    {
        dacCtrl.dac_mram_sel = 1;
    }
    else
    {
        dacCtrl.dac_mram_sel = 0;
    }
    if(dacParam.DacWorkMode == DAC_WorkContinuous)
    {
        dacCtrl.dac_conti_mode = 1;
    }
    else
    {
        dacCtrl.dac_conti_mode = 0;
    }
    dacCtrl.dac_mute_lr = 0;
    HWRITE_STRUCT(CORE_DAC_CTRL, &dacCtrl);

    HREADW_STRUCT(CORE_DAC_SEL, &dacSel);
    if(dacParam.DateMode == DAC_Date24Bit)
    {
        dacSel.dac_dat_wid_mode = 1;
    }
    else
    {
        dacSel.dac_dat_wid_mode = 0;
    }

    if(dacParam.DacDsmDitherEn == DAC_DSMDitherDisable)
    {
        dacSel.dac_dither_en = 0;
    }
    else
    {
        dacSel.dac_dither_en = 1;
    }
    if(dacParam.DSMOutdisMode == DAC_DSMModeNormal)
    {
        dacSel.dac_dsm_outdis_mode = 0;
    }
    else
    {
        dacSel.dac_dsm_outdis_mode = 1;
        dacSel.dac_zero_num_sel = dacParam.DacZeroNumSel;
    }
    if(dacParam.DWAMode == DAC_ScrambleDWARDisable)
    {
        dacSel.dac_scramble_en = 0;
    }
    else
    {
        dacSel.dac_scramble_en = 1;
        dacSel.dac_scramble_mode = dacParam.DWAMode;
    }
    HWRITEW_STRUCT(CORE_DAC_SEL, &dacSel);

    HWRITEW(CORE_DAC_SOURCE_ADDRESS, dacParam.DacStartAddr);
    HWRITEW(CORE_DAC_WPTR, dacParam.DacStartAddr);
    HWRITEW(CORE_DAC_LEN, dacParam.DacBufferSize - 1);
    dacCtrl.dac_filter_en = 1;
    dacCtrl.dac_sdm_en = 1;
    dacCtrl.dac_en = 1;
    HWRITE_STRUCT(CORE_DAC_CTRL, &dacCtrl);

    //Simulation configuration
    if(AUDIO_DacIsAnaOpen())
    {
        AUDIO_DacVolConfig(dacParam.Vol);
        return;
    }

    if(dacParam.OutMode == DAC_DifferentialOutput)
    {
        AUDIO_DacAnaDiffConfig(DAC_AnaStereo);
    }
    else if(dacParam.OutMode == DAC_SingleEndOutput)
    {
        AUDIO_DacAnaSEConfig(DAC_AnaStereo);
    }
    else if(dacParam.OutMode == DAC_VcomOutput)
    {
        AUDIO_DacAnaVcomConfig(DAC_AnaStereo);
    }
    AUDIO_DacVolConfig(dacParam.Vol);
}

/**
 * @Description: Filter Parameters Write to Register Function
 * @param {*}None
 * @return {*}None
 */
void AUDIO_DacCoefConfig(void)
{
    HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x04);
    for(int i = 0; i < 33; i++)
    {
        HWRITE(CORE_ADDA_COEF_WDATA_0, coef_hbf1[i] >> 0);
        HWRITE(CORE_ADDA_COEF_WDATA_1, coef_hbf1[i] >> 8);
        HWRITE(CORE_ADDA_COEF_WDATA_2, coef_hbf1[i] >> 16);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x0c);
        SysTick_DelayUs(5);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x04);
        SysTick_DelayUs(5);
        DAC_ChkSum += ((uint8_t)coef_hbf1[i] + (uint8_t)(coef_hbf1[i] >> 8) + (uint8_t)(coef_hbf1[i] >> 16));
    }
    for(int i = 0; i < 16; i++)
    {
        HWRITE(CORE_ADDA_COEF_WDATA_0, coef_hbf2[i] >> 0);
        HWRITE(CORE_ADDA_COEF_WDATA_1, coef_hbf2[i] >> 8);
        HWRITE(CORE_ADDA_COEF_WDATA_2, coef_hbf2[i] >> 16);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x0c);
        SysTick_DelayUs(5);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x04);
        SysTick_DelayUs(5);
        DAC_ChkSum += ((uint8_t)coef_hbf2[i] + (uint8_t)(coef_hbf2[i] >> 8) + (uint8_t)(coef_hbf2[i] >> 16));
    }
    for(int i = 0; i < 6; i++)
    {
        HWRITE(CORE_ADDA_COEF_WDATA_0, coef_cic_comp[i] >> 0);
        HWRITE(CORE_ADDA_COEF_WDATA_1, coef_cic_comp[i] >> 8);
        HWRITE(CORE_ADDA_COEF_WDATA_2, coef_cic_comp[i] >> 16);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x0c);
        SysTick_DelayUs(5);
        HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x04);
        SysTick_DelayUs(5);
        DAC_ChkSum += ((uint8_t)coef_cic_comp[i] + (uint8_t)(coef_cic_comp[i] >> 8) + (uint8_t)(coef_cic_comp[i] >> 16));
    }
    HWRITE(CORE_ADDA_COEF_WR_CTRL, 0x00);
}

/**
 * @brief Clear RAMP rising completion signal
 */
void AUDIO_DacClearRampDown(void)
{
    RAMP_CTRLRegDef clearRamp;
    HREAD_STRUCT(CORE_RAMP_CTRL, &clearRamp);
    clearRamp.ramp_down_finish_clr = 1;
    HWRITE_STRUCT(CORE_RAMP_CTRL, &clearRamp);

    SysTick_DelayUs(1);
    HREAD_STRUCT(CORE_RAMP_CTRL, &clearRamp);
    clearRamp.ramp_down_finish_clr = 0;
    HWRITE_STRUCT(CORE_RAMP_CTRL, &clearRamp);
}

/**
 * @Description: Select Left and Right Channels
 * @param {DAC_InitParamDef} config
 *                      SoundTrack:stereo/mono
 *                      LeftChannelConfig:DAC_LChannelSelLeft/DAC_LChannelSelRight/DAC_LChannelSelLeftRightMix/DAC_LChannelSelLeftRightNegation/DAC_LChannelClose
 *                      RightChannelConfig:DAC_RChannelSelLeft/DAC_RChannelSelRight/DAC_RChannelSelLeftRightMix/DAC_RChannelSelLeftRightNegation/DAC_RChannelClose
 *                      DacClk:DAC_Clk8k/DAC_Clk16k/DAC_Clk24k/DAC_Clk44p1k/DAC_Clk48k
 *                      DacStartAddr:Enter the start address of DAC playback
 *                      DacBufferSize:BUFF LEN
 *                      DacWorkMode:DAC_WorkContinuous/DAC_WorkWptr
 *                      DacDsmDitherEn:DAC_DSMDitherDisable/DAC_DSMDitherEnable
 *                      DSMOutdisMode:DAC_DSMModeNormal/DAC_DSMModeByNumSel
 *                      DacZeroNumSel:0~7
 *                      DateMode:DAC_Date16Bit\DAC_Date24Bit
 *                      DWAEn:DAC_ScrambleDWADisable/DAC_ScrambleDWAEnable
 *                      DWAMode:DAC_ScrambleDWANormal/DAC_ScrambleDWARandom/DAC_ScrambleDWARButterfly
 *                      FadeEn:DAC_FadeEnable/DAC_FadeDisable
 *                      FadeStep:dac vol step of Channel LR
 *                      Vol:0~10
 * @return {*}
 */
void AUDIO_DacSelectChannel(DAC_InitParamDef config)
{
    uint8_t temp;
    DAC_SEL2RegDef dacSel2;
    DAC_SELRegDef dacSel;
    HREADW_STRUCT(CORE_DAC_SEL2, &dacSel2);
    HREADW_STRUCT(CORE_DAC_SEL, &dacSel);
    dacSel2.dac_ana_clk_en = 1;
    if(config.LeftChannelConfig == DAC_LChannelClose)
    {
        dacSel2.dac_clk_en_l = 0;
    }
    else
    {
        dacSel2.dac_clk_en_l = 1;
        dacSel2.dac_din_l_sel = config.LeftChannelConfig;
        if(config.FadeEn == DAC_FadeEnable)
        {
            dacSel.dac_vol_fade_dis_l = 0;
        }
        else
        {
            dacSel.dac_vol_fade_dis_l = 1;
        }
    }
    if(config.RightChannelConfig == DAC_RChannelClose)
    {
        dacSel2.dac_clk_en_r = 0;
    }
    else
    {
        dacSel2.dac_clk_en_r = 1;
        dacSel2.dac_din_r_sel = config.RightChannelConfig;
        if(config.FadeEn == DAC_FadeEnable)
        {
            dacSel.dac_vol_fade_dis_r = 0;
        }
        else
        {
            dacSel.dac_vol_fade_dis_r = 1;
        }
    }
    HWRITEW_STRUCT(CORE_DAC_SEL2, &dacSel2);
    HWRITEW_STRUCT(CORE_DAC_SEL, &dacSel);
}

/**
 * @Description: Mono-Dual Channel Selection
 * @param {DAC_SoundTrackDev} mono_flag锛?    stereo/mono
 * @return {*}
 */
void AUDIO_DacMonoSteroConfig(DAC_SoundTrackDev mono_flag)
{
    DAC_SELRegDef dacSel;
    HREADW_STRUCT(CORE_DAC_SEL, &dacSel);
    if(mono_flag == stereo)
    {
        dacSel.dac_dma_mono_mode = 0;
    }
    else
    {
        dacSel.dac_dma_mono_mode = 1;
    }
    HWRITEW_STRUCT(CORE_DAC_SEL, &dacSel);
}

void AUDIO_DacAnaStop(void)
{
    //    HWRITE(0x8b05,0x01);
    codec_vmid_en0RegDef vmidEn0;
    memset(&vmidEn0, 0, sizeof(vmidEn0));
    vmidEn0.da_vmid_discharge = 1;
    vmidEn0.da_vmid_extcap_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b16,0x3c);
    au_dac_en2RegDef dacEn2;
    memset(&dacEn2, 0, sizeof(dacEn2));
    dacEn2.da_dac_mute_l_en = 1;
    dacEn2.da_drv_mute_l_en = 1;
    dacEn2.da_drv_ostg_cc_l_en = 1;
    dacEn2.da_drv_ostg_l_en = 1;
    HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

    //    HWRITE(0x8b15,0x3c);
    au_dac_en1RegDef dacEn1;
    memset(&dacEn1, 0, sizeof(dacEn1));
    dacEn1.da_dac_mute_r_en = 1;
    dacEn1.da_drv_mute_r_en = 1;
    dacEn1.da_drv_ostg_cc_r_en = 1;
    dacEn1.da_drv_ostg_r_en = 1;
    HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);

#if 0

    //    HWRITE(0x8b16,0x01);
    memset(&dacEn2, 0, sizeof(dacEn2));
    dacEn2.da_vrefgen_drv_l_en = 1;
    HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

    //    HWRITE(0x8b15,0x01);
    memset(&dacEn1, 0, sizeof(dacEn1));
    dacEn1.da_vrefgen_drv_r_en = 1;
    HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);


    //    HWRITE(0x8b16,0x3c);
    memset(&dacEn2, 0, sizeof(dacEn2));
    dacEn2.da_dac_mute_l_en = 1;
    dacEn2.da_drv_mute_l_en = 1;
    dacEn2.da_drv_ostg_cc_l_en = 1;
    dacEn2.da_drv_ostg_l_en = 1;
    HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

    //    HWRITE(0x8b15,0x3c);
    memset(&dacEn1, 0, sizeof(dacEn1));
    dacEn1.da_dac_mute_r_en = 1;
    dacEn1.da_drv_mute_r_en = 1;
    dacEn1.da_drv_ostg_cc_r_en = 1;
    dacEn1.da_drv_ostg_r_en = 1;
    HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);

#endif

    //    HWRITE(0x8b17,0x40);
    au_dac_en3RegDef dacEn3;
    memset(&dacEn3, 0, sizeof(dacEn3));
    dacEn3.da_drv_r1_open = 1;
    HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);

    //    HWRITE(0x8b07,0x60);
    codec_vmid_cfg1RegDef vmidCfg1;
    memset(&vmidCfg1, 0, sizeof(vmidCfg1));
    vmidCfg1.rg_vmid_discharge_cc = 1;
    vmidCfg1.rg_vmid_discharge_auto = 1;
    vmidCfg1.rg_vmid_isel_msb = 0x1f;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg1);

    //    HWRITE(0x8b08,0x04);
    codec_vmid_cfg2RegDef vmidCfg2;
    memset(&vmidCfg2, 0, sizeof(vmidCfg2));
    vmidCfg2.rg_vmid_vref_sel = 1;
    vmidCfg2.rg_vmid_bg_fastsetting = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b00,0x00);
    codec_ldo_en0RegDef lodEn0;
    memset(&lodEn0, 0, sizeof(lodEn0));
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lodEn0);

}

/**
 * @brief DAC stopped working
 */
void AUDIO_DacDigitalStop(void)
{
    AUDIO_DacVolConfig(0);
    SysTick_DelayMs(500);   //Adjust the delay according to fade in/out. Can be without delay

    DAC_CTRLRegDef dacCtrl;
    HREAD_STRUCT(CORE_DAC_CTRL, &dacCtrl);
    dacCtrl.dac_filter_en = 0; // Ramp Down
    dacCtrl.dac_en = 0;
    HWRITE_STRUCT(CORE_DAC_CTRL, &dacCtrl);

    CoreReg_ClkControl(REG_CLOCK_OFF_AUDIO_DAC, FALSE);
}

/**
 * @brief DAC working status
 * @return Return true at work
 */
BOOL AUDIO_DacCheckEnable(void)
{
    DAC_CTRLRegDef dacCtrl;
    HREAD_STRUCT(CORE_DAC_CTRL, &dacCtrl);
    return dacCtrl.dac_en;
}

/**
 * @brief DAC playback is complete
 * @return Complete return true
 */
BOOL AUDIO_DacCheckEmpty(void)
{
    return (HREADW(CORE_DAC_WPTR) == ((HREADW(CORE_DAC_READ_PTR))));
}

/**
 * @brief View DAC working in CM0 or BT
 * @return Return true when working in CM0 core
 */
BOOL AUDIO_DacCheckBufferMram(void)
{
    DAC_CTRLRegDef dacCtrl;
    HREAD_STRUCT(CORE_DAC_CTRL, &dacCtrl);
    return dacCtrl.dac_mram_sel;
}

/**
 * @brief View the data size unplayed
 * @return uint16_t
 */
uint16_t AUDIO_DacGetBufferSize(void)
{
    uint16_t rPtr, wPtr;

    // Check adc buffer already for cvsd work
    rPtr = HREADW(CORE_DAC_READ_PTR);
    wPtr = HREADW((CORE_DAC_WPTR));
    if(wPtr >= rPtr)
    {
        return (wPtr - rPtr);
    }
    else
    {
        return (HREADW(CORE_DAC_LEN) + 1 - (rPtr  - wPtr));
    }
}

/**
 * @brief Check the size of the data that has been played
 * @return uint16_t
 */
uint16_t AUDIO_DacGetRemindBufferSize(void)
{
    return HREADW(CORE_DAC_LEN) + 1 - AUDIO_DacGetBufferSize();
}

/**
 * @brief DAC mute processing
 * @param  The DAC will be muted when the incoming true is muted, and the DAC will have sound only after unmuting.
 *           mute:true/false
 */
void AUDIO_DacMuteConfig(BOOL mute)
{
    DAC_CTRLRegDef dacCtrl;
    HREAD_STRUCT(CORE_DAC_CTRL, &dacCtrl);
    dacCtrl.dac_mute_lr = mute;
    HWRITE_STRUCT(CORE_DAC_CTRL, &dacCtrl);
}

/**
 * @brief  Volume adjustment function, including left and right ears and prompt tone
 * @param    Vol:  Incoming 0-10
 * @return  :Whether the setting is successful
 */
BOOL AUDIO_DacVolConfig(uint8_t Vol)
{
    if(Vol > 10)
    {
        return ERROR;
    }

    DAC_VOL_LRegDef DAC_VolL;
    HREAD24BIT_STRUCT(CORE_DAC_VOL_L, &DAC_VolL);
    DAC_VolL.dac_vol_target_val_l = AUDIO_DAC_VOL_MAX * Vol / 10;
    HWRITE24BIT_STRUCT(CORE_DAC_VOL_L, &DAC_VolL);

    DAC_VOL_RRegDef DAC_VolR;
    HREAD24BIT_STRUCT(CORE_DAC_VOL_R, &DAC_VolR);
    DAC_VolR.dac_vol_target_val_r = AUDIO_DAC_VOL_MAX * Vol / 10;
    HWRITE24BIT_STRUCT(CORE_DAC_VOL_R, &DAC_VolR);

    DAC_VOL_PRegDef DAC_VolP;
    HREAD24BIT_STRUCT(CORE_DAC_VOL_P, &DAC_VolP);
    DAC_VolP.dac_voll_target_val_p = AUDIO_DAC_VOL_MAX * Vol / 10;
    HWRITE24BIT_STRUCT(CORE_DAC_VOL_P, &DAC_VolP);
    return SUCCESS;
}

/**
 * @Description: Write wptr function in DAC write pointer mode
 * @param {uint8_t*} wptrBuff锛欱uff address
 * @return None
 */
void AUDIO_DacSetWptr(uint8_t *wptrBuff)
{
    HWRITEW(CORE_DAC_WPTR, wptrBuff);
}


void AUDIO_DacAnaVcomConfig(DAC_AnaConfig config)
{
    CoreReg_ClkControl(REG_CLOCK_OFF_AUDIO_DAC, TRUE);
#if 1                                                               //Capacitance-free version
    //    HWRITE(0x8b17,0x05);
    au_dac_en3RegDef dacEn3;
    memset(&dacEn3, 0, sizeof(dacEn3));
    if(config == DAC_AnaStereo)
    {
        dacEn3.da_input_sel_l = 1;
        dacEn3.da_input_sel_r = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn3.da_input_sel_l = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn3.da_input_sel_r = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }

    //    HWRITE(0x8b00,0x20);  // mic ldo/isolation LDO enable
    codec_ldo_en0RegDef lod0;
    HREAD_STRUCT(CORE_codec_ldo_en0, &lod0);
    lod0.da_mic_reg_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lod0);

    //    HWRITE(0x8b08,0x75);
    codec_vmid_cfg2RegDef vmidCfg2;
    HREAD_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);
    vmidCfg2.rg_vmid_bg_fastsetting = 1;
    vmidCfg2.rg_vmid_vref_sel = 1;
    vmidCfg2.rg_vmid_iadjust = 0x0e;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b1b,0x7f);
    au_dac_cfg3RegDef dacCfg3;
    memset(&dacCfg3, 0, sizeof(dacCfg3));
    dacCfg3.rg_vrefgen_ccsel_int = 1;
    dacCfg3.rg_vrefgen_ccsel_intopa = 1;
    dacCfg3.rg_vrefgen_ccsel_drv = 1;
    dacCfg3.rg_drv_ccn_sel = 3;
    dacCfg3.rg_drv_ccp_sel = 3;
    HWRITE_STRUCT(CORE_au_dac_cfg3, &dacCfg3);

    //    HWRITE(0x8b05,0x31);
    codec_vmid_en0RegDef vmidEn0;
    HREAD_STRUCT(CORE_codec_vmid_en0, &vmidEn0);
    vmidEn0.da_vmid_discharge = 1;
    vmidEn0.da_vmid_extcap_en = 1;
    vmidEn0.da_vmid_bg_en = 1 ;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b14,0x07);
    //    HWRITE(0x8b16,0x1c);
    au_dac_en0RegDef dacEn0;
    memset(&dacEn0, 0, sizeof(dacEn0));
    au_dac_en2RegDef dacEn2;
    memset(&dacEn2, 0, sizeof(dacEn2));
    au_dac_en1RegDef dacEn1;
    memset(&dacEn1, 0, sizeof(dacEn1));
    if(config == DAC_AnaStereo)
    {
        dacEn0.da_drv_single_end_l_en = 1;
        dacEn0.da_drv_single_end_r_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn2.da_drv_ostg_cc_l_en = 1;
        dacEn2.da_drv_mute_l_en = 1;
        dacEn2.da_dac_mute_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_drv_ostg_cc_r_en = 1;
        dacEn1.da_dac_mute_r_en = 1;
        dacEn1.da_drv_mute_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn0.da_drv_single_end_l_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn2.da_drv_ostg_cc_l_en = 1;
        dacEn2.da_drv_mute_l_en = 1;
        dacEn2.da_dac_mute_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn0.da_drv_single_end_r_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn1.da_drv_ostg_cc_r_en = 1;
        dacEn1.da_dac_mute_r_en = 1;
        dacEn1.da_drv_mute_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    //    HWRITE(0x8b00,0x2c);
    lod0.da_ldo_daccore_en = 1;
    lod0.da_ldohp_dacdrv_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lod0);

    //    HWRITE(0x8b07,0x7f);
    codec_vmid_cfg1RegDef vmidCfg;
    HREAD_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);
    vmidCfg.rg_vmid_isel_msb = 0x1f;
    vmidCfg.rg_vmid_discharge_cc = 1;
    vmidCfg.rg_vmid_discharge_auto = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);

    //    HWRITE(0x8b05,0x35);
    vmidEn0.da_vmid_bias_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b16,0xfc);
    if(config == DAC_AnaStereo)
    {
        dacEn2.da_drv_ostg_l_en = 1;
        dacEn2.da_dac_int_l_en = 1;
        dacEn2.da_drv_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_drv_ostg_r_en = 1;
        dacEn1.da_dac_int_r_en = 1;
        dacEn1.da_drv_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn2.da_drv_ostg_l_en = 1;
        dacEn2.da_dac_int_l_en = 1;
        dacEn2.da_drv_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn1.da_drv_ostg_r_en = 1;
        dacEn1.da_dac_int_r_en = 1;
        dacEn1.da_drv_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    SysTick_DelayMs(50);

    //    HWRITE(0x8b08,0x05);
    vmidCfg2.rg_vmid_iadjust = 0;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b07,0x20);
    vmidCfg.rg_vmid_isel_msb = 0;
    vmidCfg.rg_vmid_discharge_auto = 0;
    vmidCfg.rg_vmid_lvd_vrefsel = 0;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);

    //    HWRITE(0x8b05,0x36);
    vmidEn0.da_vmid_discharge = 0;
    vmidEn0.da_vmid_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    SysTick_DelayMs(40);

    //    HWRITE(0x8b16,0xf3);
    if(config == DAC_AnaStereo)
    {
        dacEn2.da_dac_mute_l_en = 0;
        dacEn2.da_drv_mute_l_en = 0;
        dacEn2.da_vrefgen_drv_l_en = 1;
        dacEn2.da_vrefgen_dac_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_dac_mute_r_en = 0;
        dacEn1.da_drv_mute_r_en = 0;
        dacEn1.da_vrefgen_drv_r_en = 1;
        dacEn1.da_vrefgen_dac_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn2.da_dac_mute_l_en = 0;
        dacEn2.da_drv_mute_l_en = 0;
        dacEn2.da_vrefgen_drv_l_en = 1;
        dacEn2.da_vrefgen_dac_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn1.da_dac_mute_r_en = 0;
        dacEn1.da_drv_mute_r_en = 0;
        dacEn1.da_vrefgen_drv_r_en = 1;
        dacEn1.da_vrefgen_dac_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    //    HWRITE(0x8b06,0x02);
    codec_vmid_cfg0RegDef vmidCfg0;
    HREAD_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
    vmidCfg0.rg_vmid_isel_lsb = 2;
    HWRITE_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
#elif 0                                                               //Capacitive Version
    //    HWRITE(0x8b17,0x05);
    au_dac_en3RegDef dacEn3;
    memset(&dacEn3, 0, sizeof(dacEn3));
    if(config == DAC_AnaStereo)
    {
        dacEn3.da_input_sel_l = 1;
        dacEn3.da_input_sel_r = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn3.da_input_sel_l = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn3.da_input_sel_r = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }

    //    HWRITE(0x8b00,0x20);  // mic ldo/isolation LDO enable
    codec_ldo_en0RegDef lod0;
    HREAD_STRUCT(CORE_codec_ldo_en0, &lod0);
    lod0.da_mic_reg_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lod0);

    //    HWRITE(0x8b08,0x75);
    codec_vmid_cfg2RegDef vmidCfg2;
    HREAD_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);
    vmidCfg2.rg_vmid_bg_fastsetting = 1;
    vmidCfg2.rg_vmid_vref_sel = 1;
    vmidCfg2.rg_vmid_iadjust = 0x0e;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b1b,0x7f);
    au_dac_cfg3RegDef dacCfg3;
    memset(&dacCfg3, 0, sizeof(dacCfg3));
    dacCfg3.rg_vrefgen_ccsel_int = 1;
    dacCfg3.rg_vrefgen_ccsel_intopa = 1;
    dacCfg3.rg_vrefgen_ccsel_drv = 1;
    dacCfg3.rg_drv_ccn_sel = 3;
    dacCfg3.rg_drv_ccp_sel = 3;
    HWRITE_STRUCT(CORE_au_dac_cfg3, &dacCfg3);

    //    HWRITE(0x8b05,0x31);
    codec_vmid_en0RegDef vmidEn0;
    HREAD_STRUCT(CORE_codec_vmid_en0, &vmidEn0);
    vmidEn0.da_vmid_discharge = 1;
    vmidEn0.da_vmid_extcap_en = 1;
    vmidEn0.da_vmid_bg_en = 1 ;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b14,0x07);
    //    HWRITE(0x8b16,0x1c);
    au_dac_en0RegDef dacEn0;
    memset(&dacEn0, 0, sizeof(dacEn0));
    au_dac_en2RegDef dacEn2;
    memset(&dacEn2, 0, sizeof(dacEn2));
    au_dac_en1RegDef dacEn1;
    memset(&dacEn1, 0, sizeof(dacEn1));
    if(config == DAC_AnaStereo)
    {
        dacEn0.da_drv_single_end_l_en = 1;
        dacEn0.da_drv_single_end_r_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn2.da_drv_ostg_cc_l_en = 1;
        dacEn2.da_drv_mute_l_en = 1;
        dacEn2.da_dac_mute_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_drv_ostg_cc_r_en = 1;
        dacEn1.da_dac_mute_r_en = 1;
        dacEn1.da_drv_mute_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn0.da_drv_single_end_l_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn2.da_drv_ostg_cc_l_en = 1;
        dacEn2.da_drv_mute_l_en = 1;
        dacEn2.da_dac_mute_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn0.da_drv_single_end_r_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn1.da_drv_ostg_cc_r_en = 1;
        dacEn1.da_dac_mute_r_en = 1;
        dacEn1.da_drv_mute_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    //    HWRITE(0x8b00,0x2c);
    lod0.da_ldo_daccore_en = 1;
    lod0.da_ldohp_dacdrv_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lod0);

    //    HWRITE(0x8b07,0x7f);
    codec_vmid_cfg1RegDef vmidCfg;
    HREAD_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);
    vmidCfg.rg_vmid_isel_msb = 0x08;
    vmidCfg.rg_vmid_discharge_cc = 1;
    vmidCfg.rg_vmid_discharge_auto = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);

    //    HWRITE(0x8b05,0x35);
    vmidEn0.da_vmid_bias_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    SysTick_DelayMs(50);

    //    HWRITE(0x8b16,0xfc);
    if(config == DAC_AnaStereo)
    {
        dacEn2.da_drv_ostg_l_en = 1;
        dacEn2.da_dac_int_l_en = 1;
        dacEn2.da_drv_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_drv_ostg_r_en = 1;
        dacEn1.da_dac_int_r_en = 1;
        dacEn1.da_drv_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn2.da_drv_ostg_l_en = 1;
        dacEn2.da_dac_int_l_en = 1;
        dacEn2.da_drv_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn1.da_drv_ostg_r_en = 1;
        dacEn1.da_dac_int_r_en = 1;
        dacEn1.da_drv_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    SysTick_DelayMs(100);

    //    HWRITE(0x8b08,0x05);
    vmidCfg2.rg_vmid_iadjust = 0;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b07,0x20);
    vmidCfg.rg_vmid_isel_msb = 0x8;
    vmidCfg.rg_vmid_discharge_auto = 0;
    vmidCfg.rg_vmid_lvd_vrefsel = 0;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);

    //    HWRITE(0x8b05,0x36);
    vmidEn0.da_vmid_discharge = 0;
    vmidEn0.da_vmid_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    SysTick_DelayMs(30);

    //    HWRITE(0x8b16,0xf3);
    if(config == DAC_AnaStereo)
    {
        dacEn2.da_dac_mute_l_en = 0;
        dacEn2.da_drv_mute_l_en = 0;
        dacEn2.da_vrefgen_drv_l_en = 1;
        dacEn2.da_vrefgen_dac_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_dac_mute_r_en = 0;
        dacEn1.da_drv_mute_r_en = 0;
        dacEn1.da_vrefgen_drv_r_en = 1;
        dacEn1.da_vrefgen_dac_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn2.da_dac_mute_l_en = 0;
        dacEn2.da_drv_mute_l_en = 0;
        dacEn2.da_vrefgen_drv_l_en = 1;
        dacEn2.da_vrefgen_dac_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn1.da_dac_mute_r_en = 0;
        dacEn1.da_drv_mute_r_en = 0;
        dacEn1.da_vrefgen_drv_r_en = 1;
        dacEn1.da_vrefgen_dac_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    //    HWRITE(0x8b06,0x02);
    codec_vmid_cfg0RegDef vmidCfg0;
    HREAD_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
    vmidCfg0.rg_vmid_isel_lsb = 8;
    HWRITE_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
#elif 0     //test
    HWRITE(0x8b00, 0x3c);
    HWRITE(0x8b01, 0x51);
    HWRITE(0x8b02, 0x55);
    HWRITE(0x8b04, 0x2a);
    HWRITE(0x8b05, 0x36);
    HWRITE(0x8b06, 0x08);
    HWRITE(0x8b07, 0x68);
    //            SysTick_DelayMs(100);
    //            HWRITE(0x8b07,0x60);
    HWRITE(0x8b08, 0x01);
    HWRITE(0x8b09, 0x84);
    HWRITE(0x8b0b, 0x80);
    HWRITE(0x8b14, 0x04);
    //            HWRITE(0x8b14,0x07);
    HWRITE(0x8b1b, 0x7f);
    HWRITE(0x8b17, 0x05);

    HWRITE(0x8b15, 0xf3);
    HWRITE(0x8b16, 0xf3);
#endif
}

void AUDIO_DacAnaDiffConfig(DAC_AnaConfig config)
{
    CoreReg_ClkControl(REG_CLOCK_OFF_AUDIO_DAC, TRUE);

    //    HWRITE(0x8b17,0x05);
    au_dac_en3RegDef dacEn3;
    memset(&dacEn3, 0, sizeof(dacEn3));
    if(config == DAC_AnaStereo)
    {
        dacEn3.da_input_sel_l = 1;
        dacEn3.da_input_sel_r = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn3.da_input_sel_l = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn3.da_input_sel_r = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }

    //    HWRITE(0x8b00,0x20);  // mic ldo/isolation LDO enable
    codec_ldo_en0RegDef lod0;
    HREAD_STRUCT(CORE_codec_ldo_en0, &lod0);
    lod0.da_mic_reg_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lod0);

    //    HWRITE(0x8b08,0x75);
    codec_vmid_cfg2RegDef vmidCfg2;
    HREAD_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);
    vmidCfg2.rg_vmid_bg_fastsetting = 1;
    vmidCfg2.rg_vmid_vref_sel = 1;
    vmidCfg2.rg_vmid_iadjust = 0x0e;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b1b,0x7f);
    au_dac_cfg3RegDef dacCfg3;
    memset(&dacCfg3, 0, sizeof(dacCfg3));
    dacCfg3.rg_vrefgen_ccsel_int = 1;
    dacCfg3.rg_vrefgen_ccsel_intopa = 1;
    dacCfg3.rg_vrefgen_ccsel_drv = 1;
    dacCfg3.rg_drv_ccn_sel = 3;
    dacCfg3.rg_drv_ccp_sel = 3;
    HWRITE_STRUCT(CORE_au_dac_cfg3, &dacCfg3);

    //    HWRITE(0x8b05,0x31);
    codec_vmid_en0RegDef vmidEn0;
    HREAD_STRUCT(CORE_codec_vmid_en0, &vmidEn0);
    vmidEn0.da_vmid_discharge = 1;
    vmidEn0.da_vmid_extcap_en = 1;
    vmidEn0.da_vmid_bg_en = 1 ;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b14,0x07);
    //    HWRITE(0x8b16,0x1c);
    au_dac_en0RegDef dacEn0;
    memset(&dacEn0, 0, sizeof(dacEn0));
    au_dac_en2RegDef dacEn2;
    memset(&dacEn2, 0, sizeof(dacEn2));
    au_dac_en1RegDef dacEn1;
    memset(&dacEn1, 0, sizeof(dacEn1));
    if(config == DAC_AnaStereo)
    {
        dacEn0.da_drv_single_end_l_en = 0;
        dacEn0.da_drv_single_end_r_en = 0;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn2.da_drv_ostg_cc_l_en = 1;
        dacEn2.da_drv_mute_l_en = 1;
        dacEn2.da_dac_mute_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_drv_ostg_cc_r_en = 1;
        dacEn1.da_dac_mute_r_en = 1;
        dacEn1.da_drv_mute_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn0.da_drv_single_end_l_en = 0;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn2.da_drv_ostg_cc_l_en = 1;
        dacEn2.da_drv_mute_l_en = 1;
        dacEn2.da_dac_mute_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn0.da_drv_single_end_r_en = 0;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn1.da_drv_ostg_cc_r_en = 1;
        dacEn1.da_dac_mute_r_en = 1;
        dacEn1.da_drv_mute_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    //    HWRITE(0x8b00,0x2c);
    lod0.da_ldo_daccore_en = 1;
    lod0.da_ldohp_dacdrv_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lod0);

    //    HWRITE(0x8b07,0x7f);
    codec_vmid_cfg1RegDef vmidCfg;
    HREAD_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);
    vmidCfg.rg_vmid_isel_msb = 0x1f;
    vmidCfg.rg_vmid_discharge_cc = 1;
    vmidCfg.rg_vmid_discharge_auto = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);

    //    HWRITE(0x8b05,0x35);
    vmidEn0.da_vmid_bias_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b16,0xfc);
    if(config == DAC_AnaStereo)
    {
        dacEn2.da_drv_ostg_l_en = 1;
        dacEn2.da_dac_int_l_en = 1;
        dacEn2.da_drv_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_drv_ostg_r_en = 1;
        dacEn1.da_dac_int_r_en = 1;
        dacEn1.da_drv_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn2.da_drv_ostg_l_en = 1;
        dacEn2.da_dac_int_l_en = 1;
        dacEn2.da_drv_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn1.da_drv_ostg_r_en = 1;
        dacEn1.da_dac_int_r_en = 1;
        dacEn1.da_drv_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    SysTick_DelayMs(50);

    //    HWRITE(0x8b08,0x05);
    vmidCfg2.rg_vmid_iadjust = 0;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b07,0x20);
    vmidCfg.rg_vmid_isel_msb = 0;
    vmidCfg.rg_vmid_discharge_auto = 0;
    vmidCfg.rg_vmid_lvd_vrefsel = 0;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);

    //    HWRITE(0x8b05,0x36);
    vmidEn0.da_vmid_discharge = 0;
    vmidEn0.da_vmid_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    SysTick_DelayMs(40);

    //    HWRITE(0x8b16,0xf3);
    if(config == DAC_AnaStereo)
    {
        dacEn2.da_dac_mute_l_en = 0;
        dacEn2.da_drv_mute_l_en = 0;
        dacEn2.da_vrefgen_drv_l_en = 1;
        dacEn2.da_vrefgen_dac_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_dac_mute_r_en = 0;
        dacEn1.da_drv_mute_r_en = 0;
        dacEn1.da_vrefgen_drv_r_en = 1;
        dacEn1.da_vrefgen_dac_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn2.da_dac_mute_l_en = 0;
        dacEn2.da_drv_mute_l_en = 0;
        dacEn2.da_vrefgen_drv_l_en = 1;
        dacEn2.da_vrefgen_dac_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn1.da_dac_mute_r_en = 0;
        dacEn1.da_drv_mute_r_en = 0;
        dacEn1.da_vrefgen_drv_r_en = 1;
        dacEn1.da_vrefgen_dac_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    //    HWRITE(0x8b06,0x02);
    codec_vmid_cfg0RegDef vmidCfg0;
    HREAD_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
    vmidCfg0.rg_vmid_isel_lsb = 2;
    HWRITE_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
}

void AUDIO_DacAnaSEConfig(DAC_AnaConfig config)
{
    CoreReg_ClkControl(REG_CLOCK_OFF_AUDIO_DAC, TRUE);
    //    HWRITE(0x8b17,0x05);
    au_dac_en3RegDef dacEn3;
    memset(&dacEn3, 0, sizeof(dacEn3));
    if(config == DAC_AnaStereo)
    {
        dacEn3.da_input_sel_l = 1;
        dacEn3.da_input_sel_r = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn3.da_input_sel_l = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn3.da_input_sel_r = 1;
        HWRITE_STRUCT(CORE_au_dac_en3, &dacEn3);
    }

    //    HWRITE(0x8b00,0x20);  // mic ldo/isolation LDO enable
    codec_ldo_en0RegDef lod0;
    HREAD_STRUCT(CORE_codec_ldo_en0, &lod0);
    lod0.da_mic_reg_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lod0);

    //    HWRITE(0x8b08,0x75);
    codec_vmid_cfg2RegDef vmidCfg2;
    HREAD_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);
    vmidCfg2.rg_vmid_bg_fastsetting = 1;
    vmidCfg2.rg_vmid_vref_sel = 1;
    vmidCfg2.rg_vmid_iadjust = 0x0e;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b1b,0x7f);
    au_dac_cfg3RegDef dacCfg3;
    memset(&dacCfg3, 0, sizeof(dacCfg3));
    dacCfg3.rg_vrefgen_ccsel_int = 1;
    dacCfg3.rg_vrefgen_ccsel_intopa = 1;
    dacCfg3.rg_vrefgen_ccsel_drv = 1;
    dacCfg3.rg_drv_ccn_sel = 3;
    dacCfg3.rg_drv_ccp_sel = 3;
    HWRITE_STRUCT(CORE_au_dac_cfg3, &dacCfg3);

    //    HWRITE(0x8b05,0x31);
    codec_vmid_en0RegDef vmidEn0;
    HREAD_STRUCT(CORE_codec_vmid_en0, &vmidEn0);
    vmidEn0.da_vmid_discharge = 1;
    vmidEn0.da_vmid_extcap_en = 1;
    vmidEn0.da_vmid_bg_en = 1 ;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b14,0x07);
    //    HWRITE(0x8b16,0x1c);
    au_dac_en0RegDef dacEn0;
    memset(&dacEn0, 0, sizeof(dacEn0));
    au_dac_en2RegDef dacEn2;
    memset(&dacEn2, 0, sizeof(dacEn2));
    au_dac_en1RegDef dacEn1;
    memset(&dacEn1, 0, sizeof(dacEn1));
    if(config == DAC_AnaStereo)
    {
        dacEn0.da_drv_single_end_l_en = 1;
        dacEn0.da_drv_single_end_r_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn2.da_drv_ostg_cc_l_en = 1;
        dacEn2.da_drv_mute_l_en = 1;
        dacEn2.da_dac_mute_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_drv_ostg_cc_r_en = 1;
        dacEn1.da_dac_mute_r_en = 1;
        dacEn1.da_drv_mute_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn0.da_drv_single_end_l_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn2.da_drv_ostg_cc_l_en = 1;
        dacEn2.da_drv_mute_l_en = 1;
        dacEn2.da_dac_mute_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn0.da_drv_single_end_r_en = 1;
        dacEn0.da_dac_ibias_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en0, &dacEn0);

        dacEn1.da_drv_ostg_cc_r_en = 1;
        dacEn1.da_dac_mute_r_en = 1;
        dacEn1.da_drv_mute_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    //    HWRITE(0x8b00,0x2c);
    lod0.da_ldo_daccore_en = 1;
    lod0.da_ldohp_dacdrv_en = 1;
    HWRITE_STRUCT(CORE_codec_ldo_en0, &lod0);

    //    HWRITE(0x8b07,0x7f);
    codec_vmid_cfg1RegDef vmidCfg;
    HREAD_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);
    vmidCfg.rg_vmid_isel_msb = 0x1f;
    vmidCfg.rg_vmid_discharge_cc = 1;
    vmidCfg.rg_vmid_discharge_auto = 1;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);

    //    HWRITE(0x8b05,0x35);
    vmidEn0.da_vmid_bias_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    //    HWRITE(0x8b16,0xfc);
    if(config == DAC_AnaStereo)
    {
        dacEn2.da_drv_ostg_l_en = 1;
        dacEn2.da_dac_int_l_en = 1;
        dacEn2.da_drv_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_drv_ostg_r_en = 1;
        dacEn1.da_dac_int_r_en = 1;
        dacEn1.da_drv_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn2.da_drv_ostg_l_en = 1;
        dacEn2.da_dac_int_l_en = 1;
        dacEn2.da_drv_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn1.da_drv_ostg_r_en = 1;
        dacEn1.da_dac_int_r_en = 1;
        dacEn1.da_drv_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    SysTick_DelayMs(50);

    //    HWRITE(0x8b08,0x05);
    vmidCfg2.rg_vmid_iadjust = 0;
    HWRITE_STRUCT(CORE_codec_vmid_cfg2, &vmidCfg2);

    //    HWRITE(0x8b07,0x20);
    vmidCfg.rg_vmid_isel_msb = 0;
    vmidCfg.rg_vmid_discharge_auto = 0;
    vmidCfg.rg_vmid_lvd_vrefsel = 0;
    HWRITE_STRUCT(CORE_codec_vmid_cfg1, &vmidCfg);

    //    HWRITE(0x8b05,0x36);
    vmidEn0.da_vmid_discharge = 0;
    vmidEn0.da_vmid_en = 1;
    HWRITE_STRUCT(CORE_codec_vmid_en0, &vmidEn0);

    SysTick_DelayMs(40);

    //    HWRITE(0x8b16,0xf3);
    if(config == DAC_AnaStereo)
    {
        dacEn2.da_dac_mute_l_en = 0;
        dacEn2.da_drv_mute_l_en = 0;
        dacEn2.da_vrefgen_drv_l_en = 1;
        dacEn2.da_vrefgen_dac_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);

        dacEn1.da_dac_mute_r_en = 0;
        dacEn1.da_drv_mute_r_en = 0;
        dacEn1.da_vrefgen_drv_r_en = 1;
        dacEn1.da_vrefgen_dac_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }
    else if(config == DAC_AnaLeft)
    {
        dacEn2.da_dac_mute_l_en = 0;
        dacEn2.da_drv_mute_l_en = 0;
        dacEn2.da_vrefgen_drv_l_en = 1;
        dacEn2.da_vrefgen_dac_l_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en2, &dacEn2);
    }
    else if(config == DAC_AnaRight)
    {
        dacEn1.da_dac_mute_r_en = 0;
        dacEn1.da_drv_mute_r_en = 0;
        dacEn1.da_vrefgen_drv_r_en = 1;
        dacEn1.da_vrefgen_dac_r_en = 1;
        HWRITE_STRUCT(CORE_au_dac_en1, &dacEn1);
    }

    //    HWRITE(0x8b06,0x02);
    codec_vmid_cfg0RegDef vmidCfg0;
    HREAD_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
    vmidCfg0.rg_vmid_isel_lsb = 2;
    HWRITE_STRUCT(CORE_codec_vmid_cfg0, &vmidCfg0);
}

BOOL AUDIO_DacIsAnaOpen()
{
    codec_vmid_indRegDef vmidInReg;                          //Determine whether the DAC simulation is powered on
    memset(&vmidInReg, 0, sizeof(vmidInReg));
    HREAD_STRUCT(CORE_codec_vmid_ind, &vmidInReg);
    return vmidInReg.ad_vmid_ok_12;
}

void AUDIO_HighPerformanceTest()
{
    //    Tests ADC+DAC high performance mode-specific functions.
    //    For internal debug.
    //    Configure the simulation before calling this letter.
    HWRITE(0x804c, 0x88);
    HWRITE(0x804d, 0x9f);
    HWRITE(0x804e, 0x26);
    HWRITE(0x804f, 0x01);
    HWRITE(0x8005, 0x20);

    HWRITE(0x8b01, 0x79);
    HWRITE(0x8b02, 0x7d);
    HWRITE(0x8b04, 0x3e);
#if 1
    HWRITE(0x8b08, 0x05);
#else
    HWRITE(0x8b08, 0x01);  //01 performs better. SNR differs by 2 dB
#endif
}

/**
 * @Description: Mix processing initialization function
 * @param {HINTTONE_InitParamDef} config
 *                              HintToneVol:HINTTONE_HintToneVol0/HINTTONE_HintToneVol1/HINTTONE_HintToneVol2/HINTTONE_HintToneVol3
 *                              MainVol:HINTTONE_MainVol0/HINTTONE_MainVol1/HINTTONE_MainVol2/HINTTONE_MainVol3
 *                              WorkMode:HINTTONE_WorkWptr/HINTTONE_WorkContinuous
 *                              LRPlay:HINTTONE_LeftEarPlay/HINTTONE_RightEarPlay/HINTTONE_LREarPlay
 *                              StarAddr:Buff start address
 *                              BuffLen:buff len
 * @return {None}
 */
void HINTTONE_Init(HINTTONE_InitParamDef config)
{
    TISHI_CTRLRegDef ctrl;
    HREAD_STRUCT(CORE_TISHI_CTRL, &ctrl);
    ctrl.tishi_trunc = config.HintToneVol;

    if(config.HintToneVol == HINTTONE_HintToneVol2 || config.HintToneVol == HINTTONE_HintToneVol3)
    {
        RAMP_CTRLRegDef ctrlPamp;
        HREAD_STRUCT(CORE_RAMP_CTRL, &ctrlPamp);
        ctrlPamp.ramp_tishi_trunc_hi = config.HintToneVol >> 1;
        HWRITE_STRUCT(CORE_RAMP_CTRL, &ctrlPamp);
    }

    ctrl.tishi_cont_mode = config.WorkMode;

    ctrl.main_trunc = config.MainVol;
    if(reg_check_ram_m0(config.StarAddr))
    {
        ctrl.tishi_mram_sel = 1;
    }
    else
    {
        ctrl.tishi_mram_sel = 0;
    }
    if(config.LRPlay == HINTTONE_LeftEarPlay)
    {
        ctrl.tishi_l_en = 1;
        ctrl.tishi_r_en = 0;
    }
    else if(config.LRPlay == HINTTONE_RightEarPlay)
    {
        ctrl.tishi_l_en = 0;
        ctrl.tishi_r_en = 1;
    }
    else if(config.LRPlay == HINTTONE_LREarPlay)
    {
        ctrl.tishi_l_en = 1;
        ctrl.tishi_r_en = 1;
    }
    HWRITE_STRUCT(CORE_TISHI_CTRL, &ctrl);

    HWRITEW(CORE_TISHI_SADDR, config.StarAddr);;

    if(config.WorkMode == HINTTONE_WorkWptr)
    {
        HWRITEW(CORE_TISHI_WPTR, config.StarAddr);
    }

    HWRITEW(CORE_TISHI_LEN, config.BuffLen - 1);

    ctrl.tishi_en = 1;
    HWRITE_STRUCT(CORE_TISHI_CTRL, &ctrl);
}

/**
 * @Description: Stop mixing
 * @param {None}
 * @return {None}
 */
void HINTTONE_Stop(void)
{
    TISHI_CTRLRegDef ctrl;
    HREAD_STRUCT(CORE_TISHI_CTRL, &ctrl);
    ctrl.tishi_en = 0;
    HWRITE_STRUCT(CORE_TISHI_CTRL, &ctrl);
}

/**
 * @Description: Check whether the audio playback is complete
 * @param {None}
 * @return {BOOL} Return true after completion
 */
BOOL HINTTONE_CheckEmpty(void)
{
    return HREADW(CORE_TISHI_RPTR) == HREADW(CORE_TISHI_WPTR);
}

/**
 * @Description: Update wptr function in mixed write pointer mode
 * @param {uint8_t*} wptrBuff锛歂ew wptr
 * @return {None}
 */
void HINTTONE_SetWptr(uint8_t *wptrBuff)
{
    HWRITEW(CORE_TISHI_WPTR, wptrBuff);
}
