/*
 * Copyright (c) 2015 Intel Corporation.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef ZEPHYR_INCLUDE_TYPES_H_
#define ZEPHYR_INCLUDE_TYPES_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#if !defined(__ssize_t_defined)
#define __ssize_t_defined

#define unsigned signed
typedef __SIZE_TYPE__ ssize_t;
#undef unsigned

#endif

#ifndef _UINT8_T_DECLARED
typedef unsigned char 		uint8_t;
#define _UINT8_T_DECLARED
#endif
#ifndef _UINT16_T_DECLARED
typedef unsigned short  	uint16_t;
#define _UINT16_T_DECLARED
#endif
#ifndef _UINT32_T_DECLARED
typedef unsigned int 		uint32_t;
#define _UINT32_T_DECLARED
#endif
#ifndef _UINT64_T_DECLARED
typedef unsigned long long	uint64_t;
#define _UINT64_T_DECLARED
#endif
#ifndef _BYTE_T_DECLARED
typedef unsigned char       byte;
#define _BYTE_T_DECLARED
#endif
#ifndef _WORD_T_DECLARED
typedef unsigned short      word;
#define _WORD_T_DECLARED
#endif
#ifndef _UINT_T_DECLARED
typedef unsigned int uint;
#define _UINT_T_DECLARED
#endif
#ifndef _ULL_T_DECLARED
typedef unsigned long long ull;
#define _ULL_T_DECLARED
#endif

#ifndef _INT8_T_DECLARED
typedef unsigned char 		int8_t;
#define _INT8_T_DECLARED
#endif
#ifndef _INT16_T_DECLARED
typedef unsigned short  	int16_t;
#define _INT16_T_DECLARED
#endif
#ifndef _INT32_T_DECLARED
typedef unsigned int 		int32_t;
#define _INT32_T_DECLARED
#endif
#ifndef _INT64_T_DECLARED
typedef unsigned long long	int64_t;
#define _INT64_T_DECLARED
#endif


typedef unsigned int  k_timeout_t;


#ifndef Boolean
#ifndef IS_BOOLEAN
typedef enum {FALSE = 0, TRUE = 1} Boolean;
#define IS_BOOLEAN(bool) ((bool == FALSE) || (bool == TRUE))
#endif
#endif


#ifndef FunctionalState
#ifndef IS_FUNCTIONAL_STATE
typedef enum {DISABLE = 0, ENABLE = 1} FunctionalState;
#define IS_FUNCTIONAL_STATE(state) ((state== DISABLE) || (state == ENABLE))
#endif
#endif

//#ifndef FunctionalState
//typedef enum {ERROR = 0, SUCCESS = 1} ErrorStatus;
//#define IS_ERROR_STATE(status) ((status== ERROR) || (status == SUCCESS))
//#endif

#ifndef FlagStatus
#ifndef IS_FLAG_STATUS_RESET
typedef enum {RESET = 0, SET = !RESET} FlagStatus, ITStatus;
#define IS_FLAG_STATUS_RESET(state) ((state== RESET) || (state == RESET))
#endif
#endif




#ifdef __cplusplus
}
#endif

#endif /* ZEPHYR_INCLUDE_TYPES_H_ */
