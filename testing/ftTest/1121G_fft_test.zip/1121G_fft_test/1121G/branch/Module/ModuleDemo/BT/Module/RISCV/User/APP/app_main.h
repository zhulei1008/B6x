#ifndef __APP_MAIN_H__
#define __APP_MAIN_H__

//#include "app_common.h"
#include "yc11xx_systick.h"
//#include "yc11xx_dev_led.h"
//#include "yc11xx_dev_bt.h"
//#include "yc11xx_dev_voiceprompt.h"
#include "yc_sys_timer.h"

void Tool_ParamConfig(void);
void App_MainLoop(void);
void App_PowerOn(BOOL isPowerOnFromKeyPress);
void App_PowerOnWorkProcess(void);
void App_ResetAutoPwroffTimer(void);
uint8_t App_CheckPowerOn(void);
void App_StartPwroffWork(void);
void AppCB_AutoPwroff(int paras);
void App_SetAutoPwroffTimer(uint32_t count, Timer_Expire_CB pfExpire_CB);
void App_EvtCallBack(uint8_t len, uint8_t *dataPtr);
void App_Reset(void);
void App_PowerResetWork(BOOL isFromPowerOn);
void App_ReleaseAutoPwroffTimer(void);
void App_CheckWaitPwroff(void);


void App_ActionBeforeLpm(void);
void App_ActionBeforeHibernate(void);
void App_OnlineDebugPolling(void);
void App_OnlineDebugEqInit(void);
void Check_Airdosin(void);





#endif
