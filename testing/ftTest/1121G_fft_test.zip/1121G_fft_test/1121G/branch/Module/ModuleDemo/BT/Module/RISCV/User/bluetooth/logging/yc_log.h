#ifndef _YC_LOG_H_
#define _YC_LOG_H_

#include "yc_debug.h"


#define YC_LOG_LEVEL_NONE 0U
#define YC_LOG_LEVEL_ERR  1U
#define YC_LOG_LEVEL_WRN  2U
#define YC_LOG_LEVEL_INF  3U
#define YC_LOG_LEVEL_DBG  4U

static inline char z_log_minimal_level_to_char(int level)
{
    switch (level)
    {
    case YC_LOG_LEVEL_ERR:
        return 'E';
    case YC_LOG_LEVEL_WRN:
        return 'W';
    case YC_LOG_LEVEL_INF:
        return 'I';
    case YC_LOG_LEVEL_DBG:
        return 'D';
    default:
        return '?';
    }
}


#define YC_LOG_TO_PRINTK(_level, _name, fmt, ...) do {				     \
		DEBUG_LOG_STRING("%c: " "(%s)" fmt "\n", z_log_minimal_level_to_char(_level), #_name, \
			##__VA_ARGS__);					     \
	} while (false);

#ifdef FUNCTION_CONTROL_DEBUG_ENABLE
#define __YC_LOG(_level, _name, _level_thod, ...)				       \
    do {                               \
            YC_LOG_TO_PRINTK(_level, _name, __VA_ARGS__);          \
    } while (false)
#else
#define __YC_LOG(_level, _name, _level_thod, ...)
#endif



static inline char *log_strdup(const char *str)
{
    return (char *)str;
}




/**
 * @brief Logger API
 * @defgroup log_api Logging API
 * @ingroup logger
 * @{
 */

/**
 * @brief Writes an ERROR level message to the log.
 *
 * @details It's meant to report severe errors, such as those from which it's
 * not possible to recover.
 *
 * @param ... A string optionally containing printk valid conversion specifier,
 * followed by as many values as specifiers.
 */
#define YC_LOG_ERR(...)    __YC_LOG(YC_LOG_LEVEL_ERR, __VA_ARGS__)

/**
 * @brief Writes a WARNING level message to the log.
 *
 * @details It's meant to register messages related to unusual situations that
 * are not necessarily errors.
 *
 * @param ... A string optionally containing printk valid conversion specifier,
 * followed by as many values as specifiers.
 */
#define YC_LOG_WRN(...)   __YC_LOG(YC_LOG_LEVEL_WRN, __VA_ARGS__)

/**
 * @brief Writes an INFO level message to the log.
 *
 * @details It's meant to write generic user oriented messages.
 *
 * @param ... A string optionally containing printk valid conversion specifier,
 * followed by as many values as specifiers.
 */
#define YC_LOG_INF(...)   __YC_LOG(YC_LOG_LEVEL_INF, __VA_ARGS__)

/**
 * @brief Writes a DEBUG level message to the log.
 *
 * @details It's meant to write developer oriented information.
 *
 * @param ... A string optionally containing printk valid conversion specifier,
 * followed by as many values as specifiers.
 */
#define YC_LOG_DBG(...)    __YC_LOG(YC_LOG_LEVEL_DBG, __VA_ARGS__)













#endif //_YC_LOG_H_

