/*
 * Copyright (c) 2006-2020, YICHIP Development Team
 * @file     yc_timer.c
 * @brief    source file for setting timer
 *
 * Change Logs:
 * Date            Author             Version        Notes
 * 2021-3-15       zhouduo            V1.0.0         the first version
 * note:  temporary version��under revision
 */

#include "yc_sys_timer.h"
#include "yc_debug.h"
#include "yc11xx_ipc.h"
#include "reg_addr.h"

static SYS_TIMER_TYPE *gpSysTimeListHeader;
static SYS_TIMER_TYPE gSysTimerHeaderTimer;
static uint32_t gSysTimeWorkCount = 0;

static uint32_t gSystemTimerAdjustClknbt;
static uint8_t gSysTimerCheckFlag;

void SYS_TimerExpireDefaultHandle(int params)
{
    while(0);
}
/**
 * @method SYS_ChangeDPLL
 * @brief  Modify the system DPLL
 * @param  systemClk : system DPLL only can be  CLOCK_48M_multiple
 * @retval none
 */
void SYS_ChangeDPLL(uint8_t systemClk)//lost
{
    return;
    SysTick_ChangeDPLL(systemClk);
}

/**
 * @method SYS_ChangeToFastDPLL
 * @brief  change the system DPLL to highspeed  DPLL
 * @param  None
 * @retval None
 */

void SYS_ChangeToFastDPLL(void)
{
    SysTick_ChangeToFastDPLL();
}

/**
 * @method SYS_ChangeToNormalDPLL
 * @brief  change the system DPLL to normal  DPLL
 * @param  None
 * @retval None
 */
void SYS_ChangeToNormalDPLL(void)
{
    SysTick_ChangeToNormalDPLL();
}



//union is 10ms
BOOL SYS_SetTimer(SYS_TIMER_TYPE *pTimer, int tick, TIMER_TYPE isSingle, Timer_Expire_CB pfExpire_CB)
{
    SYS_TIMER_TYPE *pTemp;
    if(gpSysTimeListHeader == NULL)
    {
        return FALSE;
    }
    if(pTimer == NULL)
    {
        DEBUG_LOG(LOG_LEVEL_CORE, "IPC", "xxx: 0x%04X", LOG_POINT_A500, (uint32_t)pTimer);
        return FALSE;
    }
    if (pfExpire_CB == NULL)
    {
        DEBUG_LOG(LOG_LEVEL_CORE, "IPC", "xxx: 0x%04X", LOG_POINT_A501, (uint32_t)pTimer);
        pTimer->pfExpireCb = SYS_TimerExpireDefaultHandle;
    }
    else
    {
        pTimer->pfExpireCb = pfExpire_CB;
    }

    OS_ENTER_CRITICAL();
    pTimer->mTimerValue = gSysTimeWorkCount + tick;

    pTimer->mTick = tick;

    pTimer->mTimerStatus = TIMER_START;
    pTimer->mIsCycle = (TIMER_TYPE)(isSingle & 0x3f);

    if (SYS_TimerisExist(pTimer))
    {
        OS_EXIT_CRITICAL();
        return TRUE;
    }

    //insert to list
    pTemp = gpSysTimeListHeader;
    gpSysTimeListHeader = pTimer;
    gpSysTimeListHeader->pNextTimer = pTemp;
    OS_EXIT_CRITICAL();

    return TRUE;
}

BOOL SYS_TimerisExist(SYS_TIMER_TYPE *pTimer)
{
    SYS_TIMER_TYPE *pTemp;
    if(gpSysTimeListHeader == NULL)
    {
        return FALSE;
    }
    if (pTimer == NULL)
    {
        return FALSE;
    }
    for(pTemp = gpSysTimeListHeader; pTemp->pNextTimer != NULL; pTemp = pTemp->pNextTimer)
    {
        if (pTimer == pTemp)
        {
            return TRUE;
        }
    }
    return FALSE;
}


BOOL SYS_ResetTimer(SYS_TIMER_TYPE *pTimer)
{
    SYS_TIMER_TYPE *pTemp;
    if(gpSysTimeListHeader == NULL)
    {
        return FALSE;
    }
    if (pTimer == NULL)
    {
        return FALSE;
    }
    for(pTemp = gpSysTimeListHeader; pTemp->pNextTimer != NULL; pTemp = pTemp->pNextTimer)
    {
        if (pTimer == pTemp)
        {
            pTimer->mTimerValue = gSysTimeWorkCount + (pTimer->mTick);
            return TRUE;
        }
    }
    return FALSE;
}


void SYS_TimerTest(void)
{
    SYS_TIMER_TYPE *pTimer;
    int i = 0;
    for (pTimer = gpSysTimeListHeader; pTimer->pNextTimer != NULL; pTimer = pTimer->pNextTimer)
    {
        i++;
    }
}

void SYS_TimerPolling(void)
{
    SYS_TIMER_TYPE *pTimer;
    if(HREAD(IPC_MCU_STATE) != IPC_MCU_STATE_RUNNING)
    {
        return;
    }
    //Lpm_LockLpm(TIMER_LPM_FLAG);
    if (gSysTimerCheckFlag)
    {
        gSysTimerCheckFlag = FALSE;
        SYS_TimerTest();
        for (pTimer = gpSysTimeListHeader; pTimer->pNextTimer != NULL; pTimer = pTimer->pNextTimer)
        {
            if (pTimer->mTimerStatus == TIMER_START)
            {
                if (pTimer->mTimerValue <= gSysTimeWorkCount)
                {
                    if (pTimer->mIsCycle == TIMER_SINGLE)
                    {
                        SYS_ReleaseTimer(pTimer);
                    }
                    else
                    {
                        pTimer->mTimerValue = gSysTimeWorkCount + (pTimer->mTick);
                    }
                    //DEBUG_LOG(LOG_LEVEL_CORE, "IPC" ,"xxx: 0x%04X", LOG_POINT_A502, (uint32_t)pTimer);
                    pTimer->pfExpireCb(pTimer->cbParams);
                }
            }
        }
    }
    //Lpm_unLockLpm(TIMER_LPM_FLAG);
}

BOOL SYS_ReleaseTimer(SYS_TIMER_TYPE *pTimer)
{
    SYS_TIMER_TYPE *pTemp, *pPre;
    if(gpSysTimeListHeader == NULL)
    {
        return FALSE;
    }
    if (pTimer == NULL)
    {
        return FALSE;
    }

    if (pTimer == &gSysTimerHeaderTimer)
    {
        return FALSE;
    }

    for(pTemp = pPre = gpSysTimeListHeader; pTemp->pNextTimer != NULL; pPre = pTemp, pTemp = pTemp->pNextTimer)
    {
        if (pTimer == pTemp)
        {
            pTemp->mTimerStatus = TIMER_STOP;
            if (pPre == pTemp) //delete the first one element
            {
                gpSysTimeListHeader = pTemp->pNextTimer;
            }
            else
            {
                pPre->pNextTimer = pTemp->pNextTimer;
            }

            //YC_LOG_INFO("release timer %d,%d \r\n",pPre->cbParams,pTimer->cbParams);
            return TRUE;
        }
    }
    return FALSE;
}

void SYS_ReleaseAllTimer(void)
{
    SYS_TIMER_TYPE *pTemp;
    if(gpSysTimeListHeader == NULL)
    {
        return;
    }
    for(pTemp = gpSysTimeListHeader; pTemp->pNextTimer != NULL; pTemp = pTemp->pNextTimer)
    {
        pTemp->mTimerStatus = TIMER_STOP;
    }
    gpSysTimeListHeader = &gSysTimerHeaderTimer;
}

void SYS_IrqHandler(int params)
{
    DEBUG_LOG_STRING("Main Entryxxx.\r\n");
    SYS_ClkTicks();
    gSysTimerCheckFlag = TRUE;
}

void SYS_100msTimerHandle(uint8_t count)
{
    SYS_ClkTicks();
    gSysTimerCheckFlag = TRUE;
}

void SYS_ClkTicks(void)
{
    /*if(SYS_CheckInFastSpeed())
    {
    	return;
    }*/
    uint32_t clknbt = HREADL(CORE_CLKN);

    uint32_t diffbt = 0;

    // Check initial
    if(gSystemTimerAdjustClknbt == 0)
    {
        gSystemTimerAdjustClknbt = clknbt;
    }
    else
    {
        // TODO: Think the clock overflow
        if(gSystemTimerAdjustClknbt > clknbt)
        {
            gSystemTimerAdjustClknbt = clknbt;
            return;
        }
        // Every time need check the diff, if diff is big
        diffbt = clknbt - gSystemTimerAdjustClknbt;

        // Check diff clk
        // 1s = 3200subSlots = 12000000 = 0xB71B00 ticks
        // 1ms = 32subSlots = 12000000 = 0xB71B00 ticks
        while(diffbt >= (SYSTEM_TIMER_UNIT_SUBSLOTS))
        {
            gSysTimeWorkCount ++;
            gSystemTimerAdjustClknbt += SYSTEM_TIMER_UNIT_SUBSLOTS;

            diffbt = diffbt - (SYSTEM_TIMER_UNIT_SUBSLOTS);
        }
    }
}

void SYS_DelayMs(uint32_t nms)
{
    SysTick_DelayMs(nms);
}

void SYS_DelayUs(uint32_t nus)
{
    SysTick_DelayUs(nus);
}

BOOL SYS_CheckInFastSpeed(void)
{
    return SysTick_CheckInFastDpll();
}


/**
 * @method SYS_TimerStartTickTimer
 * @brief  Initialize the start system clock
 * @param  systemClk can be CLOCK_48M_multiple
 * @retval None
 */
void SYS_TimerStartTickTimer(uint8_t systemClk)
{
    //DEBUG_LOG_STRING("SYS_TimerStartTickTimer, systemClk: %d.\r\n", systemClk);
    SYS_ClkTicks();

    //SysTick_Init(systemClk, SYSTIMER_UNIT_MS*1000, SYS_IrqHandler);
    //DEBUG_LOG_STRING("SYS_TimerStartTickTimer1, systemClk: %d.\r\n", systemClk);
    SysTick_Init(systemClk, SYSTIMER_UNIT_MS * 1000, NULL);
    //DEBUG_LOG_STRING("SYS_TimerStartTickTimer2, systemClk: %d.\r\n", systemClk);
}
/**
 * @method SYS_TimerInit
 * @brief  Initialize the system clock
 * @param  systemClk can be CLOCK_48M_multiple
 * @retval None
 */
void SYS_TimerInit(uint8_t systemClk)
{
    //initial timer lists
    gpSysTimeListHeader = &gSysTimerHeaderTimer;
    gpSysTimeListHeader->pNextTimer = NULL;
    gpSysTimeListHeader->pfExpireCb = SYS_TimerExpireDefaultHandle;
    gpSysTimeListHeader->mTimerStatus = TIMER_START;
    gpSysTimeListHeader->mTimerValue = 0;

    gSystemTimerAdjustClknbt = 0;

    SYS_TimerStartTickTimer(systemClk);
}





