#ifndef __MSFIFO_H__
#define __MSFIFO_H__


#include "types.h"
/**
 * @brief   Define a Memory FIFO thread safe, and can full use pool.
 * @details API 1 and 2.
 *   read_index and write_index is normal process.
 *   unhandle_index for spec use.
 *   Thread-A will update read_index, for get buffer from FIFO.
 *   Thread-B will update write_index, for put buffer to FIFO
 *               update unhandle_index, for use the buffer Thread-A had processed.
 */
#define MSFIFO_DEFINE(name, cnt)                                         \
        struct {                                                    \
            uint8_t const n;         /* Number of buffers */       \
            uint8_t r;               /* Read. Read index */       \
            uint8_t w;               /* Write. Write index */       \
            uint8_t u;               /* Unhandle. Unhander index */       \
			uint32_t m[((cnt) + 1)];         \
        } msfifo_##name = {                                          \
            .n = ((cnt) + 1),                                   \
            .r = 0,                                             \
            .w = 0,                                             \
            .u = 0,                                             \
        }

/**
 * @brief   Initialize an MQUEUE to be empty
 * @details API 1 and 2. An MFIFO is empty if rptr == wptr
 */
#define MSFIFO_INIT(name) \
    msfifo_##name.u = msfifo_##name.r = msfifo_##name.w = 0

static inline uint8_t msfifo_is_empty(uint8_t rptr, uint8_t wptr)
{
    return rptr == wptr;
}

#define MSFIFO_IS_EMPTY(name) \
        msfifo_is_empty(msfifo_##name.r, \
                      msfifo_##name.w)

static inline uint8_t msfifo_is_unhandle_empty(uint8_t rptr, uint8_t uptr)
{
    return rptr == uptr;
}

#define MSFIFO_IS_UNHANDLE_EMPTY(name) \
        msfifo_is_unhandle_empty(msfifo_##name.r, \
                      msfifo_##name.u)


static inline uint8_t msfifo_size(uint8_t count, uint8_t rptr, uint8_t wptr)
{
    return wptr >= rptr ? wptr - rptr : count - (rptr - wptr);
}

#define MSFIFO_SIZE(name) \
        msfifo_size(msfifo_##name.n, msfifo_##name.r, \
                      msfifo_##name.w)


static inline uint8_t msfifo_enqueue(uint32_t *buf, void *val
                                     , uint8_t count, uint8_t rptr, uint8_t *wptr)
{
    byte nwptr = (*wptr == count - 1) ? 0 : *wptr + 1;
    if(nwptr == rptr) return FALSE;		// full
    buf[*wptr] = (uint32_t)val;
    *wptr = nwptr;
    return TRUE;
}

#define MSFIFO_ENQUEUE(name, val) \
        msfifo_enqueue(msfifo_##name.m, (val), \
                      msfifo_##name.n, msfifo_##name.r, \
                      &msfifo_##name.w)


static inline void *msfifo_dequeue(uint32_t *buf
                                   , uint8_t count, uint8_t *rptr, uint8_t wptr)
{
    void *val;
    if(wptr == *rptr) return NULL;		// full
    val = (void *)buf[*rptr];
    *rptr = (*rptr == count - 1) ? 0 : *rptr + 1;
    return val;
}

#define MSFIFO_DEQUEUE(name) \
        msfifo_dequeue(msfifo_##name.m, \
                      msfifo_##name.n, &msfifo_##name.r, \
                      msfifo_##name.w)

static inline void *msfifo_dequeue_peek(uint32_t *buf
                                        , uint8_t count, uint8_t rptr, uint8_t wptr)
{
    uint32_t val;
    if(wptr == rptr) return NULL;     // full
    val = ((uint32_t *)buf)[rptr];
    return (void *)val;
}

#define MSFIFO_DEQUEUE_PEEK(name) \
        msfifo_dequeue_peek(msfifo_##name.m, \
                      msfifo_##name.n, msfifo_##name.r, \
                      msfifo_##name.w)




static inline void *msfifo_handle(uint32_t *buf
                                  , uint8_t count, uint8_t *uptr, uint8_t rptr)
{
    uint32_t val;
    if(rptr == *uptr) return NULL;		// empty
    val = ((uint32_t *)buf)[*uptr];
    *uptr = (*uptr == count - 1) ? 0 : *uptr + 1;
    return (void *)val;
}

#define MSFIFO_HANDLE(name) \
        msfifo_handle(msfifo_##name.m, \
                      msfifo_##name.n, &msfifo_##name.u, \
                      msfifo_##name.r)

static inline void *msfifo_handle_peek(uint32_t *buf
                                       , uint8_t count, uint8_t uptr, uint8_t rptr)
{
    uint32_t val;
    if(uptr == rptr) return NULL;     // empty
    val = ((uint32_t *)buf)[uptr];
    return (void *)val;
}

#define MSFIFO_HANDLE_PEEK(name) \
        msfifo_handle_peek(msfifo_##name.m, \
                      msfifo_##name.n, msfifo_##name.u, \
                      msfifo_##name.r)







/**
 * @brief Number of available buffers
 * @details API 1 and 2
 *   Empty if rptr == wptr
 */
static inline uint8_t msfifo_avail_count_get(uint8_t count, uint8_t rptr, uint8_t wptr)
{
    if (wptr >= rptr)
    {
        return wptr - rptr;
    }
    else
    {
        return count - rptr + wptr;
    }
}

/**
 * @brief Number of available buffers
 * @details API 1 and 2
 */
#define MSFIFO_AVAIL_COUNT_GET(name) \
        msfifo_avail_count_get(msfifo_##name.n, msfifo_##name.r, \
                      msfifo_##name.w)


#endif //__MSFIFO_H__


