/**
* Copyright 2016, yichip Semiconductor(shenzhen office)
* All Rights Reserved.
*
* This is UNPUBLISHED PROPRIETARY SOURCE CODE of Yichip Semiconductor;
* the contents of this file may not be disclosed to third parties, copied
* or duplicated in any form, in whole or in part, without the prior
* written permission of Yichip Semiconductor.
*/

/**
  *@file timer.h
  *@brief timer support for application.
  */
#ifndef _YC_SYS_TIMER_H_
#define _YC_SYS_TIMER_H_

#include "yc11xx_systick.h"

#define SYSTIMER_UNIT_MS    (10)


#define CLK_SUBSLOT_10_MS    (32)
#define SYSTEM_TIMER_UNIT_SUBSLOTS    (CLK_SUBSLOT_10_MS)

typedef void (*Timer_Expire_CB)(int params);

/**
  *@brief Timer_state.
  */
typedef enum
{
    TIMER_STOP,
    TIMER_START,
} TIMER_STATUS;

/**
  *@brief Timer_type.
  */
typedef enum
{
    TIMER_SINGLE,		/*!< */
    TIMER_CYCLE,		/*!< */
} TIMER_TYPE;

/**
  *@brief System timer type.
  */
typedef struct sTimerType
{
    uint32_t mTimerValue;
    uint32_t mTick;
    Timer_Expire_CB pfExpireCb;
    struct sTimerType *pNextTimer;
    int32_t cbParams;
    TIMER_STATUS mTimerStatus;
    TIMER_TYPE mIsCycle;
} SYS_TIMER_TYPE;

/**
  *@brief Timer_number.
  */
typedef enum
{
    SYS_TIMER_0,
    SYS_TIMER_1,
    SYS_TIMER_2,
    SYS_TIMER_3,
    SYS_TIMER_4,
    SYS_TIMER_5,
    SYS_TIMER_6,
    SYS_TIMER_7,
    SYS_TIMER_8,
} SYS_TIMER_INDEX;

void SYS_TimerExpireDefaultHandle(int params);
void SYS_ChangeDPLL(uint8_t systemClk);
void SYS_ChangeToFastDPLL(void);
void SYS_ChangeToNormalDPLL(void);
BOOL SYS_SetTimer(SYS_TIMER_TYPE *pTimer, int tick, TIMER_TYPE isSingle, Timer_Expire_CB pfExpire_CB);

BOOL SYS_TimerisExist(SYS_TIMER_TYPE *pTimer);
BOOL SYS_ResetTimer(SYS_TIMER_TYPE *pTimer);
void SYS_TimerTest(void);
void SYS_TimerPolling(void);
BOOL SYS_ReleaseTimer(SYS_TIMER_TYPE *pTimer);
void SYS_ReleaseAllTimer(void);
void SYS_IrqHandler(int params);
void SYS_100msTimerHandle(uint8_t count);
void SYS_ClkTicks(void);
void SYS_DelayMs(uint32_t nms);
void SYS_DelayUs(uint32_t nus);
BOOL SYS_CheckInFastSpeed(void);
void SYS_TimerStartTickTimer(uint8_t systemClk);
void SYS_TimerInit(uint8_t systemClk);

#endif
