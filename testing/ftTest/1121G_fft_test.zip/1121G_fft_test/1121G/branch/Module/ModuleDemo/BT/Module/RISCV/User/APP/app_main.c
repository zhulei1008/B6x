#include "app_main.h"
#include "yc11xx_dev_bt_data_trans.h"
#include "yc11xx_ipc.h"
#include "yc_debug.h"
#include "yc11xx_uart.h"
#include "myprintf.h"
#include "yc_nvic.h"
#include "yc_sys_timer.h"

//BIG_MEMORY_LPM_NOT_PROTECT_ATTRIBUTES static uint8_t gHeapBuffer[HEAP_BUFFER_SIZE];

tIPCHandleCb gTIPCHandleCb[IPC_TYPE_NUM] =
{
    0,
    IpcDefaultCallBack,//cmd
    App_EvtCallBack,//evt
    IpcDefaultCallBack,//hid
    IpcDefaultCallBack,//spp
    //IpcDefaultCallBack,
    IpcDefaultCallBack,//ble
    Bt_DataBufferCallBack,//24g
    IpcDefaultCallBack,//mesh
    IpcDefaultCallBack,//mesh
    IpcDefaultCallBack,//mesh
    IpcDefaultCallBack,//a2dp
    IpcDefaultCallBack,//hfp
    IpcDefaultCallBack,//tws
};


//attribute list: handle 2bytes, uuid 2bytes, length 1bytes, attribute Nbytes
uint8_t gTestAttribute[] =
{
    //Primary service yichip transmit ------
    0x01, 0x00, 0x02, 0x00, 0x28, 0x02, 0xff, 0xff
    //Characteristic tx--notify
    , 0x02, 0x00, 0x02, 0x03, 0x28, 0x01, 0x10
    , 0x03, 0x00, 0x02, 0x11, 0xff, 0x14, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    //Client Characteristic Configuration
    , 0x04, 0x00, 0x02, 0x02, 0x29, 0x02, 0x01, 0x00

    //Characteristic rx--write
    , 0x05, 0x00, 0x02, 0x03, 0x28, 0x01, 0x04
    , 0x06, 0x00, 0x02, 0x22, 0xff, 0x14, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    //End of Attribute list
    , 0x00, 0x00
};

void ble_start_adv(uint16_t interval)       //*0.625ms
{
    HWRITEW(mem_le_adv_interval, interval);
    HWRITE(mem_le_adv_enable, 1);
}

void App_Reset(void)
{
    HWRITEL(mem_ui_le_uuid_table, gTestAttribute);
    ble_start_adv(0x30);
}

void App_EvtResetWork(void)
{
    LPM_AppCtrlRegDef lpmCtrl;
    SYS_TimerInit(CLOCK_48M_multiple);
    DEBUG_LOG_2(LOG_LEVEL_CORE, "IPC", "App_EvtCallBack: 0x%04X", LOG_POINT_900D
                , lpmCtrl.user_bit_second_power_on, lpmCtrl.user_bit_charge_power_off);
    if(lpmCtrl.user_bit_second_power_on)
    {
        // Check if second power on work.
        if(lpmCtrl.user_bit_charge_power_off)
        {
            CoreReg_LpmAppRegChargePowerOffControl(FALSE);
            App_PowerResetWork(TRUE);
            return;
        }
    }
    else
    {
        // Do something special?
        CoreReg_LpmAppRegFirstPowerOnControl(TRUE);
    }
    App_Reset();
}

void App_EvtCallBack(uint8_t len, uint8_t *dataPtr)
{
    if (*dataPtr > BT_EVT_100MS_UINT)
    {
        SYS_100msTimerHandle((*dataPtr) & (0x0F));
        return;
    }
    DEBUG_LOG(LOG_LEVEL_CORE, "IPC", "App_EvtCallBack: 0x%04X", LOG_POINT_9001, *dataPtr);
    switch(*dataPtr)
    {
    case BT_EVT_WAKEUP:
        OS_INITIAL_CRITICAL();
        SYS_TimerStartTickTimer(CLOCK_48M_multiple);   //Temporarily log off, convenient test
        //Audio_AdacPorDefaultInit();
        break;
    case BT_EVT_RESET:
        OS_INITIAL_CRITICAL();
        App_EvtResetWork();
        break;
    case BT_EVT_LE_CONNECTED:
        HWRITE(mem_le_adv_enable, 0);
        IPC_TxControlCmd(BT_CMD_LE_UPDATE_CONN);
        break;
    case BT_EVT_LE_DISCONNECTED:
        HWRITE(mem_le_adv_enable, 1);
        break;
    default:
        break;
    }
}

void App_MainLoop(void)
{
    OS_INITIAL_CRITICAL();
    IPC_init(&gTIPCHandleCb);
    DEBUG_INIT();

    while(1)
    {
        //For respin log print
        DEBUG_POLLING_PRINT();

        switch (HREAD(IPC_MCU_STATE))
        {
        case IPC_MCU_STATE_RUNNING:
            //always first init bt
            IPC_HandleRxPacket();
            if(HREAD(0x4ff0) == 1)
            {
                HWRITE(0x4ff0, 0);
                IPC_TxControlCmd(0xC0);
                IPC_TxControlCmd(BT_CMD_LE_UPDATE_CONN);
            }
            Lpm_unLockLpm(M0_LPM_FLAG);
            break;
        case IPC_MCU_STATE_LMP:
            if (IPC_IsTxBuffEmpty()
                    && Lpm_CheckLpmFlag())
            {
                OS_ENTER_CRITICAL();
                //App_ActionBeforeLpm();
                HWRITE(IPC_MCU_STATE, IPC_MCU_STATE_STOP);
            }
            else
            {
                HWRITE(IPC_MCU_STATE, IPC_MCU_STATE_RUNNING);
            }
            break;
        case IPC_MCU_STATE_HIBERNATE:
            OS_ENTER_CRITICAL();
            //App_ActionBeforeHibernate();
            HWRITE(IPC_MCU_STATE, IPC_MCU_STATE_STOP);
            break;
        case IPC_MCU_STATE_STOP:
            break;
        }
    }
}



