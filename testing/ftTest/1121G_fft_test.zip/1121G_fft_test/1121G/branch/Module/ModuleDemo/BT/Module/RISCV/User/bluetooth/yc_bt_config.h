/*
 * Copyright (c) 2015 Intel Corporation.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef ZEPHYR_INCLUDE_CONFIG_H_
#define ZEPHYR_INCLUDE_CONFIG_H_

#include <base/types.h>
#include <base/common.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __ORDER_BIG_ENDIAN__
#define __ORDER_BIG_ENDIAN__            (1)
#endif

#ifndef __ORDER_LITTLE_ENDIAN__
#define __ORDER_LITTLE_ENDIAN__         (2)
#endif

#define __BYTE_ORDER__                  __ORDER_LITTLE_ENDIAN__
#define __CHAR_BIT__ 8
#define __SIZEOF_LONG__ 4


#ifndef __fallthrough
#if __GNUC__ >= 7
#define __fallthrough        __attribute__((fallthrough))
#else
#define __fallthrough
#endif	/* __GNUC__ >= 7 */
#endif

#ifndef __packed
#define __packed        __attribute__((__packed__))
#endif
#ifndef __aligned
#define __aligned(x)	__attribute__((__aligned__(x)))
#endif
#define __may_alias     __attribute__((__may_alias__))
#ifndef __printf_like
#define __printf_like(f, a)   __attribute__((format (printf, f, a)))
#endif
#define __used		__attribute__((__used__))
#define __deprecated
#ifndef __deprecated
#define __deprecated	__attribute__((deprecated))
#endif
#define ARG_UNUSED(x) (void)(x)

#define likely(x)   __builtin_expect((bool)!!(x), true)
#define unlikely(x) __builtin_expect((bool)!!(x), false)

#define popcount(x) __builtin_popcount(x)

#ifndef __no_optimization
#define __no_optimization __attribute__((optimize("-O0")))
#endif

#ifndef __weak
#define __weak __attribute__((__weak__))
#endif
#define __unused __attribute__((__unused__))

#define __builtin_unreachable() do { __ASSERT(false, "Unreachable code"); } \
	while (true)

#define CODE_UNREACHABLE __builtin_unreachable()

#define FUNC_NORETURN    __attribute__((__noreturn__))



#ifndef errno
#define errno (*z_errno())
#endif

/*
 * POSIX Error codes
 */
#ifndef EPERM
#define EPERM 1		/* Not owner */
#define ENOENT 2	/* No such file or directory */
#define ESRCH 3		/* No such context */
#define EINTR 4		/* Interrupted system call */
#define EIO 5		/* I/O error */
#define ENXIO 6		/* No such device or address */
#define E2BIG 7		/* Arg list too long */
#define ENOEXEC 8       /* Exec format error */
#define EBADF 9		/* Bad file number */
#define ECHILD 10       /* No children */
#define EAGAIN 11       /* No more contexts */
#define ENOMEM 12       /* Not enough core */
#define EACCES 13       /* Permission denied */
#define EFAULT 14       /* Bad address */
#define ENOTEMPTY 15    /* Directory not empty */
#define EBUSY 16	/* Mount device busy */
#define EEXIST 17       /* File exists */
#define EXDEV 18	/* Cross-device link */
#define ENODEV 19       /* No such device */
#define ENOTDIR 20      /* Not a directory */
#define EISDIR 21       /* Is a directory */
#define EINVAL 22       /* Invalid argument */
#define ENFILE 23       /* File table overflow */
#define EMFILE 24       /* Too many open files */
#define ENOTTY 25       /* Not a typewriter */
#define ENAMETOOLONG 26 /* File name too long */
#define EFBIG 27	/* File too large */
#define ENOSPC 28       /* No space left on device */
#define ESPIPE 29       /* Illegal seek */
#define EROFS 30	/* Read-only file system */
#define EMLINK 31       /* Too many links */
#define EPIPE 32	/* Broken pipe */
#define EDEADLK 33      /* Resource deadlock avoided */
#define ENOLCK 34       /* No locks available */
#define ENOTSUP 35      /* Unsupported value */
#define EMSGSIZE 36     /* Message size */

/* ANSI math software */
#define EDOM 37   /* Argument too large */
#define ERANGE 38 /* Result too large */

/* ipc/network software */

/* argument errors */
#define EDESTADDRREQ 40    /* Destination address required */
#define EPROTOTYPE 41      /* Protocol wrong type for socket */
#define ENOPROTOOPT 42     /* Protocol not available */
#define EPROTONOSUPPORT 43 /* Protocol not supported */
#define ESOCKTNOSUPPORT 44 /* Socket type not supported */
#define EOPNOTSUPP 45      /* Operation not supported on socket */
#define EPFNOSUPPORT 46    /* Protocol family not supported */
#define EAFNOSUPPORT 47    /* Addr family not supported */
#define EADDRINUSE 48      /* Address already in use */
#define EADDRNOTAVAIL 49   /* Can't assign requested address */
#define ENOTSOCK 50	/* Socket operation on non-socket */

/* operational errors */
#define ENETUNREACH 51  /* Network is unreachable */
#define ENETRESET 52    /* Network dropped connection on reset */
#define ECONNABORTED 53 /* Software caused connection abort */
#define ECONNRESET 54   /* Connection reset by peer */
#define ENOBUFS 55      /* No buffer space available */
#define EISCONN 56      /* Socket is already connected */
#define ENOTCONN 57     /* Socket is not connected */
#define ESHUTDOWN 58    /* Can't send after socket shutdown */
#define ETOOMANYREFS 59 /* Too many references: can't splice */
#define ETIMEDOUT 60    /* Connection timed out */
#define ECONNREFUSED 61 /* Connection refused */
#define ENETDOWN 62     /* Network is down */
#define ETXTBSY 63      /* Text file busy */
#define ELOOP 64	/* Too many levels of symbolic links */
#define EHOSTUNREACH 65 /* No route to host */
#define ENOTBLK 66      /* Block device required */
#define EHOSTDOWN 67    /* Host is down */

/* non-blocking and interrupt i/o */
#define EINPROGRESS 68 /* Operation now in progress */
#define EALREADY 69    /* Operation already in progress */
#define EWOULDBLOCK EAGAIN /* Operation would block */

#define ENOSYS 71 /* Function not implemented */

/* aio errors (should be under posix) */
#define ECANCELED 72 /* Operation canceled */

#define ERRMAX 81

/* specific STREAMS errno values */

#define ENOSR 74   /* Insufficient memory */
#define ENOSTR 75  /* STREAMS device required */
#define EPROTO 76  /* Generic STREAMS error */
#define EBADMSG 77 /* Invalid STREAMS message */
#define ENODATA 78 /* Missing expected message data */
#define ETIME 79   /* STREAMS timeout occurred */
#define ENOMSG 80  /* Unexpected message type */

#define EILSEQ 138 /* Illegal byte sequence */
#endif

#define irq_lock() 0
#define irq_unlock(key)

/* Unaligned access */
#define UNALIGNED_GET(p)						\
__extension__ ({							\
	struct  __attribute__((__packed__)) {				\
		__typeof__(*(p)) __v;					\
	} *__p = (__typeof__(__p)) (p);					\
	__p->__v;							\
})

/* Double indirection to ensure section names are expanded before
 * stringification
 */
#define __GENERIC_SECTION(segment) __attribute__((section(STRINGIFY(segment))))
#define Z_GENERIC_SECTION(segment) __GENERIC_SECTION(segment)

#define ___in_section(a, b, c) \
        __attribute__((section("." Z_STRINGIFY(a)           \
                    "." Z_STRINGIFY(b)          \
                    "." Z_STRINGIFY(c))))
#define __in_section(a, b, c) ___in_section(a, b, c)

#define __in_section_unique(seg) ___in_section(seg, __FILE__, __COUNTER__)


#if !defined(_ASMLANGUAGE)

#define __noinit		__in_section_unique(_NOINIT_SECTION_NAME)
#define __irq_vector_table	Z_GENERIC_SECTION(_IRQ_VECTOR_TABLE_SECTION_NAME)
#define __sw_isr_table		Z_GENERIC_SECTION(_SW_ISR_TABLE_SECTION_NAME)

#if defined(CONFIG_ARM)
#define __kinetis_flash_config_section __in_section_unique(_KINETIS_FLASH_CONFIG_SECTION_NAME)
#define __ti_ccfg_section Z_GENERIC_SECTION(_TI_CCFG_SECTION_NAME)
#define __ccm_data_section Z_GENERIC_SECTION(_CCM_DATA_SECTION_NAME)
#define __ccm_bss_section Z_GENERIC_SECTION(_CCM_BSS_SECTION_NAME)
#define __ccm_noinit_section Z_GENERIC_SECTION(_CCM_NOINIT_SECTION_NAME)
#define __dtcm_data_section Z_GENERIC_SECTION(_DTCM_DATA_SECTION_NAME)
#define __dtcm_bss_section Z_GENERIC_SECTION(_DTCM_BSS_SECTION_NAME)
#define __dtcm_noinit_section Z_GENERIC_SECTION(_DTCM_NOINIT_SECTION_NAME)
#define __imx_boot_conf_section Z_GENERIC_SECTION(_IMX_BOOT_CONF_SECTION_NAME)
#define __imx_boot_data_section Z_GENERIC_SECTION(_IMX_BOOT_DATA_SECTION_NAME)
#define __imx_boot_ivt_section Z_GENERIC_SECTION(_IMX_BOOT_IVT_SECTION_NAME)
#define __imx_boot_dcd_section Z_GENERIC_SECTION(_IMX_BOOT_DCD_SECTION_NAME)
#endif /* CONFIG_ARM */

#if defined(CONFIG_NOCACHE_MEMORY)
#define __nocache __in_section_unique(_NOCACHE_SECTION_NAME)
#else
#define __nocache
#endif /* CONFIG_NOCACHE_MEMORY */

#endif /* !_ASMLANGUAGE */

#define __attr_ram_code(_x) ___in_section(_SECTION_RAM_CODE_DEFINE, _x, __FILE__)
#define __attr_ram_code_bt		  __attr_ram_code(BLUETOOTH)
#define __attr_ram_code_app		  __attr_ram_code(APP)


/**
 * Function used to read the data from the settings storage in
 * h_set handler implementations.
 *
 * @param[in] cb_arg  arguments for the read function. Appropriate cb_arg is
 *                    transferred to h_set handler implementation by
 *                    the backend.
 * @param[out] data  the destination buffer
 * @param[in] len    length of read
 *
 * @return positive: Number of bytes read, 0: key-value pair is deleted.
 *                   On error returns -ERRNO code.
 */
typedef ssize_t (*settings_read_cb)(void *cb_arg, void *data, size_t len);



/* number of nsec per usec */
#define NSEC_PER_USEC 1000U

/* number of microseconds per millisecond */
#define USEC_PER_MSEC 1000U

/* number of milliseconds per second */
#define MSEC_PER_SEC 1000U

/* number of microseconds per second */
#define USEC_PER_SEC ((USEC_PER_MSEC) * (MSEC_PER_SEC))

/* number of nanoseconds per second */
#define NSEC_PER_SEC ((NSEC_PER_USEC) * (USEC_PER_MSEC) * (MSEC_PER_SEC))

#define BT_STACK_MODE_CONTROLLER_ONLY            1
#define BT_STACK_MODE_HOST_ONLY                  2
#define BT_STACK_MODE_HOST_AND_CONTROLLER        3
#define BT_STACK_MODE_HOST_ONLY_IPC              4

#define CONFIG_BT_STACK_MODE       BT_STACK_MODE_HOST_ONLY_IPC


#define CONFIG_BLE_ATUO_TEST 1
#define CONFIG_LOG 1
#define CONFIG_LOG_MINIMAL 1
#define CONFIG_PRINTK 1

#define CONFIG_NET_BUF_LOG 1
#define CONFIG_NET_BUF_SIMPLE_LOG 1


#define CONFIG_BT_DEBUG 1
#define CONFIG_BT_DEBUG_CONN 1
#define CONFIG_BT_LOG_LEVEL (1)


#define CONFIG_BT_DEBUG_HCI_DRIVER 1
#define CONFIG_NET_BUF_USER_DATA_SIZE 1

#define CONFIG_BT_CTLR_PHY_2M 1
#define CONFIG_BT_CTLR_PHY_CODED 1
#define CONFIG_BT_CTLR_DATA_LENGTH_MAX 1

#define CONFIG_BT_COMBINE_TEST_ADV
//#define CONFIG_BT_COMBINE_TEST_SCAN






#define CONFIG_BT_ID_MAX (1)
#define CONFIG_BT_HCI_CMD_COUNT (6)
#define CONFIG_BT_RX_BUF_COUNT (6)
#define CONFIG_BT_RX_BUF_LEN (400)
#define CONFIG_BT_HCI_RESERVE (4)

#define CONFIG_BT_MAX_CONN (2)
#define CONFIG_BT_MAX_PAIRED (1)
#define CONFIG_BT_CONN_TX_MAX (12)
#define ATT_CHAN_MAX (4)



#define CONFIG_BT_L2CAP_TX_BUF_COUNT (6)
#define CONFIG_BT_L2CAP_TX_MTU (517)
#define CONFIG_BT_L2CAP_RX_MTU (517)
#define CONFIG_BT_ATT_TX_MAX (6)

#define CONFIG_BT_L2CAP_FIXED_CHAN_SIZE (3)

#define CONFIG_BT_GATT_FIXED_SERVICES_SIZE (1)



#define CONFIG_BT_CREATE_CONN_TIMEOUT (1024)



#define CONFIG_BT_BACKGROUND_SCAN_INTERVAL (100)
#define CONFIG_BT_BACKGROUND_SCAN_WINDOW (100)

#define CONFIG_BT_DEVICE_APPEARANCE (0x12)

#define CONFIG_BT_DEVICE_NAME "YC1606  Bob"

#define CONFIG_BT_CONN      1
//#define CONFIG_BT_EXT_ADV (FALSE)
//#define CONFIG_BT_EXT_ADV_MAX_ADV_SET       1


#define CONFIG_BT_GATT_CLIENT       1

//#define CONFIG_BT_ISO 0
//#define CONFIG_BT_L2CAP_DYNAMIC_CHANNEL (TRUE)
#define CONFIG_BT_CENTRAL       1
//#define CONFIG_BT_WHITELIST (FALSE)
#define CONFIG_BT_BROADCASTER       1
//#define CONFIG_BT_PRIVACY (FALSE)
#define CONFIG_BT_PERIPHERAL     1
#define CONFIG_BT_OBSERVER      1
//#define CONFIG_BT_SCAN_WITH_IDENTITY (FALSE)
//#define CONFIG_BT_HCI_VS_EXT (FALSE)
//#define CONFIG_BT_TINYCRYPT_ECC (FALSE)
//#define CONFIG_BT_HOST_CRYPTO (FALSE)
//#define CONFIG_BT_PER_ADV_SYNC (FALSE)
#define CONFIG_BT_SMP 1
//#define CONFIG_BT_DATA_LEN_UPDATE (FALSE)
//#define CONFIG_BT_PHY_UPDATE (FALSE)
//#define CONFIG_BT_ECC (FALSE)
//#define CONFIG_BT_AUTO_DATA_LEN_UPDATE (FALSE)
//#define CONFIG_BT_BREDR (FALSE)
//#define CONFIG_BT_SETTINGS (FALSE)
//#define CONFIG_BT_SETTINGS (FALSE)
//#define CONFIG_BT_SETTINGS (FALSE)
//#define CONFIG_BT_SETTINGS (FALSE)
//#define CONFIG_BT_SETTINGS (FALSE)

#define CONFIG_BT_CTLR_LE_ENC 1
#define CONFIG_BT_CTLR_PHY 1
#define CONFIG_BT_CTLR_DATA_LENGTH 1
//#define CONFIG_BT_USER_PHY_UPDATE 1

#define CONFIG_BT_CTLR_PARAM_CHECK 1

#define CONFIG_BT_HCI_VS 1
#define CONFIG_BT_HCI_VS_EXT 1

#define CONFIG_BT_CTLR_RX_BUFFERS (3)

#define CONFIG_BT_DATA_RX_BUFFERS (5)



#define CONFIG_BT_CTLR_TX_BUFFER_SIZE (300)
#define CONFIG_BT_CTLR_TX_BUFFERS (3)

#define CONFIG_BT_DATA_TX_BUFFER_SIZE (300)
#define CONFIG_BT_DATA_TX_BUFFERS (8)

#define CONFIG_BT_CTLR_COMPANY_ID (0x050e08)
#define CONFIG_BT_CTLR_SUBVERSION_NUMBER (0x0005)


#if 0
enum
{
    hci_cmd_pool = 0,
    hci_rx_pool,
    num_complete_pool,
    discardable_pool,
};
#endif

#ifdef __cplusplus
}
#endif

#endif /* ZEPHYR_INCLUDE_CONFIG_H_ */
