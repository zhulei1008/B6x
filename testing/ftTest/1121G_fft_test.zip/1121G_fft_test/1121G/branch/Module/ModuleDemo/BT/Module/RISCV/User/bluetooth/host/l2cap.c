/* l2cap.c - L2CAP handling */

/*
 * Copyright (c) 2015-2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <string.h>
#include <errno.h>
#include <base/atomic.h>
#include <base/common.h>

#include <bluetooth/hci.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/conn.h>
#include <drivers/hci_driver.h>

#define BT_DBG_ENABLED IS_ENABLED(CONFIG_BT_DEBUG_L2CAP)
#define LOG_MODULE_NAME bt_l2cap
#include "logging/bt_log.h"

#include "hci_core.h"
#include "conn_internal.h"
#include "l2cap_internal.h"

#define LE_CHAN_RTX(_w) CONTAINER_OF(_w, struct bt_l2cap_le_chan, chan.rtx_work)
#define CHAN_RX(_w) CONTAINER_OF(_w, struct bt_l2cap_le_chan, rx_work)

#define L2CAP_LE_MIN_MTU		23
#define L2CAP_ECRED_MIN_MTU		64

#if defined(CONFIG_BT_HCI_ACL_FLOW_CONTROL)
#define L2CAP_LE_MAX_CREDITS		(CONFIG_BT_ACL_RX_COUNT - 1)
#else
#define L2CAP_LE_MAX_CREDITS		(CONFIG_BT_RX_BUF_COUNT - 1)
#endif

#define L2CAP_LE_CID_DYN_START	0x0040
#define L2CAP_LE_CID_DYN_END	0x007f
#define L2CAP_LE_CID_IS_DYN(_cid) \
	(_cid >= L2CAP_LE_CID_DYN_START && _cid <= L2CAP_LE_CID_DYN_END)

#define L2CAP_LE_PSM_FIXED_START 0x0001
#define L2CAP_LE_PSM_FIXED_END   0x007f
#define L2CAP_LE_PSM_DYN_START   0x0080
#define L2CAP_LE_PSM_DYN_END     0x00ff
#define L2CAP_LE_PSM_IS_DYN(_psm) \
	(_psm >= L2CAP_LE_PSM_DYN_START && _psm <= L2CAP_LE_PSM_DYN_END)

#define L2CAP_CONN_TIMEOUT	(40)
#define L2CAP_DISC_TIMEOUT	(2)
#define L2CAP_RTX_TIMEOUT	(2)

struct bt_l2cap_fixed_chan l2cap_fixed_chan[CONFIG_BT_L2CAP_FIXED_CHAN_SIZE];


#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
/* Dedicated pool for disconnect buffers so they are guaranteed to be send
 * even in case of data congestion due to flooding.
 */
NET_BUF_POOL_FIXED_DEFINE(disc_pool, 1,
                          BT_L2CAP_BUF_SIZE(
                              sizeof(struct bt_l2cap_disconn_req)),
                          NULL);

#define L2CAP_MAX_LE_MPS	CONFIG_BT_L2CAP_RX_MTU
/* For now use MPS - SDU length to disable segmentation */
#define L2CAP_MAX_LE_MTU	(L2CAP_MAX_LE_MPS - 2)

#define L2CAP_ECRED_CHAN_MAX	5

#define l2cap_lookup_ident(conn, ident) __l2cap_lookup_ident(conn, ident, false)
#define l2cap_remove_ident(conn, ident) __l2cap_lookup_ident(conn, ident, true)

struct data_sent
{
    uint16_t len;
};

#define data_sent(buf) ((struct data_sent *)net_buf_user_data(buf))

static sys_slist_t servers;

#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */

/* L2CAP signalling channel specific context */
struct bt_l2cap
{
    /* The channel this context is associated with */
    struct bt_l2cap_le_chan	chan;
};

static struct bt_l2cap bt_l2cap_pool[CONFIG_BT_MAX_CONN];

static uint8_t get_ident(void)
{
    static uint8_t ident;

    ident++;
    /* handle integer overflow (0 is not valid) */
    if (!ident)
    {
        ident++;
    }

    return ident;
}

#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
static struct bt_l2cap_le_chan *l2cap_chan_alloc_cid(struct bt_conn *conn,
        struct bt_l2cap_chan *chan)
{
    struct bt_l2cap_le_chan *ch = BT_L2CAP_LE_CHAN(chan);
    uint16_t cid;

    /*
     * No action needed if there's already a CID allocated, e.g. in
     * the case of a fixed channel.
     */
    if (ch->rx.cid > 0)
    {
        return ch;
    }

    for (cid = L2CAP_LE_CID_DYN_START; cid <= L2CAP_LE_CID_DYN_END; cid++)
    {
        if (!bt_l2cap_le_lookup_rx_cid(conn, cid))
        {
            ch->rx.cid = cid;
            return ch;
        }
    }

    return NULL;
}

static struct bt_l2cap_le_chan *
__l2cap_lookup_ident(struct bt_conn *conn, uint16_t ident, bool remove)
{
    struct bt_l2cap_chan *chan;
    sys_snode_t *prev = NULL;

    SYS_SLIST_FOR_EACH_CONTAINER(&conn->channels, chan, node)
    {
        if (chan->ident == ident)
        {
            if (remove)
            {
                sys_slist_remove(&conn->channels, prev,
                                 &chan->node);
            }
            return BT_L2CAP_LE_CHAN(chan);
        }

        prev = &chan->node;
    }

    return NULL;
}
#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */

void bt_l2cap_chan_remove(struct bt_conn *conn, struct bt_l2cap_chan *ch)
{
    struct bt_l2cap_chan *chan;
    sys_snode_t *prev = NULL;

    SYS_SLIST_FOR_EACH_CONTAINER(&conn->channels, chan, node)
    {
        if (chan == ch)
        {
            sys_slist_remove(&conn->channels, prev, &chan->node);
            return;
        }

        prev = &chan->node;
    }
}

const char *bt_l2cap_chan_state_str(bt_l2cap_chan_state_t state)
{
    switch (state)
    {
    case BT_L2CAP_DISCONNECTED:
        return "disconnected";
    case BT_L2CAP_CONNECT:
        return "connect";
    case BT_L2CAP_CONFIG:
        return "config";
    case BT_L2CAP_CONNECTED:
        return "connected";
    case BT_L2CAP_DISCONNECT:
        return "disconnect";
    default:
        return "unknown";
    }
}

void bt_l2cap_chan_del(struct bt_l2cap_chan *chan)
{
    const struct bt_l2cap_chan_ops *ops = chan->ops;

    BT_DBG("conn %p chan %p", chan->conn, chan);

    if (!chan->conn)
    {
        goto destroy;
    }

    if (ops->disconnected)
    {
        ops->disconnected(chan);
    }

    chan->conn = NULL;

destroy:
#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
    /* Reset internal members of common channel */
    bt_l2cap_chan_set_state(chan, BT_L2CAP_DISCONNECTED);
    chan->psm = 0U;
#endif
    if (chan->destroy)
    {
        chan->destroy(chan);
    }

    if (ops->released)
    {
        ops->released(chan);
    }
}

static void l2cap_rtx_timeout(struct k_work *work)
{
    struct bt_l2cap_le_chan *chan = NULL;//LE_CHAN_RTX(work);
    struct bt_conn *conn = chan->chan.conn;

    BT_ERR("chan %p timeout", chan);

    bt_l2cap_chan_remove(conn, &chan->chan);
    bt_l2cap_chan_del(&chan->chan);

#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
    /* Remove other channels if pending on the same ident */
    while ((chan = l2cap_remove_ident(conn, chan->chan.ident)))
    {
        bt_l2cap_chan_del(&chan->chan);
    }
#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */
}

void bt_l2cap_chan_add(struct bt_conn *conn, struct bt_l2cap_chan *chan,
                       bt_l2cap_chan_destroy_t destroy)
{
    /* Attach channel to the connection */
    sys_slist_append(&conn->channels, &chan->node);
    chan->conn = conn;
    chan->destroy = destroy;

    BT_DBG("conn %p chan %p", conn, chan);
}

static bool l2cap_chan_add(struct bt_conn *conn, struct bt_l2cap_chan *chan,
                           bt_l2cap_chan_destroy_t destroy)
{
    struct bt_l2cap_le_chan *ch;

#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
    ch = l2cap_chan_alloc_cid(conn, chan);
#else
    ch = BT_L2CAP_LE_CHAN(chan);
#endif

    if (!ch)
    {
        BT_ERR("Unable to allocate L2CAP CID");
        return false;
    }

    //k_delayed_work_init(&chan->rtx_work, l2cap_rtx_timeout);
    atomic_clear(chan->status);

    bt_l2cap_chan_add(conn, chan, destroy);

#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
    if (L2CAP_LE_CID_IS_DYN(ch->rx.cid))
    {
        sys_sflist_init(&ch->rx_queue);
        bt_l2cap_chan_set_state(chan, BT_L2CAP_CONNECT);
    }
#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */

    return true;
}

void bt_l2cap_connected(struct bt_conn *conn)
{
    struct bt_l2cap_chan *chan;

    BT_DBG("bt_l2cap_connected %p", conn);

    for(int i = 0; i < ARRAY_SIZE(l2cap_fixed_chan); i ++)
    {
        struct bt_l2cap_fixed_chan *fchan = &l2cap_fixed_chan[i];
        struct bt_l2cap_le_chan *ch;

        if (fchan->accept(conn, &chan) < 0)
        {
            continue;
        }

        ch = BT_L2CAP_LE_CHAN(chan);

        /* Fill up remaining fixed channel context attached in
         * fchan->accept()
         */
        ch->rx.cid = fchan->cid;
        ch->tx.cid = fchan->cid;

        if (!l2cap_chan_add(conn, chan, fchan->destroy))
        {
            return;
        }

        if (chan->ops->connected)
        {
            chan->ops->connected(chan);
        }

        /* Always set output status to fixed channels */
        atomic_set_bit(chan->status, BT_L2CAP_STATUS_OUT);

        if (chan->ops->status)
        {
            chan->ops->status(chan, chan->status);
        }
    }

}

void bt_l2cap_disconnected(struct bt_conn *conn)
{
    struct bt_l2cap_chan *chan, *next;

    SYS_SLIST_FOR_EACH_CONTAINER_SAFE(&conn->channels, chan, next, node)
    {
        bt_l2cap_chan_del(chan);
    }
}

static struct net_buf *l2cap_create_sig_pdu(struct net_buf *buf,
        uint8_t code, uint8_t ident,
        uint16_t len)
{
    struct bt_l2cap_sig_hdr *hdr;
    struct net_buf_pool *pool = NULL;

#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
    if (code == BT_L2CAP_DISCONN_REQ)
    {
        pool = &disc_pool;
    }
#endif
    /* Don't wait more than the minimum RTX timeout of 2 seconds */
    buf = bt_l2cap_create_pdu_timeout(pool, 0, L2CAP_RTX_TIMEOUT);
    if (!buf)
    {
        /* If it was not possible to allocate a buffer within the
         * timeout return NULL.
         */
        BT_ERR("Unable to allocate buffer for op 0x%02x", code);
        return NULL;
    }

    hdr = net_buf_add(buf, sizeof(*hdr));
    hdr->code = code;
    hdr->ident = ident;
    hdr->len = len;

    return buf;
}

#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
static void l2cap_chan_send_req(struct bt_l2cap_chan *chan,
                                struct net_buf *buf, k_timeout_t timeout)
{
    /* BLUETOOTH SPECIFICATION Version 4.2 [Vol 3, Part A] page 126:
     *
     * The value of this timer is implementation-dependent but the minimum
     * initial value is 1 second and the maximum initial value is 60
     * seconds. One RTX timer shall exist for each outstanding signaling
     * request, including each Echo Request. The timer disappears on the
     * final expiration, when the response is received, or the physical
     * link is lost.
     */
    k_delayed_work_submit(&chan->rtx_work, timeout);

    bt_l2cap_send(chan->conn, BT_L2CAP_CID_LE_SIG, buf);
}

static int l2cap_le_conn_req(struct bt_l2cap_le_chan *ch)
{
    struct net_buf *buf;
    struct bt_l2cap_le_conn_req *req;

    ch->chan.ident = get_ident();

    buf = l2cap_create_sig_pdu(NULL, BT_L2CAP_LE_CONN_REQ,
                               ch->chan.ident, sizeof(*req));
    if (!buf)
    {
        return -ENOMEM;
    }

    req = net_buf_add(buf, sizeof(*req));
    req->psm = ch->chan.psm;
    req->scid = ch->rx.cid;
    req->mtu = ch->rx.mtu;
    req->mps = ch->rx.mps;
    req->credits = ch->rx.init_credits;

    l2cap_chan_send_req(&ch->chan, buf, L2CAP_CONN_TIMEOUT);

    return 0;
}

static int l2cap_ecred_conn_req(struct bt_l2cap_chan **chan, int channels)
{
    struct net_buf *buf;
    struct bt_l2cap_ecred_conn_req *req;
    struct bt_l2cap_le_chan *ch;
    int i;
    uint8_t ident;

    if (!chan || !channels)
    {
        return -EINVAL;
    }

    ident = get_ident();

    buf = l2cap_create_sig_pdu(NULL, BT_L2CAP_ECRED_CONN_REQ, ident,
                               sizeof(*req) +
                               (channels * sizeof(uint16_t)));

    req = net_buf_add(buf, sizeof(*req));

    ch = BT_L2CAP_LE_CHAN(chan[0]);

    /* Init common parameters */
    req->psm = ch->chan.psm;
    req->mtu = ch->rx.mtu;
    req->mps = ch->rx.mps;
    req->credits = ch->rx.init_credits;

    for (i = 0; i < channels; i++)
    {
        ch = BT_L2CAP_LE_CHAN(chan[i]);

        ch->chan.ident = ident;

        net_buf_add_le16(buf, ch->rx.cid);
    }

    l2cap_chan_send_req(*chan, buf, L2CAP_CONN_TIMEOUT);

    return 0;
}

static void l2cap_le_encrypt_change(struct bt_l2cap_chan *chan, uint8_t status)
{
    int err;

    /* Skip channels that are not pending waiting for encryption */
    if (!atomic_test_and_clear_bit(chan->status,
                                   BT_L2CAP_STATUS_ENCRYPT_PENDING))
    {
        return;
    }

    if (status)
    {
        goto fail;
    }

    if (chan->ident)
    {
        struct bt_l2cap_chan *echan[L2CAP_ECRED_CHAN_MAX];
        struct bt_l2cap_le_chan *ch;
        int i = 0;

        while ((ch = l2cap_remove_ident(chan->conn, chan->ident)))
        {
            echan[i++] = &ch->chan;
        }

        /* Retry ecred connect */
        l2cap_ecred_conn_req(echan, i);
        return;
    }

    /* Retry to connect */
    err = l2cap_le_conn_req(BT_L2CAP_LE_CHAN(chan));
    if (err)
    {
        goto fail;
    }

    return;
fail:
    bt_l2cap_chan_remove(chan->conn, chan);
    bt_l2cap_chan_del(chan);
}
#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */

void bt_l2cap_security_changed(struct bt_conn *conn, uint8_t hci_status)
{
    struct bt_l2cap_chan *chan, *next;

#if defined(CONFIG_BT_BREDR)
    if (conn->type == BT_CONN_TYPE_BR)
    {
        l2cap_br_encrypt_change(conn, hci_status);
        return;
    }
#endif

    SYS_SLIST_FOR_EACH_CONTAINER_SAFE(&conn->channels, chan, next, node)
    {
#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
        l2cap_le_encrypt_change(chan, hci_status);
#endif

        if (chan->ops->encrypt_change)
        {
            chan->ops->encrypt_change(chan, hci_status);
        }
    }
}

struct net_buf *bt_l2cap_create_pdu_timeout(struct net_buf_pool *pool,
        size_t reserve,
        k_timeout_t timeout)
{
    return bt_conn_create_pdu_timeout(pool,
                                      sizeof(struct bt_l2cap_hdr) + reserve,
                                      timeout);
}

int bt_l2cap_send_cb(struct bt_conn *conn, uint16_t cid, struct net_buf *buf,
                     bt_conn_tx_cb_t cb, void *user_data)
{
    struct bt_l2cap_hdr *hdr;

    BT_DBG("bt_l2cap_send_cb, conn %p cid %u len %zu", conn, cid, net_buf_frags_len(buf));

    hdr = net_buf_push(buf, sizeof(*hdr));
    hdr->len = buf->len - sizeof(*hdr);
    hdr->cid = cid;

    return bt_conn_send_cb(conn, buf, cb, user_data);
}

static void l2cap_send_cmd_reject(struct bt_conn *conn, uint8_t ident,
                                  uint16_t reason, void *data, uint8_t data_len)
{
    struct bt_l2cap_cmd_reject *rej;
    struct net_buf *buf;

    buf = l2cap_create_sig_pdu(NULL, BT_L2CAP_CMD_REJECT, ident,
                               sizeof(*rej) + data_len);
    if (!buf)
    {
        return;
    }

    rej = net_buf_add(buf, sizeof(*rej));
    rej->reason = reason;

    if (data)
    {
        net_buf_add_mem(buf, data, data_len);
    }

    bt_l2cap_send(conn, BT_L2CAP_CID_LE_SIG, buf);
}

static void l2cap_handle_conn_param_rsp(struct bt_l2cap *l2cap, struct net_buf *buf)
{
    struct bt_l2cap_conn_param_rsp *rsp = (void *)buf->data;

    if (buf->len < sizeof(*rsp))
    {
        BT_ERR("Too small LE conn param rsp");
        return;
    }

    BT_DBG("LE conn param rsp result %u", rsp->result);
}

static void l2cap_handle_conn_param_update_req(struct bt_l2cap *l2cap, uint8_t ident,
        struct net_buf *buf)
{
    struct bt_conn *conn = l2cap->chan.chan.conn;
    struct bt_le_conn_param param;
    struct bt_l2cap_conn_param_rsp *rsp;
    struct bt_l2cap_conn_param_req *req = (void *)buf->data;
    bool accepted;

    if (buf->len < sizeof(*req))
    {
        BT_ERR("Too small LE conn update param req");
        return;
    }

    if (conn->role != BT_HCI_ROLE_MASTER)
    {
        l2cap_send_cmd_reject(conn, ident, BT_L2CAP_REJ_NOT_UNDERSTOOD,
                              NULL, 0);
        return;
    }

    param.interval_min = req->min_interval;
    param.interval_max = req->max_interval;
    param.latency = req->latency;
    param.timeout = req->timeout;

    BT_DBG("le_conn_param_update_req min 0x%04x max 0x%04x latency: 0x%04x timeout: 0x%04x",
           param.interval_min, param.interval_max, param.latency,
           param.timeout);

    buf = l2cap_create_sig_pdu(buf, BT_L2CAP_CONN_PARAM_RSP, ident,
                               sizeof(*rsp));
    if (!buf)
    {
        return;
    }

    accepted = le_param_req(conn, &param);

    rsp = net_buf_add(buf, sizeof(*rsp));
    if (accepted)
    {
        rsp->result = BT_L2CAP_CONN_PARAM_ACCEPTED;
    }
    else
    {
        rsp->result = BT_L2CAP_CONN_PARAM_REJECTED;
    }

    bt_l2cap_send(conn, BT_L2CAP_CID_LE_SIG, buf);

    if (accepted)
    {
        bt_conn_le_conn_update(conn, &param);
    }
}

struct bt_l2cap_chan *bt_l2cap_le_lookup_tx_cid(struct bt_conn *conn,
        uint16_t cid)
{
    struct bt_l2cap_chan *chan;

    SYS_SLIST_FOR_EACH_CONTAINER(&conn->channels, chan, node)
    {
        if (BT_L2CAP_LE_CHAN(chan)->tx.cid == cid)
        {
            return chan;
        }
    }

    return NULL;
}

struct bt_l2cap_chan *bt_l2cap_le_lookup_rx_cid(struct bt_conn *conn,
        uint16_t cid)
{
    struct bt_l2cap_chan *chan;

    SYS_SLIST_FOR_EACH_CONTAINER(&conn->channels, chan, node)
    {
        if (BT_L2CAP_LE_CHAN(chan)->rx.cid == cid)
        {
            return chan;
        }
    }

    return NULL;
}

static int l2cap_ble_recv(struct bt_l2cap_chan *chan, struct net_buf *buf)
{
    struct bt_l2cap *l2cap = CONTAINER_OF(chan, struct bt_l2cap, chan);
    struct bt_l2cap_sig_hdr *hdr;
    uint16_t len;

    if (buf->len < sizeof(*hdr))
    {
        BT_ERR("Too small L2CAP signaling PDU");
        return 0;
    }

    hdr = net_buf_pull_mem(buf, sizeof(*hdr));
    len = hdr->len;

    BT_DBG("Signaling code 0x%02x ident %u len %u", hdr->code,
           hdr->ident, len);

    if (buf->len != len)
    {
        BT_ERR("L2CAP length mismatch (%u != %u)", buf->len, len);
        return 0;
    }

    if (!hdr->ident)
    {
        BT_ERR("Invalid ident value in L2CAP PDU");
        return 0;
    }

    switch (hdr->code)
    {
    case BT_L2CAP_CONN_PARAM_RSP:
        l2cap_handle_conn_param_rsp(l2cap, buf);
        break;
#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
    case BT_L2CAP_LE_CONN_REQ:
        le_conn_req(l2cap, hdr->ident, buf);
        break;
    case BT_L2CAP_LE_CONN_RSP:
        le_conn_rsp(l2cap, hdr->ident, buf);
        break;
    case BT_L2CAP_DISCONN_REQ:
        le_disconn_req(l2cap, hdr->ident, buf);
        break;
    case BT_L2CAP_DISCONN_RSP:
        le_disconn_rsp(l2cap, hdr->ident, buf);
        break;
    case BT_L2CAP_LE_CREDITS:
        le_credits(l2cap, hdr->ident, buf);
        break;
    case BT_L2CAP_CMD_REJECT:
        reject_cmd(l2cap, hdr->ident, buf);
        break;
    case BT_L2CAP_ECRED_CONN_REQ:
        le_ecred_conn_req(l2cap, hdr->ident, buf);
        break;
    case BT_L2CAP_ECRED_CONN_RSP:
        le_ecred_conn_rsp(l2cap, hdr->ident, buf);
        break;
    case BT_L2CAP_ECRED_RECONF_REQ:
        le_ecred_reconf_req(l2cap, hdr->ident, buf);
        break;
#else
    case BT_L2CAP_CMD_REJECT:
        /* Ignored */
        break;
#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */
    case BT_L2CAP_CONN_PARAM_REQ:
        if (IS_ENABLED(CONFIG_BT_CENTRAL))
        {
            l2cap_handle_conn_param_update_req(l2cap, hdr->ident, buf);
            break;
        }
        __fallthrough;
    default:
        BT_WARN("Unknown L2CAP PDU code 0x%02x", hdr->code);
        l2cap_send_cmd_reject(chan->conn, hdr->ident,
                              BT_L2CAP_REJ_NOT_UNDERSTOOD, NULL, 0);
        break;
    }

    return 0;
}

#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
static void l2cap_chan_shutdown(struct bt_l2cap_chan *chan)
{
    struct bt_l2cap_le_chan *ch = BT_L2CAP_LE_CHAN(chan);
    struct net_buf *buf;

    BT_DBG("chan %p", chan);

    atomic_set_bit(chan->status, BT_L2CAP_STATUS_SHUTDOWN);

    /* Destroy segmented SDU if it exists */
    if (ch->_sdu)
    {
        net_buf_unref(ch->_sdu);
        ch->_sdu = NULL;
        ch->_sdu_len = 0U;
    }

    /* Cleanup outstanding request */
    if (ch->tx_buf)
    {
        net_buf_unref(ch->tx_buf);
        ch->tx_buf = NULL;
    }

    /* Remove buffers on the TX queue */
    while ((buf = net_buf_get(&ch->tx_queue, K_NO_WAIT)))
    {
        net_buf_unref(buf);
    }

    /* Remove buffers on the RX queue */
    while ((buf = net_buf_get(&ch->rx_queue, K_NO_WAIT)))
    {
        net_buf_unref(buf);
    }

    /* Update status */
    if (chan->ops->status)
    {
        chan->ops->status(chan, chan->status);
    }
}

static void l2cap_chan_send_credits(struct bt_l2cap_le_chan *chan,
                                    struct net_buf *buf, uint16_t credits)
{
    struct bt_l2cap_le_credits *ev;

    /* Cap the number of credits given */
    if (credits > chan->rx.init_credits)
    {
        credits = chan->rx.init_credits;
    }

    buf = l2cap_create_sig_pdu(buf, BT_L2CAP_LE_CREDITS, get_ident(),
                               sizeof(*ev));
    if (!buf)
    {
        BT_ERR("Unable to send credits update");
        /* Disconnect would probably not work either so the only
         * option left is to shutdown the channel.
         */
        l2cap_chan_shutdown(&chan->chan);
        return;
    }

    l2cap_chan_rx_give_credits(chan, credits);

    ev = net_buf_add(buf, sizeof(*ev));
    ev->cid = chan->rx.cid;
    ev->credits = credits;

    bt_l2cap_send(chan->chan.conn, BT_L2CAP_CID_LE_SIG, buf);

    BT_DBG("chan %p credits %u", chan, atomic_get(&chan->rx.credits));
}

static void l2cap_chan_update_credits(struct bt_l2cap_le_chan *chan,
                                      struct net_buf *buf)
{
    uint16_t credits;
    atomic_val_t old_credits = atomic_get(&chan->rx.credits);

    /* Restore enough credits to complete the sdu */
    credits = ((chan->_sdu_len - net_buf_frags_len(buf)) +
               (chan->rx.mps - 1)) / chan->rx.mps;

    if (credits < old_credits)
    {
        return;
    }

    credits -= old_credits;

    l2cap_chan_send_credits(chan, buf, credits);
}

int bt_l2cap_chan_recv_complete(struct bt_l2cap_chan *chan, struct net_buf *buf)
{
    struct bt_l2cap_le_chan *ch = BT_L2CAP_LE_CHAN(chan);
    struct bt_conn *conn = chan->conn;
    uint16_t credits;

    __ASSERT_NO_MSG(chan);
    __ASSERT_NO_MSG(buf);

    if (!conn)
    {
        return -ENOTCONN;
    }

    if (conn->type != BT_CONN_TYPE_LE)
    {
        return -ENOTSUP;
    }

    BT_DBG("chan %p buf %p", chan, buf);

    /* Restore credits used by packet */
    memcpy(&credits, net_buf_user_data(buf), sizeof(credits));

    l2cap_chan_send_credits(ch, buf, credits);

    net_buf_unref(buf);

    return 0;
}

static struct net_buf *l2cap_alloc_frag(k_timeout_t timeout, void *user_data)
{
    struct bt_l2cap_le_chan *chan = user_data;
    struct net_buf *frag = NULL;

    frag = chan->chan.ops->alloc_buf(&chan->chan);
    if (!frag)
    {
        return NULL;
    }

    BT_DBG("frag %p tailroom %zu", frag, net_buf_tailroom(frag));

    return frag;
}

static void l2cap_chan_le_recv_sdu(struct bt_l2cap_le_chan *chan,
                                   struct net_buf *buf, uint16_t seg)
{
    int err;

    BT_DBG("chan %p len %zu", chan, net_buf_frags_len(buf));

    /* Receiving complete SDU, notify channel and reset SDU buf */
    err = chan->chan.ops->recv(&chan->chan, buf);
    if (err < 0)
    {
        if (err != -EINPROGRESS)
        {
            BT_ERR("err %d", err);
            bt_l2cap_chan_disconnect(&chan->chan);
            net_buf_unref(buf);
        }
        return;
    }

    l2cap_chan_send_credits(chan, buf, seg);
    net_buf_unref(buf);
}

static void l2cap_chan_le_recv_seg(struct bt_l2cap_le_chan *chan,
                                   struct net_buf *buf)
{
    uint16_t len;
    uint16_t seg = 0U;

    len = net_buf_frags_len(chan->_sdu);
    if (len)
    {
        memcpy(&seg, net_buf_user_data(chan->_sdu), sizeof(seg));
    }

    if (len + buf->len > chan->_sdu_len)
    {
        BT_ERR("SDU length mismatch");
        bt_l2cap_chan_disconnect(&chan->chan);
        return;
    }

    seg++;
    /* Store received segments in user_data */
    memcpy(net_buf_user_data(chan->_sdu), &seg, sizeof(seg));

    BT_DBG("chan %p seg %d len %zu", chan, seg, net_buf_frags_len(buf));

    /* Append received segment to SDU */
    len = net_buf_append_bytes(chan->_sdu, buf->len, buf->data, K_NO_WAIT,
                               l2cap_alloc_frag, chan);
    if (len != buf->len)
    {
        BT_ERR("Unable to store SDU");
        bt_l2cap_chan_disconnect(&chan->chan);
        return;
    }

    if (net_buf_frags_len(chan->_sdu) < chan->_sdu_len)
    {
        /* Give more credits if remote has run out of them, this
         * should only happen if the remote cannot fully utilize the
         * MPS for some reason.
         */
        if (!atomic_get(&chan->rx.credits) &&
                seg == chan->rx.init_credits)
        {
            l2cap_chan_update_credits(chan, buf);
        }
        return;
    }

    buf = chan->_sdu;
    chan->_sdu = NULL;
    chan->_sdu_len = 0U;

    l2cap_chan_le_recv_sdu(chan, buf, seg);
}

static void l2cap_chan_le_recv(struct bt_l2cap_le_chan *chan,
                               struct net_buf *buf)
{
    uint16_t sdu_len;
    int err;

    if (!test_and_dec(&chan->rx.credits))
    {
        BT_ERR("No credits to receive packet");
        bt_l2cap_chan_disconnect(&chan->chan);
        return;
    }

    /* Check if segments already exist */
    if (chan->_sdu)
    {
        l2cap_chan_le_recv_seg(chan, buf);
        return;
    }

    sdu_len = net_buf_pull_le16(buf);

    BT_DBG("chan %p len %u sdu_len %u", chan, buf->len, sdu_len);

    if (sdu_len > chan->rx.mtu)
    {
        BT_ERR("Invalid SDU length");
        bt_l2cap_chan_disconnect(&chan->chan);
        return;
    }

    /* Always allocate buffer from the channel if supported. */
    if (chan->chan.ops->alloc_buf)
    {
        chan->_sdu = chan->chan.ops->alloc_buf(&chan->chan);
        if (!chan->_sdu)
        {
            BT_ERR("Unable to allocate buffer for SDU");
            bt_l2cap_chan_disconnect(&chan->chan);
            return;
        }
        chan->_sdu_len = sdu_len;
        l2cap_chan_le_recv_seg(chan, buf);
        return;
    }

    err = chan->chan.ops->recv(&chan->chan, buf);
    if (err)
    {
        if (err != -EINPROGRESS)
        {
            BT_ERR("err %d", err);
            bt_l2cap_chan_disconnect(&chan->chan);
        }
        return;
    }

    l2cap_chan_send_credits(chan, buf, 1);
}

static void l2cap_chan_recv_queue(struct bt_l2cap_le_chan *chan,
                                  struct net_buf *buf)
{
    if (chan->chan.state == BT_L2CAP_DISCONNECT)
    {
        BT_WARN("Ignoring data received while disconnecting");
        net_buf_unref(buf);
        return;
    }

    if (atomic_test_bit(chan->chan.status, BT_L2CAP_STATUS_SHUTDOWN))
    {
        BT_WARN("Ignoring data received while channel has shutdown");
        net_buf_unref(buf);
        return;
    }

    if (!L2CAP_LE_PSM_IS_DYN(chan->chan.psm))
    {
        l2cap_chan_le_recv(chan, buf);
        net_buf_unref(buf);
        return;
    }

    net_buf_put(&chan->rx_queue, buf);
}
#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */

static void l2cap_chan_recv(struct bt_l2cap_chan *chan, struct net_buf *buf)
{
#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
    struct bt_l2cap_le_chan *ch = BT_L2CAP_LE_CHAN(chan);

    if (L2CAP_LE_CID_IS_DYN(ch->rx.cid))
    {
        l2cap_chan_recv_queue(ch, buf);
        return;
    }
#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */

    BT_DBG("chan %p len %u", chan, buf->len);

    chan->ops->recv(chan, buf);
    net_buf_unref(buf);
}

void bt_l2cap_recv(struct bt_conn *conn, struct net_buf *buf)
{
    struct bt_l2cap_hdr *hdr;
    struct bt_l2cap_chan *chan;
    uint16_t cid;

    if (buf->len < sizeof(*hdr))
    {
        BT_ERR("Too small L2CAP PDU received");
        net_buf_unref(buf);
        return;
    }

    hdr = net_buf_pull_mem(buf, sizeof(*hdr));
    cid = hdr->cid;

    BT_DBG("Packet for CID %u len %u", cid, buf->len);

    chan = bt_l2cap_le_lookup_rx_cid(conn, cid);
    if (!chan)
    {
        BT_WARN("Ignoring data for unknown CID 0x%04x", cid);
        net_buf_unref(buf);
        return;
    }

    l2cap_chan_recv(chan, buf);
}

int bt_l2cap_update_conn_param(struct bt_conn *conn,
                               const struct bt_le_conn_param *param)
{
    struct bt_l2cap_conn_param_req *req;
    struct net_buf *buf;

    buf = l2cap_create_sig_pdu(NULL, BT_L2CAP_CONN_PARAM_REQ,
                               get_ident(), sizeof(*req));
    if (!buf)
    {
        return -ENOMEM;
    }

    req = net_buf_add(buf, sizeof(*req));
    req->min_interval = param->interval_min;
    req->max_interval = param->interval_max;
    req->latency = param->latency;
    req->timeout = param->timeout;

    bt_l2cap_send(conn, BT_L2CAP_CID_LE_SIG, buf);

    return 0;
}

static void l2cap_ble_connected(struct bt_l2cap_chan *chan)
{
    BT_DBG("ch %p cid 0x%04x", BT_L2CAP_LE_CHAN(chan),
           BT_L2CAP_LE_CHAN(chan)->rx.cid);
}

static void l2cap_ble_disconnected(struct bt_l2cap_chan *chan)
{
    BT_DBG("ch %p cid 0x%04x", BT_L2CAP_LE_CHAN(chan),
           BT_L2CAP_LE_CHAN(chan)->rx.cid);
}

static int l2cap_ble_accept(struct bt_conn *conn, struct bt_l2cap_chan **chan)
{
    int i;
    static const struct bt_l2cap_chan_ops ops =
    {
        .connected = l2cap_ble_connected,
        .disconnected = l2cap_ble_disconnected,
        .recv = l2cap_ble_recv,
    };

    BT_DBG("l2cap_accept, conn %p handle %u", conn, conn->handle);

    for (i = 0; i < ARRAY_SIZE(bt_l2cap_pool); i++)
    {
        struct bt_l2cap *l2cap = &bt_l2cap_pool[i];

        if (l2cap->chan.chan.conn)
        {
            continue;
        }

        l2cap->chan.chan.ops = &ops;
        *chan = &l2cap->chan.chan;

        return 0;
    }

    BT_ERR("No available L2CAP context for conn %p", conn);

    return -ENOMEM;
}

BT_L2CAP_CHANNEL_DEFINE_NEW(le_fixed_chan, BT_L2CAP_CID_LE_SIG, l2cap_ble_accept, NULL);


void bt_l2cap_init(void)
{
#if defined(CONFIG_BT_BREDR)
    bt_l2cap_br_init();
#endif
}

#if defined(CONFIG_BT_L2CAP_DYNAMIC_CHANNEL)
static int l2cap_le_connect(struct bt_conn *conn, struct bt_l2cap_le_chan *ch,
                            uint16_t psm)
{
    int err;

    if (psm < L2CAP_LE_PSM_FIXED_START || psm > L2CAP_LE_PSM_DYN_END)
    {
        return -EINVAL;
    }

    l2cap_chan_tx_init(ch);
    l2cap_chan_rx_init(ch);

    if (!l2cap_chan_add(conn, &ch->chan, l2cap_chan_destroy))
    {
        return -ENOMEM;
    }

    ch->chan.psm = psm;

    if (conn->sec_level < ch->chan.required_sec_level)
    {
        err = bt_conn_set_security(conn, ch->chan.required_sec_level);
        if (err)
        {
            goto fail;
        }

        atomic_set_bit(ch->chan.status,
                       BT_L2CAP_STATUS_ENCRYPT_PENDING);

        return 0;
    }

    err = l2cap_le_conn_req(ch);
    if (err)
    {
        goto fail;
    }

    return 0;

fail:
    bt_l2cap_chan_remove(conn, &ch->chan);
    bt_l2cap_chan_del(&ch->chan);
    return err;
}

static int l2cap_ecred_init(struct bt_conn *conn,
                            struct bt_l2cap_le_chan *ch, uint16_t psm)
{

    if (psm < L2CAP_LE_PSM_FIXED_START || psm > L2CAP_LE_PSM_DYN_END)
    {
        return -EINVAL;
    }

    l2cap_chan_tx_init(ch);
    l2cap_chan_rx_init(ch);

    if (!l2cap_chan_add(conn, &ch->chan, l2cap_chan_destroy))
    {
        return -ENOMEM;
    }

    ch->chan.psm = psm;

    BT_DBG("ch %p psm 0x%02x mtu %u mps %u credits %u", ch, ch->chan.psm,
           ch->rx.mtu, ch->rx.mps, ch->rx.init_credits);

    return 0;
}

int bt_l2cap_ecred_chan_connect(struct bt_conn *conn,
                                struct bt_l2cap_chan **chan, uint16_t psm)
{
    int i, err;

    BT_DBG("conn %p chan %p psm 0x%04x", conn, chan, psm);

    if (!conn || !chan)
    {
        return -EINVAL;
    }

    /* Init non-null channels */
    for (i = 0; i < L2CAP_ECRED_CHAN_MAX; i++)
    {
        if (!chan[i])
        {
            break;
        }

        err = l2cap_ecred_init(conn, BT_L2CAP_LE_CHAN(chan[i]), psm);
        if (err < 0)
        {
            i--;
            goto fail;
        }
    }

    return l2cap_ecred_conn_req(chan, i);
fail:
    /* Remove channels added */
    for (; i >= 0; i--)
    {
        if (!chan[i])
        {
            continue;
        }

        bt_l2cap_chan_remove(conn, chan[i]);
    }

    return err;
}

int bt_l2cap_chan_connect(struct bt_conn *conn, struct bt_l2cap_chan *chan,
                          uint16_t psm)
{
    BT_DBG("conn %p chan %p psm 0x%04x", conn, chan, psm);

    if (!conn || conn->state != BT_CONN_CONNECTED)
    {
        return -ENOTCONN;
    }

    if (!chan)
    {
        return -EINVAL;
    }

    if (IS_ENABLED(CONFIG_BT_BREDR) &&
            conn->type == BT_CONN_TYPE_BR)
    {
        return bt_l2cap_br_chan_connect(conn, chan, psm);
    }

    if (chan->required_sec_level > BT_SECURITY_L4)
    {
        return -EINVAL;
    }
    else if (chan->required_sec_level == BT_SECURITY_L0)
    {
        chan->required_sec_level = BT_SECURITY_L1;
    }

    return l2cap_le_connect(conn, BT_L2CAP_LE_CHAN(chan), psm);
}

int bt_l2cap_chan_disconnect(struct bt_l2cap_chan *chan)
{
    struct bt_conn *conn = chan->conn;
    struct net_buf *buf;
    struct bt_l2cap_disconn_req *req;
    struct bt_l2cap_le_chan *ch;

    if (!conn)
    {
        return -ENOTCONN;
    }

    if (IS_ENABLED(CONFIG_BT_BREDR) &&
            conn->type == BT_CONN_TYPE_BR)
    {
        return bt_l2cap_br_chan_disconnect(chan);
    }

    ch = BT_L2CAP_LE_CHAN(chan);

    BT_DBG("chan %p scid 0x%04x dcid 0x%04x", chan, ch->rx.cid,
           ch->tx.cid);

    ch->chan.ident = get_ident();

    buf = l2cap_create_sig_pdu(NULL, BT_L2CAP_DISCONN_REQ,
                               ch->chan.ident, sizeof(*req));
    if (!buf)
    {
        return -ENOMEM;
    }

    req = net_buf_add(buf, sizeof(*req));
    req->dcid = ch->rx.cid;
    req->scid = ch->tx.cid;

    l2cap_chan_send_req(chan, buf, L2CAP_DISC_TIMEOUT);
    bt_l2cap_chan_set_state(chan, BT_L2CAP_DISCONNECT);

    return 0;
}

int bt_l2cap_chan_send(struct bt_l2cap_chan *chan, struct net_buf *buf)
{
    struct bt_l2cap_le_chan *ch = BT_L2CAP_LE_CHAN(chan);
    int err;

    if (!buf)
    {
        return -EINVAL;
    }

    BT_DBG("chan %p buf %p len %zu", chan, buf, net_buf_frags_len(buf));

    if (!chan->conn || chan->conn->state != BT_CONN_CONNECTED)
    {
        return -ENOTCONN;
    }

    if (atomic_test_bit(chan->status, BT_L2CAP_STATUS_SHUTDOWN))
    {
        return -ESHUTDOWN;
    }

    if (IS_ENABLED(CONFIG_BT_BREDR) &&
            chan->conn->type == BT_CONN_TYPE_BR)
    {
        return bt_l2cap_br_chan_send(chan, buf);
    }

    /* Queue if there are pending segments left from previous packet or
     * there are no credits available.
     */
    if (ch->tx_buf || !sys_sflist_is_empty(&ch->tx_queue) ||
            !atomic_get(&ch->tx.credits))
    {
        data_sent(buf)->len = 0;
        net_buf_put(&ch->tx_queue, buf);
        return 0;
    }

    err = l2cap_chan_le_send_sdu(ch, &buf, 0);
    if (err < 0)
    {
        if (err == -EAGAIN && data_sent(buf)->len)
        {
            /* Queue buffer if at least one segment could be sent */
            net_buf_put(&ch->tx_queue, buf);
            return data_sent(buf)->len;
        }
        BT_ERR("failed to send message %d", err);
    }

    return err;
}
#endif /* CONFIG_BT_L2CAP_DYNAMIC_CHANNEL */
