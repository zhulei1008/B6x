/* hci_core.c - HCI core Bluetooth handling */

/*
 * Copyright (c) 2017 Nordic Semiconductor ASA
 * Copyright (c) 2015-2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <base/atomic.h>
#include <base/common.h>
#include <utils/slist.h>
#include <base/byteorder.h>
#include <base/__assert.h>


#include <bluetooth/bluetooth.h>
#include <bluetooth/conn.h>
#include <bluetooth/l2cap.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_vs.h>
#include <drivers/hci_driver.h>

#define BT_DBG_ENABLED IS_ENABLED(CONFIG_BT_DEBUG_HCI_CORE)
#define LOG_MODULE_NAME bt_hci_core
#include "logging/bt_log.h"

#include "common/rpa.h"
#include "keys.h"
#include "hci_core.h"
#include "hci_ecc.h"
#include "ecc.h"

#include "conn_internal.h"
#include "l2cap_internal.h"
#include "gatt_internal.h"
#include "smp.h"
#include "crypto.h"

#include "yc_debug.h"

static int hci_send_cmd_le_set_event_mask(void);
static int hci_send_cmd_set_event_mask(void);


/* Peripheral timeout to initialize Connection Parameter Update procedure */
#define CONN_UPDATE_TIMEOUT    (CONFIG_BT_CONN_PARAM_UPDATE_TIMEOUT)
#define RPA_TIMEOUT_MS       (CONFIG_BT_RPA_TIMEOUT * MSEC_PER_SEC)
#define RPA_TIMEOUT          (RPA_TIMEOUT_MS)

#define HCI_CMD_TIMEOUT      (10)

struct bt_dev bt_dev_set;

static bt_ready_cb_t ready_cb;

static bt_le_scan_cb_t *scan_dev_found_cb;

#if defined(CONFIG_BT_OBSERVER)
static int set_le_scan_enable(uint8_t enable);
static sys_slist_t scan_cbs = SYS_SLIST_STATIC_INIT(&scan_cbs);
#endif /* defined(CONFIG_BT_OBSERVER) */

struct event_handler
{
    uint8_t event;
    uint8_t min_len;
    void (*handler)(struct net_buf *buf);
};

#define EVENT_HANDLER(_evt, _handler, _min_len) \
{ \
	.event = _evt, \
	.handler = _handler, \
	.min_len = _min_len, \
}

static inline void handle_event(uint8_t event, struct net_buf *buf,
                                const struct event_handler *handlers,
                                size_t num_handlers)
{
    size_t i;

    for (i = 0; i < num_handlers; i++)
    {
        const struct event_handler *handler = &handlers[i];

        if (handler->event != event)
        {
            continue;
        }

        if (buf->len < handler->min_len)
        {
            BT_ERR("Too small (%u bytes) event 0x%02x",
                   buf->len, event);
            return;
        }

        handler->handler(buf);
        return;
    }

    BT_WARN("Unhandled event 0x%02x len %u: %s", event,
            buf->len, bt_hex(buf->data, buf->len));
}


struct net_buf *bt_hci_cmd_create(uint16_t opcode, uint8_t param_len)
{
    struct bt_hci_cmd_hdr *hdr;
    struct net_buf *buf;

    BT_DBG("opcode 0x%04x param_len %u", opcode, param_len);

    buf = bt_buf_get_host_tx_cmd();

    hdr = net_buf_add(buf, sizeof(*hdr));
    hdr->opcode = opcode;
    hdr->param_len = param_len;

    return buf;
}

int bt_hci_cmd_send(uint16_t opcode, struct net_buf *buf)
{
    if (!buf)
    {
        buf = bt_hci_cmd_create(opcode, 0);
        if (!buf)
        {
            return -ENOBUFS;
        }
    }

    BT_DBG("opcode 0x%04x len %u", opcode, buf->len);

    net_buf_put(&bt_dev_set.cmd_tx_queue, buf);

    return 0;
}

int bt_hci_cmd_send_sync(uint16_t opcode, struct net_buf *buf,
                         struct net_buf **rsp)
{
    BT_ERR("bt_hci_cmd_send_sync, work err. 0x%x",
           opcode);
    while(1);

    return 0;
}

#if defined(CONFIG_BT_OBSERVER) || defined(CONFIG_BT_BROADCASTER)
const bt_addr_le_t *bt_lookup_id_addr(uint8_t id, const bt_addr_le_t *addr)
{
#ifdef CONFIG_BT_SMP
    if (IS_ENABLED(CONFIG_BT_SMP))
    {
        struct bt_keys *keys;

        keys = bt_keys_find_irk(id, addr);
        if (keys)
        {
            BT_DBG("Identity %s matched RPA %s",
                   bt_addr_le_str(&keys->addr),
                   bt_addr_le_str(addr));
            return &keys->addr;
        }
    }
#endif

    return addr;
}
#endif /* CONFIG_BT_OBSERVER || CONFIG_BT_CONN */

static void bt_adv_foreach(void (*func)(struct bt_le_ext_adv *adv, void *data),
                           void *data)
{
    func(&bt_dev_set.adv, data);
}

static struct bt_le_ext_adv *adv_new_legacy(void)
{
    return &bt_dev_set.adv;
}

static void adv_delete_legacy(void)
{
}

struct bt_le_ext_adv *bt_adv_lookup_legacy(void)
{
    return &bt_dev_set.adv;
}

static int hci_send_cmd_le_set_adv_enable(struct bt_le_ext_adv *adv, bool enable)
{
    struct net_buf *buf;
    int err;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_ADV_ENABLE, 1);
    if (!buf)
    {
        return -ENOBUFS;
    }

    if (enable)
    {
        net_buf_add_u8(buf, BT_HCI_LE_ADV_ENABLE);
    }
    else
    {
        net_buf_add_u8(buf, BT_HCI_LE_ADV_DISABLE);
    }

    if(enable)
    {
        atomic_set_bit(adv->flags, BT_ADV_ENABLED);
    }
    else
    {
        atomic_clear_bit(adv->flags, BT_ADV_ENABLED);
    }

    err = bt_hci_cmd_send(BT_HCI_OP_LE_SET_ADV_ENABLE, buf);
    if (err)
    {
        return err;
    }

    return 0;
}

static int hci_send_cmd_le_set_random_address(const bt_addr_t *addr)
{
    struct net_buf *buf;
    int err;

    BT_DBG("%s", bt_addr_str(addr));

    /* Do nothing if we already have the right address */
    if (!bt_addr_cmp(addr, &bt_dev_set.random_addr.a))
    {
        return 0;
    }

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_RANDOM_ADDRESS, sizeof(*addr));
    if (!buf)
    {
        return -ENOBUFS;
    }

    net_buf_add_mem(buf, addr, sizeof(*addr));

    err = bt_hci_cmd_send(BT_HCI_OP_LE_SET_RANDOM_ADDRESS, buf);
    if (err)
    {
        return err;
    }

    bt_addr_copy(&bt_dev_set.random_addr.a, addr);
    bt_dev_set.random_addr.type = BT_ADDR_LE_RANDOM;
    return 0;
}

static int hci_set_le_adv_enable(struct bt_le_ext_adv *adv, bool enable)
{
    return hci_send_cmd_le_set_adv_enable(adv, enable);
}

static int hci_send_cmd_le_set_adv_random_address(struct bt_le_ext_adv *adv,
        const bt_addr_t *addr)
{
    struct bt_hci_cp_le_set_adv_set_random_addr *cp;
    struct net_buf *buf;
    int err;

    BT_DBG("%s", bt_addr_str(addr));

    if (!atomic_test_bit(adv->flags, BT_ADV_PARAMS_SET))
    {
        bt_addr_copy(&adv->random_addr.a, addr);
        adv->random_addr.type = BT_ADDR_LE_RANDOM;
        atomic_set_bit(adv->flags, BT_ADV_RANDOM_ADDR_PENDING);
        return 0;
    }

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_ADV_SET_RANDOM_ADDR,
                            sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));

    cp->handle = adv->handle;
    bt_addr_copy(&cp->bdaddr, addr);

    err = bt_hci_cmd_send(BT_HCI_OP_LE_SET_ADV_SET_RANDOM_ADDR, buf);
    if (err)
    {
        return err;
    }

    bt_addr_copy(&adv->random_addr.a, addr);
    adv->random_addr.type = BT_ADDR_LE_RANDOM;
    return 0;
}

int bt_addr_from_str(const char *str, bt_addr_t *addr)
{
    int i, j;
    uint8_t tmp;

    if (strlen(str) != 17U)
    {
        return -EINVAL;
    }

    for (i = 5, j = 1; *str != '\0'; str++, j++)
    {
        if (!(j % 3) && (*str != ':'))
        {
            return -EINVAL;
        }
        else if (*str == ':')
        {
            i--;
            continue;
        }

        addr->val[i] = addr->val[i] << 4;

        if (char2hex(*str, &tmp) < 0)
        {
            return -EINVAL;
        }

        addr->val[i] |= tmp;
    }

    return 0;
}

int bt_addr_le_from_str(const char *str, const char *type, bt_addr_le_t *addr)
{
    int err;

    err = bt_addr_from_str(str, &addr->a);
    if (err < 0)
    {
        return err;
    }

    if (!strcmp(type, "public") || !strcmp(type, "(public)"))
    {
        addr->type = BT_ADDR_LE_PUBLIC;
    }
    else if (!strcmp(type, "random") || !strcmp(type, "(random)"))
    {
        addr->type = BT_ADDR_LE_RANDOM;
    }
    else if (!strcmp(type, "public-id") || !strcmp(type, "(public-id)"))
    {
        addr->type = BT_ADDR_LE_PUBLIC_ID;
    }
    else if (!strcmp(type, "random-id") || !strcmp(type, "(random-id)"))
    {
        addr->type = BT_ADDR_LE_RANDOM_ID;
    }
    else
    {
        return -EINVAL;
    }

    return 0;
}

static int le_set_private_addr(uint8_t id)
{
    bt_addr_t nrpa;
    int err;

    err = bt_rand(nrpa.val, sizeof(nrpa.val));
    if (err)
    {
        return err;
    }

    nrpa.val[5] &= 0x3f;

    return hci_send_cmd_le_set_random_address(&nrpa);
}

static int le_adv_set_private_addr(struct bt_le_ext_adv *adv)
{
    bt_addr_t nrpa;
    int err;

    err = bt_rand(nrpa.val, sizeof(nrpa.val));
    if (err)
    {
        return err;
    }

    nrpa.val[5] &= 0x3f;

    return hci_send_cmd_le_set_adv_random_address(adv, &nrpa);
}

struct adv_id_check_data
{
    uint8_t id;
    bool adv_enabled;
};

static void adv_id_check_func(struct bt_le_ext_adv *adv, void *data)
{
    struct adv_id_check_data *check_data = data;

    if (check_data->id == adv->id &&
            atomic_test_bit(adv->flags, BT_ADV_ENABLED))
    {
        check_data->adv_enabled = true;
    }

}

static void adv_id_check_connectable_func(struct bt_le_ext_adv *adv, void *data)
{
    struct adv_id_check_data *check_data = data;

    if (atomic_test_bit(adv->flags, BT_ADV_ENABLED) &&
            atomic_test_bit(adv->flags, BT_ADV_CONNECTABLE) &&
            check_data->id != adv->id)
    {
        check_data->adv_enabled = true;
    }
}


#if defined(CONFIG_BT_OBSERVER)
static int hci_send_cmd_le_set_scan_enable(uint8_t enable)
{
    struct bt_hci_cp_le_set_scan_enable *cp;
    struct net_buf *buf;
    int err;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_SCAN_ENABLE, sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));

    if (enable == BT_HCI_LE_SCAN_ENABLE)
    {
        cp->filter_dup = atomic_test_bit(bt_dev_set.flags,
                                         BT_DEV_SCAN_FILTER_DUP);
    }
    else
    {
        cp->filter_dup = BT_HCI_LE_SCAN_FILTER_DUP_DISABLE;
    }

    cp->enable = enable;

    if(enable == BT_HCI_LE_SCAN_ENABLE)
    {
        atomic_set_bit(bt_dev_set.flags, BT_DEV_SCANNING);
    }
    else
    {
        atomic_clear_bit(bt_dev_set.flags, BT_DEV_SCANNING);
    }

    err = bt_hci_cmd_send(BT_HCI_OP_LE_SET_SCAN_ENABLE, buf);
    if (err)
    {
        return err;
    }

    return 0;
}

static int set_le_scan_enable(uint8_t enable)
{
    return hci_send_cmd_le_set_scan_enable(enable);
}
#endif /* CONFIG_BT_OBSERVER */

static int hci_send_cmd_le_read_max_data_len(uint16_t *tx_octets, uint16_t *tx_time)
{
    struct bt_hci_rp_le_read_max_data_len *rp;
    struct net_buf *rsp;
    int err;

    err = bt_hci_cmd_send_sync(BT_HCI_OP_LE_READ_MAX_DATA_LEN, NULL, &rsp);
    if (err)
    {
        BT_ERR("Failed to read DLE max data len");
        return err;
    }

    rp = (void *)rsp->data;
    *tx_octets = rp->max_tx_octets;
    *tx_time = rp->max_tx_time;
    net_buf_unref(rsp);

    return 0;
}

#if (defined(CONFIG_BT_OBSERVER) && defined(CONFIG_BT_EXT_ADV)) \
	|| defined(CONFIG_BT_USER_PHY_UPDATE)
static uint8_t get_phy(uint8_t hci_phy)
{
    switch (hci_phy)
    {
    case BT_HCI_LE_PHY_1M:
        return BT_GAP_LE_PHY_1M;
    case BT_HCI_LE_PHY_2M:
        return BT_GAP_LE_PHY_2M;
    case BT_HCI_LE_PHY_CODED:
        return BT_GAP_LE_PHY_CODED;
    default:
        return 0;
    }
}
#endif /* (BT_OBSERVER && BT_EXT_ADV) || USER_PHY_UPDATE */

#if defined(CONFIG_BT_CONN)
static void hci_handle_acl(struct net_buf *buf)
{
    struct bt_hci_acl_hdr *hdr;
    uint16_t handle, len;
    struct bt_conn *conn;
    uint8_t flags;

    BT_DBG("buf %p", buf);

    BT_ASSERT(buf->len >= sizeof(*hdr));

    hdr = net_buf_pull_mem(buf, sizeof(*hdr));
    len = hdr->len;
    handle = hdr->handle;
    flags = bt_acl_flags(handle);

    BT_DBG("handle %u len %u flags %u", handle, len, flags);

    if (buf->len != len)
    {
        BT_ERR("ACL data length mismatch (%u != %u)", buf->len, len);
        net_buf_unref(buf);
        return;
    }

    conn = bt_conn_lookup_handle(bt_acl_handle(handle));
    if (!conn)
    {
        return;
    }

    bt_conn_recv(conn, buf, flags);
}

static void hci_handle_evt_data_buf_overflow(struct net_buf *buf)
{
    struct bt_hci_evt_data_buf_overflow *evt = (void *)buf->data;

    BT_WARN("Data buffer overflow (link type 0x%02x)", evt->link_type);
}

static void hci_handle_evt_num_completed_packets(struct net_buf *buf)
{
    struct bt_hci_evt_num_completed_packets *evt = (void *)buf->data;
    int i;

    BT_DBG("num_handles %u", evt->num_handles);

    for (i = 0; i < evt->num_handles; i++)
    {
        uint16_t handle, count;
        struct bt_conn *conn;

        handle = evt->h[i].handle;
        count = evt->h[i].count;

        BT_DBG("handle %u count %u", handle, count);

        conn = bt_conn_lookup_handle(handle);
        if (!conn)
        {
            BT_ERR("No connection for handle %u", handle);
            continue;
        }

        while (count--)
        {
            struct bt_conn_tx *tx;
            sys_snode_t *node;

            node = sys_slist_get(&conn->tx_pending);

            if (!node)
            {
                BT_ERR("packets count mismatch");
                break;
            }

            tx = CONTAINER_OF(node, struct bt_conn_tx, node);

            sys_slist_append(&conn->tx_complete, &tx->node);
        }
    }
}

#if defined(CONFIG_BT_CENTRAL)
static int le_create_conn_set_random_addr(bool use_filter, uint8_t *own_addr_type)
{
    int err;

    const bt_addr_le_t *addr = &bt_dev_set.id_addr[BT_ID_DEFAULT];

    /* If Static Random address is used as Identity address we
     * need to restore it before creating connection. Otherwise
     * NRPA used for active scan could be used for connection.
     */
    if (addr->type == BT_ADDR_LE_RANDOM)
    {
        err = hci_send_cmd_le_set_random_address(&addr->a);
        if (err)
        {
            return err;
        }
    }

    *own_addr_type = addr->type;

    return 0;
}

static void set_phy_conn_param(const struct bt_conn *conn,
                               struct bt_hci_ext_conn_phy *phy)
{
    phy->conn_interval_min = conn->le.interval_min;
    phy->conn_interval_max = conn->le.interval_max;
    phy->conn_latency = conn->le.latency;
    phy->supervision_timeout = conn->le.timeout;

    phy->min_ce_len = 0;
    phy->max_ce_len = 0;
}
#if 0
int bt_le_create_conn_ext(const struct bt_conn *conn)
{
    struct bt_hci_cp_le_ext_create_conn *cp;
    struct bt_hci_ext_conn_phy *phy;
    struct cmd_state_set state;
    bool use_filter = false;
    struct net_buf *buf;
    uint8_t own_addr_type;
    uint8_t num_phys;
    int err;

    err = le_create_conn_set_random_addr(use_filter, &own_addr_type);
    if (err)
    {
        return err;
    }

    num_phys = (!(bt_dev_set.create_param.options &
                  BT_CONN_LE_OPT_NO_1M) ? 1 : 0) +
               ((bt_dev_set.create_param.options &
                 BT_CONN_LE_OPT_CODED) ? 1 : 0);

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_EXT_CREATE_CONN, sizeof(*cp) +
                            num_phys * sizeof(*phy));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    (void)memset(cp, 0, sizeof(*cp));

    if (use_filter)
    {
        /* User Initiated procedure use fast scan parameters. */
        bt_addr_le_copy(&cp->peer_addr, BT_ADDR_LE_ANY);
        cp->filter_policy = BT_HCI_LE_CREATE_CONN_FP_WHITELIST;
    }
    else
    {
        const bt_addr_le_t *peer_addr = &conn->le.dst;

#if defined(CONFIG_BT_SMP)
        if (!bt_dev_set.le.rl_size ||
                bt_dev_set.le.rl_entries > bt_dev_set.le.rl_size)
        {
            /* Host resolving is used, use the RPA directly. */
            peer_addr = &conn->le.resp_addr;
        }
#endif
        bt_addr_le_copy(&cp->peer_addr, peer_addr);
        cp->filter_policy = BT_HCI_LE_CREATE_CONN_FP_DIRECT;
    }

    cp->own_addr_type = own_addr_type;
    cp->phys = 0;

    if (!(bt_dev_set.create_param.options & BT_CONN_LE_OPT_NO_1M))
    {
        cp->phys |= BT_HCI_LE_EXT_SCAN_PHY_1M;
        phy = net_buf_add(buf, sizeof(*phy));
        phy->scan_interval = sys_cpu_to_le16(
                                 bt_dev_set.create_param.interval);
        phy->scan_window = sys_cpu_to_le16(
                               bt_dev_set.create_param.window);
        set_phy_conn_param(conn, phy);
    }

    if (bt_dev_set.create_param.options & BT_CONN_LE_OPT_CODED)
    {
        cp->phys |= BT_HCI_LE_EXT_SCAN_PHY_CODED;
        phy = net_buf_add(buf, sizeof(*phy));
        phy->scan_interval = sys_cpu_to_le16(
                                 bt_dev_set.create_param.interval_coded);
        phy->scan_window = sys_cpu_to_le16(
                               bt_dev_set.create_param.window_coded);
        set_phy_conn_param(conn, phy);
    }

    //cmd_state_set_init(&state, bt_dev_set.flags, BT_DEV_INITIATING, true);
    //cmd(buf)->state = &state;
    atomic_set_bit(bt_dev_set.flags, BT_DEV_INITIATING);

    return bt_hci_cmd_send(BT_HCI_OP_LE_EXT_CREATE_CONN, buf, NULL);
}
#endif
int hci_send_cmd_le_create_conn(const struct bt_conn *conn)
{
    struct bt_hci_cp_le_create_conn *cp;
    bool use_filter = false;
    struct net_buf *buf;
    uint8_t own_addr_type;
    int err;

    err = le_create_conn_set_random_addr(use_filter, &own_addr_type);
    if (err)
    {
        return err;
    }

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_CREATE_CONN, sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    memset(cp, 0, sizeof(*cp));
    cp->own_addr_type = own_addr_type;

    if (use_filter)
    {
        /* User Initiated procedure use fast scan parameters. */
        bt_addr_le_copy(&cp->peer_addr, BT_ADDR_LE_ANY);
        cp->filter_policy = BT_HCI_LE_CREATE_CONN_FP_WHITELIST;
    }
    else
    {
        const bt_addr_le_t *peer_addr = &conn->le.dst;
#if 0
#if defined(CONFIG_BT_SMP)
        if (!bt_dev_set.le.rl_size ||
                bt_dev_set.le.rl_entries > bt_dev_set.le.rl_size)
        {
            /* Host resolving is used, use the RPA directly. */
            peer_addr = &conn->le.resp_addr;
        }
#endif
#endif
        bt_addr_le_copy(&cp->peer_addr, peer_addr);
        cp->filter_policy = BT_HCI_LE_CREATE_CONN_FP_DIRECT;
    }

    cp->scan_interval = bt_dev_set.create_param.interval;
    cp->scan_window = bt_dev_set.create_param.window;

    cp->conn_interval_min = conn->le.interval_min;
    cp->conn_interval_max = conn->le.interval_max;
    cp->conn_latency = conn->le.latency;
    cp->supervision_timeout = conn->le.timeout;

    atomic_set_bit(bt_dev_set.flags, BT_DEV_INITIATING);

    return bt_hci_cmd_send(BT_HCI_OP_LE_CREATE_CONN, buf);
}

int bt_le_create_conn(const struct bt_conn *conn)
{
    return hci_send_cmd_le_create_conn(conn);
}

int hci_send_cmd_le_create_conn_cancel(void)
{
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_CREATE_CONN_CANCEL, 0);

    atomic_clear_bit(bt_dev_set.flags, BT_DEV_INITIATING);

    return bt_hci_cmd_send(BT_HCI_OP_LE_CREATE_CONN_CANCEL, buf);
}
#endif /* CONFIG_BT_CENTRAL */

int hci_send_cmd_disconnect(uint16_t handle, uint8_t reason)
{
    struct net_buf *buf;
    struct bt_hci_cp_disconnect *disconn;

    buf = bt_hci_cmd_create(BT_HCI_OP_DISCONNECT, sizeof(*disconn));
    if (!buf)
    {
        return -ENOBUFS;
    }

    disconn = net_buf_add(buf, sizeof(*disconn));
    disconn->handle = handle;
    disconn->reason = reason;

    return bt_hci_cmd_send(BT_HCI_OP_DISCONNECT, buf);
}

static void hci_handle_evt_disconnect_complete_prio(struct net_buf *buf)
{
    struct bt_hci_evt_disconn_complete *evt = (void *)buf->data;
    uint16_t handle = evt->handle;
    struct bt_conn *conn;

    BT_DBG("status 0x%02x handle %u reason 0x%02x", evt->status, handle,
           evt->reason);

    if (evt->status)
    {
        return;
    }

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to look up conn with handle %u", handle);
        return;
    }

    bt_conn_set_state(conn, BT_CONN_DISCONNECT_COMPLETE);
}

static void hci_handle_evt_disconnect_complete(struct net_buf *buf)
{
    struct bt_hci_evt_disconn_complete *evt = (void *)buf->data;
    uint16_t handle = evt->handle;
    struct bt_conn *conn;

    BT_DBG("status 0x%02x handle %u reason 0x%02x", evt->status, handle,
           evt->reason);

    if (evt->status)
    {
        return;
    }

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to look up conn with handle %u", handle);
        return;
    }

    conn->err = evt->reason;

    bt_conn_set_state(conn, BT_CONN_DISCONNECTED);
    conn->handle = 0U;

#if defined(CONFIG_BT_CENTRAL) && !defined(CONFIG_BT_WHITELIST)
    if (atomic_test_bit(conn->flags, BT_CONN_AUTO_CONNECT))
    {
        bt_conn_set_state(conn, BT_CONN_CONNECT_SCAN);
        bt_le_scan_update(false);
    }
#endif /* defined(CONFIG_BT_CENTRAL) && !defined(CONFIG_BT_WHITELIST) */
}

static int hci_send_cmd_le_read_remote_features(struct bt_conn *conn)
{
    struct bt_hci_cp_le_read_remote_features *cp;
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_READ_REMOTE_FEATURES,
                            sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    cp->handle = conn->handle;
    bt_hci_cmd_send(BT_HCI_OP_LE_READ_REMOTE_FEATURES, buf);

    return 0;
}

static int hci_send_cmd_read_remote_version(struct bt_conn *conn)
{
    struct bt_hci_cp_read_remote_version_info *cp;
    struct net_buf *buf;

    if (conn->state != BT_CONN_CONNECTED)
    {
        return -ENOTCONN;
    }

    /* Remote version cannot change. */
    if (atomic_test_bit(conn->flags, BT_CONN_AUTO_VERSION_INFO))
    {
        return 0;
    }

    buf = bt_hci_cmd_create(BT_HCI_OP_READ_REMOTE_VERSION_INFO,
                            sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    cp->handle = conn->handle;

    return bt_hci_cmd_send(BT_HCI_OP_READ_REMOTE_VERSION_INFO, buf);
}

/* LE Data Length Change Event is optional so this function just ignore
 * error and stack will continue to use default values.
 */
int hci_send_cmd_le_set_data_len(struct bt_conn *conn, uint16_t tx_octets, uint16_t tx_time)
{
    struct bt_hci_cp_le_set_data_len *cp;
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_DATA_LEN, sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    cp->handle = conn->handle;
    cp->tx_octets = tx_octets;
    cp->tx_time = tx_time;

    return bt_hci_cmd_send(BT_HCI_OP_LE_SET_DATA_LEN, buf);
}

#if defined(CONFIG_BT_USER_PHY_UPDATE)
static int hci_send_cmd_le_read_phy(struct bt_conn *conn)
{
    struct bt_hci_cp_le_read_phy *cp;
    struct bt_hci_rp_le_read_phy *rp;
    struct net_buf *buf, *rsp;
    int err;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_READ_PHY, sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    cp->handle = conn->handle;

    err = bt_hci_cmd_send(BT_HCI_OP_LE_READ_PHY, buf);
    if (err)
    {
        return err;
    }
#if 0
    rp = (void *)rsp->data;
    conn->le.phy.tx_phy = get_phy(rp->tx_phy);
    conn->le.phy.rx_phy = get_phy(rp->rx_phy);
    net_buf_unref(rsp);
#endif
    return 0;
}
#endif /* defined(CONFIG_BT_USER_PHY_UPDATE) */

int hci_send_cmd_le_set_phy(struct bt_conn *conn, uint8_t all_phys,
                            uint8_t pref_tx_phy, uint8_t pref_rx_phy, uint8_t phy_opts)
{
    struct bt_hci_cp_le_set_phy *cp;
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_PHY, sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    cp->handle = conn->handle;
    cp->all_phys = all_phys;
    cp->tx_phys = pref_tx_phy;
    cp->rx_phys = pref_rx_phy;
    cp->phy_opts = phy_opts;

    return bt_hci_cmd_send(BT_HCI_OP_LE_SET_PHY, buf);
}

static void slave_update_conn_param(struct bt_conn *conn)
{
    if (!IS_ENABLED(CONFIG_BT_PERIPHERAL))
    {
        return;
    }

    /* don't start timer again on PHY update etc */
    if (atomic_test_bit(conn->flags, BT_CONN_SLAVE_PARAM_UPDATE))
    {
        return;
    }

    /*
     * Core 4.2 Vol 3, Part C, 9.3.12.2
     * The Peripheral device should not perform a Connection Parameter
     * Update procedure within 5 s after establishing a connection.
     */
    //k_delayed_work_submit(&conn->update_work, CONN_UPDATE_TIMEOUT);
}


static struct bt_conn *find_pending_connect(uint8_t role, bt_addr_le_t *peer_addr)
{
    struct bt_conn *conn;

    /*
     * Make lookup to check if there's a connection object in
     * CONNECT or CONNECT_AUTO state associated with passed peer LE address.
     */
    if (IS_ENABLED(CONFIG_BT_CENTRAL) && role == BT_HCI_ROLE_MASTER)
    {
        conn = bt_conn_lookup_state_le(BT_ID_DEFAULT, peer_addr,
                                       BT_CONN_CONNECT);
        if (IS_ENABLED(CONFIG_BT_WHITELIST) && !conn)
        {
            conn = bt_conn_lookup_state_le(BT_ID_DEFAULT,
                                           BT_ADDR_LE_NONE,
                                           BT_CONN_CONNECT_AUTO);
        }

        return conn;
    }

    if (IS_ENABLED(CONFIG_BT_PERIPHERAL) && role == BT_HCI_ROLE_SLAVE)
    {
        conn = bt_conn_lookup_state_le(bt_dev_set.adv_conn_id, peer_addr,
                                       BT_CONN_CONNECT_DIR_ADV);
        if (!conn)
        {
            conn = bt_conn_lookup_state_le(bt_dev_set.adv_conn_id,
                                           BT_ADDR_LE_NONE,
                                           BT_CONN_CONNECT_ADV);
        }

        return conn;
    }

    return NULL;
}

static void conn_auto_initiate(struct bt_conn *conn)
{
    int err;

    if (conn->state != BT_CONN_CONNECTED)
    {
        /* It is possible that connection was disconnected directly from
         * connected callback so we must check state before doing
         * connection parameters update.
         */
        return;
    }

    if (!atomic_test_bit(conn->flags, BT_CONN_AUTO_FEATURE_EXCH) &&
            ((conn->role == BT_HCI_ROLE_MASTER) ||
             BT_FEAT_LE_SLAVE_FEATURE_XCHG(bt_dev_set.le.features)))
    {
        err = hci_send_cmd_le_read_remote_features(conn);
        if (!err)
        {
            return;
        }
    }

#if defined(CONFIG_BT_REMOTE_VERSION)
    if (!atomic_test_bit(conn->flags, BT_CONN_AUTO_VERSION_INFO))
    {
        err = hci_send_cmd_read_remote_version(conn);
        if (!err)
        {
            return;
        }
    }
#endif

#if defined(CONFIG_BT_AUTO_PHY_UPDATE)
    if (!atomic_test_bit(conn->flags, BT_CONN_AUTO_PHY_COMPLETE) &&
            BT_FEAT_LE_PHY_2M(bt_dev_set.le.features))
    {
        err = hci_send_cmd_le_set_phy(conn, 0U, BT_HCI_LE_PHY_PREFER_2M,
                                      BT_HCI_LE_PHY_PREFER_2M,
                                      BT_HCI_LE_PHY_CODED_ANY);
        if (!err)
        {
            atomic_set_bit(conn->flags, BT_CONN_AUTO_PHY_UPDATE);
            return;
        }

        BT_ERR("Failed to set LE PHY (%d)", err);
    }
#endif

#if defined(CONFIG_BT_AUTO_DATA_LEN_UPDATE)
    if (BT_FEAT_LE_DLE(bt_dev_set.le.features))
    {
        uint16_t tx_octets, tx_time;

        err = hci_send_cmd_le_read_max_data_len(&tx_octets, &tx_time);
        if (!err)
        {
            err = hci_send_cmd_le_set_data_len(conn,
                                               tx_octets, tx_time);
            if (err)
            {
                BT_ERR("Failed to set data len (%d)", err);
            }
        }
    }
#endif

#if defined(CONFIG_BT_PERIPHERAL)
    if (conn->role == BT_CONN_ROLE_SLAVE)
    {
        slave_update_conn_param(conn);
    }
#endif
}

static void le_conn_complete_cancel(void)
{
    struct bt_conn *conn;

    /* Handle create connection cancel.
     *
     * There is no need to check ID address as only one
     * connection in master role can be in pending state.
     */
    conn = find_pending_connect(BT_HCI_ROLE_MASTER, NULL);
    if (!conn)
    {
        BT_ERR("No pending master connection");
        return;
    }

    conn->err = BT_HCI_ERR_UNKNOWN_CONN_ID;

    /* Handle cancellation of outgoing connection attempt. */
    if (!IS_ENABLED(CONFIG_BT_WHITELIST))
    {
        /* We notify before checking autoconnect flag
         * as application may choose to change it from
         * callback.
         */
        bt_conn_set_state(conn, BT_CONN_DISCONNECTED);
        /* Check if device is marked for autoconnect. */
        if (atomic_test_bit(conn->flags, BT_CONN_AUTO_CONNECT))
        {
            /* Restart passive scanner for device */
            bt_conn_set_state(conn, BT_CONN_CONNECT_SCAN);
        }
    }
    else
    {
        if (atomic_test_bit(conn->flags, BT_CONN_AUTO_CONNECT))
        {
            /* Restart whitelist initiator after RPA timeout. */
            bt_le_create_conn(conn);
        }
        else
        {
            /* Create connection canceled by timeout */
            bt_conn_set_state(conn, BT_CONN_DISCONNECTED);
        }
    }
}

static void le_conn_complete_adv_timeout(void)
{
    struct bt_le_ext_adv *adv = bt_adv_lookup_legacy();
    struct bt_conn *conn;

    /* Handle advertising timeout after high duty cycle directed
     * advertising.
     */

    atomic_clear_bit(adv->flags, BT_ADV_ENABLED);

    /* There is no need to check ID address as only one
     * connection in slave role can be in pending state.
     */
    conn = find_pending_connect(BT_HCI_ROLE_SLAVE, NULL);
    if (!conn)
    {
        BT_ERR("No pending slave connection");
        return;
    }

    conn->err = BT_HCI_ERR_ADV_TIMEOUT;
    bt_conn_set_state(conn, BT_CONN_DISCONNECTED);
}

static void enh_conn_complete(struct bt_hci_evt_le_enh_conn_complete *evt)
{
    uint16_t handle = evt->handle;
    bt_addr_le_t peer_addr, id_addr;
    struct bt_conn *conn;

    BT_DBG("enh_conn_complete, status 0x%02x handle %u role %u peer %s peer RPA %s",
           evt->status, handle, evt->role, bt_addr_le_str(&evt->peer_addr),
           bt_addr_str(&evt->peer_rpa));
    BT_DBG("local RPA %s", bt_addr_str(&evt->local_rpa));

#if defined(CONFIG_BT_SMP)
    //pending_id_keys_update();
#endif

    // Connection Error.
    if (evt->status)
    {
#if defined(CONFIG_BT_PERIPHERAL)
        if (evt->status == BT_HCI_ERR_ADV_TIMEOUT)
        {
            le_conn_complete_adv_timeout();
            return;
        }
#endif

#if defined(CONFIG_BT_CENTRAL)
        if (evt->status == BT_HCI_ERR_UNKNOWN_CONN_ID)
        {
            le_conn_complete_cancel();
            bt_le_scan_update(false);
            return;
        }
#endif

        BT_WARN("Unexpected status 0x%02x", evt->status);

        return;
    }

    /* Translate "enhanced" identity address type to normal one */
    if (evt->peer_addr.type == BT_ADDR_LE_PUBLIC_ID ||
            evt->peer_addr.type == BT_ADDR_LE_RANDOM_ID)
    {
        bt_addr_le_copy(&id_addr, &evt->peer_addr);
        id_addr.type -= BT_ADDR_LE_PUBLIC_ID;

        bt_addr_copy(&peer_addr.a, &evt->peer_rpa);
        peer_addr.type = BT_ADDR_LE_RANDOM;
    }
    else
    {
        uint8_t id = evt->role == BT_HCI_ROLE_SLAVE ? bt_dev_set.adv_conn_id :
                     BT_ID_DEFAULT;

        bt_addr_le_copy(&id_addr,
                        bt_lookup_id_addr(id, &evt->peer_addr));
        bt_addr_le_copy(&peer_addr, &evt->peer_addr);
    }

    conn = find_pending_connect(evt->role, &id_addr);

#if defined(CONFIG_BT_PERIPHERAL)
    if (evt->role == BT_HCI_ROLE_SLAVE)
    {
        struct bt_le_ext_adv *adv = bt_adv_lookup_legacy();
        /* Clear advertising even if we are not able to add connection
         * object to keep host in sync with controller state.
         */
        atomic_clear_bit(adv->flags, BT_ADV_ENABLED);
    }
#endif

#if defined(CONFIG_BT_CENTRAL)
    if (evt->role == BT_HCI_ROLE_MASTER)
    {
        /* Clear initiating even if we are not able to add connection
         * object to keep the host in sync with controller state.
         */
        atomic_clear_bit(bt_dev_set.flags, BT_DEV_INITIATING);
    }
#endif

    if (!conn)
    {
        BT_ERR("No pending conn for peer %s",
               bt_addr_le_str(&evt->peer_addr));
        hci_send_cmd_disconnect(handle, BT_HCI_ERR_UNSPECIFIED);
        return;
    }

    conn->handle = handle;
    bt_addr_le_copy(&conn->le.dst, &id_addr);
    conn->le.interval = evt->interval;
    conn->le.latency = evt->latency;
    conn->le.timeout = evt->supv_timeout;
    conn->role = evt->role;
    conn->err = 0U;

#if defined(CONFIG_BT_USER_DATA_LEN_UPDATE)
    conn->le.data_len.tx_max_len = BT_GAP_DATA_LEN_DEFAULT;
    conn->le.data_len.tx_max_time = BT_GAP_DATA_TIME_DEFAULT;
    conn->le.data_len.rx_max_len = BT_GAP_DATA_LEN_DEFAULT;
    conn->le.data_len.rx_max_time = BT_GAP_DATA_TIME_DEFAULT;
#endif

#if defined(CONFIG_BT_USER_PHY_UPDATE)
    conn->le.phy.tx_phy = BT_GAP_LE_PHY_1M;
    conn->le.phy.rx_phy = BT_GAP_LE_PHY_1M;
#endif

#if defined(CONFIG_BT_PERIPHERAL)
    /*
     * Use connection address (instead of identity address) as initiator
     * or responder address. Only slave needs to be updated. For master all
     * was set during outgoing connection creation.
     */
    if (conn->role == BT_HCI_ROLE_SLAVE)
    {
        bt_addr_le_copy(&conn->le.init_addr, &peer_addr);

        struct bt_le_ext_adv *adv = bt_adv_lookup_legacy();

        bt_addr_le_copy(&conn->le.resp_addr,
                        &bt_dev_set.id_addr[conn->id]);

        /* if the controller supports, lets advertise for another
         * slave connection.
         * check for connectable advertising state is sufficient as
         * this is how this le connection complete for slave occurred.
         */
        if (BT_LE_STATES_SLAVE_CONN_ADV(bt_dev_set.le.states))
        {
            bt_le_adv_resume();
        }
    }
#endif

    BT_ERR("enh_conn_complete role: %d.", conn->role);

#if defined(CONFIG_BT_CENTRAL)
    if (conn->role == BT_HCI_ROLE_MASTER)
    {
        bt_addr_le_copy(&conn->le.resp_addr, &peer_addr);

        bt_addr_le_copy(&conn->le.init_addr,
                        &bt_dev_set.id_addr[conn->id]);
    }
#endif

    bt_conn_set_state(conn, BT_CONN_CONNECTED);

    /* Start auto-initiated procedures */
    conn_auto_initiate(conn);

#if defined(CONFIG_BT_CENTRAL)
    if (conn->role == BT_HCI_ROLE_MASTER)
    {
        bt_le_scan_update(false);
    }
#endif
}

static void hci_handle_evt_le_enh_conn_complete(struct net_buf *buf)
{
    enh_conn_complete((void *)buf->data);
}

static void hci_handle_evt_le_legacy_conn_complete(struct net_buf *buf)
{
    struct bt_hci_evt_le_conn_complete *evt = (void *)buf->data;
    struct bt_hci_evt_le_enh_conn_complete enh;

    BT_DBG("le_legacy_conn_complete, status 0x%02x role %u %s", evt->status, evt->role,
           bt_addr_le_str(&evt->peer_addr));

    enh.status         = evt->status;
    enh.handle         = evt->handle;
    enh.role           = evt->role;
    enh.interval       = evt->interval;
    enh.latency        = evt->latency;
    enh.supv_timeout   = evt->supv_timeout;
    enh.clock_accuracy = evt->clock_accuracy;

    bt_addr_le_copy(&enh.peer_addr, &evt->peer_addr);

    bt_addr_copy(&enh.local_rpa, BT_ADDR_ANY);

    bt_addr_copy(&enh.peer_rpa, BT_ADDR_ANY);

    enh_conn_complete(&enh);
}

static void hci_handle_evt_le_remote_feat_complete(struct net_buf *buf)
{
    struct bt_hci_evt_le_remote_feat_complete *evt = (void *)buf->data;
    uint16_t handle = evt->handle;
    struct bt_conn *conn;

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to lookup conn for handle %u", handle);
        return;
    }

    if (!evt->status)
    {
        memcpy(conn->le.features, evt->features,
               sizeof(conn->le.features));
    }

    atomic_set_bit(conn->flags, BT_CONN_AUTO_FEATURE_EXCH);

    if (IS_ENABLED(CONFIG_BT_REMOTE_INFO) &&
            !IS_ENABLED(CONFIG_BT_REMOTE_VERSION))
    {
        notify_remote_info(conn);
    }

    /* Continue with auto-initiated procedures */
    conn_auto_initiate(conn);
}

#if defined(CONFIG_BT_DATA_LEN_UPDATE)
static void hci_handle_evt_le_data_len_change(struct net_buf *buf)
{
    struct bt_hci_evt_le_data_len_change *evt = (void *)buf->data;
    uint16_t max_tx_octets = evt->max_tx_octets;
    uint16_t max_rx_octets = evt->max_rx_octets;
    uint16_t max_tx_time = evt->max_tx_time;
    uint16_t max_rx_time = evt->max_rx_time;
    uint16_t handle = evt->handle);
    struct bt_conn *conn;

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
{
    BT_ERR("Unable to lookup conn for handle %u", handle);
        return;
    }

    BT_DBG("max. tx: %u (%uus), max. rx: %u (%uus)", max_tx_octets,
           max_tx_time, max_rx_octets, max_rx_time);

#if defined(CONFIG_BT_USER_DATA_LEN_UPDATE)
    if (IS_ENABLED(CONFIG_BT_AUTO_DATA_LEN_UPDATE))
    {
        atomic_set_bit(conn->flags, BT_CONN_AUTO_DATA_LEN_COMPLETE);
    }

    conn->le.data_len.tx_max_len = max_tx_octets;
    conn->le.data_len.tx_max_time = max_tx_time;
    conn->le.data_len.rx_max_len = max_rx_octets;
    conn->le.data_len.rx_max_time = max_rx_time;
    notify_le_data_len_updated(conn);
#endif
}
#endif /* CONFIG_BT_DATA_LEN_UPDATE */

#if defined(CONFIG_BT_PHY_UPDATE)
static void hci_handle_evt_le_phy_update_complete(struct net_buf *buf)
{
    struct bt_hci_evt_le_phy_update_complete *evt = (void *)buf->data;
    uint16_t handle = evt->handle;
    struct bt_conn *conn;

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to lookup conn for handle %u", handle);
        return;
    }

    BT_DBG("PHY updated: status: 0x%02x, tx: %u, rx: %u",
           evt->status, evt->tx_phy, evt->rx_phy);

    if (IS_ENABLED(CONFIG_BT_AUTO_PHY_UPDATE) &&
            atomic_test_and_clear_bit(conn->flags, BT_CONN_AUTO_PHY_UPDATE))
    {
        atomic_set_bit(conn->flags, BT_CONN_AUTO_PHY_COMPLETE);

        /* Continue with auto-initiated procedures */
        conn_auto_initiate(conn);
    }

#if defined(CONFIG_BT_USER_PHY_UPDATE)
    conn->le.phy.tx_phy = get_phy(evt->tx_phy);
    conn->le.phy.rx_phy = get_phy(evt->rx_phy);
    notify_le_phy_updated(conn);
#endif
}
#endif /* CONFIG_BT_PHY_UPDATE */

bool bt_le_conn_params_valid(const struct bt_le_conn_param *param)
{
    /* All limits according to BT Core spec 5.0 [Vol 2, Part E, 7.8.12] */

    if (param->interval_min > param->interval_max ||
            param->interval_min < 6 || param->interval_max > 3200)
    {
        return false;
    }

    if (param->latency > 499)
    {
        return false;
    }

    if (param->timeout < 10 || param->timeout > 3200 ||
            ((param->timeout * 4U) <=
             ((1U + param->latency) * param->interval_max)))
    {
        return false;
    }

    return true;
}

static void hci_send_cmd_le_conn_param_neg_reply(uint16_t handle, uint8_t reason)
{
    struct bt_hci_cp_le_conn_param_req_neg_reply *cp;
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_CONN_PARAM_REQ_NEG_REPLY,
                            sizeof(*cp));
    if (!buf)
    {
        BT_ERR("Unable to allocate buffer");
        return;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    cp->handle = handle;
    cp->reason = reason;

    bt_hci_cmd_send(BT_HCI_OP_LE_CONN_PARAM_REQ_NEG_REPLY, buf);
}

static int hci_send_cmd_le_conn_param_req_reply(uint16_t handle,
        const struct bt_le_conn_param *param)
{
    struct bt_hci_cp_le_conn_param_req_reply *cp;
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_CONN_PARAM_REQ_REPLY, sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    (void)memset(cp, 0, sizeof(*cp));

    cp->handle = handle;
    cp->interval_min = param->interval_min;
    cp->interval_max = param->interval_max;
    cp->latency = param->latency;
    cp->timeout = param->timeout;

    return bt_hci_cmd_send(BT_HCI_OP_LE_CONN_PARAM_REQ_REPLY, buf);
}

static void hci_handle_evt_le_conn_param_req(struct net_buf *buf)
{
    struct bt_hci_evt_le_conn_param_req *evt = (void *)buf->data;
    struct bt_le_conn_param param;
    struct bt_conn *conn;
    uint16_t handle;

    handle = evt->handle;
    param.interval_min = evt->interval_min;
    param.interval_max = evt->interval_max;
    param.latency = evt->latency;
    param.timeout = evt->timeout;

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to lookup conn for handle %u", handle);
        hci_send_cmd_le_conn_param_neg_reply(handle, BT_HCI_ERR_UNKNOWN_CONN_ID);
        return;
    }

    if (!le_param_req(conn, &param))
    {
        hci_send_cmd_le_conn_param_neg_reply(handle, BT_HCI_ERR_INVALID_LL_PARAM);
    }
    else
    {
        hci_send_cmd_le_conn_param_req_reply(handle, &param);
    }
}

static void hci_handle_evt_le_conn_update_complete(struct net_buf *buf)
{
    struct bt_hci_evt_le_conn_update_complete *evt = (void *)buf->data;
    struct bt_conn *conn;
    uint16_t handle;

    handle = evt->handle;

    BT_DBG("le_conn_update_complete, status 0x%02x, handle %u", evt->status, handle);

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to lookup conn for handle %u", handle);
        return;
    }

    if (!evt->status)
    {
        conn->le.interval = evt->interval;
        conn->le.latency = evt->latency;
        conn->le.timeout = evt->supv_timeout;
        notify_le_param_updated(conn);
    }
    else if (evt->status == BT_HCI_ERR_UNSUPP_REMOTE_FEATURE &&
             conn->role == BT_HCI_ROLE_SLAVE &&
             !atomic_test_and_set_bit(conn->flags,
                                      BT_CONN_SLAVE_PARAM_L2CAP))
    {
        /* CPR not supported, let's try L2CAP CPUP instead */
        struct bt_le_conn_param param;

        param.interval_min = conn->le.interval_min;
        param.interval_max = conn->le.interval_max;
        param.latency = conn->le.pending_latency;
        param.timeout = conn->le.pending_timeout;

        bt_l2cap_update_conn_param(conn, &param);
    }
}

#if defined(CONFIG_BT_CENTRAL)
static void check_pending_conn(const bt_addr_le_t *id_addr,
                               const bt_addr_le_t *addr, uint8_t adv_props)
{
    struct bt_conn *conn;

    /* No connections are allowed during explicit scanning */
    if (atomic_test_bit(bt_dev_set.flags, BT_DEV_EXPLICIT_SCAN))
    {
        return;
    }

    /* Return if event is not connectable */
    if (!(adv_props & BT_HCI_LE_ADV_EVT_TYPE_CONN))
    {
        return;
    }

    conn = bt_conn_lookup_state_le(BT_ID_DEFAULT, id_addr,
                                   BT_CONN_CONNECT_SCAN);
    if (!conn)
    {
        return;
    }

    if (atomic_test_bit(bt_dev_set.flags, BT_DEV_SCANNING) &&
            set_le_scan_enable(BT_HCI_LE_SCAN_DISABLE))
    {
        goto failed;
    }

    bt_addr_le_copy(&conn->le.resp_addr, addr);
    if (bt_le_create_conn(conn))
    {
        goto failed;
    }

    bt_conn_set_state(conn, BT_CONN_CONNECT);
    return;

failed:
    conn->err = BT_HCI_ERR_UNSPECIFIED;
    bt_conn_set_state(conn, BT_CONN_DISCONNECTED);
    bt_le_scan_update(false);
}
#endif /* CONFIG_BT_CENTRAL */

static void unpair(uint8_t id, const bt_addr_le_t *addr)
{
    struct bt_keys *keys = NULL;
    struct bt_conn *conn = bt_conn_lookup_addr_le(id, addr);

    if (conn)
    {
        /* Clear the conn->le.keys pointer since we'll invalidate it,
         * and don't want any subsequent code (like disconnected
         * callbacks) accessing it.
         */
        if (conn->type == BT_CONN_TYPE_LE)
        {
            keys = conn->le.keys;
            conn->le.keys = NULL;
        }

        bt_conn_disconnect(conn, BT_HCI_ERR_REMOTE_USER_TERM_CONN);
    }

    if (IS_ENABLED(CONFIG_BT_SMP))
    {
        if (!keys)
        {
            keys = bt_keys_find_addr(id, addr);
        }

        if (keys)
        {
            bt_keys_clear(keys);
        }
    }

    //bt_gatt_clear(id, addr);

#if defined(CONFIG_BT_SMP) || defined(CONFIG_BT_BREDR)
    if (bt_auth && bt_auth->bond_deleted)
    {
        bt_auth->bond_deleted(id, addr);
    }
#endif /* defined(CONFIG_BT_SMP) || defined(CONFIG_BT_BREDR) */
}

static void unpair_remote(const struct bt_bond_info *info, void *data)
{
    uint8_t *id = (uint8_t *) data;

    unpair(*id, &info->addr);
}

int bt_unpair(uint8_t id, const bt_addr_le_t *addr)
{
    if (id >= CONFIG_BT_ID_MAX)
    {
        return -EINVAL;
    }

    if (IS_ENABLED(CONFIG_BT_SMP) &&
            (!addr || !bt_addr_le_cmp(addr, BT_ADDR_LE_ANY)))
    {
        bt_foreach_bond(id, unpair_remote, &id);
        return 0;
    }

    unpair(id, addr);
    return 0;
}

#endif /* CONFIG_BT_CONN */

#if defined(CONFIG_BT_SMP) || defined(CONFIG_BT_BREDR)
enum bt_security_err bt_security_err_get(uint8_t hci_err)
{
    switch (hci_err)
    {
    case BT_HCI_ERR_SUCCESS:
                return BT_SECURITY_ERR_SUCCESS;
    case BT_HCI_ERR_AUTH_FAIL:
        return BT_SECURITY_ERR_AUTH_FAIL;
    case BT_HCI_ERR_PIN_OR_KEY_MISSING:
        return BT_SECURITY_ERR_PIN_OR_KEY_MISSING;
    case BT_HCI_ERR_PAIRING_NOT_SUPPORTED:
        return BT_SECURITY_ERR_PAIR_NOT_SUPPORTED;
    case BT_HCI_ERR_PAIRING_NOT_ALLOWED:
        return BT_SECURITY_ERR_PAIR_NOT_ALLOWED;
    case BT_HCI_ERR_INVALID_PARAM:
        return BT_SECURITY_ERR_INVALID_PARAM;
    default:
        return BT_SECURITY_ERR_UNSPECIFIED;
    }
}
#endif /* defined(CONFIG_BT_SMP) || defined(CONFIG_BT_BREDR) */

#if defined(CONFIG_BT_SMP)
#if 0
static int hci_send_cmd_le_set_privacy_mode(const bt_addr_le_t *addr, uint8_t mode)
{
    struct bt_hci_cp_le_set_privacy_mode cp;
    struct net_buf *buf;
    int err;

    /* Check if set privacy mode command is supported */
    if (!BT_CMD_TEST(bt_dev_set.supported_commands, 39, 2))
    {
        BT_WARN("Set privacy mode command is not supported");
        return 0;
    }

    BT_DBG("addr %s mode 0x%02x", bt_addr_le_str(addr), mode);

    bt_addr_le_copy(&cp.id_addr, addr);
    cp.mode = mode;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_PRIVACY_MODE, sizeof(cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    net_buf_add_mem(buf, &cp, sizeof(cp));

    err = bt_hci_cmd_send_sync(BT_HCI_OP_LE_SET_PRIVACY_MODE, buf, NULL);
    if (err)
    {
        return err;
    }

    return 0;
}

static int hci_send_cmd_addr_res_enable(uint8_t enable)
{
    struct net_buf *buf;

    BT_DBG("%s", enable ? "enabled" : "disabled");

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_ADDR_RES_ENABLE, 1);
    if (!buf)
    {
        return -ENOBUFS;
    }

    net_buf_add_u8(buf, enable);

    return bt_hci_cmd_send_sync(BT_HCI_OP_LE_SET_ADDR_RES_ENABLE,
                                buf, NULL);
}

static int hci_id_add(uint8_t id, const bt_addr_le_t *addr, uint8_t peer_irk[16])
{
    struct bt_hci_cp_le_add_dev_to_rl *cp;
    struct net_buf *buf;

    BT_DBG("addr %s", bt_addr_le_str(addr));

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_ADD_DEV_TO_RL, sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    bt_addr_le_copy(&cp->peer_id_addr, addr);
    memcpy(cp->peer_irk, peer_irk, 16);

#if defined(CONFIG_BT_PRIVACY)
    memcpy(cp->local_irk, bt_dev_set.irk[id], 16);
#else
    (void)memset(cp->local_irk, 0, 16);
#endif

    return bt_hci_cmd_send_sync(BT_HCI_OP_LE_ADD_DEV_TO_RL, buf, NULL);
}

static void keys_add_id(struct bt_keys *keys, void *data)
{
    if (keys->state & BT_KEYS_ID_ADDED)
    {
        hci_id_add(keys->id, &keys->addr, keys->irk.val);
    }
}

static int hci_id_del(const bt_addr_le_t *addr)
{
    struct bt_hci_cp_le_rem_dev_from_rl *cp;
    struct net_buf *buf;

    BT_DBG("addr %s", bt_addr_le_str(addr));

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_REM_DEV_FROM_RL, sizeof(*cp));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    bt_addr_le_copy(&cp->peer_id_addr, addr);

    return bt_hci_cmd_send_sync(BT_HCI_OP_LE_REM_DEV_FROM_RL, buf, NULL);
}
#endif


static void update_sec_level(struct bt_conn *conn)
{
    if (!conn->encrypt)
    {
        conn->sec_level = BT_SECURITY_L1;
        return;
    }

    if (conn->le.keys && (conn->le.keys->flags & BT_KEYS_AUTHENTICATED))
    {
        if (conn->le.keys->flags & BT_KEYS_SC &&
                conn->le.keys->enc_size == BT_SMP_MAX_ENC_KEY_SIZE)
        {
            conn->sec_level = BT_SECURITY_L4;
        }
        else
        {
            conn->sec_level = BT_SECURITY_L3;
        }
    }
    else
    {
        conn->sec_level = BT_SECURITY_L2;
    }

    if (conn->required_sec_level > conn->sec_level)
    {
        BT_ERR("Failed to set required security level");
        bt_conn_disconnect(conn, BT_HCI_ERR_AUTH_FAIL);
    }
}
#endif /* CONFIG_BT_SMP */

#if defined(CONFIG_BT_SMP) || defined(CONFIG_BT_BREDR)
static void hci_handle_evt_encrypt_change(struct net_buf *buf)
{
    struct bt_hci_evt_encrypt_change *evt = (void *)buf->data;
    uint16_t handle = evt->handle;
    struct bt_conn *conn;

    BT_DBG("status 0x%02x handle %u encrypt 0x%02x", evt->status, handle,
           evt->encrypt);

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to look up conn with handle %u", handle);
        return;
    }

    if (evt->status)
    {
        bt_conn_security_changed(conn, evt->status,
                                 bt_security_err_get(evt->status));
        return;
    }

    conn->encrypt = evt->encrypt;

#if defined(CONFIG_BT_SMP)
    if (conn->type == BT_CONN_TYPE_LE)
    {
        /*
         * we update keys properties only on successful encryption to
         * avoid losing valid keys if encryption was not successful.
         *
         * Update keys with last pairing info for proper sec level
         * update. This is done only for LE transport, for BR/EDR keys
         * are updated on HCI 'Link Key Notification Event'
         */
        if (conn->encrypt)
        {
            bt_smp_update_keys(conn);
        }
        update_sec_level(conn);
    }
#endif /* CONFIG_BT_SMP */

    bt_conn_security_changed(conn, evt->status, BT_SECURITY_ERR_SUCCESS);
}

static void hci_handle_evt_encrypt_key_refresh_complete(struct net_buf *buf)
{
    struct bt_hci_evt_encrypt_key_refresh_complete *evt = (void *)buf->data;
    struct bt_conn *conn;
    uint16_t handle;

    handle = evt->handle;

    BT_DBG("status 0x%02x handle %u", evt->status, handle);

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to look up conn with handle %u", handle);
        return;
    }

    if (evt->status)
    {
        bt_conn_security_changed(conn, evt->status,
                                 bt_security_err_get(evt->status));
        return;
    }

    /*
     * Update keys with last pairing info for proper sec level update.
     * This is done only for LE transport. For BR/EDR transport keys are
     * updated on HCI 'Link Key Notification Event', therefore update here
     * only security level based on available keys and encryption state.
     */
#if defined(CONFIG_BT_SMP)
    if (conn->type == BT_CONN_TYPE_LE)
    {
        bt_smp_update_keys(conn);
        update_sec_level(conn);
    }
#endif /* CONFIG_BT_SMP */

    bt_conn_security_changed(conn, evt->status, BT_SECURITY_ERR_SUCCESS);
}
#endif /* CONFIG_BT_SMP || CONFIG_BT_BREDR */

#if defined(CONFIG_BT_REMOTE_VERSION)
static void hci_handle_evt_read_remote_version_complete(struct net_buf *buf)
{
    struct bt_hci_evt_remote_version_info *evt;
    struct bt_conn *conn;

    evt = net_buf_pull_mem(buf, sizeof(*evt));
    conn = bt_conn_lookup_handle(evt->handle);
    if (!conn)
    {
        BT_ERR("No connection for handle %u", evt->handle);
        return;
    }

    if (!evt->status)
    {
        conn->rv.version = evt->version;
        conn->rv.manufacturer = evt->manufacturer;
        conn->rv.subversion = evt->subversion;
    }

    atomic_set_bit(conn->flags, BT_CONN_AUTO_VERSION_INFO);

    if (IS_ENABLED(CONFIG_BT_REMOTE_INFO))
    {
        /* Remote features is already present */
        notify_remote_info(conn);
    }

    /* Continue with auto-initiated procedures */
    conn_auto_initiate(conn);
}
#endif /* CONFIG_BT_REMOTE_VERSION */

static void hci_handle_evt_hardware_error(struct net_buf *buf)
{
    struct bt_hci_evt_hardware_error *evt;

    evt = net_buf_pull_mem(buf, sizeof(*evt));

    BT_ERR("Hardware error, hardware code: %d", evt->hardware_code);
}

#if defined(CONFIG_BT_SMP)
static void hci_send_cmd_le_ltk_neg_reply(uint16_t handle)
{
    struct bt_hci_cp_le_ltk_req_neg_reply *cp;
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_LTK_REQ_NEG_REPLY, sizeof(*cp));
    if (!buf)
    {
        BT_ERR("Out of command buffers");

        return;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    cp->handle = handle;

    bt_hci_cmd_send(BT_HCI_OP_LE_LTK_REQ_NEG_REPLY, buf);
}

static void hci_send_cmd_le_ltk_reply(uint16_t handle, uint8_t *ltk)
{
    struct bt_hci_cp_le_ltk_req_reply *cp;
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_LTK_REQ_REPLY,
                            sizeof(*cp));
    if (!buf)
    {
        BT_ERR("Out of command buffers");
        return;
    }

    cp = net_buf_add(buf, sizeof(*cp));
    cp->handle = handle;
    memcpy(cp->ltk, ltk, sizeof(cp->ltk));

    bt_hci_cmd_send(BT_HCI_OP_LE_LTK_REQ_REPLY, buf);
}

static void le_ltk_request(struct net_buf *buf)
{
    struct bt_hci_evt_le_ltk_request *evt = (void *)buf->data;
    struct bt_conn *conn;
    uint16_t handle;
    uint8_t ltk[16];

    handle = evt->handle;

    BT_DBG("handle %u", handle);

    conn = bt_conn_lookup_handle(handle);
    if (!conn)
    {
        BT_ERR("Unable to lookup conn for handle %u", handle);
        return;
    }

    if (bt_smp_request_ltk(conn, evt->rand, evt->ediv, ltk))
    {
        hci_send_cmd_le_ltk_reply(handle, ltk);
    }
    else
    {
        hci_send_cmd_le_ltk_neg_reply(handle);
    }
}
#endif /* CONFIG_BT_SMP */

static void hci_handle_cmd_cmp_evt_reset_complete(struct net_buf *buf)
{
    uint8_t status = buf->data[0];
    atomic_t flags;

    BT_DBG("status 0x%02x", status);

    if (status)
    {
        return;
    }

    scan_dev_found_cb = NULL;

    flags = (atomic_get(bt_dev_set.flags) & BT_DEV_PERSISTENT_FLAGS);
    atomic_set(bt_dev_set.flags, flags);
}

static void hci_cmd_done(uint16_t opcode, uint8_t status, struct net_buf *buf)
{
    BT_DBG("hci_cmd_done opcode 0x%04x status 0x%02x buf %p", opcode, status, buf);
#if 0
    BT_DBG("hci_cmd_done buf->pool_id %p hci_cmd_pool %p", net_buf_pool_get(buf->pool_id), &hci_cmd_pool);

    if (net_buf_pool_get(buf->pool_id) != &hci_cmd_pool)
    {
        BT_WARN("opcode 0x%04x pool id %u pool %p != &hci_cmd_pool %p",
                opcode, buf->pool_id, net_buf_pool_get(buf->pool_id),
                &hci_cmd_pool);
        return;
    }

    if (cmd(buf)->opcode != opcode)
    {
        BT_WARN("OpCode 0x%04x completed instead of expected 0x%04x",
                opcode, cmd(buf)->opcode);
    }
#endif
#if 0
    BT_DBG("2222");

    if (cmd(buf)->state && !status)
    {
        struct cmd_state_set *update = cmd(buf)->state;

        BT_WARN("update 0x%04x",
                update);

        atomic_set_bit_to(update->target, update->bit, update->val);
    }


    BT_DBG("333");

    /* If the command was synchronous wake up bt_hci_cmd_send_sync() */
    if (cmd(buf)->sync)
    {
        cmd(buf)->status = status;
        //k_sem_give(cmd(buf)->sync);
    }
    BT_DBG("444");
#endif
}

static void hci_handle_evt_cmd_status(struct net_buf *buf)
{
    struct bt_hci_evt_cmd_status *evt;
    uint16_t opcode;
    uint8_t ncmd;

    evt = net_buf_pull_mem(buf, sizeof(*evt));
    opcode = evt->opcode;
    ncmd = evt->ncmd;

    BT_DBG("opcode 0x%04x", opcode);

    hci_cmd_done(opcode, evt->status, buf);
}

#if defined(CONFIG_BT_OBSERVER)
static bool is_adv_using_rand_addr(void)
{
    struct bt_le_ext_adv *adv = bt_adv_lookup_legacy();

    return adv && atomic_test_bit(adv->flags, BT_ADV_ENABLED);
}

static int le_scan_set_random_addr(bool active_scan, uint8_t *own_addr_type)
{
    int err;

    BT_DBG("le_scan_set_random_addr, active_scan: %d", active_scan);

    *own_addr_type = bt_dev_set.id_addr[0].type;

    return 0;
}

static int start_le_scan_legacy(uint8_t scan_type, uint16_t interval, uint16_t window)
{
    struct bt_hci_cp_le_set_scan_param set_param;
    struct net_buf *buf;
    int err;
    bool active_scan;

    BT_DBG("start_le_scan_legacy, scan_type: %d, interval: 0x%x, window: 0x%x"
           , scan_type, interval, window);

    (void)memset(&set_param, 0, sizeof(set_param));

    set_param.scan_type = scan_type;

    /* for the rest parameters apply default values according to
     *  spec 4.2, vol2, part E, 7.8.10
     */
    set_param.interval = interval;
    set_param.window = window;

    if (IS_ENABLED(CONFIG_BT_WHITELIST) &&
            atomic_test_bit(bt_dev_set.flags, BT_DEV_SCAN_WL))
    {
        set_param.filter_policy = BT_HCI_LE_SCAN_FP_USE_WHITELIST;
    }
    else
    {
        set_param.filter_policy = BT_HCI_LE_SCAN_FP_NO_WHITELIST;
    }

    active_scan = scan_type == BT_HCI_LE_SCAN_ACTIVE;
    err = le_scan_set_random_addr(active_scan, &set_param.addr_type);
    if (err)
    {
        return err;
    }

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_SCAN_PARAM, sizeof(set_param));
    if (!buf)
    {
        return -ENOBUFS;
    }

    net_buf_add_mem(buf, &set_param, sizeof(set_param));

    err = bt_hci_cmd_send(BT_HCI_OP_LE_SET_SCAN_PARAM, buf);
    if (err)
    {
        return err;
    }

    err = set_le_scan_enable(BT_HCI_LE_SCAN_ENABLE);
    if (err)
    {
        return err;
    }

    atomic_set_bit_to(bt_dev_set.flags, BT_DEV_ACTIVE_SCAN, active_scan);

    return 0;
}

static int start_passive_scan(bool fast_scan)
{
    uint16_t interval, window;

    if (fast_scan)
    {
        interval = BT_GAP_SCAN_FAST_INTERVAL;
        window = BT_GAP_SCAN_FAST_WINDOW;
    }
    else
    {
        interval = CONFIG_BT_BACKGROUND_SCAN_INTERVAL;
        window = CONFIG_BT_BACKGROUND_SCAN_WINDOW;
    }

    return start_le_scan_legacy(BT_HCI_LE_SCAN_PASSIVE, interval, window);
}

int bt_le_scan_update(bool fast_scan)
{
    BT_WARN("bt_le_scan_update, fast_scan: %d, flags: 0x%x.", fast_scan, *(int *)bt_dev_set.flags);

    if (atomic_test_bit(bt_dev_set.flags, BT_DEV_EXPLICIT_SCAN))
    {
        return 0;
    }

    if (atomic_test_bit(bt_dev_set.flags, BT_DEV_SCANNING))
    {
        int err;

        err = set_le_scan_enable(BT_HCI_LE_SCAN_DISABLE);
        if (err)
        {
            return err;
        }
    }

    if (IS_ENABLED(CONFIG_BT_CENTRAL))
    {
        struct bt_conn *conn;

        /* don't restart scan if we have pending connection */
        conn = bt_conn_lookup_state_le(BT_ID_DEFAULT, NULL,
                                       BT_CONN_CONNECT);
        if (conn)
        {
            return 0;
        }

        conn = bt_conn_lookup_state_le(BT_ID_DEFAULT, NULL,
                                       BT_CONN_CONNECT_SCAN);
        if (conn)
        {
            atomic_set_bit(bt_dev_set.flags, BT_DEV_SCAN_FILTER_DUP);

            return start_passive_scan(fast_scan);
        }
    }

    return 0;
}

void bt_data_parse(struct net_buf_simple *ad,
                   bool (*func)(struct bt_data *data, void *user_data),
                   void *user_data)
{
    while (ad->len > 1)
    {
        struct bt_data data;
        uint8_t len;

        len = net_buf_simple_pull_u8(ad);
        if (len == 0U)
        {
            /* Early termination */
            return;
        }

        if (len > ad->len)
        {
            BT_WARN("Malformed data");
            return;
        }

        data.type = net_buf_simple_pull_u8(ad);
        data.data_len = len - 1;
        data.data = ad->data;

        if (!func(&data, user_data))
        {
            return;
        }

        net_buf_simple_pull(ad, len - 1);
    }
}

/* Convert Legacy adv report evt_type field to adv props */
static uint8_t get_adv_props(uint8_t evt_type)
{
    switch (evt_type)
    {
    case BT_GAP_ADV_TYPE_ADV_IND:
        return BT_GAP_ADV_PROP_CONNECTABLE |
               BT_GAP_ADV_PROP_SCANNABLE;

    case BT_GAP_ADV_TYPE_ADV_DIRECT_IND:
        return BT_GAP_ADV_PROP_CONNECTABLE |
               BT_GAP_ADV_PROP_DIRECTED;

    case BT_GAP_ADV_TYPE_ADV_SCAN_IND:
        return BT_GAP_ADV_PROP_SCANNABLE;

    case BT_GAP_ADV_TYPE_ADV_NONCONN_IND:
        return 0;

    /* In legacy advertising report, we don't know if the scan
     * response come from a connectable advertiser, so don't
     * set connectable property bit.
     */
    case BT_GAP_ADV_TYPE_SCAN_RSP:
        return BT_GAP_ADV_PROP_SCAN_RESPONSE |
               BT_GAP_ADV_PROP_SCANNABLE;

    default:
        return 0;
    }
}

static void le_adv_recv(bt_addr_le_t *addr, struct bt_le_scan_recv_info *info,
                        struct net_buf *buf, uint8_t len)
{
    struct bt_le_scan_cb *listener;
    struct net_buf_simple_state state;
    bt_addr_le_t id_addr;

    BT_DBG("%s event %u, len %u, rssi %d dBm", bt_addr_le_str(addr),
           info->adv_type, len, info->rssi);

    if (!IS_ENABLED(CONFIG_BT_PRIVACY) &&
            !IS_ENABLED(CONFIG_BT_SCAN_WITH_IDENTITY) &&
            atomic_test_bit(bt_dev_set.flags, BT_DEV_EXPLICIT_SCAN) &&
            (info->adv_props & BT_HCI_LE_ADV_PROP_DIRECT))
    {
        BT_DBG("Dropped direct adv report");
        return;
    }

    if (addr->type == BT_ADDR_LE_PUBLIC_ID ||
            addr->type == BT_ADDR_LE_RANDOM_ID)
    {
        bt_addr_le_copy(&id_addr, addr);
        id_addr.type -= BT_ADDR_LE_PUBLIC_ID;
    }
    else if (addr->type == BT_HCI_PEER_ADDR_ANONYMOUS)
    {
        bt_addr_le_copy(&id_addr, BT_ADDR_LE_ANY);
    }
    else
    {
        bt_addr_le_copy(&id_addr,
                        bt_lookup_id_addr(BT_ID_DEFAULT, addr));
    }

    info->addr = &id_addr;

    if (scan_dev_found_cb)
    {
        net_buf_simple_save(&buf->b, &state);

        buf->len = len;
        scan_dev_found_cb(&id_addr, info->rssi, info->adv_type,
                          &buf->b);

        net_buf_simple_restore(&buf->b, &state);
    }

#if defined(CONFIG_BT_CENTRAL)
    check_pending_conn(&id_addr, addr, info->adv_props);
#endif /* CONFIG_BT_CENTRAL */
}

static void hci_handle_evt_le_adv_report(struct net_buf *buf)
{
    uint8_t num_reports = net_buf_pull_u8(buf);
    struct bt_hci_evt_le_advertising_info *evt;

    BT_DBG("Adv number of reports %u",  num_reports);

    while (num_reports--)
    {
        struct bt_le_scan_recv_info adv_info;

        if (buf->len < sizeof(*evt))
        {
            BT_ERR("Unexpected end of buffer");
            break;
        }

        evt = net_buf_pull_mem(buf, sizeof(*evt));

        adv_info.rssi = evt->data[evt->length];
        adv_info.primary_phy = BT_GAP_LE_PHY_1M;
        adv_info.secondary_phy = 0;
        adv_info.tx_power = BT_GAP_TX_POWER_INVALID;
        adv_info.sid = BT_GAP_SID_INVALID;

        adv_info.adv_type = evt->evt_type;
        adv_info.adv_props = get_adv_props(evt->evt_type);

        le_adv_recv(&evt->addr, &adv_info, buf, evt->length);

        net_buf_pull(buf, evt->length + sizeof(adv_info.rssi));
    }
}
#endif /* CONFIG_BT_OBSERVER */

static void le_adv_stop_free_conn(const struct bt_le_ext_adv *adv, uint8_t status)
{
    struct bt_conn *conn;

    if (!bt_addr_le_cmp(&adv->target_addr, BT_ADDR_LE_ANY))
    {
        conn = bt_conn_lookup_state_le(adv->id, BT_ADDR_LE_NONE,
                                       BT_CONN_CONNECT_ADV);
    }
    else
    {
        conn = bt_conn_lookup_state_le(adv->id, &adv->target_addr,
                                       BT_CONN_CONNECT_DIR_ADV);
    }

    if (conn)
    {
        conn->err = status;
        bt_conn_set_state(conn, BT_CONN_DISCONNECTED);
    }
}


int bt_hci_get_conn_handle(const struct bt_conn *conn, uint16_t *conn_handle)
{
    if (conn->state != BT_CONN_CONNECTED)
    {
        return -ENOTCONN;
    }

    *conn_handle = conn->handle;
    return 0;
}

static void hci_handle_evt_vendor(struct net_buf *buf)
{
    bool handled = false;

    if (IS_ENABLED(CONFIG_BT_HCI_VS_EXT) && !handled)
    {
        /* do nothing at present time */
        BT_WARN("Unhandled vendor-specific event: %s",
                bt_hex(buf->data, buf->len));
    }
}

static const struct event_handler meta_events[] =
{
#if defined(CONFIG_BT_OBSERVER)
    EVENT_HANDLER(BT_HCI_EVT_LE_ADVERTISING_REPORT
                  , hci_handle_evt_le_adv_report
                  , sizeof(struct bt_hci_evt_le_advertising_report)),
#endif /* CONFIG_BT_OBSERVER */
#if defined(CONFIG_BT_CONN)
    EVENT_HANDLER(BT_HCI_EVT_LE_CONN_COMPLETE
                  , hci_handle_evt_le_legacy_conn_complete
                  , sizeof(struct bt_hci_evt_le_conn_complete)),
    EVENT_HANDLER(BT_HCI_EVT_LE_ENH_CONN_COMPLETE
                  , hci_handle_evt_le_enh_conn_complete
                  , sizeof(struct bt_hci_evt_le_enh_conn_complete)),
    EVENT_HANDLER(BT_HCI_EVT_LE_CONN_UPDATE_COMPLETE
                  , hci_handle_evt_le_conn_update_complete
                  , sizeof(struct bt_hci_evt_le_conn_update_complete)),
    EVENT_HANDLER(BT_HCI_EV_LE_REMOTE_FEAT_COMPLETE
                  , hci_handle_evt_le_remote_feat_complete
                  , sizeof(struct bt_hci_evt_le_remote_feat_complete)),
    EVENT_HANDLER(BT_HCI_EVT_LE_CONN_PARAM_REQ
                  , hci_handle_evt_le_conn_param_req
                  , sizeof(struct bt_hci_evt_le_conn_param_req)),
#if defined(CONFIG_BT_DATA_LEN_UPDATE)
    EVENT_HANDLER(BT_HCI_EVT_LE_DATA_LEN_CHANGE
                  , hci_handle_evt_le_data_len_change
                  , sizeof(struct bt_hci_evt_le_data_len_change)),
#endif /* CONFIG_BT_DATA_LEN_UPDATE */
#if defined(CONFIG_BT_PHY_UPDATE)
    EVENT_HANDLER(BT_HCI_EVT_LE_PHY_UPDATE_COMPLETE
                  , hci_handle_evt_le_phy_update_complete
                  , sizeof(struct bt_hci_evt_le_phy_update_complete)),
#endif /* CONFIG_BT_PHY_UPDATE */
#endif /* CONFIG_BT_CONN */
#if defined(CONFIG_BT_SMP)
    EVENT_HANDLER(BT_HCI_EVT_LE_LTK_REQUEST
                  , le_ltk_request
                  , sizeof(struct bt_hci_evt_le_ltk_request)),
#endif /* CONFIG_BT_SMP */
};

static void hci_handle_evt_le_meta_event(struct net_buf *buf)
{
    struct bt_hci_evt_le_meta_event *evt;

    evt = net_buf_pull_mem(buf, sizeof(*evt));

    BT_DBG("hci_le_meta_event 0x%02x", evt->subevent);

    handle_event(evt->subevent, buf, meta_events, ARRAY_SIZE(meta_events));
}

static const struct event_handler normal_events[] =
{
    EVENT_HANDLER(BT_HCI_EVT_VENDOR
                  , hci_handle_evt_vendor
                  , sizeof(struct bt_hci_evt_vs)),
    EVENT_HANDLER(BT_HCI_EVT_LE_META_EVENT
                  , hci_handle_evt_le_meta_event
                  , sizeof(struct bt_hci_evt_le_meta_event)),
#if defined(CONFIG_BT_CONN)
    EVENT_HANDLER(BT_HCI_EVT_DISCONN_COMPLETE
                  , hci_handle_evt_disconnect_complete
                  , sizeof(struct bt_hci_evt_disconn_complete)),
#endif /* CONFIG_BT_CONN */
#if defined(CONFIG_BT_SMP) || defined(CONFIG_BT_BREDR)
    EVENT_HANDLER(BT_HCI_EVT_ENCRYPT_CHANGE
                  , hci_handle_evt_encrypt_change
                  , sizeof(struct bt_hci_evt_encrypt_change)),
    EVENT_HANDLER(BT_HCI_EVT_ENCRYPT_KEY_REFRESH_COMPLETE
                  , hci_handle_evt_encrypt_key_refresh_complete
                  , sizeof(struct bt_hci_evt_encrypt_key_refresh_complete)),
#endif /* CONFIG_BT_SMP || CONFIG_BT_BREDR */
#if defined(CONFIG_BT_REMOTE_VERSION)
    EVENT_HANDLER(BT_HCI_EVT_REMOTE_VERSION_INFO
                  , hci_handle_evt_read_remote_version_complete
                  , sizeof(struct bt_hci_evt_remote_version_info)),
#endif /* CONFIG_BT_REMOTE_VERSION */
    EVENT_HANDLER(BT_HCI_EVT_HARDWARE_ERROR
                  , hci_handle_evt_hardware_error
                  , sizeof(struct bt_hci_evt_hardware_error)),
};

static void hci_handle_event(struct net_buf *buf)
{
    struct bt_hci_evt_hdr *hdr;

    BT_ASSERT(buf->len >= sizeof(*hdr));

    hdr = net_buf_pull_mem(buf, sizeof(*hdr));
    BT_DBG("event 0x%02x", hdr->evt);
    BT_ASSERT(bt_hci_evt_get_flags(hdr->evt) & BT_HCI_EVT_FLAG_RECV);

    handle_event(hdr->evt, buf, normal_events, ARRAY_SIZE(normal_events));

    net_buf_unref(buf);
}

static void hci_send_cmd(void)
{
    struct net_buf *buf;
    int err;

    /* Get next command */
    BT_DBG("send_cmd, calling net_buf_get");
    buf = net_buf_get(&bt_dev_set.cmd_tx_queue, 0);
    BT_ASSERT(buf);

    err = bt_send(buf);
    if (err)
    {
        BT_ERR("Unable to send to driver (err %d)", err);

        net_buf_unref(buf);
    }
}

static void hci_tx_thread(void)
{
    uint8_t i;
    if(!sys_sflist_is_empty(&bt_dev_set.cmd_tx_queue))
    {
        // send one by one?
        //if (bt_dev_set.sent_cmd) {
        //    return;
        //}
        hci_send_cmd();
    }
    if (IS_ENABLED(CONFIG_BT_CONN))
    {
        bt_conn_tx_polling();
    }
}


static void hci_handle_cmd_cmp_evt_read_local_ver_complete(struct net_buf *buf)
{
    struct bt_hci_rp_read_local_version_info *rp = (void *)buf->data;

    BT_DBG("status 0x%02x", rp->status);

    bt_dev_set.hci_version = rp->hci_version;
    bt_dev_set.hci_revision = rp->hci_revision;
    bt_dev_set.lmp_version = rp->lmp_version;
    bt_dev_set.lmp_subversion = rp->lmp_subversion;
    bt_dev_set.manufacturer = rp->manufacturer;
}

static void hci_handle_cmd_cmp_evt_read_le_features_complete(struct net_buf *buf)
{
    struct bt_hci_rp_le_read_local_features *rp = (void *)buf->data;

    BT_DBG("status 0x%02x", rp->status);

    memcpy(bt_dev_set.le.features, rp->features, sizeof(bt_dev_set.le.features));
}

#if defined(CONFIG_BT_CONN)
static void hci_handle_cmd_cmp_evt_le_read_buffer_size_complete(struct net_buf *buf)
{
    struct bt_hci_rp_le_read_buffer_size *rp = (void *)buf->data;

    BT_DBG("status 0x%02x", rp->status);

    bt_dev_set.le.acl_mtu = rp->le_max_len;
    if (!bt_dev_set.le.acl_mtu)
    {
        return;
    }

    BT_DBG("ACL LE buffers: pkts %u mtu %u", rp->le_max_num,
           bt_dev_set.le.acl_mtu);
}
#endif /* CONFIG_BT_CONN */

static void hci_handle_cmd_cmp_evt_read_supported_commands_complete(struct net_buf *buf)
{
    struct bt_hci_rp_read_supported_commands *rp = (void *)buf->data;

    BT_DBG("status 0x%02x", rp->status);

    memcpy(bt_dev_set.supported_commands, rp->commands,
           sizeof(bt_dev_set.supported_commands));
}

static void hci_handle_cmd_cmp_evt_read_local_features_complete(struct net_buf *buf)
{
    struct bt_hci_rp_read_local_features *rp = (void *)buf->data;

    BT_DBG("status 0x%02x", rp->status);

    memcpy(bt_dev_set.features[0], rp->features, sizeof(bt_dev_set.features[0]));
}

static void id_create(uint8_t id, bt_addr_le_t *addr, uint8_t *irk);
static void hci_handle_cmd_cmp_evt_read_bd_addr_complete(struct net_buf *buf)
{
    bt_addr_le_t addr;
    struct bt_hci_rp_read_bd_addr *rp;
    uint8_t *irk = NULL;
    rp = (void *)buf->data;
    if (!bt_addr_cmp(&rp->bdaddr, BT_ADDR_ANY) ||
            !bt_addr_cmp(&rp->bdaddr, BT_ADDR_NONE))
    {
        BT_DBG("Controller has no public address");
        return;
    }
    bt_addr_copy(&addr.a, &rp->bdaddr);
    addr.type = BT_ADDR_LE_PUBLIC;

    bt_dev_set.id_count = 1;

    id_create(BT_ID_DEFAULT, &addr, irk);
}


struct hci_command_complete_process_handler
{
    uint16_t opcode;
    void (*handler)(struct net_buf *rsp);
};

#define HCI_COMMAND_COMPLETE_HANDLER(_opcode, _handler) \
{ \
	.opcode = _opcode, \
	.handler = _handler, \
}

static const struct hci_command_complete_process_handler hci_cmd_cmp_handles[] =
{
    HCI_COMMAND_COMPLETE_HANDLER(BT_HCI_OP_RESET
                                 , hci_handle_cmd_cmp_evt_reset_complete),
    HCI_COMMAND_COMPLETE_HANDLER(BT_HCI_OP_READ_LOCAL_FEATURES
                                 , hci_handle_cmd_cmp_evt_read_local_features_complete),
    HCI_COMMAND_COMPLETE_HANDLER(BT_HCI_OP_READ_LOCAL_VERSION_INFO
                                 , hci_handle_cmd_cmp_evt_read_local_ver_complete),
    HCI_COMMAND_COMPLETE_HANDLER(BT_HCI_OP_READ_SUPPORTED_COMMANDS
                                 , hci_handle_cmd_cmp_evt_read_supported_commands_complete),
    HCI_COMMAND_COMPLETE_HANDLER(BT_HCI_OP_LE_READ_LOCAL_FEATURES
                                 , hci_handle_cmd_cmp_evt_read_le_features_complete),
    HCI_COMMAND_COMPLETE_HANDLER(BT_HCI_OP_READ_BD_ADDR
                                 , hci_handle_cmd_cmp_evt_read_bd_addr_complete),
    HCI_COMMAND_COMPLETE_HANDLER(BT_HCI_OP_LE_READ_BUFFER_SIZE
                                 , hci_handle_cmd_cmp_evt_le_read_buffer_size_complete),

};

static inline void handle_hci_command_complete_work(uint16_t opcode, struct net_buf *buf,
        const struct hci_command_complete_process_handler *handlers,
        size_t num_handlers)
{
    size_t i;

    for (i = 0; i < num_handlers; i++)
    {
        const struct hci_command_complete_process_handler *handler = &handlers[i];

        if (handler->opcode != opcode)
        {
            continue;
        }

        handler->handler(buf);
        return;
    }

    BT_WARN("Unhandled opcode 0x%02x, status: 0x%x", opcode, buf->data[0]);
}

static void hci_init_process(int opcode, struct net_buf *rsp);
static void hci_handle_evt_cmd_complete(struct net_buf *buf)
{
    struct bt_hci_evt_cmd_complete *evt;
    uint8_t status, ncmd;
    uint16_t opcode;

    evt = net_buf_pull_mem(buf, sizeof(*evt));
    ncmd = evt->ncmd;
    opcode = evt->opcode;

    BT_DBG("opcode 0x%04x", opcode);

    /* All command return parameters have a 1-byte status in the
     * beginning, so we can safely make this generalization.
     */
    status = buf->data[0];

    hci_cmd_done(opcode, status, buf);

    handle_hci_command_complete_work(opcode, buf, hci_cmd_cmp_handles
                                     , ARRAY_SIZE(hci_cmd_cmp_handles));

    hci_init_process(opcode, buf);
}

int gWorkInInitialWork = 0;
int gWorkInInitialWorkProcess = 0;
static int hci_le_init_process(int opcode)
{
    struct net_buf *buf;
    struct bt_hci_cp_write_le_host_supp *cp_le;
    int err;

#if defined(CONFIG_BT_CONN)
    /* Read LE Buffer Size */
    err = bt_hci_cmd_send(BT_HCI_OP_LE_READ_BUFFER_SIZE, NULL);
    if (err)
    {
        return err;
    }
#endif /* CONFIG_BT_CONN */

    if(opcode == BT_HCI_OP_LE_READ_LOCAL_FEATURES)
    {
        if (BT_FEAT_BREDR(bt_dev_set.features))
        {
            buf = bt_hci_cmd_create(BT_HCI_OP_LE_WRITE_LE_HOST_SUPP,
                                    sizeof(*cp_le));
            if (!buf)
            {
                return -ENOBUFS;
            }

            cp_le = net_buf_add(buf, sizeof(*cp_le));

            /* Explicitly enable LE for dual-mode controllers */
            cp_le->le = 0x01;
            cp_le->simul = 0x00;
            // here not need wait.
            bt_hci_cmd_send(BT_HCI_OP_LE_WRITE_LE_HOST_SUPP
                            , buf);
        }
    }

    hci_send_cmd_le_set_event_mask();

le_init_process_end:
    return 0;
}
static void hci_init_end(int err)
{
    BT_INFO("hci_init_end, work end.");
    gWorkInInitialWork = 0;
    if (IS_ENABLED(CONFIG_BT_CONN))
    {
        err = bt_conn_init();
        if (err)
        {
            return err;
        }
    }

    bt_finalize_init();

    if (ready_cb)
    {
        ready_cb(err);
    }
}


static int hci_send_cmd_vs_set_public_addr(void)
{
    struct bt_hci_cp_vs_write_bd_addr *cp_bd_addr;
    struct net_buf *buf;

    /* Set LE event mask */
    buf = bt_hci_cmd_create(BT_HCI_OP_VS_WRITE_BD_ADDR, sizeof(*cp_bd_addr));
    if (!buf)
    {
        return -ENOBUFS;
    }
    cp_bd_addr = net_buf_add(buf, sizeof(*cp_bd_addr));

    cp_bd_addr->bdaddr.val[0] = 0x44;
    cp_bd_addr->bdaddr.val[1] = 0x55;
    cp_bd_addr->bdaddr.val[2] = 0x66;
    cp_bd_addr->bdaddr.val[3] = 0x77;
    cp_bd_addr->bdaddr.val[4] = 0x88;
    cp_bd_addr->bdaddr.val[5] = 0x99;

    return bt_hci_cmd_send(BT_HCI_OP_VS_WRITE_BD_ADDR, buf);
}


static void hci_init_process(int opcode, struct net_buf *rsp)
{
    if(!gWorkInInitialWork)
    {
        BT_INFO("hci_init_process, work error: 0x%04x",
                opcode);
        return;
    }
    switch(opcode)
    {
    case BT_HCI_OP_RESET:
        hci_send_cmd_vs_set_public_addr();
        break;
    case BT_HCI_OP_VS_WRITE_BD_ADDR:
        bt_hci_cmd_send(BT_HCI_OP_READ_LOCAL_FEATURES, NULL);
        break;
    case BT_HCI_OP_READ_LOCAL_FEATURES:
        bt_hci_cmd_send(BT_HCI_OP_READ_LOCAL_VERSION_INFO, NULL);
        break;
    case BT_HCI_OP_READ_LOCAL_VERSION_INFO:
        bt_hci_cmd_send(BT_HCI_OP_READ_SUPPORTED_COMMANDS, NULL);
        break;
    case BT_HCI_OP_READ_SUPPORTED_COMMANDS:
        /* For now we only support LE capable controllers */
        if (BT_FEAT_LE(bt_dev_set.features))
        {
            bt_hci_cmd_send(BT_HCI_OP_LE_READ_LOCAL_FEATURES, NULL);
        }
        break;
    case BT_HCI_OP_LE_READ_LOCAL_FEATURES:
        hci_le_init_process(opcode);
        break;

    case BT_HCI_OP_LE_SET_EVENT_MASK:
        hci_send_cmd_set_event_mask();
        break;

    case BT_HCI_OP_SET_EVENT_MASK:
        bt_hci_cmd_send(BT_HCI_OP_READ_BD_ADDR, NULL);
        break;

    case BT_HCI_OP_READ_BD_ADDR:
        hci_init_end(0);
        break;

    default:
        BT_WARN("hci_init_process, Unknown handle command: 0x%04x",
                opcode);
        break;
    }


}

static int hci_send_cmd_le_set_event_mask(void)
{
    struct bt_hci_cp_le_set_event_mask *cp_mask;
    struct net_buf *buf;
    uint64_t mask = 0U;

    /* Set LE event mask */
    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_EVENT_MASK, sizeof(*cp_mask));
    if (!buf)
    {
        return -ENOBUFS;
    }

    cp_mask = net_buf_add(buf, sizeof(*cp_mask));

    mask |= BT_EVT_MASK_LE_ADVERTISING_REPORT;

    if (IS_ENABLED(CONFIG_BT_CONN))
    {
        if ((IS_ENABLED(CONFIG_BT_SMP) &&
                BT_FEAT_LE_PRIVACY(bt_dev_set.le.features)))
        {
            /* C24:
             * Mandatory if the LE Controller supports Connection
             * State and either LE Feature (LL Privacy) or
             * LE Feature (Extended Advertising) is supported, ...
             */
            mask |= BT_EVT_MASK_LE_ENH_CONN_COMPLETE;
        }
        else
        {
            mask |= BT_EVT_MASK_LE_CONN_COMPLETE;
        }

        mask |= BT_EVT_MASK_LE_CONN_UPDATE_COMPLETE;
        mask |= BT_EVT_MASK_LE_REMOTE_FEAT_COMPLETE;

        if (BT_FEAT_LE_CONN_PARAM_REQ_PROC(bt_dev_set.le.features))
        {
            mask |= BT_EVT_MASK_LE_CONN_PARAM_REQ;
        }

        if (IS_ENABLED(CONFIG_BT_DATA_LEN_UPDATE) &&
                BT_FEAT_LE_DLE(bt_dev_set.le.features))
        {
            mask |= BT_EVT_MASK_LE_DATA_LEN_CHANGE;
        }

        if (IS_ENABLED(CONFIG_BT_PHY_UPDATE) &&
                (BT_FEAT_LE_PHY_2M(bt_dev_set.le.features) ||
                 BT_FEAT_LE_PHY_CODED(bt_dev_set.le.features)))
        {
            mask |= BT_EVT_MASK_LE_PHY_UPDATE_COMPLETE;
        }
    }

    if (IS_ENABLED(CONFIG_BT_SMP) &&
            BT_FEAT_LE_ENCR(bt_dev_set.le.features))
    {
        mask |= BT_EVT_MASK_LE_LTK_REQUEST;
    }

    BT_ERR("le_set_event_mask, mask: 0x%x.", mask);

    sys_put_le64(mask, cp_mask->events);

    return bt_hci_cmd_send(BT_HCI_OP_LE_SET_EVENT_MASK, buf);
}

static int hci_send_cmd_set_event_mask(void)
{
    struct bt_hci_cp_set_event_mask *ev;
    struct net_buf *buf;
    uint64_t mask = 0U;

    buf = bt_hci_cmd_create(BT_HCI_OP_SET_EVENT_MASK, sizeof(*ev));
    if (!buf)
    {
        return -ENOBUFS;
    }

    ev = net_buf_add(buf, sizeof(*ev));

    mask |= BT_EVT_MASK_HARDWARE_ERROR;
    mask |= BT_EVT_MASK_DATA_BUFFER_OVERFLOW;
    mask |= BT_EVT_MASK_LE_META_EVENT;

    if (IS_ENABLED(CONFIG_BT_CONN))
    {
        mask |= BT_EVT_MASK_DISCONN_COMPLETE;
        mask |= BT_EVT_MASK_REMOTE_VERSION_INFO;
    }

    if (IS_ENABLED(CONFIG_BT_SMP) &&
            BT_FEAT_LE_ENCR(bt_dev_set.le.features))
    {
        mask |= BT_EVT_MASK_ENCRYPT_CHANGE;
        mask |= BT_EVT_MASK_ENCRYPT_KEY_REFRESH_COMPLETE;
    }

    sys_put_le64(mask, ev->events);

    return bt_hci_cmd_send(BT_HCI_OP_SET_EVENT_MASK, buf);
}

static inline int create_random_addr(bt_addr_le_t *addr)
{
    addr->type = BT_ADDR_LE_RANDOM;

    return bt_rand(addr->a.val, 6);
}

int bt_addr_le_create_nrpa(bt_addr_le_t *addr)
{
    int err;

    err = create_random_addr(addr);
    if (err)
    {
        return err;
    }

    BT_ADDR_SET_NRPA(&addr->a);

    return 0;
}

int bt_addr_le_create_static(bt_addr_le_t *addr)
{
    int err;

    err = create_random_addr(addr);
    if (err)
    {
        return err;
    }

    BT_ADDR_SET_STATIC(&addr->a);

    return 0;
}

#if defined(CONFIG_BT_DEBUG)
static const char *ver_str(uint8_t ver)
{
    const char *const str[] =
    {
        "1.0b", "1.1", "1.2", "2.0", "2.1", "3.0", "4.0", "4.1", "4.2",
        "5.0", "5.1", "5.2"
    };

    if (ver < ARRAY_SIZE(str))
    {
        return str[ver];
    }

    return "unknown";
}

static void bt_dev_show_info(void)
{
    int i;

    BT_INFO("Identity%s: %s", bt_dev_set.id_count > 1 ? "[0]" : "",
            bt_addr_le_str(&bt_dev_set.id_addr[0]));

    for (i = 1; i < bt_dev_set.id_count; i++)
    {
        BT_INFO("Identity[%d]: %s",
                i, bt_addr_le_str(&bt_dev_set.id_addr[i]));
    }

    BT_INFO("HCI: version %s (0x%02x) revision 0x%04x, manufacturer 0x%04x",
            ver_str(bt_dev_set.hci_version), bt_dev_set.hci_version,
            bt_dev_set.hci_revision, bt_dev_set.manufacturer);
    BT_INFO("LMP: version %s (0x%02x) subver 0x%04x",
            ver_str(bt_dev_set.lmp_version), bt_dev_set.lmp_version,
            bt_dev_set.lmp_subversion);
}
#else
static inline void bt_dev_show_info(void)
{
}
#endif /* CONFIG_BT_DEBUG */

#if defined(CONFIG_BT_HCI_VS_EXT)
static void hci_vs_init(void)
{
}
#endif /* CONFIG_BT_HCI_VS_EXT */

static int hci_init(void)
{
    int err;

    BT_INFO("hci_init");

    sys_sflist_init(&bt_dev_set.cmd_tx_queue);
    sys_sflist_init(&bt_dev_set.rx_queue);

    gWorkInInitialWork = 1;
    /* Send HCI_RESET */
    err = bt_hci_cmd_send(BT_HCI_OP_RESET, NULL);

    return err;
}

int bt_send(struct net_buf *buf)
{
    BT_DBG("buf %p len %u type %u", buf, buf->len, bt_buf_get_type(buf));

    return bt_dev_set.drv->send(buf);
}

static const struct event_handler prio_events[] =
{
    EVENT_HANDLER(BT_HCI_EVT_CMD_COMPLETE
                  , hci_handle_evt_cmd_complete
                  , sizeof(struct bt_hci_evt_cmd_complete)),
    EVENT_HANDLER(BT_HCI_EVT_CMD_STATUS
                  , hci_handle_evt_cmd_status
                  , sizeof(struct bt_hci_evt_cmd_status)),
#if defined(CONFIG_BT_CONN)
    EVENT_HANDLER(BT_HCI_EVT_DATA_BUF_OVERFLOW
                  , hci_handle_evt_data_buf_overflow
                  , sizeof(struct bt_hci_evt_data_buf_overflow)),
    EVENT_HANDLER(BT_HCI_EVT_NUM_COMPLETED_PACKETS
                  , hci_handle_evt_num_completed_packets
                  , sizeof(struct bt_hci_evt_num_completed_packets)),
    EVENT_HANDLER(BT_HCI_EVT_DISCONN_COMPLETE
                  , hci_handle_evt_disconnect_complete_prio
                  , sizeof(struct bt_hci_evt_disconn_complete)),

#endif /* CONFIG_BT_CONN */
};

void hci_handle_event_prio(struct net_buf *buf)
{
    struct net_buf_simple_state state;
    struct bt_hci_evt_hdr *hdr;
    uint8_t evt_flags;

    net_buf_simple_save(&buf->b, &state);

    BT_ASSERT(buf->len >= sizeof(*hdr));

    hdr = net_buf_pull_mem(buf, sizeof(*hdr));
    evt_flags = bt_hci_evt_get_flags(hdr->evt);
    BT_ASSERT(evt_flags & BT_HCI_EVT_FLAG_RECV_PRIO);

    handle_event(hdr->evt, buf, prio_events, ARRAY_SIZE(prio_events));

    if (evt_flags & BT_HCI_EVT_FLAG_RECV)
    {
        net_buf_simple_restore(&buf->b, &state);
    }
    else
    {
        net_buf_unref(buf);
    }
}

int bt_recv(struct net_buf *buf)
{
#if CONFIG_BT_STACK_MODE == BT_STACK_MODE_HOST_AND_CONTROLLER
    DEBUG_LOG_PRINT_HCI_H4_RAW(1, bt_get_h4_type_by_buffer(bt_buf_get_type(buf))
                               , buf->data, buf->len);
#endif

    struct bt_hci_evt_hdr *hdr = (void *)buf->data;
    uint8_t evt_flags = bt_hci_evt_get_flags(hdr->evt);

    BT_DBG("bt_recv, evt: 0x%x, evt_flags: 0x%x, buf %p len %u pool %x", hdr->evt, evt_flags, buf, buf->len, buf->pool_id);

    if (evt_flags & BT_HCI_EVT_FLAG_RECV_PRIO)
    {
        hci_handle_event_prio(buf);
    }

    if (evt_flags & BT_HCI_EVT_FLAG_RECV)
    {
        net_buf_put(&bt_dev_set.rx_queue, buf);
    }
}

int bt_hci_driver_register(const struct bt_hci_driver *drv)
{
    if (bt_dev_set.drv)
    {
        return -EALREADY;
    }

    if (!drv->open || !drv->send)
    {
        return -EINVAL;
    }

    bt_dev_set.drv = drv;

    return 0;
}

void bt_finalize_init(void)
{
    BT_INFO("bt_finalize_init.");
    atomic_set_bit(bt_dev_set.flags, BT_DEV_READY);

    if (IS_ENABLED(CONFIG_BT_OBSERVER))
    {
        bt_le_scan_update(false);
    }

    bt_dev_show_info();
}

static int bt_init(void)
{
    int err;

    err = hci_init();
    if (err)
    {
        return err;
    }

    return 0;
}

static void hci_rx_thread(void)
{
    struct net_buf *buf;
    if(sys_sflist_is_empty(&bt_dev_set.rx_queue))
    {
        return;
    }

    BT_DBG("calling fifo_get_wait");
    buf = net_buf_get(&bt_dev_set.rx_queue, 0);
    BT_DBG("buf %p type %u len %u", buf, bt_buf_get_type(buf),
           buf->len);

    switch (bt_buf_get_type(buf))
    {
#if defined(CONFIG_BT_CONN)
    case BT_BUF_ACL_IN:
        hci_handle_acl(buf);
        break;
#endif /* CONFIG_BT_CONN */
    case BT_BUF_EVT:
        hci_handle_event(buf);
        break;
    default:
        BT_ERR("Unknown buf type %u", bt_buf_get_type(buf));
        net_buf_unref(buf);
        break;
    }

}

int bt_polling_work(void)
{
    hci_tx_thread();
    hci_rx_thread();
#if CONFIG_BT_STACK_MODE == BT_STACK_MODE_HOST_AND_CONTROLLER
    hci_driver_polling_work();
#endif
}

int bt_enable(bt_ready_cb_t cb)
{
    int err;

    BT_INFO("bt_enable");
#if CONFIG_BT_STACK_MODE == BT_STACK_MODE_HOST_AND_CONTROLLER
    // contact a uart or other device.
    hci_driver_init();
#else

#endif

    if (!bt_dev_set.drv)
    {
        BT_ERR("No HCI driver registered");
        return -ENODEV;
    }

    if (atomic_test_and_set_bit(bt_dev_set.flags, BT_DEV_ENABLE))
    {
        return -EALREADY;
    }

    ready_cb = cb;

    err = bt_dev_set.drv->open();
    if (err)
    {
        BT_ERR("HCI driver open failed (%d)", err);
        return err;
    }

    bt_init();
}

struct bt_ad
{
    const struct bt_data *data;
    size_t len;
};

static int set_data_add(uint8_t *set_data, uint8_t set_data_len_max,
                        const struct bt_ad *ad, size_t ad_len, uint8_t *data_len)
{
    uint8_t set_data_len = 0;

    for (size_t i = 0; i < ad_len; i++)
    {
        const struct bt_data *data = ad[i].data;

        for (size_t j = 0; j < ad[i].len; j++)
        {
            size_t len = data[j].data_len;
            uint8_t type = data[j].type;

            /* Check if ad fit in the remaining buffer */
            if ((set_data_len + len + 2) > set_data_len_max)
            {
                ssize_t shortened_len = set_data_len_max -
                                        (set_data_len + 2);

                if (!(type == BT_DATA_NAME_COMPLETE &&
                        shortened_len > 0))
                {
                    BT_ERR("Too big advertising data");
                    return -EINVAL;
                }

                type = BT_DATA_NAME_SHORTENED;
                len = shortened_len;
            }

            set_data[set_data_len++] = len + 1;
            set_data[set_data_len++] = type;

            memcpy(&set_data[set_data_len], data[j].data, len);
            set_data_len += len;
        }
    }

    *data_len = set_data_len;
    return 0;
}

static int hci_set_ad(uint16_t hci_op, const struct bt_ad *ad, size_t ad_len)
{
    struct bt_hci_cp_le_set_adv_data *set_data;
    struct net_buf *buf;
    int err;

    buf = bt_hci_cmd_create(hci_op, sizeof(*set_data));
    if (!buf)
    {
        return -ENOBUFS;
    }

    set_data = net_buf_add(buf, sizeof(*set_data));
    (void)memset(set_data, 0, sizeof(*set_data));

    err = set_data_add(set_data->data, BT_GAP_ADV_MAX_ADV_DATA_LEN,
                       ad, ad_len, &set_data->len);
    if (err)
    {
        net_buf_unref(buf);
        return err;
    }

    return bt_hci_cmd_send(hci_op, buf);
}

static int hci_send_cmd_le_set_adv_data(struct bt_le_ext_adv *adv, const struct bt_ad *ad,
                                        size_t ad_len)
{
    return hci_set_ad(BT_HCI_OP_LE_SET_ADV_DATA, ad, ad_len);
}

static int hci_send_cmd_le_set_scan_rsp_data(struct bt_le_ext_adv *adv, const struct bt_ad *sd,
        size_t sd_len)
{
    return hci_set_ad(BT_HCI_OP_LE_SET_SCAN_RSP_DATA, sd, sd_len);
}

const char *bt_get_name(void)
{
    return CONFIG_BT_DEVICE_NAME;
}

static int id_find(const bt_addr_le_t *addr)
{
    uint8_t id;

    for (id = 0U; id < bt_dev_set.id_count; id++)
    {
        if (!bt_addr_le_cmp(addr, &bt_dev_set.id_addr[id]))
        {
            return id;
        }
    }

    return -ENOENT;
}

static void id_create(uint8_t id, bt_addr_le_t *addr, uint8_t *irk)
{
    if (addr && bt_addr_le_cmp(addr, BT_ADDR_LE_ANY))
    {
        bt_addr_le_copy(&bt_dev_set.id_addr[id], addr);
    }
    else
    {
        bt_addr_le_t new_addr;

        do
        {
            bt_addr_le_create_static(&new_addr);
            /* Make sure we didn't generate a duplicate */
        }
        while (id_find(&new_addr) >= 0);

        bt_addr_le_copy(&bt_dev_set.id_addr[id], &new_addr);

        if (addr)
        {
            bt_addr_le_copy(addr, &bt_dev_set.id_addr[id]);
        }
    }

#if defined(CONFIG_BT_PRIVACY)
    {
        uint8_t zero_irk[16] = { 0 };

        if (irk && memcmp(irk, zero_irk, 16))
        {
            memcpy(&bt_dev_set.irk[id], irk, 16);
        }
        else
        {
            bt_rand(&bt_dev_set.irk[id], 16);
            if (irk)
            {
                memcpy(irk, &bt_dev_set.irk[id], 16);
            }
        }
    }
#endif
    /* Only store if stack was already initialized. Before initialization
     * we don't know the flash content, so it's potentially harmful to
     * try to write anything there.
     */
    if (IS_ENABLED(CONFIG_BT_SETTINGS) &&
            atomic_test_bit(bt_dev_set.flags, BT_DEV_READY))
    {
        bt_settings_save_id();
    }
}

bool bt_addr_le_is_bonded(uint8_t id, const bt_addr_le_t *addr)
{
    if (IS_ENABLED(CONFIG_BT_SMP))
    {
        struct bt_keys *keys = bt_keys_find_addr(id, addr);

        /* if there are any keys stored then device is bonded */
        return keys && keys->keys;
    }
    else
    {
        return false;
    }
}


static bool valid_adv_ext_param(const struct bt_le_adv_param *param)
{
    if (param->id >= bt_dev_set.id_count ||
            !bt_addr_le_cmp(&bt_dev_set.id_addr[param->id], BT_ADDR_LE_ANY))
    {
        return false;
    }

    if (!(param->options & BT_LE_ADV_OPT_CONNECTABLE))
    {
        /*
         * BT Core 4.2 [Vol 2, Part E, 7.8.5]
         * The Advertising_Interval_Min and Advertising_Interval_Max
         * shall not be set to less than 0x00A0 (100 ms) if the
         * Advertising_Type is set to ADV_SCAN_IND or ADV_NONCONN_IND.
         */
        if (bt_dev_set.hci_version < BT_HCI_VERSION_5_0 &&
                param->interval_min < 0x00a0)
        {
            return false;
        }
    }

    if ((param->options & BT_LE_ADV_OPT_DIR_MODE_LOW_DUTY) ||
            !param->peer)
    {
        if (param->interval_min > param->interval_max ||
                param->interval_min < 0x0020 ||
                param->interval_max > 0x4000)
        {
            return false;
        }
    }

    if ((param->options & BT_LE_ADV_OPT_DISABLE_CHAN_37) &&
            (param->options & BT_LE_ADV_OPT_DISABLE_CHAN_38) &&
            (param->options & BT_LE_ADV_OPT_DISABLE_CHAN_39))
    {
        return false;
    }

    return true;
}

static bool valid_adv_param(const struct bt_le_adv_param *param)
{
    if (param->options & BT_LE_ADV_OPT_EXT_ADV)
    {
        return false;
    }

    if (param->peer && !(param->options & BT_LE_ADV_OPT_CONNECTABLE))
    {
        return false;
    }

    return valid_adv_ext_param(param);
}

static inline bool ad_has_name(const struct bt_data *ad, size_t ad_len)
{
    size_t i;

    for (i = 0; i < ad_len; i++)
    {
        if (ad[i].type == BT_DATA_NAME_COMPLETE ||
                ad[i].type == BT_DATA_NAME_SHORTENED)
        {
            return true;
        }
    }

    return false;
}

static int le_adv_update(struct bt_le_ext_adv *adv,
                         const struct bt_data *ad, size_t ad_len,
                         const struct bt_data *sd, size_t sd_len,
                         bool ext_adv, bool scannable, bool use_name)
{
    struct bt_ad d[2] = {};
    struct bt_data data;
    size_t d_len;
    int err;

    if (use_name)
    {
        const char *name = bt_get_name();

        if ((ad && ad_has_name(ad, ad_len)) ||
                (sd && ad_has_name(sd, sd_len)))
        {
            /* Cannot use name if name is already set */
            return -EINVAL;
        }

        data = (struct bt_data)BT_DATA(
                   BT_DATA_NAME_COMPLETE,
                   name, strlen(name));
    }

    if (!(ext_adv && scannable))
    {
        d_len = 1;
        d[0].data = ad;
        d[0].len = ad_len;

        if (use_name && !scannable)
        {
            d[1].data = &data;
            d[1].len = 1;
            d_len = 2;
        }

        err = hci_send_cmd_le_set_adv_data(adv, d, d_len);
        if (err)
        {
            return err;
        }
    }

    if (scannable)
    {
        d_len = 1;
        d[0].data = sd;
        d[0].len = sd_len;

        if (use_name)
        {
            d[1].data = &data;
            d[1].len = 1;
            d_len = 2;
        }

        err = hci_send_cmd_le_set_scan_rsp_data(adv, d, d_len);
        if (err)
        {
            return err;
        }
    }

    atomic_set_bit(adv->flags, BT_ADV_DATA_SET);
    return 0;
}

int bt_le_adv_update_data(const struct bt_data *ad, size_t ad_len,
                          const struct bt_data *sd, size_t sd_len)
{
    struct bt_le_ext_adv *adv = bt_adv_lookup_legacy();
    bool scannable, use_name;

    if (!adv)
    {
        return -EINVAL;
    }

    if (!atomic_test_bit(adv->flags, BT_ADV_ENABLED))
    {
        return -EAGAIN;
    }

    scannable = atomic_test_bit(adv->flags, BT_ADV_SCANNABLE);
    use_name = atomic_test_bit(adv->flags, BT_ADV_INCLUDE_NAME);

    return le_adv_update(adv, ad, ad_len, sd, sd_len, false, scannable,
                         use_name);
}

static uint8_t get_filter_policy(uint32_t options)
{
    if (!IS_ENABLED(CONFIG_BT_WHITELIST))
    {
        return BT_LE_ADV_FP_NO_WHITELIST;
    }
    else if ((options & BT_LE_ADV_OPT_FILTER_SCAN_REQ) &&
             (options & BT_LE_ADV_OPT_FILTER_CONN))
    {
        return BT_LE_ADV_FP_WHITELIST_BOTH;
    }
    else if (options & BT_LE_ADV_OPT_FILTER_SCAN_REQ)
    {
        return BT_LE_ADV_FP_WHITELIST_SCAN_REQ;
    }
    else if (options & BT_LE_ADV_OPT_FILTER_CONN)
    {
        return BT_LE_ADV_FP_WHITELIST_CONN_IND;
    }
    else
    {
        return BT_LE_ADV_FP_NO_WHITELIST;
    }
}

static uint8_t get_adv_channel_map(uint32_t options)
{
    uint8_t channel_map = 0x07;

    if (options & BT_LE_ADV_OPT_DISABLE_CHAN_37)
    {
        channel_map &= ~0x01;
    }

    if (options & BT_LE_ADV_OPT_DISABLE_CHAN_38)
    {
        channel_map &= ~0x02;
    }

    if (options & BT_LE_ADV_OPT_DISABLE_CHAN_39)
    {
        channel_map &= ~0x04;
    }

    return channel_map;
}

static int le_adv_set_random_addr(struct bt_le_ext_adv *adv, uint32_t options,
                                  bool dir_adv, uint8_t *own_addr_type)
{
    const bt_addr_le_t *id_addr;
    int err = 0;

    /* Set which local identity address we're advertising with */
    id_addr = &bt_dev_set.id_addr[adv->id];

    if (options & BT_LE_ADV_OPT_CONNECTABLE)
    {
#if defined(CONFIG_BT_PRIVACY)
        if (!(options & BT_LE_ADV_OPT_USE_IDENTITY))
        {
            err = le_adv_set_private_addr(adv);
            if (err)
            {
                return err;
            }

            if (BT_FEAT_LE_PRIVACY(bt_dev_set.le.features))
            {
                *own_addr_type = BT_HCI_OWN_ADDR_RPA_OR_RANDOM;
            }
            else
            {
                *own_addr_type = BT_ADDR_LE_RANDOM;
            }
        }
        else
#endif
        {
            /*
             * If Static Random address is used as Identity
             * address we need to restore it before advertising
             * is enabled. Otherwise NRPA used for active scan
             * could be used for advertising.
             */
            if (id_addr->type == BT_ADDR_LE_RANDOM)
            {
                err = hci_send_cmd_le_set_adv_random_address(adv, &id_addr->a);
                if (err)
                {
                    return err;
                }
            }

            *own_addr_type = id_addr->type;
        }

        if (dir_adv)
        {
            if (IS_ENABLED(CONFIG_BT_SMP) &&
                    !IS_ENABLED(CONFIG_BT_PRIVACY) &&
                    BT_FEAT_LE_PRIVACY(bt_dev_set.le.features) &&
                    (options & BT_LE_ADV_OPT_DIR_ADDR_RPA))
            {
                /* This will not use RPA for our own address
                 * since we have set zeroed out the local IRK.
                 */
                *own_addr_type |= BT_HCI_OWN_ADDR_RPA_MASK;
            }
        }
    }
    else
    {
        if (options & BT_LE_ADV_OPT_USE_IDENTITY)
        {
            if (id_addr->type == BT_ADDR_LE_RANDOM)
            {
                err = hci_send_cmd_le_set_adv_random_address(adv, &id_addr->a);
            }

            *own_addr_type = id_addr->type;
        }
        else
        {
            err = le_adv_set_private_addr(adv);
            *own_addr_type = BT_ADDR_LE_RANDOM;
        }

        if (err)
        {
            return err;
        }
    }

    return 0;
}

static int le_adv_start_add_conn(const struct bt_le_ext_adv *adv,
                                 struct bt_conn **out_conn)
{
    struct adv_id_check_data check_data =
    {
        .id = adv->id,
        .adv_enabled = false
    };
    struct bt_conn *conn;

    // check is already have connectable adv in work.
    bt_adv_foreach(adv_id_check_connectable_func, &check_data);
    if (check_data.adv_enabled)
    {
        return -ENOTSUP;
    }

    bt_dev_set.adv_conn_id = adv->id;

    if (!bt_addr_le_cmp(&adv->target_addr, BT_ADDR_LE_ANY))
    {
        /* Undirected advertising */
        conn = bt_conn_add_le(adv->id, BT_ADDR_LE_NONE);
        if (!conn)
        {
            return -ENOMEM;
        }

        bt_conn_set_state(conn, BT_CONN_CONNECT_ADV);
        *out_conn = conn;
        return 0;
    }

    if (bt_conn_exists_le(adv->id, &adv->target_addr))
    {
        return -EINVAL;
    }

    conn = bt_conn_add_le(adv->id, &adv->target_addr);
    if (!conn)
    {
        return -ENOMEM;
    }

    bt_conn_set_state(conn, BT_CONN_CONNECT_DIR_ADV);
    *out_conn = conn;
    return 0;
}

int bt_le_adv_start_legacy(struct bt_le_ext_adv *adv,
                           const struct bt_le_adv_param *param,
                           const struct bt_data *ad, size_t ad_len,
                           const struct bt_data *sd, size_t sd_len)
{
    struct bt_hci_cp_le_set_adv_param set_param;
    struct bt_conn *conn = NULL;
    struct net_buf *buf;
    bool dir_adv = (param->peer != NULL), scannable;
    int err;

    if (!atomic_test_bit(bt_dev_set.flags, BT_DEV_READY))
    {
        return -EAGAIN;
    }

    if (!valid_adv_param(param))
    {
        return -EINVAL;
    }

    if (atomic_test_bit(adv->flags, BT_ADV_ENABLED))
    {
        return -EALREADY;
    }

    (void)memset(&set_param, 0, sizeof(set_param));

    set_param.min_interval = param->interval_min;
    set_param.max_interval = param->interval_max;
    set_param.channel_map = get_adv_channel_map(param->options);
    set_param.filter_policy = get_filter_policy(param->options);

    if (adv->id != param->id)
    {
        atomic_clear_bit(bt_dev_set.flags, BT_DEV_RPA_VALID);
    }

    adv->id = param->id;
    bt_dev_set.adv_conn_id = adv->id;

    err = le_adv_set_random_addr(adv, param->options, dir_adv,
                                 &set_param.own_addr_type);
    if (err)
    {
        return err;
    }

    if (dir_adv)
    {
        bt_addr_le_copy(&adv->target_addr, param->peer);
    }
    else
    {
        bt_addr_le_copy(&adv->target_addr, BT_ADDR_LE_ANY);
    }

    if (param->options & BT_LE_ADV_OPT_CONNECTABLE)
    {
        scannable = true;

        if (dir_adv)
        {
            if (param->options & BT_LE_ADV_OPT_DIR_MODE_LOW_DUTY)
            {
                set_param.type = BT_HCI_ADV_DIRECT_IND_LOW_DUTY;
            }
            else
            {
                set_param.type = BT_HCI_ADV_DIRECT_IND;
            }

            bt_addr_le_copy(&set_param.direct_addr, param->peer);
        }
        else
        {
            set_param.type = BT_HCI_ADV_IND;
        }
    }
    else
    {
        scannable = sd || (param->options & BT_LE_ADV_OPT_USE_NAME);

        set_param.type = scannable ? BT_HCI_ADV_SCAN_IND :
                         BT_HCI_ADV_NONCONN_IND;
    }

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_SET_ADV_PARAM, sizeof(set_param));
    if (!buf)
    {
        return -ENOBUFS;
    }

    net_buf_add_mem(buf, &set_param, sizeof(set_param));

    err = bt_hci_cmd_send(BT_HCI_OP_LE_SET_ADV_PARAM, buf);
    if (err)
    {
        return err;
    }

    if (!dir_adv)
    {
        err = le_adv_update(adv, ad, ad_len, sd, sd_len, false,
                            scannable,
                            param->options & BT_LE_ADV_OPT_USE_NAME);
        if (err)
        {
            return err;
        }
    }

#if defined(CONFIG_BT_PERIPHERAL)
    if (param->options & BT_LE_ADV_OPT_CONNECTABLE)
    {
        err = le_adv_start_add_conn(adv, &conn);
        if (err)
        {
            BT_ERR("Failed to start advertiser, add conn error: %d", err);
            if (err == -ENOMEM && !dir_adv &&
                    !(param->options & BT_LE_ADV_OPT_ONE_TIME))
            {
                goto set_adv_state;
            }

            return err;
        }
    }
#endif

    err = hci_set_le_adv_enable(adv, true);
    if (err)
    {
        BT_ERR("Failed to start advertiser");
#if defined(CONFIG_BT_PERIPHERAL)
        if (conn)
        {
            bt_conn_set_state(conn, BT_CONN_DISCONNECTED);
        }
#endif

        return err;
    }

#if defined(CONFIG_BT_PERIPHERAL)
    if (conn)
    {
        /* If undirected connectable advertiser we have created a
         * connection object that we don't yet give to the application.
         * Since we don't give the application a reference to manage in
         * this case, we need to release this reference here
         */
    }
#endif

set_adv_state:
    atomic_set_bit_to(adv->flags, BT_ADV_PERSIST, !dir_adv &&
                      !(param->options & BT_LE_ADV_OPT_ONE_TIME));

    atomic_set_bit_to(adv->flags, BT_ADV_INCLUDE_NAME,
                      param->options & BT_LE_ADV_OPT_USE_NAME);

    atomic_set_bit_to(adv->flags, BT_ADV_CONNECTABLE,
                      param->options & BT_LE_ADV_OPT_CONNECTABLE);

    atomic_set_bit_to(adv->flags, BT_ADV_SCANNABLE, scannable);

    atomic_set_bit_to(adv->flags, BT_ADV_USE_IDENTITY,
                      param->options & BT_LE_ADV_OPT_USE_IDENTITY);

    return 0;
}

int bt_le_adv_start(const struct bt_le_adv_param *param,
                    const struct bt_data *ad, size_t ad_len,
                    const struct bt_data *sd, size_t sd_len)
{
    struct bt_le_ext_adv *adv = adv_new_legacy();
    int err;

    if (!adv)
    {
        return -ENOMEM;
    }

    err = bt_le_adv_start_legacy(adv, param, ad, ad_len, sd, sd_len);

    if (err)
    {
        adv_delete_legacy();
    }

    return err;
}

int bt_le_adv_stop(void)
{
    struct bt_le_ext_adv *adv = bt_adv_lookup_legacy();
    int err;

    if (!adv)
    {
        BT_ERR("No valid legacy adv");
        return 0;
    }

    /* Make sure advertising is not re-enabled later even if it's not
     * currently enabled (i.e. BT_DEV_ADVERTISING is not set).
     */
    atomic_clear_bit(adv->flags, BT_ADV_PERSIST);

    if (!atomic_test_bit(adv->flags, BT_ADV_ENABLED))
    {
        /* Legacy advertiser exists, but is not currently advertising.
         * This happens when keep advertising behavior is active but
         * no conn object is available to do connectable advertising.
         */
        adv_delete_legacy();
        return 0;
    }

#if defined(CONFIG_BT_PERIPHERAL)
    if (atomic_test_bit(adv->flags, BT_ADV_CONNECTABLE))
    {
        le_adv_stop_free_conn(adv, 0);
    }
#endif

    err = hci_send_cmd_le_set_adv_enable(adv, false);
    if (err)
    {
        return err;
    }


    adv_delete_legacy();

    return 0;
}

#if defined(CONFIG_BT_PERIPHERAL)
void bt_le_adv_resume(void)
{
    struct bt_le_ext_adv *adv = bt_adv_lookup_legacy();
    struct bt_conn *conn;
    bool persist_paused = false;
    int err;

    if (!adv)
    {
        BT_DBG("No valid legacy adv");
        return;
    }

    if (!(atomic_test_bit(adv->flags, BT_ADV_PERSIST) &&
            !atomic_test_bit(adv->flags, BT_ADV_ENABLED)))
    {
        return;
    }

    if (!atomic_test_bit(adv->flags, BT_ADV_CONNECTABLE))
    {
        return;
    }

    err = le_adv_start_add_conn(adv, &conn);
    if (err)
    {
        BT_DBG("Host cannot resume connectable advertising (%d)", err);
        return;
    }

    BT_DBG("Resuming connectable advertising");

#if defined(CONFIG_BT_PRIVACY)
    if (!atomic_test_bit(adv->flags, BT_ADV_USE_IDENTITY))
    {
        le_adv_set_private_addr(adv);
    }
#endif

    err = hci_set_le_adv_enable(adv, true);
    if (err)
    {
        BT_DBG("Controller cannot resume connectable advertising (%d)",
               err);
        bt_conn_set_state(conn, BT_CONN_DISCONNECTED);

        /* Temporarily clear persist flag to avoid recursion in
         * bt_conn_unref if the flag is still set.
         */
        persist_paused = atomic_test_and_clear_bit(adv->flags,
                         BT_ADV_PERSIST);
    }

    /* Since we don't give the application a reference to manage in
     * this case, we need to release this reference here.
     */
    if (persist_paused)
    {
        atomic_set_bit(adv->flags, BT_ADV_PERSIST);
    }
}
#endif /* defined(CONFIG_BT_PERIPHERAL) */


#if defined(CONFIG_BT_OBSERVER)
static bool valid_le_scan_param(const struct bt_le_scan_param *param)
{
    if (param->type != BT_HCI_LE_SCAN_PASSIVE &&
            param->type != BT_HCI_LE_SCAN_ACTIVE)
    {
        return false;
    }

    if (param->options & ~(BT_LE_SCAN_OPT_FILTER_DUPLICATE |
                           BT_LE_SCAN_OPT_FILTER_WHITELIST |
                           BT_LE_SCAN_OPT_CODED |
                           BT_LE_SCAN_OPT_NO_1M))
    {
        return false;
    }

    if (param->interval < 0x0004 || param->interval > 0x4000)
    {
        return false;
    }

    if (param->window < 0x0004 || param->window > 0x4000)
    {
        return false;
    }

    if (param->window > param->interval)
    {
        return false;
    }

    return true;
}

int bt_le_scan_start(const struct bt_le_scan_param *param, bt_le_scan_cb_t cb)
{
    int err;

    if (!atomic_test_bit(bt_dev_set.flags, BT_DEV_READY))
    {
        return -EAGAIN;
    }

    /* Check that the parameters have valid values */
    if (!valid_le_scan_param(param))
    {
        return -EINVAL;
    }

    /* Return if active scan is already enabled */
    if (atomic_test_and_set_bit(bt_dev_set.flags, BT_DEV_EXPLICIT_SCAN))
    {
        return -EALREADY;
    }


    if (atomic_test_bit(bt_dev_set.flags, BT_DEV_SCANNING))
    {
        err = set_le_scan_enable(BT_HCI_LE_SCAN_DISABLE);
        if (err)
        {
            atomic_clear_bit(bt_dev_set.flags, BT_DEV_EXPLICIT_SCAN);
            return err;
        }
    }

    atomic_set_bit_to(bt_dev_set.flags, BT_DEV_SCAN_FILTER_DUP,
                      param->options & BT_LE_SCAN_OPT_FILTER_DUPLICATE);

#if defined(CONFIG_BT_WHITELIST)
    atomic_set_bit_to(bt_dev_set.flags, BT_DEV_SCAN_WL,
                      param->options & BT_LE_SCAN_OPT_FILTER_WHITELIST);
#endif /* defined(CONFIG_BT_WHITELIST) */
    {
        if (param->timeout)
        {
            atomic_clear_bit(bt_dev_set.flags, BT_DEV_EXPLICIT_SCAN);
            return -ENOTSUP;
        }

        err = start_le_scan_legacy(param->type, param->interval,
                                   param->window);
    }

    if (err)
    {
        atomic_clear_bit(bt_dev_set.flags, BT_DEV_EXPLICIT_SCAN);
        return err;
    }

    scan_dev_found_cb = cb;

    return 0;
}

int bt_le_scan_stop(void)
{
    /* Return if active scanning is already disabled */
    if (!atomic_test_and_clear_bit(bt_dev_set.flags, BT_DEV_EXPLICIT_SCAN))
    {
        return -EALREADY;
    }

    scan_dev_found_cb = NULL;

    return bt_le_scan_update(false);
}
#endif /* CONFIG_BT_OBSERVER */





int hci_send_cmd_le_conn_update(const struct hci_cp_le_conn_update *param)
{
    struct net_buf *buf;

    buf = bt_hci_cmd_create(BT_HCI_OP_LE_CONN_UPDATE,
                            sizeof(*param));
    if (!buf)
    {
        return -ENOBUFS;
    }
    net_buf_add_mem(buf, param, sizeof(*param));

    return bt_hci_cmd_send(BT_HCI_OP_LE_CONN_UPDATE, buf);
}


