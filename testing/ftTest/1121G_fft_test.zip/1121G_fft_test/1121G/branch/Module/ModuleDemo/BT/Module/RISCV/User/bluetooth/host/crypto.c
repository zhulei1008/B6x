/*
 * Copyright (c) 2017 Nordic Semiconductor ASA
 * Copyright (c) 2015-2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <string.h>
#include <errno.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/conn.h>
#include <bluetooth/crypto.h>


#define BT_DBG_ENABLED IS_ENABLED(CONFIG_BT_DEBUG_HCI_CORE)
#define LOG_MODULE_NAME bt_crypto
#include "logging/bt_log.h"

#include "hci_core.h"

int bt_rand(void *buf, size_t len)
{
    //return lll_csrand_get(buf, len);
	return 0;
}

int bt_encrypt_le(const uint8_t key[16], const uint8_t plaintext[16],
                  uint8_t enc_data[16])
{
    BT_DBG("key %s", bt_hex(key, 16));
    BT_DBG("plaintext %s", bt_hex(plaintext, 16));

    // Our asic is negated
    //aes_encrypt(AES_BIG_ENDIAN, key, plaintext, 16);
    //aes_result(enc_data);

    BT_DBG("enc_data %s", bt_hex(enc_data, 16));

    return 0;
}

int bt_encrypt_sk(const uint8_t key[16], const uint8_t plaintext[16],
                  uint8_t enc_data[16])
{
    BT_DBG("sk key %s", bt_hex(key, 16));
    BT_DBG("sk plaintext %s", bt_hex(plaintext, 16));

    // Our asic is negated
    //aes_encrypt(AES_BIG_ENDIAN, key, plaintext, 16);
    //aes_encrypt_ctrl(0);        // little out
    //aes_result(enc_data);

    BT_DBG("sk enc_data %s", bt_hex(enc_data, 16));

    return 0;
}

