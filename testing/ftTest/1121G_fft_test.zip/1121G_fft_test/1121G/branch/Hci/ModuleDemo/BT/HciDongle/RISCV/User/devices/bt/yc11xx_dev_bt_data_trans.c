#include "yc11xx_dev_bt_data_trans.h"
#include "btreg.h"
#include "yc_debug.h"
#include "yc11xx_ipc.h"
#define FUNCTION_BT_HCI
#ifdef FUNCTION_BT_HCI
#include "yc11xx_h4.h"
#endif

//#include "system.h"
extern void Bt_BleOTACallBack(uint8_t len,uint8_t *dataPtr);

BT_HCI_DATA_FIFO gHciDataFifo;
BT_HCI_DATA_FIFO *gpHciDataFifo;
BT_HCI_DATA_DEBUG gHciDataDebug;


void Bt_HciFifoInit(void)
{
    gpHciDataFifo = &gHciDataFifo;
    memset((void *)gpHciDataFifo, 0, sizeof(BT_HCI_DATA_FIFO));
    memset((void *)&gHciDataDebug, 0, sizeof(BT_HCI_DATA_DEBUG));
}
BT_HCI_DATA *Bt_HciGetSendBufferPtr(void)
{
    BT_HCI_DATA_FIFO* pFifo = gpHciDataFifo;
    return &(pFifo->queue[pFifo->wptr]);
}

void Bt_HciFifoIn(void)
{
    BT_HCI_DATA_FIFO* pFifo = gpHciDataFifo;
    if(pFifo->cnt >= HCI_QUEUE_MAX)
    {
        return;
    }
    pFifo->cnt++;
    pFifo->wptr += 1;
    if(pFifo->wptr == HCI_QUEUE_MAX)
    {
    	pFifo->wptr = 0;
    }
}

void Bt_HciFifoOut(void)
{
    BT_HCI_DATA_FIFO* pFifo = gpHciDataFifo;
    if(pFifo->cnt == 0)
    {
        return;
    }
    pFifo->cnt--;
    pFifo->rptr += 1;
    //if(prxDataFifo->wptr == M0_SCO_RX_BUFFER_SIZE)
    if(pFifo->rptr == HCI_QUEUE_MAX)
    {
    	pFifo->rptr = 0;
    }
}
uint8_t Bt_HciCheckBufferFull(void)
{
    BT_HCI_DATA_FIFO* pFifo = gpHciDataFifo;
    if(pFifo->cnt >= HCI_QUEUE_MAX)
    {
        return 1;
    }
    return 0;
}

void Bt_HciWaitBufferElement(void)
{
    while(Bt_HciCheckBufferFull());
}

void Bt_SndToBtData(uint8_t subType, uint32_t payloadPtr)
{
    OS_ENTER_CRITICAL();
    uint8_t data[4];
    data[0] = subType;
    data[1] = payloadPtr;
    data[2] = payloadPtr >> 8;
    data[3] = payloadPtr >> 16;
    IPC_TxCommon(IPC_TYPE_CM0_TO_BT_DATA, data, sizeof(data));
    OS_EXIT_CRITICAL();
    DEBUG_LOG(LOG_LEVEL_CORE, "IPC" ,"Bt_SndToBtData: 0x%04X", LOG_POINT_9005, subType);
    DEBUG_LOG(LOG_LEVEL_CORE, "IPC" ,"Bt_SndToBtData: 0x%04X", LOG_POINT_9020, payloadPtr);
    switch(subType)
    {
        case IPC_DATA_SUBTYPE_BLE:
            gHciDataDebug.bleTxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_SPP:
            gHciDataDebug.sppTxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_SCO:
            gHciDataDebug.scoTxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_AAP:
            gHciDataDebug.aapTxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_HID:
            gHciDataDebug.hidTxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_FREE:
           // DEBUG_LOG_STRING("Bt_SndToBtData free:addr=0x%x\r\n",payloadPtr);
            gHciDataDebug.freeTxCnt ++;
            break;
#ifdef FUNCTION_BT_HCI
        case IPC_DATA_SUBTYPE_HCI:
            break;
        case IPC_DATA_SUBTYPE_ACL_BLE:
            break;
        case IPC_DATA_SUBTYPE_ACL_CLASSIC:
            break;
#endif
    }
}

// Avoid work in interrupt
void Bt_SndDataToRespin(uint8_t type, const uint8_t *data, uint16_t len)
{
    BT_HCI_DATA* pHciData = Bt_HciGetSendBufferPtr();
 //   DEBUG_LOG_STRING("pHciData->data 1  ==== 0x%04x\r\n",pHciData->data);
  
    pHciData->data[0] = len;
    pHciData->data[1] = len >> 8; 
    memcpy((pHciData->data + 2), data, len);
    pHciData->len = len;
    pHciData->type = type;
    // Only send data ptr.
    Bt_SndToBtData(type, (uint32_t)pHciData->data);
    Bt_HciFifoIn();
}

void Bt_ParseRcvBLEPacket(uint8_t* payloadPtr, BLE_PacketRcvHeaderTypeDef* headerInfo, uint8_t* rcvBuf)
{
    // Parse packet
    uint16_t offset, l2capLength, l2capCid, attHandle, lenPayload;
    uint8_t attOpcode;
    uint32_t addrPayload;

    offset = 0;
    l2capLength = HREADW(payloadPtr + offset);
    offset += 2;
    l2capCid = HREADW(payloadPtr + offset);
    offset += 2;
    attOpcode = HREAD(payloadPtr + offset);
    offset += 1;
    attHandle = HREADW(payloadPtr + offset);
    offset += 2;
    lenPayload = (l2capLength - 3);
    addrPayload =(uint32_t) payloadPtr + offset;
    if(lenPayload != 0)
    {
        xmemcpy(rcvBuf, (uint8_t *)reg_map(addrPayload), lenPayload);
    }

    headerInfo->l2capLength = l2capLength;
    headerInfo->l2capCid = l2capCid;
    headerInfo->attHandle = attHandle;
    headerInfo->lenPayload = lenPayload;
    headerInfo->attOpcode = attOpcode;
}

void Bt_SppCallback(uint16_t len,uint8_t *dataPtr)
{
    DEBUG_LOG_STRING("Bt_SppCallback len: %d, dataPtr=0x%x\r\n", len, dataPtr);
    DEBUG_LOG_STRING("val: 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\r\n"
        , dataPtr[0], dataPtr[1], dataPtr[2], dataPtr[3]
        , dataPtr[4], dataPtr[5], dataPtr[6], dataPtr[7]);
    if(Bt_HciCheckBufferFull())
    {
        DEBUG_LOG_STRING("Bt_SppCallback ---- Snd Queue Full.");
        return;
    }
    if(len == 0)
    {
        DEBUG_LOG_STRING("Bt_SppCallback ---- Empty Data.");
        return;
    }

    Bt_SndDataToRespin(IPC_DATA_SUBTYPE_SPP, dataPtr, len);
#if 0
	BT_SPP_DATA_FIFO* pFifo = &gSppDataFifo;
	
    memcpy((pFifo->queue[pFifo->wptr].data), dataPtr, len);
    pFifo->queue[pFifo->wptr].len = len;
	MyPrintf("\r\npFifo->queue[pFifo->wptr].len=%d\r\n",len);
	if(!len)
	{
		//while(1);
		return;
	}
    Bt_SppFifoIn();
#endif
}

void Bt_ParseRcvSPPPacket(int8_t* payloadPtr, SPP_PacketRcvHeaderTypeDef* headerInfo, uint8_t* rcvBuf)
{
    // Parse packet
    uint16_t temp, lenPayload;
    uint8_t uihType, payloadStartOffset, lenExt;
    uint32_t addrPayload;

    //get packet start addr
    addrPayload = (uint32_t)payloadPtr;

    //get seq
    uihType = HREAD(addrPayload+5);
    lenPayload = HREAD(addrPayload+6);
    if(lenPayload & 0x01)
    {
        lenExt = 0;
    }
    else
    {
        lenExt = 1;
    }
    if(lenExt)
    {
        lenPayload = HREADW(addrPayload+6);
    }
    lenPayload = lenPayload >> 1;
    if(uihType == 0xEF)//RFCOMM_FRAME_TYPE_UIH
    {
        if(!lenExt)
        {
            payloadStartOffset = 7;
        }
        else
        {
            payloadStartOffset = 8;
        }
    }
    else
    {
        if(!lenExt)
        {
            payloadStartOffset = 8;
        }
        else
        {
            payloadStartOffset = 9;
        }
    }
#if 0
    if(lenPayload >= sizeof(rcvBuf))
    {
        HWRITE(0x4ff0, 1);
        MyPrintf("uihType: %02x, lenExt: %d, buf: %p, addr: 0x%x, lenPayload: %d"
        , uihType, lenExt, rcvBuf, addrPayload, 	lenPayload);
        _ASSERT_FAULT();
    }
#endif
    addrPayload = addrPayload + payloadStartOffset;
    //DEBUG_LOG_STRING("uihType: %02x, lenExt: %d, buf: %p, addr: 0x%x, lenPayload: %d \r\n"
    //    , uihType, lenExt, rcvBuf, addrPayload, lenPayload);
    xmemcpy(rcvBuf, (uint8_t *)reg_map(addrPayload), lenPayload);


    headerInfo->lenPayload = lenPayload;
    headerInfo->uihType = uihType;
#if 0
    int offset = 0;
    int startFlag = 0;
    for(int i = 0; i < lenPayload; i ++)
    {
        if((startFlag == 0))
        {
                if((rcvBuf[i] != 0))
                {
                        MyPrintf("4444 offset: %d, i: %d, val: 0x%x\r\n"
            	            , offset, i, rcvBuf[i]);
                    continue;
                }
                else
                {
                    startFlag = 1;
                    offset = i;
                }
        }
            if(rcvBuf[i] != (i - offset))
            {
                if((rcvBuf[i] == 0)
                    && (i != 0))
                {
                    offset = i;
                        MyPrintf("333 offset: %d, i: %d\r\n"
            	    , offset, i);
                    continue;
                }
                HWRITE(0x4ff0, 1);
            MyPrintf("22 uihType: %02x, lenExt: %d, buf: %p, addr: 0x%x, lenPayload: %d, off: %d, val: 0x%x, i: %d, cnt: 0x%x\r\n"
        , uihType, lenExt, rcvBuf, addrPayload, 	lenPayload, offset, rcvBuf[i], i, gTestPollRxCnt);
                _ASSERT_FAULT();
            }
    }
#endif
}

void Bt_ScoCallback(uint8_t *dataPtr)
{
    //DEBUG_LOG_STRING("Bt_ScoCallback dataPtr=0x%x\r\n", dataPtr);
    //DEBUG_LOG_STRING("Bt_ScoCallback val: 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\r\n"
       // , dataPtr[0], dataPtr[1], dataPtr[2], dataPtr[3]
       // , dataPtr[4], dataPtr[5], dataPtr[6], dataPtr[7]);

    Bt_SCORxRespinData(dataPtr);
}

void Bt_DataBufferCallBack(uint8_t len,uint8_t *dataPtr)
{
    uint32_t payloadPtr;
    uint8_t subType;
	uint16_t conn_handle;
    BLE_PacketRcvHeaderTypeDef headerInfoBle;
    SPP_PacketRcvHeaderTypeDef headerInfoSpp;
    //uint16_t lenPayload;
    uint8_t rcvBuf[628];
    subType = dataPtr[0];
    payloadPtr = reg_map(dataPtr[1] |(dataPtr[2]<<8)|(dataPtr[3]<<16));
    //DEBUG_LOG_STRING("Bt_DataBufferCallBack len: %d,  subType=0x%x,   payloadPtr=0x%x\r\n"
     //   , len, subType, payloadPtr);
    DEBUG_LOG(LOG_LEVEL_CORE, "IPC" ,"Bt_DataBufferCallBack: 0x%04X", LOG_POINT_9003, subType);
    DEBUG_LOG(LOG_LEVEL_CORE, "IPC" ,"Bt_DataBufferCallBack: 0x%04X", LOG_POINT_9004, payloadPtr);
   
    switch(subType) 
    {
        case IPC_DATA_SUBTYPE_FREE:
            /************************release tx buffer *****************************/
            Bt_HciFifoOut();
            break;
#ifdef FUNCTION_BT_HCI
        case IPC_DATA_SUBTYPE_HCI:
            // TODO: Need change to m0 ram.
            Bt_HciCallback((uint8_t *)payloadPtr);
            Bt_SndToBtData(IPC_DATA_SUBTYPE_FREE, payloadPtr);
            break;
        case IPC_DATA_SUBTYPE_ACL_BLE:
            conn_handle = dataPtr[4]+(dataPtr[5]<<8);
            Bt_ACLCallbackBle((uint8_t *)payloadPtr,conn_handle);
            Bt_SndToBtData(IPC_DATA_SUBTYPE_FREE, payloadPtr);
            break;
        case IPC_DATA_SUBTYPE_ACL_CLASSIC:
            conn_handle = dataPtr[4]+(dataPtr[5]<<8);
            Bt_ACLCallbackClassic((uint8_t *)payloadPtr,conn_handle);
            Bt_SndToBtData(IPC_DATA_SUBTYPE_FREE, payloadPtr);
            break;
#endif
    }

    
    switch(subType)
    {
        case IPC_DATA_SUBTYPE_BLE:
            gHciDataDebug.bleRxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_SPP:
            gHciDataDebug.sppRxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_SCO:
            gHciDataDebug.scoRxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_AAP:
            gHciDataDebug.aapRxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_HID:
            gHciDataDebug.hidRxCnt ++;
            break;
        case IPC_DATA_SUBTYPE_FREE:
            gHciDataDebug.freeRxCnt ++;
            break;
#ifdef FUNCTION_BT_HCI
        case IPC_DATA_SUBTYPE_HCI:
            break;
        case IPC_DATA_SUBTYPE_ACL_BLE:
            break;
        case IPC_DATA_SUBTYPE_ACL_CLASSIC:
            break;
#endif
    }
}



#ifdef FUNCTION_BT_HCI

void Bt_HciParseEvt(uint8_t evtCode, uint16_t len, uint8_t *dataPtr)
{
    uint16_t opcode = 0;
    uint8_t numPacket = 0;
    DEBUG_LOG_2(LOG_LEVEL_CORE, "HCI" ,"", LOG_POINT_E000, evtCode, len);
    if(evtCode == BT_HCI_EVT_CMD_COMPLETE)
    {
        numPacket = (*(dataPtr + 0) << 0);
        opcode = (*(dataPtr + 1) << 0) |(*(dataPtr + 2) << 8);
        DEBUG_LOG(LOG_LEVEL_CORE, "HCI" ,"", LOG_POINT_E001, opcode);
        DEBUG_LOG_2(LOG_LEVEL_CORE, "HCI" ,"", LOG_POINT_E002, (*(dataPtr + 3)), (*(dataPtr + 4)));
    }
    
}
void Bt_HciParseCmd(uint16_t opcode, uint8_t len, uint8_t *dataPtr)
{
    DEBUG_LOG(LOG_LEVEL_CORE, "HCI" ,"", LOG_POINT_E100, opcode);
    
}

void Bt_HciCallback(uint8_t *dataPtr)
{
    uint8_t type = *(dataPtr);
    uint16_t len = 0;
    uint16_t handle = 0;
    uint16_t totalLength = 0;
    uint8_t evtCode = 0;
    //Avoid host use respin buffer
    uint8_t evtBuffer[500];
    switch(type)
    {
        case H4_EVT:
            evtCode = *(dataPtr + 1);
            len = *(dataPtr + 2);
            totalLength = len+3;// 04 + evtCode(1) + length(1)
            
            //Avoid host use respin buffer
            xmemcpy(evtBuffer,dataPtr,totalLength);
            dataPtr = evtBuffer;

            Bt_HciParseEvt(evtCode, len, dataPtr + 3);

            
            break;
        case H4_ACL:
            handle = (*(dataPtr + 1) << 0) |(*(dataPtr + 2) << 8);
            len = (*(dataPtr + 3) << 0) |(*(dataPtr + 4) << 8);
            totalLength = len+5;// 02 + handle(2) + length(2)
            DEBUG_LOG(LOG_LEVEL_CORE, "HCI" ,"", LOG_POINT_E010, handle);
            DEBUG_LOG(LOG_LEVEL_CORE, "HCI" ,"", LOG_POINT_E011, len);
            break;
        default:
            //_ASSERT_FAULT();
            break;
    }


    h4_send_data(dataPtr, totalLength);
}

void Bt_HciParseRcvData(uint8_t *dataPtr, uint16_t len)
{
    uint8_t type = *(dataPtr);
    uint16_t handle = 0;
    uint16_t opcode = 0;
    switch(type)
    {
        case H4_CMD:
            opcode = (*(dataPtr + 1) << 0) |(*(dataPtr + 2) << 8);
            len = *(dataPtr + 3);
            Bt_HciParseCmd(opcode, len, dataPtr + 4);
            break;
        case H4_ACL:
            handle = (*(dataPtr + 1) << 0) |(*(dataPtr + 2) << 8);
            len = (*(dataPtr + 3) << 0) |(*(dataPtr + 4) << 8);
            DEBUG_LOG(LOG_LEVEL_CORE, "HCI" ,"", LOG_POINT_E110, handle);
            DEBUG_LOG(LOG_LEVEL_CORE, "HCI" ,"", LOG_POINT_E111, len);
            break;
        default:
            //_ASSERT_FAULT();
            break;
    }
    
}
void Bt_SndHciToRespin(uint8_t *data, uint16_t len)
{
    BT_HCI_DATA* pHciData = Bt_HciGetSendBufferPtr();

    memcpy((pHciData->data), data, len);
    pHciData->len = len;
    Bt_HciParseRcvData(data, len);
    Bt_SndToBtData(IPC_DATA_SUBTYPE_HCI, (uint32_t)pHciData->data);
    DEBUG_LOG_STRING("Bt_SndHciToRespin len=%d, payload=0x%x\r\n",len, (uint32_t)pHciData->data);
    if(!len)
    {
        //while(1);
        return;
    }
    Bt_HciFifoIn();
}

void Bt_ACLCallbackBle(uint8_t *dataPtr,uint16_t conn_handle)
{
	uint8_t packet[300];
	uint16_t handle = 0;
	uint16_t len=0;
	uint16_t totalLength = 0;
	handle = (((*(dataPtr))& 0x03)<<12)|conn_handle; 
	len = (*(dataPtr+1));
	packet[0] = H4_ACL;
	packet[1] = handle& 0xff;
	packet[2] = (handle>>8)& 0xff;
	packet[3] = len & 0xff;
	packet[4] = (len>>8)& 0xff;
	totalLength =len+5;
	xmemcpy(packet+5,dataPtr+2,len);
	Bt_HciCallback(packet);
}
void Bt_ACLCallbackClassic(uint8_t *dataPtr,uint16_t conn_handle)
{
	uint8_t packet[800];
	uint16_t handle = 0;
	uint16_t len=0;
	uint16_t totalLength = 0;
	handle = (((*(dataPtr))& 0x03)<<12)|conn_handle; 
	len = (*(dataPtr + 1) << 0) |(*(dataPtr + 2) << 8);
	packet[0] = H4_ACL;
	packet[1] = handle& 0xff;
	packet[2] = (handle>>8)& 0xff;
	packet[3] = len & 0xff;
	packet[4] = (len>>8)& 0xff;
	totalLength =len+5;
	xmemcpy(packet+5,dataPtr+3,len);
	Bt_HciCallback(packet);
}
#endif

