#include "yc11xx_dev_uart.h"
#include "yc11xx_dev_gpio.h"
#include "yc11xx_gpio.h"

#define UART_A_TX_GPIO GPIO_18
#define UART_A_RX_GPIO GPIO_8
#define UART_B_TX_GPIO GPIO_1
#define UART_B_RX_GPIO GPIO_2

void UART_GPIO_Init(UART_TypeDef UARTx)
{
	if(UARTA == UARTx)
	{
		YC_DevGpioInit(UART_A_RX_GPIO,GPIO_Mode_Uart_Rxd);
		YC_DevGpioInit(UART_A_TX_GPIO,GPIO_Mode_Uart_Txd);

	}
	else if (UARTB == UARTx)
	{
		YC_DevGpioInit(UART_B_RX_GPIO,GPIO_Mode_Uartb_Rxd);
		YC_DevGpioInit(UART_B_TX_GPIO,GPIO_Mode_Uartb_Txd);
	}
}

void UART_Config(UART_TypeDef UARTx)
{
	UART_GPIO_Init(UARTx);

	UART_InitTypeDef UART_InitStruct ;

	UART_InitStruct.UART_BaudRate             = UARTE_BAUDRATE_BAUDRATE_Baud921600;
	UART_InitStruct.UART_HardwareFlowControl  = UART_HardwareFlowControl_None;
	UART_InitStruct.UART_WordLength           = UART_WordLength_8b;
	UART_InitStruct.UART_StopBits             = UART_StopBits_1;
	UART_InitStruct.UART_Mode                 = UART_Mode_duplex;
	UART_InitStruct.UART_Parity               = UART_Parity_Even ;
	UART_InitStruct.UART_TXLen                = 512;
	UART_InitStruct.UART_RXLen                = 1;

	UART_Init(UARTx, &UART_InitStruct);
}
