#ifndef _YC11XX_DEV_GPIO_H_
#define _YC11XX_DEV_GPIO_H_

#include "yc11xx_gpio.h"
#include "yc11xx.h"


typedef enum
{
	GPIO_0 = 0,
	GPIO_1,
	GPIO_2,
	GPIO_3,
	GPIO_4,
	GPIO_5,
	GPIO_6,
	GPIO_7,
	GPIO_8,
	GPIO_9,
	GPIO_10,
	GPIO_11,
	GPIO_12,
	GPIO_13,
	GPIO_14,
	GPIO_15,
	GPIO_16,
	GPIO_17,
	GPIO_18,
	GPIO_19,
	GPIO_20,
	GPIO_21,
	GPIO_22,
	GPIO_23,
	GPIO_24,
	GPIO_25,
	GPIO_26,
	GPIO_27,
	GPIO_28,
	GPIO_29,
	GPIO_30,
	GPIO_31,
	GPIO_MAX_NUM,
	TOUCH_key1,
	TOUCH_key2,
	GPIO_ADC_0=0,
	GPIO_ADC_1,
	GPIO_ADC_2,
	GPIO_ADC_3,
	GPIO_ADC_4,
	GPIO_ADC_5,
	
	GPIO_ACTIVE_BIT=0x80,
}GPIO_NUM;


typedef struct
{
	GPIO_TypeDef *gpiotype;
	uint16_t gpionum;
}DEV_GPIO_NUM;



void YC_DeviceGpioNumSelect(GPIO_NUM gpionum,DEV_GPIO_NUM *gpio);
void YC_DeviceGetGpioNum(uint8_t num,GPIO_NUM gpionum,DEV_GPIO_NUM *gpio);
void YC_DevGpioInit(GPIO_NUM gpionum,GPIOMode_TypeDef mode);
void YC_DevGPIOSetOut(GPIO_NUM gpio, BOOL BitVal);
void YC_DevGPIOSetInput(GPIO_NUM gpio);
BOOL YC_DevGPIOCheckGpioIsInputFunction(GPIO_NUM gpio);
void YC_DevGPIOSetWakeup(GPIO_NUM gpio);
BOOL YC_DevGPIOGetInputStatus(GPIO_NUM gpio);
BOOL YC_DevGPIOGetInputStatusWithJitter(GPIO_NUM gpio);



#endif //_YC11XX_DEV_GPIO_H_


