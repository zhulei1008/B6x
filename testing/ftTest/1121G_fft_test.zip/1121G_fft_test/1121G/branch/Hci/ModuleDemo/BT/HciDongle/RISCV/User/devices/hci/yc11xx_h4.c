/* h4.c - H:4 UART based Bluetooth driver */

/*
 * Copyright (c) 2015-2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */
    
#include "yc11xx_h4.h"
#include "yc11xx.h"
#include <string.h>
#include "yc_debug.h"
#include "yc11xx_uart.h"
#include "yc11xx_dev_gpio.h"

#define FUNCTION_BT_HCI

static struct {
	uint8_t buf[600];
	uint16_t buf_pos;

	
	uint16_t    remaining;
	uint16_t    discard;

	bool     have_hdr;
	bool     discardable;

	uint8_t     hdr_len;

	uint8_t     type;
	union {
		struct bt_hci_cmd_hdr cmd;
		struct bt_hci_evt_hdr evt;
		struct bt_hci_acl_hdr acl;
		struct bt_hci_iso_hdr iso;
		uint8_t hdr[4];
	};
} rx;

static struct {
	uint8_t type;
	uint8_t *buf;
} tx;


void h4_uart_init(uint16_t baudRate)
{
    UART_InitTypeDef UART_InitStruct ;

	UART_InitStruct.UART_BaudRate             = baudRate;
    UART_InitStruct.UART_HardwareFlowControl  = UART_HardwareFlowControl_None;
	UART_InitStruct.UART_WordLength           = UART_WordLength_8b;
	UART_InitStruct.UART_StopBits             = UART_StopBits_1;
	UART_InitStruct.UART_Mode                 = UART_Mode_duplex;
	UART_InitStruct.UART_Parity               = UART_Parity_Even ;
	UART_InitStruct.UART_TXLen                = 512;
	UART_InitStruct.UART_RXLen                = 512;

	if(UARTA == HCI_H4_UART){
		YC_DevGpioInit(H4_UART_RXIO,GPIO_Mode_Uart_Rxd);
		YC_DevGpioInit(H4_UART_TXIO,GPIO_Mode_Uart_Txd);
	}else if (UARTB == HCI_H4_UART){
		YC_DevGpioInit(H4_UART_TXIO,GPIO_Mode_Uartb_Txd);
		YC_DevGpioInit(H4_UART_RXIO,GPIO_Mode_Uartb_Rxd);
	}
	UART_Init(HCI_H4_UART,&UART_InitStruct);
}


static size_t h4_discard(size_t len)
{
	uint8_t buf[33];
	return UART_ReadDatatoBuff(HCI_H4_UART, buf, MIN(len, sizeof(buf)));
}

static size_t h4_read(uint8_t* rxBuff, size_t len)
{
	return UART_ReadDatatoBuff(HCI_H4_UART, rxBuff, len);
}

const char *bt_hex_real(const void *buf, size_t len)
{
	static const char hex[] = "0123456789abcdef";
	static char str[129];
	const uint8_t *b = buf;
	size_t i;

	len = MIN(len, (sizeof(str) - 1) / 2);

	for (i = 0; i < len; i++) {
		str[i * 2]     = hex[b[i] >> 4];
		str[i * 2 + 1] = hex[b[i] & 0xf];
	}

	str[i * 2] = '\0';

	return str;
}

static inline void h4_get_type(void)
{
	/* Get packet type */
	if (h4_read(&rx.type, 1) != 1)
	{
		BT_WARN("Unable to read H:4 packet type\r\n");
		rx.type = H4_NONE;
		return;
	}

	switch (rx.type) {
	case H4_CMD:
		rx.remaining = sizeof(rx.cmd);
		rx.hdr_len = rx.remaining;
		break;
	case H4_EVT:
		rx.remaining = sizeof(rx.evt);
		rx.hdr_len = rx.remaining;
		break;
	case H4_ACL:
		rx.remaining = sizeof(rx.acl);
		rx.hdr_len = rx.remaining;
		break;
	case H4_ISO:
		rx.remaining = sizeof(rx.iso);
		rx.hdr_len = rx.remaining;
		break;
	default:
		BT_ERR("Unknown H:4 type 0x%02x\r\n", rx.type);
		rx.type = H4_NONE;
	}
}

static inline void get_acl_hdr(void)
{
	struct bt_hci_acl_hdr *hdr = &rx.acl;
	int to_read = sizeof(*hdr) - rx.remaining;

	rx.remaining -= h4_read((uint8_t *)hdr + to_read,
				       rx.remaining);
	if (!rx.remaining) {
		rx.remaining = (hdr->len);
		BT_DBG("Got ACL header. Payload %u bytes\r\n", rx.remaining);
		rx.have_hdr = true;
	}
}

static inline void get_cmd_hdr(void)
{
	struct bt_hci_cmd_hdr *hdr = &rx.cmd;
	int to_read = rx.hdr_len - rx.remaining;

	rx.remaining -= h4_read((uint8_t *)hdr + to_read,
				       rx.remaining);

	if (!rx.remaining) {
		rx.remaining = hdr->param_len;
		BT_DBG("Got cmd header. Payload %u bytes\r\n", hdr->param_len);
		rx.have_hdr = true;
	}
}

static inline uint8_t* get_rx_buf_read_pos(void)
{
	return rx.buf + rx.buf_pos;
}
static inline void increase_rx_buf_pos(uint16_t len)
{
	rx.buf_pos += len;
}

static inline void copy_hdr(void)
{
	// Save type.
	*(uint8_t *)get_rx_buf_read_pos() = rx.type;
	increase_rx_buf_pos(1);

	// Save header
	memcpy(get_rx_buf_read_pos(), rx.hdr, rx.hdr_len);
	increase_rx_buf_pos(rx.hdr_len);
}

static void reset_rx(void)
{
	rx.type = H4_NONE;
	rx.remaining = 0U;
	rx.have_hdr = false;
	rx.hdr_len = 0U;
	rx.discardable = false;
	rx.buf_pos= 0;
}

static inline void process_rx_packet(uint8_t type, uint8_t* buf, uint16_t len)
{
	//
	BT_DBG("<--- process_rx_packet (type %u) (len %u): %s\r\n", type, len,
	       bt_hex_real(buf, len));

    DEBUG_LOG_PRINT_HCI_H4(0, buf, len);
#ifdef FUNCTION_BT_HCI
	Bt_SndHciToRespin(buf, len);
#endif
}

static inline void read_payload(void)
{
	uint8_t evt_flags;
	int read;

	if (rx.remaining) {
		read = h4_read(get_rx_buf_read_pos(), rx.remaining);
		increase_rx_buf_pos(read);
		rx.remaining -= read;

		BT_DBG("got %d bytes, remaining %u\r\n", read, rx.remaining);
		BT_DBG("Payload (len %u): %s\r\n", rx.buf_pos,
		       bt_hex_real(rx.buf, rx.buf_pos));

		if (rx.remaining) {
			return;
		}
	}

	// receive a full packet
	process_rx_packet(rx.type, rx.buf, rx.buf_pos);
	
	reset_rx();
}

static inline void read_header(void)
{
	switch (rx.type) {
	case H4_NONE:
		h4_get_type();
		return;
	case H4_CMD:
		get_cmd_hdr();
		break;
	case H4_ACL:
		get_acl_hdr();
		break;
	default:
		BT_ERR("Something error\r\n");
		return;
	}

	if (rx.have_hdr) {
		if (rx.remaining > (sizeof(rx.buf) - rx.buf_pos)) {
			BT_ERR("Not enough space in buffer\r\n");
			rx.discard = rx.remaining;
			reset_rx();
		} else {
			copy_hdr();

			// Check receive full packet
			if (!rx.remaining) {
				// receive a full packet
				process_rx_packet(rx.type, rx.buf, rx.buf_pos);
				
				reset_rx();
			}

		}
	}
}
static inline void process_rx(void)
{
	if(UART_GetRxCount(HCI_H4_UART) == 0)
	{
		return;
	}
	BT_DBG("remaining %u discard %u have_hdr %u len %u\r\n",
	       rx.remaining, rx.discard, rx.have_hdr,
	       rx.buf_pos);

	if (rx.discard) {
		rx.discard -= h4_discard(rx.discard);
		return;
	}

	if (rx.have_hdr) {
		read_payload();
	} else {
		read_header();
	}
}


static int h4_send(uint8_t* buf, uint16_t len)
{
	BT_DBG("---> h4_send Payload (len %u): %s\r\n", len,
	       bt_hex_real(buf, len));

	UART_SendDataFromBuff(HCI_H4_UART, buf, len);

	return 0;
}


static int h4_open(void)
{
	int ret;

	BT_DBG("");
#ifdef FUNCTION_FSC_RTK_HOST
	h4_uart_init(UARTE_BAUDRATE_BAUDRATE_Baud115200);
#else
	h4_uart_init(UARTE_BAUDRATE_BAUDRATE_Baud921600);
#endif
	
	return 0;
}


void h4_init(void)
{
	h4_open();
}
void h4_polling_rx(void)
{
	process_rx();
}
void h4_send_data(uint8_t* buf, uint16_t len)
{
	h4_send(buf, len);
        DEBUG_LOG_PRINT_HCI_H4(1, buf, len);
#if 0
        if(HREAD(mem_fsc_rtk_host) == 0x3f)
        {
#ifdef FUNCTION_FSC_RTK_HOST_WHITE
            h4_uart_init(UARTE_BAUDRATE_BAUDRATE_Baud512000);
#else
            h4_uart_init(UARTE_BAUDRATE_BAUDRATE_Baud1M);
#endif
            HWRITE(mem_fsc_rtk_host, 0);
        }
#endif
}

