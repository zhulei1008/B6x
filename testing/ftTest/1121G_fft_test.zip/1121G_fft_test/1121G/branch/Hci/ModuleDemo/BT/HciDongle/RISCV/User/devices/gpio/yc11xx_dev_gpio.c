#include "yc11xx_dev_gpio.h"
#include "reg_addr.h"
#include "btreg.h"


void YC_DeviceGpioNumSelect(GPIO_NUM gpionum,DEV_GPIO_NUM *gpio)
{
	gpionum&=0x1f;
	switch (gpionum/8)
	{
	case 0:
		gpio->gpiotype=GPIOA;
		YC_DeviceGetGpioNum(0,gpionum,gpio);
		break;
	case 1:
		gpio->gpiotype=GPIOB;
		YC_DeviceGetGpioNum(1,gpionum,gpio);
		break;
	case 2:
		gpio->gpiotype=GPIOC;
		YC_DeviceGetGpioNum(2,gpionum,gpio);
		break;
	case 3:
		gpio->gpiotype=GPIOD;
		YC_DeviceGetGpioNum(3,gpionum,gpio);
		break;
	case 4:
		gpio->gpiotype=GPIOE;
		YC_DeviceGetGpioNum(4,gpionum,gpio);
		break;
	}	
}
void YC_DeviceGetGpioNum(uint8_t num,GPIO_NUM gpionum,DEV_GPIO_NUM *gpio)
{
	gpionum&=0x1f;
	switch(gpionum-num*8)
	{
		case 0:
			gpio->gpionum=GPIO_Pin_0;
			break;
		case 1:
			gpio->gpionum=GPIO_Pin_1;
			break;
		case 2:
			gpio->gpionum=GPIO_Pin_2;
			break;
		case 3:
			gpio->gpionum=GPIO_Pin_3;
			break;
		case 4:
			gpio->gpionum=GPIO_Pin_4;
			break;
		case 5:
			gpio->gpionum=GPIO_Pin_5;
			break;
		case 6:
			gpio->gpionum=GPIO_Pin_6;
			break;
		case 7:
			gpio->gpionum=GPIO_Pin_7;
			break;
	}
}

void YC_DevGpioInit(GPIO_NUM gpionum,GPIOMode_TypeDef mode)
{
	GPIO_InitTypeDef gpiohandle;
	DEV_GPIO_NUM gpiocfg;
	YC_DeviceGpioNumSelect(gpionum,&gpiocfg);
	
	
	gpiohandle.GPIO_Pin = gpiocfg.gpionum;
	gpiohandle.GPIO_Mode = mode;
	gpiohandle.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(gpiocfg.gpiotype, &gpiohandle);
}
void YC_DevGPIOSetOut(GPIO_NUM gpio, BOOL BitVal)
{
	DEV_GPIO_NUM gpiocfg;
	YC_DeviceGpioNumSelect(gpio,&gpiocfg);
	if (gpio &GPIO_ACTIVE_BIT)
	{
		if(BitVal)
		{
			GPIO_SetBits(gpiocfg.gpiotype, gpiocfg.gpionum);
		}
		else
		{
			GPIO_ResetBits(gpiocfg.gpiotype, gpiocfg.gpionum);
		}
	}
	else
	{
		if(BitVal)
		{
			GPIO_ResetBits(gpiocfg.gpiotype, gpiocfg.gpionum);
		}
		else
		{
			GPIO_SetBits(gpiocfg.gpiotype, gpiocfg.gpionum);
		}
	}
	
}
void YC_DevGPIOSetInput(GPIO_NUM gpio)
{
	GPIO_InitTypeDef gpiohandle;
	DEV_GPIO_NUM gpiocfg;
	YC_DeviceGpioNumSelect(gpio,&gpiocfg);

	gpiohandle.GPIO_Pin = gpiocfg.gpionum;
	gpiohandle.GPIO_Speed = GPIO_Speed_10MHz;
	if (gpio & GPIO_ACTIVE_BIT)
		gpiohandle.GPIO_Mode = GPIO_Mode_In_Down;
	else
		gpiohandle.GPIO_Mode = GPIO_Mode_In_Up;
	GPIO_Init(gpiocfg.gpiotype, &gpiohandle);
}
BOOL YC_DevGPIOCheckGpioIsInputFunction(GPIO_NUM gpio)
{
	return ((HREAD(CORE_GPIO0_CONFIG + (gpio & 0x3f)) & 0x3f) == GPIO_Mode_Deinit);
}

void YC_DevGPIOSetWakeup(GPIO_NUM gpio)
{
	uint8_t row,col;
	row = (gpio>>3) & 0x03;
	col = (gpio & 0x07);

	if (gpio &GPIO_ACTIVE_BIT) 
	{
		//high active,high bat will wakeup
		HWRITE(mem_gpio_wakeup_low+row,HREAD(mem_gpio_wakeup_low+row)& (~(1<<col)));
		HWRITE(mem_gpio_wakeup_high+row,HREAD(mem_gpio_wakeup_high+row) |(1<<col));
	}
	else
	{
		//low active, low bat will wakeup
		HWRITE(mem_gpio_wakeup_high+row,HREAD(mem_gpio_wakeup_high+row)& (~(1<<col)));
		HWRITE(mem_gpio_wakeup_low+row,HREAD(mem_gpio_wakeup_low+row) |(1<<col));
	}
}

BOOL YC_DevGPIOGetInputStatus(GPIO_NUM gpio)
{
	GPIO_InitTypeDef gpiohandle;
	DEV_GPIO_NUM gpiocfg;
	YC_DeviceGpioNumSelect(gpio, &gpiocfg);
	if (gpio == GPIO_MAX_NUM)
	{
		error_handle();
	}
	
	//return gpioGetBit(gpio&GPIO_NUM_MASK, CORE_GPIO_IN);
	if (gpio & GPIO_ACTIVE_BIT)
	{
		return GPIO_ReadInputDataBit(gpiocfg.gpiotype, gpiocfg.gpionum);
	}
	else
	{
		return !GPIO_ReadInputDataBit(gpiocfg.gpiotype, gpiocfg.gpionum);
	}
}

BOOL YC_DevGPIOGetInputStatusWithJitter(GPIO_NUM gpio)
{
	BOOL res1,res2,res3;
	
	do{
		res1 = YC_DevGPIOGetInputStatus(gpio);
		SYS_DelayMs(10);
		res2 = YC_DevGPIOGetInputStatus(gpio);
		if (res1 != res2)
			continue;
		SYS_DelayMs(10);
		res3 = YC_DevGPIOGetInputStatus(gpio);
	}while(res2 != res3);
	
	return res1;
}



