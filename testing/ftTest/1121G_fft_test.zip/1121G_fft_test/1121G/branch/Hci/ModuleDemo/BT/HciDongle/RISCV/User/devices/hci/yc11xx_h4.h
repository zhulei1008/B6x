#ifndef DRIVERS_HCI_YC11XX_H4_H_
#define DRIVERS_HCI_YC11XX_H4_H_

#include "yc11xx_hci.h"


#define H4_NONE 0x00
#define H4_CMD  0x01
#define H4_ACL  0x02
#define H4_SCO  0x03
#define H4_EVT  0x04
#define H4_ISO  0x05

#define HCI_H4_UART (UARTA)
#define H4_UART_RXIO  (GPIO_6)
#define H4_UART_TXIO  (GPIO_5)  

#define BT_DBG(fmt, ...) DEBUG_LOG_STRING(fmt, ##__VA_ARGS__)
#define BT_ERR(fmt, ...) DEBUG_LOG_STRING(fmt, ##__VA_ARGS__)
#define BT_WARN(fmt, ...) DEBUG_LOG_STRING(fmt, ##__VA_ARGS__)
#define BT_INFO(fmt, ...) DEBUG_LOG_STRING(fmt, ##__VA_ARGS__)

#define  MIN(a, b)      (((a) < (b)) ? (a) : (b))

void h4_init(void);
void h4_polling_rx(void);
void h4_send_data(uint8_t* buf, uint16_t len);

#endif //DRIVERS_HCI_YC11XX_H4_H_


