#include "yc11xx_systick.h"
#include "yc11xx.h"
#include "yc_debug.h"
#include "yc11xx_ipc.h"
#include "yc11xx_bt_interface.h"

extern void App_EvtCallBack(uint8_t len,uint8_t *dataPtr);
extern void Bt_DataBufferCallBack(uint8_t len,uint8_t *dataPtr);

tIPCHandleCb gTIPCHandleCb[IPC_TYPE_NUM]=
{
	0,
	IpcDefaultCallBack,//cmd
	App_EvtCallBack,//evt
	IpcDefaultCallBack,//hid
	IpcDefaultCallBack,//spp
	//IpcDefaultCallBack,
	IpcDefaultCallBack,//ble
	Bt_DataBufferCallBack,//24g
	IpcDefaultCallBack,//mesh
	IpcDefaultCallBack,//mesh
	IpcDefaultCallBack,//mesh
	IpcDefaultCallBack,//a2dp
	IpcDefaultCallBack,//hfp
	IpcDefaultCallBack,//tws
};

void App_EvtResetWork(void)
{
    DEBUG_LOG_STRING("App_EvtResetWork.\r\n");
}

void App_EvtLpmWakeWork(void)
{
    DEBUG_LOG_STRING("App_EvtLpmWakeWork.\r\n");
}


void App_EvtCallBack(uint8_t len,uint8_t *dataPtr)
{
	if (*dataPtr >BT_EVT_100MS_UINT)
	{
		//SYS_100msTimerHandle((*dataPtr)&(0x0F));
		return;
	}
	
	switch(*dataPtr)
	{
		case BT_EVT_WAKEUP:
            OS_INITIAL_CRITICAL();
            App_EvtLpmWakeWork();
			break;
		case BT_EVT_RESET:
            OS_INITIAL_CRITICAL();
            App_EvtResetWork();
			break;
            
		default:
			break;
	}
	return;
}

void App_ActionBeforeHibernate(void)
{
    DEBUG_LOG_STRING("App_ActionBeforeHibernate.\r\n");
}
void App_ActionBeforeLpm(void)
{
    DEBUG_LOG_STRING("App_ActionBeforeLpm.\r\n");
}

uint8_t gTestEnterHibernate = 1;

int main(void)
{
    IPC_init(&gTIPCHandleCb);

    DEBUG_INIT();
    DEBUG_LOG_STRING("App_MainLoop Start Work.\r\n");

    h4_init();
    Bt_HciFifoInit();

    while(1)
    {
        //For respin log print
        DEBUG_POLLING_PRINT();

        switch (HREAD(IPC_MCU_STATE))
        {
            case IPC_MCU_STATE_RUNNING:
                //always first init bt
                IPC_HandleRxPacket();

                // Uart rx have error.
                if(HREAD(0x4ff0) != 0)
                {
                    HWRITE(0x4ff0, 0);
                    // hci reset
                    uint8_t testBuffReset[] = {0x01, 0x03, 0x0c, 0x00};
                    DEBUG_LOG_PRINT_HCI_H4(0, testBuffReset, sizeof(testBuffReset));
                    Bt_SndHciToRespin(testBuffReset, sizeof(testBuffReset));
                    
                    // hci error
                    uint8_t testBuffError[] = {0x01, 0x03, 0x01, 0x00};
                    DEBUG_LOG_PRINT_HCI_H4(0, testBuffError, sizeof(testBuffError));
                    Bt_SndHciToRespin(testBuffError, sizeof(testBuffError));
                    
                    // hci event mask
                    uint8_t testBuffEventMask[] = {0x01, 0x01, 0x0c, 0x08, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
                    DEBUG_LOG_PRINT_HCI_H4(0, testBuffEventMask, sizeof(testBuffEventMask));
                    Bt_SndHciToRespin(testBuffEventMask, sizeof(testBuffEventMask));
                }
                h4_polling_rx();

                Lpm_unLockLpm(M0_LPM_FLAG);
                break;
            case IPC_MCU_STATE_LMP:
                if (IPC_IsTxBuffEmpty()
                    && Lpm_CheckLpmFlag())
                {
                    OS_ENTER_CRITICAL();
                    App_ActionBeforeLpm();
                    HWRITE(IPC_MCU_STATE,IPC_MCU_STATE_STOP);
                }
                else
                {
                    HWRITE(IPC_MCU_STATE,IPC_MCU_STATE_RUNNING);
                }
                break;
            case IPC_MCU_STATE_HIBERNATE:
                OS_ENTER_CRITICAL();
                App_ActionBeforeHibernate();
                HWRITE(IPC_MCU_STATE,IPC_MCU_STATE_STOP);
                break;
            case IPC_MCU_STATE_STOP:
                break;
        }
    }

	return 0;
}




