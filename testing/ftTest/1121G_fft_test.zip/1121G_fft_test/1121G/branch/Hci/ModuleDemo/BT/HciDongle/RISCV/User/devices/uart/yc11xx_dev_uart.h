#ifndef __YC11_DEV_UART_H__
#define __YC11_DEV_UART_H__
#include "yc11xx_uart.h"

void UART_GPIO_Init(UART_TypeDef UARTx);
void UART_Config(UART_TypeDef UARTx);



#endif
