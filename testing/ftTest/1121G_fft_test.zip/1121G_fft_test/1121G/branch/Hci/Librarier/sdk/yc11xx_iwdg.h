/*
		 * Copyright (c) 2006-2021, YICHIP Development Team
		 * @file     YC_STM32_iwdg.h
		 * @brief    source file for setting wdg
		 *
		 * Change Logs:
		 * Date           Author      	Version        Notes
		 * 2021-02-08     huangqihong 	V1.0.0         the first version
		 */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __YC11XX_IWDG_H
#define __YC11XX_IWDG_H

#define IWDG_IP(x)				*((volatile int*)(0xE000E400 + x*4))

#include "yc11xx.h"

/** 
  * @brief  watch dog number definition  
  */ 
typedef enum
{
	WDT2 = 2,
	WDT,
}IWDG_NumTypeDef;

/** 
  * @brief  watch dog mode definition  
  */ 
typedef enum
{
	RESET_MODE = 0x02,
	INTR_MODE = 0xfd
} IWDG_ModeTypedef;

/** 
  * @brief  watch dog Init Structure definition  
  */ 

#define WDT_timer_125ms  0x7F
#define WDT_timer_250ms  0x7e
#define WDT_timer_500ms  0x7c
#define WDT_timer_1_5s   0x74
#define WDT_timer_10s    0x32
#define WDT_timer_Max    0x00 //16.384s

typedef struct
{
	IWDG_NumTypeDef WDTx;
	IWDG_ModeTypedef mode;
	uint8_t setload;
}IWDG_InitTypeDef;


void WDT_NVIC_Clear(IWDG_NumTypeDef WDTx);
void IWDG_SetPriority(IRQn_Type IRQn, uint8_t priority);
void IWDG_InterruptConfig(void);
void IWDG_Start(IWDG_InitTypeDef* IWDG_init_struct);
void IWDG_Init(IWDG_InitTypeDef* WDT_init_struct);
void IWDG_SetReload(uint16_t Reload);
void IWDG_ReloadCounter(void);
void IWDG_Enable(IWDG_InitTypeDef* WDT_init_struct);
void IWDG_Disable(IWDG_NumTypeDef WDTx);
void WDT_NVIC_Out(void);


#endif /* _YC1121G_IWDG_H */



/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
