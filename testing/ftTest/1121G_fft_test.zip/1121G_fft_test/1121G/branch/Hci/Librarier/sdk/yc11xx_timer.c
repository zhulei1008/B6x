/**
 * @file yc11xx_timer.c
 * @brief TIMER driver
 * @date 2021-07-07
 * 
 * Date           Author      Version        Notes
 * 2021-03-11     zhouduo     V1.0.0      the first version
 * 2021-06-15     zhouduo     V1.1.0      the formal version
 */
#include "yc11xx_timer.h"
#include "reg_addr.h"
#include "yc11xx_gpio.h"

/**
 * @brief   Init tim with pwm mode
 * @param   TIM_Init_Struct : TIM initializes the structure
 * @retval  none
 */
void TIM_Init(TIM_InitTypeDef* TIM_init_struct)
{
	uint8_t pwmCtrl = 0;
	if (TIM_init_struct->mode == TIM_Mode_TIMER)
	{

		pwmCtrl |= TIM_init_struct->mode;
		pwmCtrl |= TIM_init_struct->frequency;
		
		HWRITEW(reg_map(CORE_PWM_PCNT(TIM_init_struct->TIMx)), TIM_init_struct->period);
		HWRITE(reg_map(CORE_PWM_CTRL(TIM_init_struct->TIMx)), pwmCtrl);
	}
	else 
	{
		HWCOR((CORE_PWM_CTRL(TIM_init_struct->TIMx)),1<<7);
		pwmCtrl |= TIM_init_struct->mode;
		pwmCtrl |= TIM_init_struct->pwm.LoadMode;
		pwmCtrl |= TIM_init_struct->pwm.Sync;
		HWRITEW(reg_map(CORE_PWM_PCNT(TIM_init_struct->TIMx)), TIM_init_struct->pwm.HighLevelPeriod);
		HWRITEW(reg_map(CORE_PWM_NCNT(TIM_init_struct->TIMx)), TIM_init_struct->pwm.LowLevelPeriod);
		HWRITE(reg_map(CORE_PWM_CTRL(TIM_init_struct->TIMx)),pwmCtrl);//a0
	}
}

/**
 * @brief   enable or disable timer
 * @param   TIMx : the timer number,TIM0-TIM7
 * @param   NewState :Fixed FunctionalState enumeration type
 * @retval  none
 */
void TIM_Cmd(TIM_NumTypeDef TIMx, FunctionalState NewState)
{

	uint8_t pwmClken;
	
	pwmClken = HREAD(CORE_PWM_CLKEN);
	if (NewState == ENABLE)
	{
		pwmClken |= (0x01 << TIMx);
	}
	else if (NewState == DISABLE)
	{
		pwmClken &= (~(0x01 << TIMx));
	}
	HWRITE(reg_map(CORE_PWM_CLKEN), pwmClken);

}






