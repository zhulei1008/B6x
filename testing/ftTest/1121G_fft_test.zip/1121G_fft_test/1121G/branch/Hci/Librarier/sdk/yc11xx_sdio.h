 /**
***************************************************************************
* @file:  yc11xx_sdio.h
* @Date:  2021-8-4-20:35:22
* @brief:  This file contains all the functions prototypes for the SDIO firmware library.
**************************************************************************
 */


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _YC11XX_SDIO_H_
#define _YC11XX_SDIO_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "yc11xx.h"
	 
/** 
SD clk frequency select
 */
typedef enum
{
	SDCLK_Frequency_24M = 0,
  	SDCLK_Frequency_12M,
	SDCLK_Frequency_8M,
	SDCLK_Frequency_6M,
	SDCLK_Frequency_4M = 0x05,
	SDCLK_Frequency_3 = 0x07,
	SDCLK_Frequency_2M = 0x0b,
	SDCLK_Frequency_400KB = 0x3d,
	SDCLK_Frequency_200KB = 0x7a,
}SDCLK_Fre_InitTypeDef;

typedef enum
{
	ROM_CLK = 0,
	  ROM_IOTP_CLK,
	DEBUG_UART_CLK,
	RAM_CLK,
	QSPI_CLK,
	DAC_CLK,
	VOICE_FILTER_CLK,
	IIC_CLK,
	CM0_CLK,
	MRAM_CLK,
	USB_CLK,
	SBC_CLK,
	SPI_CLK,
	PWM_SDIO_CLK,
	I2S_CLK,
	UART_CLK,
}RCC_CLOCK_InitTypeDef;

typedef struct
{
                                           
} SDIO_InitTypeDef;

typedef struct
{
  
} SDIO_CmdInitTypeDef;

typedef struct
{
 
} SDIO_DataInitTypeDef;


/** @defgroup SDIO_Exported_Functions
  * @{
  */

void SDIO_DeInit(void);
void SDIO_Init(SDIO_InitTypeDef* SDIO_InitStruct);
void SDIO_StructInit(SDIO_InitTypeDef* SDIO_InitStruct);
void SDIO_ClockCmd(FunctionalState NewState);
void SDIO_SetPowerState(uint32_t SDIO_PowerState);
uint32_t SDIO_GetPowerState(void);
void SDIO_ITConfig(uint32_t SDIO_IT, FunctionalState NewState);
void SDIO_DMACmd(FunctionalState NewState);
void SDIO_SendCommand(SDIO_CmdInitTypeDef *SDIO_CmdInitStruct);
void SDIO_CmdStructInit(SDIO_CmdInitTypeDef* SDIO_CmdInitStruct);
uint8_t SDIO_GetCommandResponse(void);
uint32_t SDIO_GetResponse(uint32_t SDIO_RESP);
void SDIO_DataConfig(SDIO_DataInitTypeDef* SDIO_DataInitStruct);
void SDIO_DataStructInit(SDIO_DataInitTypeDef* SDIO_DataInitStruct);
uint32_t SDIO_GetDataCounter(void);
uint32_t SDIO_ReadData(void);
void SDIO_WriteData(uint32_t Data);
uint32_t SDIO_GetFIFOCount(void);
void SDIO_StartSDIOReadWait(FunctionalState NewState);
void SDIO_StopSDIOReadWait(FunctionalState NewState);
void SDIO_SetSDIOReadWaitMode(uint32_t SDIO_ReadWaitMode);
void SDIO_SetSDIOOperation(FunctionalState NewState);
void SDIO_SendSDIOSuspendCmd(FunctionalState NewState);
void SDIO_CommandCompletionCmd(FunctionalState NewState);
void SDIO_CEATAITCmd(FunctionalState NewState);
void SDIO_SendCEATACmd(FunctionalState NewState);
uint32_t SDIO_GetFlagStatus(uint32_t SDIO_FLAG);
void SDIO_ClearFlag(uint32_t SDIO_FLAG);
ITStatus SDIO_GetITStatus(uint32_t SDIO_IT);
void SDIO_ClearITPendingBit(uint32_t SDIO_IT);




#ifdef __cplusplus
}
#endif

#endif /* __STM32F10x_SDIO_H */
/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
