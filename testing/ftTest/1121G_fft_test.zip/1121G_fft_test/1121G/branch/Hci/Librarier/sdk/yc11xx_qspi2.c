#include "yc11xx_qspi2.h"
//#include "system.h"

//delay ms
void qspi2_delay_ms(unsigned short val)
{
    unsigned short i, j;
    for (i = 0; i < val; i ++)
    {
        for (j = 0; j < 1019; j ++ )
        { // to  be done!!!
            ;
        }
    }
}

// reg wr
void qspi2_reg_wr(unsigned char addr, unsigned char val)
{
    int paddr;
    paddr = (unsigned int)(addr) |0x1001f000; // regmap
    *(volatile unsigned char *)(paddr) = val;
}

// reg rd
unsigned char qspi2_reg_rd(unsigned char addr)
{
    int paddr;
    paddr = (unsigned int)(addr) | 0x1001f000; // regmap
    return *(volatile unsigned char *)(paddr);
}

// reg wr
void qspi2_reg_wr_seg(unsigned char addr, unsigned char sbit, unsigned char ebit, unsigned char val)
{
    unsigned char tmp, msk, i;
    msk = 0;
    for (i=0; i<8; i++) {
        if ((i>=sbit) && (i<=ebit)) {
            msk = msk + (0x01 << i);
        }
    }
    tmp = qspi2_reg_rd(addr);
    tmp = tmp & (~msk);
    tmp = tmp | ((val << sbit) & msk);
    qspi2_reg_wr(addr, tmp);
}

// txaddr
void qspi2_set_txaddr (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi2_reg_wr(QSPI2_TXADDR0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi2_reg_wr(QSPI2_TXADDR1, tmp);
}

// txlen
void qspi2_set_txlen (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi2_reg_wr(QSPI2_TXLEN0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi2_reg_wr(QSPI2_TXLEN1, tmp);
}

// rxaddr
void qspi2_set_rxaddr (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi2_reg_wr(QSPI2_RXADDR0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi2_reg_wr(QSPI2_RXADDR1, tmp);
}

// txlen
void qspi2_set_rxlen (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi2_reg_wr(QSPI2_RXLEN0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi2_reg_wr(QSPI2_RXLEN1, tmp);
}

// cmdaddr
void qspi2_set_cmdaddr (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi2_reg_wr(QSPI2_CMDADDR0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi2_reg_wr(QSPI2_CMDADDR1, tmp);
}

// cmdlen
void qspi2_set_cmdlen (unsigned char val)
{
	qspi2_reg_wr(QSPI2_CMDLEN, val);
}

// ctrl0
void qspi2_set_ctrl0 (unsigned char val)
{
	qspi2_reg_wr(QSPI2_CTRL0, val);
}

// mode
void qspi2_set_mode (unsigned char val)
{
	qspi2_reg_wr_seg(QSPI2_CTRL0, 0, 1, val);
}

// auto_inc
void qspi2_set_inc (unsigned char val)
{
	qspi2_reg_wr_seg(QSPI2_CTRL0, 2, 2, val);
}

// mbyte
void qspi2_set_mbyte (unsigned char val)
{
	qspi2_reg_wr_seg(QSPI2_CTRL0, 4, 4, val);
}

// cont
void qspi2_set_clk (unsigned char val)
{
	qspi2_reg_wr_seg(QSPI2_CTRL0, 5, 5, val);
}

// interrupt
void qspi2_set_interrupt (unsigned char val)
{
	qspi2_reg_wr_seg(QSPI2_CTRL0, 6, 6, val);
}

// clkp
void qspi2_set_clkp (unsigned char val)
{
	qspi2_reg_wr_seg(QSPI2_CTRL0, 7, 7, val);
}

// ctrl1
void qspi2_set_ctrl1 (unsigned char val)
{
	qspi2_reg_wr(QSPI2_CTRL1, val);
}

// dly
void qspi2_set_dly (unsigned char val)
{
	qspi2_reg_wr_seg(QSPI2_CTRL1, 0, 3, val);
}

// start
void qspi2_set_start (unsigned char val)
{
	qspi2_reg_wr(QSPI2_START, val);
}

// wait_done
void qspi2_wait_done (void)
{
    unsigned char tmp;
    while (1) {
        tmp = qspi2_reg_rd(QSPI2_STATUS);
        tmp = tmp & 0x01;
        if (tmp == 0x01)
            break;
    }
}


