#ifndef __YC11XX_QSPI1_H__
#define __YC11XX_QSPI1_H__

#include "yc11xx.h"

#define QSPI_1_MODE_1_BIT        0
#define QSPI_1_MODE_2_BIT        1
#define QSPI_1_MODE_4_BIT        2

#define QSPI1_TXADDR0           0x68
#define QSPI1_TXADDR1           0x69
#define QSPI1_TXLEN0            0x6a
#define QSPI1_TXLEN1            0x6b
#define QSPI1_RXADDR0           0x6c
#define QSPI1_RXADDR1           0x6d
#define QSPI1_RXLEN0            0x6e
#define QSPI1_RXLEN1            0x6f
#define QSPI1_CTRL0             0x70
#define QSPI1_CTRL1             0x71
#define QSPI1_CMDLEN		    0x76
#define QSPI1_START             0x78
#define QSPI1_CMDADDR0		    0x74
#define QSPI1_CMDADDR1		    0x75
#define QSPI1_STATUS            0x7c

// macro
#define QSPI1_MRAM_SEL_ON                 1
#define QSPI1_MRAM_SEL_OFF                0

void qspi1_reg_wr(unsigned char addr, unsigned char val);
unsigned char qspi1_reg_rd(unsigned char addr);
void qspi1_reg_wr_seg(unsigned char addr, unsigned char sbit, unsigned char ebit, unsigned char val);
void qspi1_set_txaddr (unsigned short val);
void qspi1_set_txlen (unsigned short val);
void qspi1_set_rxaddr (unsigned short val);
void qspi1_set_rxlen (unsigned short val);
void qspi1_set_cmdaddr (unsigned short val);
void qspi1_set_cmdlen (unsigned char val);
void qspi1_set_ctrl0 (unsigned char val);
void qspi1_set_mode (unsigned char val);
void qspi1_set_inc (unsigned char val);
void qspi1_set_clk (unsigned char val);
void qspi1_set_mbyte (unsigned char val);
void qspi1_set_cont (unsigned char val);
void qspi1_set_interrupt(unsigned char val);
void qspi1_set_clkp (unsigned char val);
void qspi1_set_ctrl1 (unsigned char val);
void qspi1_set_dly (unsigned char val);
void qspi1_set_start (unsigned char val);
void qspi1_wait_done (void);
void qspi1_delay_ms(unsigned short val);

#endif
