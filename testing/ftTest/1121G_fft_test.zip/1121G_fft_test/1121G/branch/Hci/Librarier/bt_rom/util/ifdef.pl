open file, "bt_program23.meta"
@prog = <file>;
close file;
open file, "bt_format.meta"
@fmt = <file>;
close file;


