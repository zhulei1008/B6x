#include "yc11xx_pwm.h"
/**
 * @brief  PWM param config
 * @param    GPIOx   GPIO grouping
 * @param    pin    :GPIO number
 * @param    pcnt  :Duration of PWM high level
 * @param    pcnt  :Duration of PWM low level
 * @return  None
 */
void PWM_Config(GPIO_TypeDef* GPIOx ,uint16_t pin,uint16_t pcnt,uint16_t ncnt)
{
    TIM_Cmd(pin, ENABLE);

    TIM_InitTypeDef PWM_InitStruct;
    PWM_InitStruct.TIMx = (TIM_NumTypeDef)pin;
    PWM_InitStruct.mode = TIM_Mode_PWM;
    PWM_InitStruct.pwm.LoadMode = Load_enable;//load the pcnt/ncnt from self
    //default when sync mode on
    PWM_InitStruct.pwm.Sync = Sync_default;
    PWM_InitStruct.pwm.HighLevelPeriod = pcnt;
    PWM_InitStruct.pwm.LowLevelPeriod = ncnt;

    GPIO_InitTypeDef PWM_GPIODEF;
    PWM_GPIODEF.GPIO_Pin   = pin;
    PWM_GPIODEF.GPIO_Mode  = GPIO_Mode_Pwm_Out0;
    PWM_GPIODEF.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_Init(GPIOx, &PWM_GPIODEF);

    TIM_Init(&PWM_InitStruct);
}
/**
 * @brief  Failure of PWM function corresponding to GPIO
 * @param    GPIOx   GPIO grouping
 * @param    pin    :GPIO number
 * @return  None
 */
void PWM_DisConfig(GPIO_TypeDef* GPIOx ,uint16_t pin)
{
    GPIO_InitTypeDef PWM_GPIODIS;
    PWM_GPIODIS.GPIO_Pin   = pin;
    PWM_GPIODIS.GPIO_Mode  = GPIO_Mode_Deinit;
    PWM_GPIODIS.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_Init(GPIOx, &PWM_GPIODIS);

    TIM_Cmd(pin, DISABLE);
}
/**
 * @brief  Set the PWM synchronization function
 * @param    GPIOx   GPIO grouping
 * @param    pin    :GPIO number
 * @param    pcnt  :Duration of PWM high level
 * @param    pcnt  :Duration of PWM low level
 * @return  None
 */
void PWM_Config_Sync(GPIO_TypeDef* GPIOx ,uint16_t pin,uint16_t pcnt,uint16_t ncnt)
{
    TIM_InitTypeDef PWM_InitStruct;
    PWM_InitStruct.TIMx = (TIM_NumTypeDef)pin;
    PWM_InitStruct.mode = TIM_Mode_PWM;
    PWM_InitStruct.pwm.LoadMode = Load_default;//default when sync mode on
    PWM_InitStruct.pwm.Sync = Sync_enable;
    PWM_InitStruct.pwm.HighLevelPeriod = pcnt;
    PWM_InitStruct.pwm.LowLevelPeriod = ncnt;

    GPIO_InitTypeDef PWM_GPIODEF;
    PWM_GPIODEF.GPIO_Pin   = pin;
    PWM_GPIODEF.GPIO_Mode  = GPIO_Mode_Pwm_Out0;
    PWM_GPIODEF.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_Init(GPIOx, &PWM_GPIODEF);

    TIM_Init(&PWM_InitStruct);
    TIM_Cmd(pin, ENABLE);
}
