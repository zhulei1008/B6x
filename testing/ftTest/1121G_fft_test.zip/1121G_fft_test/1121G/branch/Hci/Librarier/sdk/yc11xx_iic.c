 /**
***************************************************************************
* @file:  yc11xx_iic.c
* @Date:  2021-6-4-20:14:05
* @brief:  I2C driver
*
* Change Logs:
* Date           Author      Version        Notes
* 2021-06-04     xxx         V1.0.0         the first version

**************************************************************************
 */
#include "yc11xx_iic.h"
#include "yc11xx_gpio.h"
#include "reg_addr.h"
#include "reg_struct.h"
#include "MyPrintf.h"
#include "yc_nvic.h"


/** 
 * @brief	 IIC function and parameter configure
 * @param    type: IIC_0/IIC_1                    
 * @param    rate : IIC baud rate 
 *				iic_rate_25k,
 *				iic_rate_50k,
 *				iic_rate_100k,
 *				iic_rate_200k,
 *				iic_rate_400k,
 *				iic_rate_600k,
 *				iic_rate_660k,
 *				iic_rate_860k,//max
 * @return  None
 */
void IIC_Init(IIC_TypeDef type,IIC_RateDev rate,IIC_Address SRAM_Or_MRAM)
{
	IIC_InitTypeDef iicConfig;
	CLOCK_OFFRegDef clockOffReg;
	CoreReg_ClkControl(REG_CLOCK_OFF_I2C,ENABLE);
	switch(rate)
	{
	case iic_rate_25k:
		iicConfig.scll = 236;
		iicConfig.sclh = 236;
		break;
	case iic_rate_50k:
		iicConfig.scll = 116;
		iicConfig.sclh = 116;
		break;
	case iic_rate_100k:
		iicConfig.scll = 56;
		iicConfig.sclh = 56;
		break;
	case iic_rate_200k:
		iicConfig.scll = 26;
		iicConfig.sclh = 26;
		break;
	case iic_rate_400k:
		iicConfig.scll = 11;
		iicConfig.sclh = 11;
		break;
	case iic_rate_600k:
		iicConfig.scll = 6;
		iicConfig.sclh = 6;
		break;
	case iic_rate_660k:
		iicConfig.scll = 5;
		iicConfig.sclh = 5;
		break;
	case iic_rate_860k:
		iicConfig.scll = 3;
		iicConfig.sclh = 3;
		break;
	}

	iicConfig.stsu = (iicConfig.sclh)/2;
	iicConfig.sthd = (iicConfig.sclh)/2;
	iicConfig.sosu = (iicConfig.sclh)/2;
	iicConfig.dtsu = iicConfig.sclh;
	iicConfig.dthd = 0;
	IIC_ParamConfig(type,&iicConfig,SRAM_Or_MRAM);
}

/** 
 * @brief  	configure IIC function
 * @param  	type: IIC_0/IIC_1                    
 * @param  	I2C_InitStruct :I2C timer patameter   
 *			scll:	SCL Pulse Width Low. 
 *			sclh:   SCL Pulse Width High. 
 *			stsu: 	the Start Setup Time. 
 *			sthd: 	the Start Hold Time. 
 *			sosu:	the Stop Setup Time. 
 *	 		dtsu: 	the Data Setup Time. 
 *	 		dthd:	the Data Hold Time. 
 * @return 	None
 */
void IIC_ParamConfig(IIC_TypeDef type,IIC_InitTypeDef* iicInitStruct,IIC_Address SRAM_Or_MRAM)
{
	IICD_CTRLRegDef	iic0Ctrl;
	IICD1_CTRLRegDef iic1Ctrl;
	//IIC_DeInit(type);
	IIC_RegDef* iicAddr = NULL;
	
	if(type==IIC_0)
	{
		iicAddr = (IIC_RegDef*)(reg_map(CORE_IICD_CTRL));
		HREAD_STRUCT(CORE_IICD_CTRL,&iic0Ctrl);
		iic0Ctrl.iicd_auto_inc=1;
		iic0Ctrl.iicd_restart=1;
		iic0Ctrl.iicd_mram_sel=SRAM_Or_MRAM;
		HWRITE_STRUCT(CORE_IICD_CTRL,&iic0Ctrl);
	}
	else
	{
		iicAddr = (IIC_RegDef*)(reg_map(CORE_IICD1_CTRL));
		//HWRITE((uint32_t)&I2cAdr->Ctrl, IICD_CTRL_VAL);
		HREAD_STRUCT(CORE_IICD1_CTRL,&iic1Ctrl);
		iic1Ctrl.iicd1_auto_inc=1;
		iic1Ctrl.iicd1_restart=1;
		iic1Ctrl.iicd1_mram_sel=SRAM_Or_MRAM;
		HWRITE_STRUCT(CORE_IICD1_CTRL,&iic1Ctrl);
	}
	/*set iic clock speed*/
	iicAddr->sclsdaclk.scll = iicInitStruct->scll;
	iicAddr->sclsdaclk.sclh = iicInitStruct->sclh;
	iicAddr->sclsdaclk.stsu = iicInitStruct->stsu;
	iicAddr->sclsdaclk.sthd = iicInitStruct->sthd;
	iicAddr->sclsdaclk.sosu = iicInitStruct->sosu;
	iicAddr->sclsdaclk.dtsu = iicInitStruct->dtsu;
	iicAddr->sclsdaclk.dthd = iicInitStruct->dthd;
}

/** 
 * @brief    clear IIC Reg configure
 * @param    type: IIC_0/IIC_1                     
 * @return  None
 */
void IIC_DeInit(IIC_TypeDef type)
{
	IIC_RegDef* iicAddr = NULL;
	iicAddr = (IIC_RegDef *)(reg_map(CORE_IICD_CTRL));
	if(type==IIC_0)
	{
		HWRITE(CORE_IICD_CTRL,0);
	}
	else
	{
		HWRITE(CORE_IICD1_CTRL,0);
	}
}

/** 
 * @brief	 IIC send Dma buffer data
 * @param    type: IIC_0/IIC_1                   
 * @param    src :send buffer addr                     
 * @param    len : send data length                      
 * @return	  None
 */
void IIC_SendData(IIC_TypeDef type,uint8_t *src, uint16_t len)
{
	DMA_STARTRegDef dmaStart;
	IIC_RegDef * iicAddr = NULL;
	if(type==IIC_0)
	{

		HWRITEW(CORE_IICD_TXADDR, (int)src);
    	HWRITEW(CORE_IICD_TXLEN, len);
    	iicAddr = (IIC_RegDef *)(reg_map(CORE_IICD_CTRL));
	}
	else
	{
		HWRITEW(CORE_IICD1_TXADDR, (int)src);
    	HWRITEW(CORE_IICD1_TXLEN, len);
    	iicAddr = (IIC_RegDef *)(reg_map(CORE_IICD1_CTRL));
	}
	//I2cTxPtr = (uint8_t *)reg_map_m0(HREADW((uint32_t)&I2cAdr->TxAddr));
	//memcpy(I2cTxPtr, Src, len);
	HWRITEW((uint32_t )&iicAddr->TxLen, len);
	HWRITEW((uint32_t)&iicAddr->RxLen, 0);
	HREAD_STRUCT(CORE_DMA_START,&dmaStart);
	if(type==IIC_0)
	{
		HREAD_STRUCT(CORE_DMA_START, &dmaStart);
		dmaStart.iic_dma_start=1;
		HWRITE_STRUCT(CORE_DMA_START, &dmaStart);
		while(!(HREAD(CORE_DMA_STATUS) & (IIC0_DmaDone)));
	}
	else
	{
		HREAD_STRUCT(CORE_DMA_START, &dmaStart);
		dmaStart.iic1_dma_start=1;
		HWRITE_STRUCT(CORE_DMA_START, &dmaStart);
		while(!(HREAD(CORE_DMA_STATUS) & (IIC1_DmaDone)));
	}
}

/** 
 * @brief  	 IIC receive data by dma
 * @param    type: IIC_0/IIC_1                     
 * @param    src : send data buffer                   
 * @param    srclen : send data length                 
 * @param    dest : read buffer addr                  
 * @param    destlen :read data length                 
 * @return	 None
 */
void IIC_ReceiveData(IIC_TypeDef type,uint8_t *src, uint16_t srclen, uint8_t *dest, uint16_t destlen)
{
	DMA_STARTRegDef dmaStart;
	IIC_RegDef * iicAddr = NULL;
	//uint8_t * I2cTxPtr = NULL;
	//uint8_t * I2cRxPtr = NULL;
	if(type==IIC_0)
	{
		HWRITEW(CORE_IICD_TXADDR,(int)src);
    	HWRITEW(CORE_IICD_TXLEN, srclen);
    	HWRITEW(CORE_IICD_RXADDR,(int) dest);
    	HWRITEW(CORE_IICD_RXLEN, destlen);
    	iicAddr = (IIC_RegDef*)(reg_map(CORE_IICD_CTRL));
	}
	else
	{
		HWRITEW(CORE_IICD1_TXADDR, (int)src);
    	HWRITEW(CORE_IICD1_TXLEN, srclen);
   	 	HWRITEW(CORE_IICD1_RXADDR, (int) dest);
    	HWRITEW(CORE_IICD1_RXLEN, destlen);
    	iicAddr = (IIC_RegDef*)(reg_map(CORE_IICD1_CTRL));
	}
	//I2cTxPtr = (uint8_t *)reg_map_m0(HREADW((uint32_t)&I2cAdr->TxAddr));
	//I2cRxPtr = (uint8_t *)reg_map_m0(HREADW((uint32_t)&I2cAdr->RxAddr));
	//memcpy(I2cTxPtr, Src, Srclen);
	HWRITEW((uint32_t)&iicAddr->TxLen, srclen);
	HWRITEW((uint32_t )&iicAddr->RxLen, destlen);
	HREAD_STRUCT(CORE_DMA_START,&dmaStart);
	if(type==IIC_0)
	{
		HREAD_STRUCT(CORE_DMA_START, &dmaStart);
		dmaStart.iic_dma_start=1;
		HWRITE_STRUCT(CORE_DMA_START, &dmaStart);
		while(!(HREAD(CORE_DMA_STATUS) & (IIC0_DmaDone)));
	}
	else
	{
		HREAD_STRUCT(CORE_DMA_START, &dmaStart);
		dmaStart.iic1_dma_start=1;
		HWRITE_STRUCT(CORE_DMA_START, &dmaStart);
		while(!(HREAD(CORE_DMA_STATUS) & (IIC1_DmaDone)));
	}

	//memcpy(Dest,I2cRxPtr,Destlen);
}

/** 
 * @brief  	 Enable IIC interrupt
 * @param    type: IIC_0/IIC_1                      
 * @param    irqnum: Interrupt priority:1~15                 
 * @return    None
 */
void IIC_IRQ_Enable(IIC_TypeDef type,uint8_t irqlevel)
{
	IICD_CTRLRegDef	IIC0Ctrl;
	IICD1_CTRLRegDef IIC1Ctrl;
	if(type==IIC_0)
	{
		NVIC_Configuration(iicd_IRQn,irqlevel,ENABLE);
		HREAD_STRUCT(CORE_IICD_CTRL,&IIC0Ctrl);
		IIC0Ctrl.iicd_intr_en=1;
		HWRITE_STRUCT(CORE_IICD_CTRL,&IIC0Ctrl);
	}
	else
	{
		NVIC_Configuration(iicd1_IRQn,irqlevel,ENABLE);
		HREAD_STRUCT(CORE_IICD1_CTRL,&IIC1Ctrl);
		IIC1Ctrl.iicd1_intr_en=1;
		HWRITE_STRUCT(CORE_IICD1_CTRL,&IIC1Ctrl);
	}
}
/** 
 * @brief  Disable IIC interrupt
 * @param    type:IIC_0/IIC_1                                             
 * @return  None
 */
void IIC_IRQ_Disable(IIC_TypeDef type)
{
	IICD_CTRLRegDef	iic0Ctrl;
	IICD1_CTRLRegDef iic1Ctrl;
	if(type==IIC_0)
	{
		NVIC_Configuration(iicd_IRQn,0,DISABLE);
		HREAD_STRUCT(CORE_IICD_CTRL,&iic0Ctrl);
		iic0Ctrl.iicd_intr_en=0;
		HWRITE_STRUCT(CORE_IICD_CTRL,&iic0Ctrl);
	}
	else
	{
		NVIC_Configuration(iicd1_IRQn,0,DISABLE);
		HREAD_STRUCT(CORE_IICD1_CTRL,&iic1Ctrl);
		iic1Ctrl.iicd1_intr_en=0;
		HWRITE_STRUCT(CORE_IICD1_CTRL,&iic1Ctrl);
	}
}
/** 
 * @brief  Clear Interrupt trigger status
 * @param    type:IIC_0/IIC_1                     
 * @return  None
 */
void IIC_IRQStatusClear(IIC_TypeDef type)
{
	IICD_CTRLRegDef	iic0Ctrl;
	IICD1_CTRLRegDef iic1Ctrl;
	if(type==IIC_0)
	{
		HREAD_STRUCT(CORE_IICD_CTRL,&iic0Ctrl);
		iic0Ctrl.iicd_intr_clr=1;
		HWRITE_STRUCT(CORE_IICD_CTRL,&iic0Ctrl);
		iic0Ctrl.iicd_intr_clr=0;
		HWRITE_STRUCT(CORE_IICD_CTRL,&iic0Ctrl);
	}
	else
	{
		HREAD_STRUCT(CORE_IICD1_CTRL,&iic1Ctrl);
		iic1Ctrl.iicd1_intr_clr=1;
		HWRITE_STRUCT(CORE_IICD1_CTRL,&iic1Ctrl);
		iic1Ctrl.iicd1_intr_clr=0;
		HWRITE_STRUCT(CORE_IICD1_CTRL,&iic1Ctrl);
	}
}





