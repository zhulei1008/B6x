/*
 * Copyright (c) 2006-2020, YICHIP Development Team
 * @file     touch.c
 * @brief    source file for setting timer
 *
 * Change Logs:
 * Date            Author             Version        Notes
 * 2021-4-26       WJJ            V 1.0.0         the first version
 * note:  temporary version  revision
 */
#include "yc_debug.h"
#include "yc11xx_touch.h"
#include "yc11xx_systick.h"
#include "yc11xx.h"
/** 
 * @brief  	Touch Register initialization
 * @param   TOUCH_InitStruct:Register configuration

 * @return   None
 */
void TOUCH_Init(TOUCH_InitTypeDef* TouchInitStruct)
{
	uint32_t touchRegCtrl = 0;

	/*old ana
	touchRegCtrl = ((TouchInitStruct->TS_ANA_CTRL.tch2_en << 29) 			 | \
					 (TouchInitStruct->TS_ANA_CTRL.ts_esi << 8) 				 |	\
					 TS_ANA_DEFAULT);

	TOUCH_WriteReg(Ts_Ana, touchRegCtrl);
	*/
	/*old fir
	touchRegCtrl = ((TouchInitStruct->TS_FIR_CTRL.ts_ch1_ffi_cfg << 0)		 | \
					  (TouchInitStruct->TS_FIR_CTRL.ts_ch1_avg_mode << 3) 		 | \
					  (TouchInitStruct->TS_FIR_CTRL.ts_ch1_sfi_cfg << 4) 		 | \
					  (TouchInitStruct->TS_FIR_CTRL.ts_ch1_en << 7) 			 | \
					  (TouchInitStruct->TS_FIR_CTRL.ts_ch2_ffi_cfg << 8) 		 | \
					  (TouchInitStruct->TS_FIR_CTRL.ts_ch2_avg_mode << 11) 	 | \
					  (TouchInitStruct->TS_FIR_CTRL.ts_ch2_sfi_cfg << 12)  	 | \
					  (TouchInitStruct->TS_FIR_CTRL.ts_ch2_en << 15)			 | \
					  (TouchInitStruct->TS_FIR_CTRL.ts_clk_div << 16)			 | \
					  TS_FIR_DEFAULT);

	TOUCH_WriteReg(Ts_Fir, touchRegCtrl);
    */
	touchRegCtrl = TS_BL1_DEFAULT;
	TOUCH_WriteReg(Ts_Bl1, touchRegCtrl);

	touchRegCtrl = TS_BL2_DEFAULT;
	TOUCH_WriteReg(Ts_Bl2, touchRegCtrl);

	TOUCH_WriteReg(Ts_Bl4, TS_BL4_DEFAULT);
	touchRegCtrl = ((TouchInitStruct->TS_BL4_CTRL.ts_ch1_baseline_cfg << 0)  |	\
					  (TouchInitStruct->TS_BL4_CTRL.ts_ch2_baseline_cfg << 12));
	TOUCH_WriteReg(Ts_Bl4, touchRegCtrl);
	touchRegCtrl = ((TouchInitStruct->TS_BL3_CTRL.ts_ch1_fdl << 0) 			|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch1_tfrt_cfg << 4)		|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch1_tfrt_en << 7)		|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch1_track_en << 13)		|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch1_baseline_wr << 14)	|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch2_fdl << 16) 			|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch2_tfrt_cfg << 20)		|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch2_tfrt_en << 23)		|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch2_track_en << 29)		|	\
					  (TouchInitStruct->TS_BL3_CTRL.ts_ch2_baseline_wr << 30)	|	\
					  TS_BL3_DEFAULT);
	//SysTick_DelayUs(100);
	TOUCH_WriteReg(Ts_Bl3, touchRegCtrl);


	touchRegCtrl = ((TouchInitStruct->TS_CMP1_CTRL.ts_ch1_dr_cfg << 0)		|	\
					  (TouchInitStruct->TS_CMP1_CTRL.ts_ch1_dt_cfg << 4)		|	\
					  (TouchInitStruct->TS_CMP1_CTRL.ts_ch1_rth_cfg << 8)		|	\
					  (TouchInitStruct->TS_CMP1_CTRL.ts_ch1_tth_cfg << 16)		|	\
					  TS_CMP1_DEFAULT);
	TOUCH_WriteReg(Ts_Cmp1, touchRegCtrl);

	touchRegCtrl = ((TouchInitStruct->TS_CMP2_CTRL.ts_ch2_dr_cfg << 0)		|	\
					  (TouchInitStruct->TS_CMP2_CTRL.ts_ch2_dt_cfg << 4)		|	\
					  (TouchInitStruct->TS_CMP2_CTRL.ts_ch2_rth_cfg << 8)		|	\
					  (TouchInitStruct->TS_CMP2_CTRL.ts_ch2_tth_cfg << 16)		|	\
					  TS_CMP2_DEFAULT);
	TOUCH_WriteReg(Ts_Cmp2, touchRegCtrl);

	touchRegCtrl = ((TouchInitStruct->TS_CAL1_CTRL.ts_ch1_lsl << 0)			|	\
					  (TouchInitStruct->TS_CAL1_CTRL.ts_ch1_usl << 10)			|	\
					  (TouchInitStruct->TS_CAL1_CTRL.ts_ch1_tl << 20)			|	\
					  TS_CAL1_DEFAULT);
	TOUCH_WriteReg(Ts_Cal1, touchRegCtrl);
	DEBUG_LOG_STRING("Ts_Cal1\r\n");

	touchRegCtrl = ((TouchInitStruct->TS_CAL2_CTRL.ts_ch2_lsl << 0)			|	\
					  (TouchInitStruct->TS_CAL2_CTRL.ts_ch2_usl << 10)			|	\
					  (TouchInitStruct->TS_CAL2_CTRL.ts_ch2_tl << 20)			|	\
					  TS_CAL2_DEFAULT);
	TOUCH_WriteReg(Ts_Cal2, touchRegCtrl);

	touchRegCtrl = ((TouchInitStruct->TS_CAL3_CTRL.ts_ch1_ibc_init << 4)		|	\
					  (TouchInitStruct->TS_CAL3_CTRL.ts_ch1_cdc_init << 8)		|	\
					  (TouchInitStruct->TS_CAL3_CTRL.ts_ch2_ibc_init << 20)	|	\
					  (TouchInitStruct->TS_CAL3_CTRL.ts_ch2_cbc_init << 24)	|	\
					  TS_CAL3_DEFAULT);
	TOUCH_WriteReg(Ts_Cal3, touchRegCtrl);

	touchRegCtrl = ((TouchInitStruct->TS_CAL4_CTRL.ts_ch1_cal_err_th << 0) 	|	\
					  (TouchInitStruct->TS_CAL4_CTRL.ts_ch2_cal_err_th << 8)	|	\
					  TS_CAL4_DEFAULT);
	TOUCH_WriteReg(Ts_Cal4, touchRegCtrl);

    touchRegCtrl = ((TouchInitStruct->TS_FIR_CTRL.ts_ch1_ffi_cfg << 0)       | \
                      (TouchInitStruct->TS_FIR_CTRL.ts_ch1_avg_mode << 3)        | \
                      (TouchInitStruct->TS_FIR_CTRL.ts_ch1_sfi_cfg << 4)         | \
                      (TouchInitStruct->TS_FIR_CTRL.ts_ch1_en << 7)              | \
                      (TouchInitStruct->TS_FIR_CTRL.ts_ch2_ffi_cfg << 8)         | \
                      (TouchInitStruct->TS_FIR_CTRL.ts_ch2_avg_mode << 11)   | \
                      (TouchInitStruct->TS_FIR_CTRL.ts_ch2_sfi_cfg << 12)    | \
                      (TouchInitStruct->TS_FIR_CTRL.ts_ch2_en << 15)             | \
                      (TouchInitStruct->TS_FIR_CTRL.ts_clk_div << 16)            | \
                      (TouchInitStruct->TS_FIR_CTRL.pad_sel_tch1<< 26)             | \
                      (TouchInitStruct->TS_FIR_CTRL.pad_sel_tch2<< 28)            | \
                      TS_FIR_DEFAULT);
    TOUCH_WriteReg(Ts_Fir, touchRegCtrl);

    touchRegCtrl = (
                    /*(TouchInitStruct->TS_ANA_CTRL.tch2_en << 29)             | \*/
                     (TouchInitStruct->TS_ANA_CTRL.lpm_ts_ldo_en << 4)              |  \
                     TS_ANA_DEFAULT);
    TOUCH_WriteReg(Ts_Ana, touchRegCtrl);

    SysTick_DelayUs(100);

    touchRegCtrl = (
                    (TouchInitStruct->TS_ANA_CTRL.tch2_en << 29)             | \
                     (TouchInitStruct->TS_ANA_CTRL.ts_en << 30)              |  \
                     (TouchInitStruct->TS_ANA_CTRL.lpm_ts_ldo_en << 4)              |  \
                     TS_ANA_DEFAULT);
    TOUCH_WriteReg(Ts_Ana, touchRegCtrl);

}

/**
 * @brief    touch enable switch
 * @param    newstate: ENABLE/DISABLE
 * @return     None
 */
void TOUCH_Set( FunctionalState newstate)
{
    uint32_t touchRegCtrl = 0;
    uint32_t i ;
    touchRegCtrl = TOUCH_ReadReg(Ts_Ana);
    if(newstate == ENABLE){
        touchRegCtrl = (newstate << 30|touchRegCtrl);
        TOUCH_WriteReg(Ts_Ana, touchRegCtrl);
        touchRegCtrl = TOUCH_ReadReg(Ts_Fir) &~ ((1<<7)|(1<<15));
        touchRegCtrl = touchRegCtrl|(newstate<<7)|(newstate<<15);
        TOUCH_WriteReg(Ts_Fir, touchRegCtrl);
    }else{
        touchRegCtrl = ((touchRegCtrl) &~ (1<< 30));
        TOUCH_WriteReg(Ts_Ana, touchRegCtrl);
        touchRegCtrl = TOUCH_ReadReg(Ts_Fir) &~ ((1<<7)|(1<<15));
        touchRegCtrl = touchRegCtrl|(newstate<<7)|(newstate<<15);
        TOUCH_WriteReg(Ts_Fir, touchRegCtrl);
    }
}

/**
 * @brief    change pads when sixchannel function turn on
 * @param    baseLine1/baseLine2: Ch1_baseLine/Ch2_baseLine
 * @return     None
 */
void TOUCH_PadChange(uint8_t pad1,uint8_t pad2)
{
    TOUCH_InitTypeDef   TouchInitStruct;
    uint32_t touchRegCtrl = 0;
    touchRegCtrl = TOUCH_ReadReg(Ts_Fir) &~ ((3 << 26) |(3<< 28));
    touchRegCtrl = (touchRegCtrl| (pad1<< 26) | (pad2<< 28)  );
    TOUCH_WriteReg(Ts_Fir, touchRegCtrl);
}

/**
 * @brief    update baseline in different pads
 * @param    baseLine1/baseLine2: Ch1_baseLine/Ch2_baseLine
 * @return     None
 */
void TOUCH_BaselineChange(uint16_t  baseLine1,uint16_t baseLine2)
{
    //MyPrintf("changed  vaule  baseLine1,baseLine2 =%x,%x,\r\n ",baseLine1,baseLine2);
    uint32_t touchRegCtrl = 0;
    if(baseLine1 > 0){
        touchRegCtrl = TOUCH_ReadReg(Ts_Bl4) &~ (0xfff);
        touchRegCtrl = (touchRegCtrl|baseLine1);
        TOUCH_WriteReg(Ts_Bl4, touchRegCtrl);

        touchRegCtrl = TOUCH_ReadReg(Ts_Bl3) &~ (1<<14);
        TOUCH_WriteReg(Ts_Bl3, touchRegCtrl);
        touchRegCtrl = (touchRegCtrl|(1<<14));
        TOUCH_WriteReg(Ts_Bl3, touchRegCtrl);
    }
	if(baseLine2 > 0)
	{
		touchRegCtrl = TOUCH_ReadReg(Ts_Bl4) &~ (0xfff<<12);
		touchRegCtrl = (touchRegCtrl|(baseLine2<<12));
		TOUCH_WriteReg(Ts_Bl4, touchRegCtrl);

		touchRegCtrl = TOUCH_ReadReg(Ts_Bl3);
		TOUCH_WriteReg(Ts_Bl3, TS_BL3_DEFAULT);
		TOUCH_WriteReg(Ts_Bl3, touchRegCtrl);
	}
}
//void touch_write_reg(Touch_Reg_TypeDef touch_reg, uint32_t ts_ctrl)
//{
//	uint8_t writeLpmVal = 0;
//
//	if(touch_reg > 7)
//	{
//		writeLpmVal = touch_reg & 7;
//		CoreReg_LpmWriteCommon(ts_ctrl, CORE_LPM_TS_CTRL2, 1 << writeLpmVal);
//	}
//	else
//	{
//		writeLpmVal = touch_reg;
//		CoreReg_LpmWriteCommon(ts_ctrl, CORE_LPM_TS_CTRL, 1 << writeLpmVal);
//	}
//}
/** 
 * @brief       Writes the parameters to the corresponding register
 * @param    touch_reg :The corresponding register name               
 * @param    ts_ctrl :The value to write to the register                 
 * @return     None
 */
void TOUCH_WriteReg(Touch_Reg_TypeDef touchReg, uint32_t touchCtrl)
{
	uint8_t WriteLpmVal = 0;

	OS_ENTER_CRITICAL();
	SetLockLpmWriteReg();

	HWRITEW(CORE_LPM_TS_CTRL, 0x0000);
	HWRITEL(CORE_LPM_REG, touchCtrl);
	HWRITEW(CORE_LPM_TS_CTRL, 1 << touchReg);

	SysTick_DelayMs(1);
	SetReleaseLpmWriteReg();
	OS_EXIT_CRITICAL();
}
/** 
 * @brief    Read the value of the relevant register
 * @param    touch_reg: The register to read               
 * @return  
 */
uint32_t TOUCH_ReadReg(Touch_Reg_TypeDef touchReg)
{
	uint32_t readRegValue = 0;
//    OS_ENTER_CRITICAL();
//    SetLockLpmWriteReg();
	HWRITEW(CORE_LPM_TS_RD_MUX,0x0000);
	/* Location 0x81f2  write 1 to read 804C-804f to the corresponding register */
	if(touchReg > 7)
		HWRITEW(CORE_LPM_TS_RD_MUX, 1 << (touchReg + 1));/* 0x81f2 bit 0 not read*/
	else
		HWRITEW(CORE_LPM_TS_RD_MUX, 1 << touchReg);

		readRegValue = HREADL(CORE_LPM_TS_CFG_STATUS);

	return readRegValue;
}
/** 
 * @brief        read the status of touch:touch or relaese
 * @param    TOUCH_Chx_Num	touch_chx  :Ts_Ch1/Ts_Ch2
 * @return      the  status of Ts_Ch1/Ts_Ch2,Returns 1 if touched, 0 otherwise
 */
TOUCH_Status TOUCH_ReadStatus(TOUCH_Chx_Num	touchChx)
{
	//uint8_t value = 0;
	uint8_t status = 0;

	status = HREAD(CORE_LPM_TS_STATUS);

	if(touchChx == Ts_Ch1)
	{
		if(status & (1 << ch1_ts_status))
			return Ts_Touch;
		else
			return Ts_Release;
	}
	else
	{
		if(status & (1 << ch2_ts_tsatus))
			return Ts_Touch;
		else
			return Ts_Release;
	}

}
/** 
 * @brief       Read the base value
 * @param    TOUCH_Chx_Num	touch_chx  :Ts_Ch1/Ts_Ch2
 * @return      Get the reference value for channel 1 or channel 2
 */
uint32_t TOUCH_ReadBaseline(TOUCH_Chx_Num touchChx)
{
	uint32_t tsBaselineValue = 0;

	if(touchChx != Ts_Ch2)
		tsBaselineValue = ((HREAD(CORE_LPM_TS_BASELINE + 1) & 0x0f) << 8) | \
							 HREAD(CORE_LPM_TS_BASELINE);
	else
		tsBaselineValue = ((HREAD(CORE_LPM_TS_BASELINE + 2) << 4) | \
							 (HREAD(CORE_LPM_TS_BASELINE + 1) & 0xf0) >> 4);

	return tsBaselineValue;
}
/** 
 * @brief        Read the filter output data
 * @param    TOUCH_Chx_Num	ouch_chx  :Ts_Ch1/Ts_Ch2
 * @return      Read the value of filter output channel 1 or channel 2
 */
uint32_t TOUCH_ReadFirData(TOUCH_Chx_Num touchChx)
{
	uint32_t tsFirDataValue = 0;
	uint32_t fakeRead = 0;
	if(touchChx != Ts_Ch2){
	    //fakeRead = HREAD(CORE_LPM_TS_FIR2_DATA)|HREAD(CORE_LPM_TS_FIR2_DATA+1)|HREAD(CORE_LPM_TS_FIR2_DATA+2);
//	    MyPrintf("1FirData === %x,%x,%x\r\n",HREAD(CORE_LPM_TS_FIR2_DATA),HREAD(CORE_LPM_TS_FIR2_DATA+1),HREAD(CORE_LPM_TS_FIR2_DATA+2));
		tsFirDataValue = ((HREAD(CORE_LPM_TS_FIR2_DATA + 1) & 0x0f) << 8) |	 HREAD(CORE_LPM_TS_FIR2_DATA);
	}else{
	    //fakeRead = HREAD(CORE_LPM_TS_FIR2_DATA)|HREAD(CORE_LPM_TS_FIR2_DATA+1)|HREAD(CORE_LPM_TS_FIR2_DATA+2);
//	    MyPrintf("2FirData === %x,%x,%x\r\n",HREAD(CORE_LPM_TS_FIR2_DATA),HREAD(CORE_LPM_TS_FIR2_DATA+1),HREAD(CORE_LPM_TS_FIR2_DATA+2));
	    tsFirDataValue = ((HREAD(CORE_LPM_TS_FIR2_DATA + 2) << 4) | \
							 ((HREAD(CORE_LPM_TS_FIR2_DATA + 1) & 0xf0) >> 4));
	}

	return tsFirDataValue;
}

