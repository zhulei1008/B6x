 /**
 * @file yc11xx_spi.c
 * @author duanchu.he
 * @brief SPI driver
 * @version 0.1
 * @date 2021-07-06
 * 
 * 
 */
#include "yc11xx_spi.h"
#include "reg_addr.h"
#include "reg_struct.h"
#include "MyPrintf.h"

/**
 * @brief Deinitializes the SPI registers to their default reset values.
 * 
 */
void SPI_DeInit(void)
{
    HWRITEL(CORE_SPI_CTRL, 0x00);
    HWRITEL(CORE_SPI_DMA, 0x00);
    HWRITEL(CORE_SPI_DMA_TX_SADDR, 0x00);
    HWRITEL(CORE_SPI_DMA_TX_LEN, 0x00);
    HWRITEL(CORE_SPI_DMA_RX_LEN, 0x00);
    HWRITEL(CORE_SPI_FIFO, 0x00);
    HWRITEL(CORE_SPI_IRQRS, 0x00);
}

/**
 * @brief Initializes the SPI according to the specified parameters in the SPI_InitStruct.
 * 
 * @param SPI_InitStruct pointer to a SPI_InitTypeDef structure that contains
  *         the configuration information for the SPI.
 */
void SPI_Init(SPI_InitTypeDef* spiInitStruct)
{
	SPI_CTRLRegDef	spiCtrlHandle = {0};
	SPI_FIFO_CTRLRegDef	spiFifoCtrlHandle = {0};

    _ASSERT(Is_SPI_TxRx_Sequence(spiInitStruct->TxRxSeq));
    _ASSERT(Is_SPI_CPHA(spiInitStruct->CPHA));
    _ASSERT(Is_SPI_CPOL(spiInitStruct->CPOL));
    _ASSERT(Is_SPI_Hw_Start_Sel(spiInitStruct->SpiHwStartSel));
    _ASSERT(Is_SPI_ClkDiv(spiInitStruct->ClkDiv));

    HREADL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);

    spiCtrlHandle.clk_div = spiInitStruct->ClkDiv;
    spiCtrlHandle.cpha = spiInitStruct->CPHA;
    spiCtrlHandle.cpol = spiInitStruct->CPOL;
    spiCtrlHandle.fifo_sw_en = spiInitStruct->Fifo_Sw_En;
    spiCtrlHandle.mram_sel = spiInitStruct->Mram_Sel;
    spiCtrlHandle.ncs_dly = spiInitStruct->NcsDly;
    spiCtrlHandle.rx_adj_clk = spiInitStruct->RxAdjClk;
    spiCtrlHandle.rx_adj_en = spiInitStruct->RxAdjEn;
    spiCtrlHandle.trx_dly = spiInitStruct->TxRxDly;
    spiCtrlHandle.tx_rx_seq = spiInitStruct->TxRxSeq;
    spiCtrlHandle.spi_hw_start_sel = spiInitStruct->SpiHwStartSel;

    HWRITEL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);

    HREADL_STRUCT(CORE_SPI_FIFO_CTRL, &spiFifoCtrlHandle);

    spiFifoCtrlHandle.rx_fifo_waterlevel = spiInitStruct->RxFifoWaterlevel;
    spiFifoCtrlHandle.tx_fifo_waterlevel = spiInitStruct->TxFifoWaterlevel;

    HWRITEL_STRUCT(CORE_SPI_FIFO_CTRL, &spiFifoCtrlHandle);
}


/**
 * @brief Enables or disables the HPI hardware start.
 * 
 * @param newstate DISABLE or ENABLE
 */
void SPI_HwStartCmd(FunctionalState newstate)
{
	SPI_CTRLRegDef	spiCtrlHandle = {0};

    _ASSERT(IS_FUNCTIONAL_STATE(newstate));

    HREADL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);

    spiCtrlHandle.spi_hw_start_en = newstate;

    HWRITEL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);
}

/**
 * @brief Enables or disables the SPI interface.
 * 
 * @param newstate new state of the SPI interface.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_EnableCmd(FunctionalState newstate)
{
	SPI_CTRLRegDef	spiCtrlHandle = {0};

    _ASSERT(IS_FUNCTIONAL_STATE(newstate));

    HREADL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);

    spiCtrlHandle.spi_en = newstate;

    HWRITEL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);
}

/**
 * @brief Enables or disables the SPI DMA ping-pang display.
 * 
 * @param newstate new state of the SPI DMA ping-pang display.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_PingpangEnableCmd(FunctionalState newstate)
{
	SPI_DMARegDef	spiDmaHandle= {0};

    _ASSERT(IS_FUNCTIONAL_STATE(newstate));

    HREADL_STRUCT(CORE_SPI_DMA, &spiDmaHandle);

    spiDmaHandle.dma_pingpang_en = newstate;

    HWRITEL_STRUCT(CORE_SPI_DMA, &spiDmaHandle);
}

/**
 * @brief Enables or disables the SPI .
 *
 * @param newstate new state of the SPI.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_Start(FunctionalState newstate)
{
	SPI_CTRLRegDef		spiCtrlHandle = {0};

    _ASSERT(IS_FUNCTIONAL_STATE(newstate));

    HREADL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);

    spiCtrlHandle.spi_start = newstate;

	HWRITEL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);
}

/**
 * @brief Enables or disables the SPI DMA.
 * 
 * @param newstate new state of the SPI DMA.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_DmaEnableCmd(FunctionalState newstate)
{
	SPI_DMARegDef	spiDmaHandle = {0};

    _ASSERT(IS_FUNCTIONAL_STATE(newstate));

    HREADL_STRUCT(CORE_SPI_DMA, &spiDmaHandle);

    spiDmaHandle.dma_en = newstate;

    HWRITEL_STRUCT(CORE_SPI_DMA, &spiDmaHandle);
}

/**
 * @brief Enables or disables the SPI DMA auto start.
 * 
 * @param newstate new state of the SPI DMA auto start.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_DmaAutoStartCmd(FunctionalState newstate)
{
	SPI_DMARegDef	spiDmaHandle;

    _ASSERT(IS_FUNCTIONAL_STATE(newstate));

    HREADL_STRUCT(CORE_SPI_DMA, &spiDmaHandle);

    spiDmaHandle.dma_start_auto = newstate;

    HWRITEL_STRUCT(CORE_SPI_DMA, &spiDmaHandle);
}

/**
 * @brief Enables or disables the SPI FIFO auto start.
 * 
 * @param newstate new state of the SPI FIFO auto start.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_FifoAutoStartCmd(FunctionalState newstate)
{
	SPI_FIFORegDef	spiFifoHandle;

    _ASSERT(IS_FUNCTIONAL_STATE(newstate));

    HREADL_STRUCT(CORE_SPI_FIFO, &spiFifoHandle);

    spiFifoHandle.fifo_auto_rst = newstate;

    HWRITEL_STRUCT(CORE_SPI_FIFO, &spiFifoHandle);
}

/**
 * @brief Writes data to the FIFO of TX
 * 
 * @param tx_data To write txdata
 */

void WRITE_TxFifData(uint8_t txdata)
{
	SPI_FIFOTDATARegDef	spiFifoDataHandle = {0};

	spiFifoDataHandle.tx_fifo_data = txdata;

    HWRITE_STRUCT(CORE_SPI_FIFOTDATA, &spiFifoDataHandle);
}

/**
 * @brief Writes data to the FIFO of TX
 *
 * @param tx_data To write txdata
 */

void WRITE_RxFifData(uint8_t rxdata)
{
	SPI_FIFORDATARegDef	spiFifoDataHandle = {0};

	spiFifoDataHandle.rx_fifo_data = rxdata;

    HWRITE_STRUCT(CORE_SPI_FIFORDATA, &spiFifoDataHandle);
}


/**
 * @brief READ data to the FIFO of RX
 *
 * @param rx_data To read rxdata
 */

uint8_t READ_RxFifoData(void)
{
	SPI_FIFORDATARegDef	spiFifoDataHandle = {0};

	HREAD_STRUCT(CORE_SPI_FIFORDATA, &spiFifoDataHandle);

	return spiFifoDataHandle.rx_fifo_data;
}
/**
 * @brief Decrease the RXFIFO depth by one
 * 
 */
void Reduce_OneByteRxFifo(void)
{
	SPI_FIFORegDef	spiFifoHandle;

	HREADW_STRUCT(CORE_SPI_FIFO, &spiFifoHandle);

    spiFifoHandle.rx_fifo_rd = 1;

    HWRITEW_STRUCT(CORE_SPI_FIFO, &spiFifoHandle);
}

void Reduce_OneByteTxFifo(void)
{
	SPI_FIFORegDef	spiFifoHandle;

	HREADW_STRUCT(CORE_SPI_FIFO, &spiFifoHandle);

    spiFifoHandle.tx_fifo_rd = 1;

    HWRITEW_STRUCT(CORE_SPI_FIFO, &spiFifoHandle);
}

/**
 * @brief Enables or disables the SPI interface interrupts.
 * 
 * @param irq_mis irq_mis interrupt type
 * @param newstate new state of the specified SPI interrupts.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_ITConfig(SPI_IRQ_MIS irqMis, FunctionalState newstate)
{
	SPI_IRQMENRegDef	spiIrqHandle = {0};

    switch(irqMis)
    {
   		case DMA_Done_MIS:
   			spiIrqHandle.dma_done_en = newstate;
   			break;
   		case TxFifo_Low_MIS:
   			spiIrqHandle.tx_fifo_lo_en = newstate;
   			break;
   		case TxFifo_Overflow_MIS:
   			spiIrqHandle.tx_fifo_ovfl_en = newstate;
   			break;
   		case RxFifo_High_MIS:
   			spiIrqHandle.rx_fifo_hi_en = newstate;
   			break;
   		case RxFifo_Overflow_MIS:
   			spiIrqHandle.rx_fifo_ovfl_en = newstate;
   			break;
   		case Start_Over_Quick_MIS:
   			spiIrqHandle.start_over_quick_en = newstate;
   			break;
    }

    HWRITE_STRUCT(CORE_SPI_IRQMEN, &spiIrqHandle);
}

/**
 * @brief Clears the SPI's interrupt pending bits.
 * 
 * @param irq_ris irq_ris interrupt type
 * @param newstate new state of the specified SPI interrupts.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_ClearFlagStatus(SPI_IRQ_RIS irqRis, FunctionalState newstate)
{
	SPI_IRQRSRegDef	spiIrqHandle = {0};

    switch(irqRis)
    {
   		case DMA_Done_RIS:
   			spiIrqHandle.dma_done_ris = newstate;
   			break;
   		case TxFifo_Low_RIS:
   			spiIrqHandle.tx_fifo_lo_ris = newstate;
   			break;
   		case TxFifo_Overflow_RIS:
   			spiIrqHandle.tx_fifo_ovfl_ris = newstate;
   			break;
   		case RxFifo_High_RIS:
   			spiIrqHandle.rx_fifo_hi_ris = newstate;
   			break;
   		case RxFifo_Overflow_RIS:
   			spiIrqHandle.rx_fifo_ovfl_ris = newstate;
   			break;
   		case Start_Over_Quick_RIS:
   			spiIrqHandle.start_over_quick_ris = newstate;
   			break;
    }

    HWRITE_STRUCT(CORE_SPI_IRQRS, &spiIrqHandle);
}

/**
 * @brief Clears the SPI's interrupt pending bits.
 * 
 * @param irq_mis irq_mis interrupt type
 * @param newstate new state of the specified SPI interrupts.
  *         This parameter can be: ENABLE or DISABLE.
 */
void SPI_ClearITStatus(SPI_IRQ_MIS irqMis, FunctionalState newstate)
{
	SPI_IRQMSRegDef	spiIrqHandle;

    switch(irqMis)
    {
   		case DMA_Done_MIS:
   			spiIrqHandle.dma_done_mis = newstate;
   			break;
   		case TxFifo_Low_MIS:
   			spiIrqHandle.tx_fifo_lo_mis = newstate;
   			break;
   		case TxFifo_Overflow_MIS:
   			spiIrqHandle.tx_fifo_ovfl_mis = newstate;
   			break;
   		case RxFifo_High_MIS:
   			spiIrqHandle.rx_fifo_hi_mis = newstate;
   			break;
   		case RxFifo_Overflow_MIS:
   			spiIrqHandle.rx_fifo_ovfl_mis = newstate;
   			break;
   		case Start_Over_Quick_MIS:
   			spiIrqHandle.start_over_quick_mis = newstate;
   			break;
    }

    HWRITE_STRUCT(CORE_SPI_IRQMS, &spiIrqHandle);
}

/**
 * @brief Checks whether the SPI interface  is set or not.
 * 
 * @param irq_mis irq_mis interrupt type
 * @return FlagStatus SET or RESET
 */
FlagStatus SPI_GetITStatus(SPI_IRQ_MIS irqMis)
{
	SPI_IRQMSRegDef	spiIrqHandle;
	FlagStatus bitStatus = RESET;

    HREAD_STRUCT(CORE_SPI_IRQMS, &spiIrqHandle);

    switch(irqMis)
    {
   		case DMA_Done_MIS:
   			bitStatus = spiIrqHandle.dma_done_mis;
   			break;
   		case TxFifo_Low_MIS:
   			bitStatus = spiIrqHandle.tx_fifo_lo_mis;
   			break;
   		case TxFifo_Overflow_MIS:
   			bitStatus = spiIrqHandle.tx_fifo_ovfl_mis;
   			break;
   		case RxFifo_High_MIS:
   			bitStatus = spiIrqHandle.rx_fifo_hi_mis;
   			break;
   		case RxFifo_Overflow_MIS:
   			bitStatus = spiIrqHandle.rx_fifo_ovfl_mis;
   			break;
   		case Start_Over_Quick_MIS:
   			bitStatus = spiIrqHandle.start_over_quick_mis;
   			break;
    }


    return  bitStatus;
}

/**
 * @brief Checks whether the SPI  flag is set or not.
 * 
 * @param irq_ris irq_ris interrupt type
 * @return FlagStatus SET or RESET
 */
FlagStatus SPI_GetFlagStatus(SPI_IRQ_RIS irq_ris)
{
	SPI_IRQRSRegDef	spiIrqHandle;
	FlagStatus bitStatus = RESET;

    HREAD_STRUCT(CORE_SPI_IRQRS, &spiIrqHandle);

    switch(irq_ris)
    {
   		case DMA_Done_RIS:
   			bitStatus = spiIrqHandle.dma_done_ris;
   			break;
   		case TxFifo_Low_RIS:
   			bitStatus = spiIrqHandle.tx_fifo_lo_ris;
   			break;
   		case TxFifo_Overflow_RIS:
   			bitStatus = spiIrqHandle.tx_fifo_ovfl_ris;
   			break;
   		case RxFifo_High_RIS:
   			bitStatus = spiIrqHandle.rx_fifo_hi_ris;
   			break;
   		case RxFifo_Overflow_RIS:
   			bitStatus = spiIrqHandle.rx_fifo_ovfl_ris;
   			break;
   		case Start_Over_Quick_RIS:
   			bitStatus = spiIrqHandle.start_over_quick_ris;
   			break;
    }

    return  bitStatus;
}

/**
 * @brief Transmits one data via SPI DMA.
 * 
 * @param data the data you want transmit.
 */
void SPI_SendData(uint8_t data)
{
	SPI_SendAndReceiveData(&data, 1, 0, 0);
}

/**
 * @brief Transmits datas via SPI DMA.
 * 
 * @param txbuff pointer to a buf that contains the data you want send.
 * @param txlen the buf length
 */
void SPI_SendBuff(uint8_t *txbuff, uint32_t txlen)
{
	SPI_SendAndReceiveData(txbuff, txlen, 0, 0);
}

/**
 * @brief Send and recerive data.
 * 
 * @param txbuff pointer to a txbuff  that contains the data you want send.
 * @param txlen the length of send datas
 * @param rxbuff pointer to a txbuff  that contains the data you want receive.
 * @param rxlen the length of receive datas
 */
void SPI_SendAndReceiveData(uint8_t *txBuff, uint32_t txlen, uint8_t *rxBuff, uint32_t rxlen)
{
    SPI_CTRLRegDef	spiCtrlHandle = {0};
    SPI_DMA_TX_LENRegDef	spiDmaTxHandle = {0};
    SPI_DMA_RX_LENRegDef	spiDmaRxHandle = {0};
    SPI_DMA_TX_SADDRRegDef	spiDmaTxSaddrHandle = {0};
    SPI_DMA_RX_SADDRRegDef	spiDmaRxSaddrHandle = {0};

    if (txlen < 1)
        return;

    spiDmaTxSaddrHandle.tx_start_addr = (uint32_t)txBuff;
    HWRITEL_STRUCT(CORE_SPI_DMA_TX_SADDR, &spiDmaTxSaddrHandle);

    spiDmaRxSaddrHandle.rx_start_addr = (uint32_t)rxBuff;
    HWRITEL_STRUCT(CORE_SPI_DMA_RX_SADDR, &spiDmaRxSaddrHandle);

    spiDmaTxHandle.tx_len = txlen;
    HWRITEL_STRUCT(CORE_SPI_DMA_TX_LEN, &spiDmaTxHandle);

    spiDmaRxHandle.rx_len = rxlen;
    HWRITEL_STRUCT(CORE_SPI_DMA_RX_LEN, &spiDmaRxHandle);

    HREADL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);
    spiCtrlHandle.spi_start = 1;
	HWRITEL_STRUCT(CORE_SPI_CTRL, &spiCtrlHandle);

	while (!(SPI_GetFlagStatus(DMA_Done_RIS)));
	SPI_ClearFlagStatus(DMA_Done_RIS, ENABLE);
}



