#ifndef __YC1121E_USB_H__
#define __YC1121E_USB_H__

#include "yc11xx.h"

#define USB_PID_OUT		0xe1
#define USB_PID_IN		0x69
#define USB_PID_SETUP	0x2d
#define USB_PID_DATA0	0xc3
#define USB_PID_DATA1	0x4b

#define SET_ADDRESS			0x0500
#define SET_CONFIGURATION		0x0900
#define SET_INTERFACE		0x0B01
#define CLEAR_FEATURE_END		0x0102
#define GET_STATUS_END		0x0082
#define GET_DESCRIPTOR			0x0680
#define GET_HID_DESCRIPTOR		0x0681
#define GET_HID_REPORT			0x01a1
#define GET_HID_IDLE				0x02a1
#define GET_HID_PROTOCOL		0x03a1
#define SET_HID_REPORT			0x0921
#define SET_HID_IDLE				0x0a21
#define SET_HID_PROTOCOL		0x0b21
#define GET_MAX_LUN			0xfea1

#define DESC_DEVICE			0x0100
#define DESC_CONFIG			0x0200
#define DESC_STRING0		0x0300
#define DESC_STRING1		0x0301
#define DESC_STRING2		0x0302
#define DESC_STRING3		0x0303
#define DESC_HID				0x21
#define DESC_HID_RPT		0x2200

#define UFICMD_INQUIRY		0x12
#define UFICMD_READCAP		0x25
#define UFICMD_READ			0x28
#define UFICMD_WRITE		0x2A
#define UFICMD_REQUEST_SENSE			0x03	
#define UFICMD_MODE_SENSE			0x5A	
#define UFICMD_TEST_UNIT_READY			0	


#define USB_STATUS_SETUP		1
#define USB_STATUS_SUSPEND	2
#define USB_STATUS_NAK			4
#define USB_STATUS_RESET		8
#define USB_STATUS_ACK			16
#define USB_STATUS_RXREADY	32

#define core_usb_config          0x8c00 
#define core_usb_addr                     0x8c01 
#define core_usb_int_mask                 0x8c02 
#define core_usb_rx_saddr                 0x8c04 
#define core_usb_rx_buflen                0x8c06 
#define core_usb_rxptr                    0x8c08 
#define core_usb_tx_saddr0                0x8c0a 
#define core_usb_tx_saddr1                0x8c0c 
#define core_usb_tx_saddr2                0x8c0e 
#define core_usb_tx_saddr3                0x8c10 
#define core_usb_hmode                    0x8c12 
#define core_usb_trig                     0x8c20 
#define core_usb_stall                    0x8c21
#define core_usb_clear                    0x8c22 
#define core_usb_rx_wptr                  0x8c30 
#define core_usb_status                   0x8c32 
#define core_usb_status_stall             0x8c34 
#define core_usb_txbusy                   0x8c35 
#define core_usb_sof_cnt                 0x8c36 
#define core_usb_ccnt                 0x8c38 
#define core_usb_rx_cnt                 0x8c3a 



extern byte usb_host_read(unsigned char *buffer, unsigned int sector, unsigned char count);
extern byte usb_host_write(unsigned char *buffer, unsigned int sector, unsigned char count);
extern void usb_main(void);
byte usb_host_ufi_write(unsigned char *buffer, unsigned int sector, unsigned char count);


void usb_main();

#define SETBIT(reg, val)	HWRITE(reg, HREAD(reg) | (val))
#define CLRBIT(reg, val)	HWRITE(reg, HREAD(reg) & ~(val))

#define USB_OTG_MODIFY_REG8(reg, clear_mask, set_mask)  \
        HWRITE(reg, (((HREAD(reg)) & ~clear_mask) | set_mask))

#define USB_OTG_MODIFY_REG16(reg, clear_mask, set_mask)  \
        HWRITEW(reg, (((HREADW(reg)) & ~clear_mask) | set_mask))



#define BL(addr)			(int)*(addr) << 24 | (int)*(addr + 1) << 16 | (int)*(addr + 2) << 8 | *(addr + 3)
#define LL(addr)			(int)*(addr + 3) << 24 | (int)*(addr + 2) << 16 | (int)*(addr + 1) << 8 | *(addr)

#endif

