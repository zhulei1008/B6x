 /**
***************************************************************************
* @file:  yc11xx_sd.c
* @Date:  2021-7-31-14:31:57
* @brief:
**************************************************************************
 */


#include "yc11xx_sd.h"
#include "yc11xx_systick.h"
#include "reg_addr.h"

uint8_t resp_8bit[15] = {0};
uint8_t Card_Type = 0;
uint8_t CMD8_RESP_FLAG = 0;				//CMD8 Response Flag
uint8_t MEM_FLAG = 0;					//MEM Initialize Flag
uint8_t S18R = 0;							//Switch to 1.8V signal voltage
uint16_t RCA = 0;							//Relative Address
/**
 * @brief  :send stop command
 * @param    void
 * @return  None
 */
void SD_SetAbortCmd (void)
{
	uint16_t count = 0;
	SD_SetTranstioDir(TRANS_DIR_WR);
	SD_SetDatResponse(DAT_PRES_OFF);
	do{
//		MyPrintf("\n-----CMD12-----\n");
		SD_SendCmd(CMD12_STOP_MULTI_BLOCKS, 0, RESP_TYPE_48);
		count++;
	}while((SD_SetCurrentStatus() != SD_TRAN_STATE) && (count < 2000));//retry
}
/**
 * @brief  :The SD card writes data in multiple blocks
 * @param    buffer :Start address of write data
 * @param    sector : The starting block for writing data
 * @param    count   :Length of the data to be written
 * @return  :Returns the status of execution
 */
uint8_t SD_WriteMultipleBlock (const uint8_t *buffer, uint32_t sector, uint16_t count)
{
	//��׼���Ķ�д��ַ����ByteΪ��λ��
	if((Card_Type == SDSC_V1)||(Card_Type == SDSC_V2V3)){
		sector = sector*512;
	}
	//SD DMA Init
	SD_SetDmaStartAddress((uint32_t)buffer);
	SD_SetDmaBufferLength(count*512);
	SD_SetWtiteDmaStart(DMA_HW_START_OFF);
	SD_SetSelectMram(MRAM_SEL_ON);

	SD_SetBlockCount(count);

	SD_SetTranstioDir(TRANS_DIR_WR);
	SD_SetDatResponse(DAT_PRES_OFF);
	//ÿ�ζ���дǰ��Ҫ���·���CMD23����SD���Ŀ���
	//���������Ĭ��Ϊ���޿鴫�䣬״̬������'data'
	if ((Card_Type == SDHC_SDXC) && (S18R == 1)) {
//		MyPrintf("\n-----CMD23-----");
		SD_SendCmd(CMD23_SET_BLOCK_COUNT, count, RESP_TYPE_48);
	}
	//CMD23���д����֮�䲻�ܽ����������(����CMD13)���������������Ч
	SD_SetTranstioDir(TRANS_DIR_WR);
	SD_SetDatResponse(DAT_PRES_ON);
//	MyPrintf("\n-----CMD25-----");
	SD_SendCmd(CMD25_WRITE_MULTI_BLOCKS, sector, RESP_TYPE_48);
	SD_WaitResponseData();
	if((Card_Type == SDSC_V1) || (Card_Type == SDSC_V2V3) || (S18R == 0)){
		SD_SetAbortCmd();//��׼�����߲�֧�ֳ����ٵĸ������������������Ҫ����ֹͣ
	}
	return SD_WR_BLOCKS_SUCCESS;
}
/**
 * @brief  :The SD card read data in multiple blocks
 * @param    buffer :Start address of read data
 * @param    sector : The starting block for writing data
 * @param    count   :Length of the data to be written
 * @return  :Returns the status of execution
 */
uint8_t SD_ReadMultipleBlock (uint8_t *buffer, uint32_t sector, uint16_t count)
{
//     MyPrintf("sd_rd_multi_block sector=%x count=%x\r\n",sector,count);
	//��׼���Ķ�д��ַ����ByteΪ��λ��
	// The standard card reads and writes addresses in bytes
	if((Card_Type == SDSC_V1)||(Card_Type == SDSC_V2V3)){
		sector = sector*512;
	}
	//SD DMA Init
	SD_SetDmaStartAddress((uint32_t)buffer);
	SD_SetDmaBufferLength(count*512);
	SD_SetWtiteDmaStart(DMA_HW_START_OFF);
	SD_SetSelectMram(MRAM_SEL_ON);

	SD_SetBlockCount(count);

	SD_SetTranstioDir(TRANS_DIR_WR);
	SD_SetDatResponse(DAT_PRES_OFF);
// Before each read/write, you must resend the number of SD card blocks configured by CMD23
// If the default is not configured for unlimited block transfers, the state machine keeps 'data'
	if ((Card_Type == SDHC_SDXC) && (S18R == 1)) {
		//MyPrintf("\n-----CMD23-----");
		SD_SendCmd(CMD23_SET_BLOCK_COUNT, count, RESP_TYPE_48);
	}
// Command operations (including CMD13) cannot be performed between CMD23 and read/write commands, otherwise the block setting is invalid
	SD_SetTranstioDir(TRANS_DIR_RD);
	SD_SetDatResponse(DAT_PRES_ON);
//	MyPrintf("\n-----CMD18-----\n");
	SD_SendCmd(CMD18_READ_MULTI_BLOCKS, sector, RESP_TYPE_48);
	SD_WaitResponseData();
	if((Card_Type == SDSC_V1) || (Card_Type == SDSC_V2V3) || (S18R == 0)){
		SD_SetAbortCmd();
		// Standard cards or high capacity cards that do not support super high speed, the software needs to stop at the end of transmission
	}
	return SD_RD_BLOCKS_SUCCESS;
}

/**
 * @brief  :Whether the card type is supported
 * @param    cmd  :enable or disable
 * @return  None
 */
void SD_SwitchCardType(FunctionalState cmd)
{
	uint8_t tmp = 0;

	tmp = HREAD(0x894d);
	tmp = tmp & (~(1 << 1));// clear bit[1], 0:sd,1:tf(default)

	if(cmd)
	tmp |= cmd;

	HWRITE(0x894d, tmp);
}

/**
 * @brief  :SD set  Rx sample
 * @param    cmd:enable or disable
 * @return  None
 */
void SD_SetRxSample (FunctionalState cmd)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg (SD_CLK_CTRL);
    tmp &= (~(1 << 4)); // clear bit[4]

		if(cmd)
			tmp |= cmd;

    SD_WriteReg (SD_CLK_CTRL, tmp);
}

/** 
 * @brief  ��SD set  POS sample
 * @param    cmd :enable or disable                     
 * @return  None
 */
void SD_SetTxSample (FunctionalState cmd)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg (SD_CLK_CTRL);
    tmp = tmp & 0xdf; // clear bit[5]

		if(cmd)
			tmp |= cmd;

    SD_WriteReg (SD_CLK_CTRL, tmp);
}


/** 
 * @brief  :sd clk frequency select
 * @param    SDCLK_Frequency   :clk select       
 * @return  None
 */
 
void SD_SetClkDiv (SDCLK_Fre_InitTypeDef SDCLK_Frequency)
{
    SD_WriteReg(SD_CLK_DIV, SDCLK_Frequency);
}

/** 
 * @brief  :setting SD send transtion mode
 * @param    val  :   mode value                 
 * @return  None
 */
void SD_SetTranstionMode (uint8_t val)
{
    SD_WriteReg(SD_TRANS_MODE, val);// direct set reg
}

/** 
 * @brief  :get SD care response error interruot
 * @param    vp:intterupt num                        
 * @return  None
 */
void SD_GetNormalInterupt (uint8_t *vp)
{
    *vp = SD_ReadReg (SD_NORM_IRQ);
}

/** 
 * @brief  :get SD care response error interruot
 * @param    vp :intterupt num                      
 * @return  None
 */
void SD_GetErrorInterrupt (uint8_t *vp)
{
    *vp = SD_ReadReg (SD_ERR_IRQ);
}

void SD_GetCmdStatus (uint8_t * vp)
{
    *(vp) = SD_ReadReg (SD_CMD_STATUS);
}

void SD_GetDataStatus (uint8_t * vp)
{
    *(vp) = SD_ReadReg (SD_DAT_STATUS);
}

//Software Reset
/** 
 * @brief  :Program software reset
 * @param    void                     
 * @return  None
 */
void SD_SoftwareReset (void)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_SW_RST);

    tmp = tmp & (~(1 << 0)); // clear bit[0]
    tmp = tmp | 0x01;
    SD_WriteReg(SD_SW_RST, tmp);

    tmp = tmp & (~(1 << 0)); // clear bit[0]
    tmp = tmp | 0x00;
    SD_WriteReg(SD_SW_RST, tmp);
}



/** 
 * @brief  :Example Set the internal clock of the SD card
 * @param    cmd    :enable or diable                  
 * @return  None
 */
void SD_SetClkCmd (FunctionalState cmd)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg (SD_CLK_CTRL);
    tmp = tmp & (~(1 << 0)); // clear bit[0]

		if(cmd)
			tmp = tmp | cmd;

    SD_WriteReg(SD_CLK_CTRL, tmp);
}

/** 
 * @brief  :Set the response type of the SD card
 * @param    val :response type                     
 * @return  None
 */
void SD_SetResponseType (uint8_t val)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_TRANS_MODE);
    tmp = tmp & 0xfc; // clear bit[1:0], resp_type
    tmp = tmp | val; // set bit[1:0], resp_type

    SD_WriteReg(SD_TRANS_MODE, tmp);
}

/** 
 * @brief  ��command index, trigger one command transceive
 * @param    val                      
 * @return  None
 */
void SD_SetCmd (uint8_t val)
{
    uint8_t tmp = 0;

    tmp = val & 0x3f; // bit[5:0]
    SD_WriteReg(SD_COMMAND, tmp);
}

/** 
 * @brief  :sd card cmd 
 * @param    val                      
 * @return  None
 */
void SD_SetCmdArg (uint32_t val)
{
    uint8_t tmp = 0;

    tmp = val & 0xff;
    SD_WriteReg(SD_CMD_ARG_B0, tmp);

    tmp = (val >> 8) & 0xff;
    SD_WriteReg(SD_CMD_ARG_B1, tmp);

    tmp = (val >> 16) & 0xff;
    SD_WriteReg(SD_CMD_ARG_B2, tmp);

    tmp = (val >> 24) & 0xff;
    SD_WriteReg(SD_CMD_ARG_B3, tmp);
}

/** 
 * @brief  :wait SD return CMD
 * @param    void                     
 * @return  
 */
uint8_t SD_WaitResponseCmd (void)
{
	uint8_t tmp1 = 0;
	uint8_t tmp2 = 0;

	do
	{
		SD_GetNormalInterupt(resp_8bit);
		tmp1 = resp_8bit[0];

		SD_GetErrorInterrupt(resp_8bit);
		tmp2 = resp_8bit[0];

		// check complete--bit[0]
		if (tmp1 & 0x01)
		{
			// check errirq--bit[4]
			if (tmp1 & 0x10)
//				MyPrintf("Err_Irq!\t");

			// check index--bit[3]
			if (tmp2 & 0x08)
//				MyPrintf("ERR_CMD_INDEX!\t");

			// check endbit--bit[2]
			if (tmp2 & 0x04)
//				MyPrintf("ERR_CMD_ENDBIT!\t");

			// check crc--bit[1]
			if (tmp2 & 0x02)
//				MyPrintf("ERR_CMD_CRC!\t");

			if(tmp2 & 0x0e)//exist mistake
				return ERR_CMD;
			else
				return ERR_NONE;
		}

		// check timeout--bit[0]
		if (tmp2 & 0x01)
		{
//			MyPrintf("ERR_CMD_TIMEOUT!\t");

			//cmd status
			SD_GetCmdStatus(resp_8bit);
//			MyPrintf("\nSD_CMD_STATUS=0x%02x!", resp_8bit[0]);

			SD_SoftwareReset();//��ʱ����и�λ

			return ERR_CMD_TIMEOUT;
		}

	}while((tmp1 & 0x01) != 1);

	return 0;
}

/**
 * @brief  SD send command
 * @param    cmd:
 * @param    arg  :
 * @param    resp_type  :
 * @return
 */
uint8_t SD_SendCmd(uint8_t cmd, uint32_t arg, uint8_t resp_type)
{
	SD_SetCmdArg(arg);
	SD_SetResponseType(resp_type);
	SD_SetCmd(cmd);
	return SD_WaitResponseCmd();
}

/**
 * @brief
 * @param    val
 * @return  None
 */
void SD_SetCmdIndexChk (uint8_t val)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_TRANS_MODE);
    tmp = tmp & (~(1 << 3)); // clear bit[3], cmd_idx_chk_en
    tmp = tmp | val; // set bit[3], cmd_idx_chk_en
    SD_WriteReg(SD_TRANS_MODE, tmp);
}

// cmd_crc_chk
/**
 * @brief
 * @param    val
 * @return  None
 */
void SD_SetCmdCRCChk (uint8_t val)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_TRANS_MODE);
    tmp = tmp & (~(1 << 2)); // clear bit[2], cmd_crc_chk_en
    tmp = tmp | val; // set bit[2], cmd_crc_chk_en
    SD_WriteReg(SD_TRANS_MODE, tmp);
}
/** 
 * @brief  :get SD card response
 * @param    vp                       
 * @return  None
 */
void SD_GetResponse32 (uint8_t* vp)
{
    uint8_t tmp = 0;

    for (tmp = 0; tmp < 4; tmp ++)
		{
        *(vp + tmp) = SD_ReadReg (SD_RSP_B0 + tmp);
    }
}

/** 
 * @brief  :get VDD Voltage Window
 * @param    void                     
 * @return  
 */
uint16_t SD_GetVoltageWindows (void)
{
	uint16_t tmp = 0;

	SD_GetResponse32(resp_8bit);
	tmp = resp_8bit[2] << 8| resp_8bit[1];

	return tmp;
}
/** 
 * @brief  :get SD busy status
 * @param    void                     
 * @return  
 */
uint8_t SD_GetBusyStatus (void)
{
	uint8_t tmp = 0;

	SD_GetResponse32(resp_8bit);
	tmp = (resp_8bit[3] & 0x80) >> 7;

	return tmp;
}

uint8_t SD_GetResponseS18R (void)
{
	uint8_t tmp = 0;

	SD_GetResponse32(resp_8bit);
	tmp = resp_8bit[3] & 0x01;

	return tmp;
}
/** 
 * @brief  ;get The SD card capacity is obtained
 * @param    void                     
 * @return  None
 */
void SD_CheckCardCapaticy (void)
{
	SD_GetResponse32(resp_8bit);

	if(resp_8bit[3] & 0x40)			//bit[2]:CCS=1(SD_RSP_B3)
	{
		MEM_FLAG =1;
		Card_Type = SDHC_SDXC;
	}
	else
	{
		MEM_FLAG =1;
		Card_Type = SDSC_V2V3;
	}
}
/** 
 * @brief : get the RCA of SD 
 * @param    void                     
 * @return  
 */
uint16_t SD_GetRCA (void)
{
	uint16_t tmp = 0;

	SD_GetResponse32(resp_8bit);
	tmp = (resp_8bit[3] <<8) | resp_8bit[2];

	return tmp;
}

// trans_dir
void SD_SetTranstioDir (uint8_t val)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_TRANS_MODE);
//    tmp = tmp & (~(1 << 5)); // clear bit[5], trans_dir
//    tmp = tmp | val; // set bit[5], trans_dir
    tmp = tmp & 0xdf; // clear bit[5], trans_dir
      tmp = tmp | val; // set bit[5], trans_dir
    SD_WriteReg(SD_TRANS_MODE, tmp);
}

// dat_present
/** 
 * @brief  :set sd card data response
 * @param    val :    data command                 
 * @return  None
 */
void SD_SetDatResponse (uint8_t val)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_TRANS_MODE);
//    tmp = tmp & (~(1 << 4)); // clear bit[4], dat_pres
//    tmp = tmp | val; // set bit[4], dat_pres
    tmp = tmp & 0xef; // clear bit[4], dat_pres
       tmp = tmp | val; // set bit[4], dat_pres
    SD_WriteReg(SD_TRANS_MODE, tmp);
}

void SD_SelectCard (void)
{
	SD_SetTranstioDir(TRANS_DIR_WR);
	SD_SetDatResponse(DAT_PRES_OFF);

//	MyPrintf("\n-----CMD7-----");
	SD_SendCmd(CMD7_SELECT_CARD, RCA<<16, RESP_TYPE_48);
}

/** 
 * @brief  :set sd card timeout count
 * @param    val                      
 * @return  None
 */
void SD_SetTimeoutCount (uint8_t val)
{
    SD_WriteReg(SD_TIMEOUT_CNT, val);
}

/** 
 * @brief  :set sd card block size
 * @param    val:block size value                     
 * @return  None
 */
void SD_SetBlockSize (uint16_t val)
{
    uint8_t tmp = 0;

    tmp = val & 0xff;
    SD_WriteReg(SD_BLK_SIZE_L, tmp);
    tmp = (val >> 8) & 0xff;
    SD_WriteReg(SD_BLK_SIZE_H, tmp);
}
/** 
 * @brief  
 * @param    val                      
 * @return  None
 */
void SD_SetBusWidth (uint8_t val)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_TRANS_MODE);
    tmp = tmp & (~(1 << 6)); // clear bit[6], bus_width
    tmp = tmp | val; // set bit[6], bus_width
    SD_WriteReg(SD_TRANS_MODE, tmp);
}

/**
 * @brief:sd read/write block configurate
 * @param    card_bus_width
 * @param    SDCLK_frequency
 * @param    block_mode
 * @return  None
 */
void SD_ReadWriteBlockConfig (uint16_t card_bus_width, SDCLK_Fre_InitTypeDef SDCLK_frequency, uint8_t block_mode)
{
	if (SDCLK_frequency == SDCLK_Frequency_24M)
	{
	 	SD_SetTxSample(DISABLE);
	 	SD_SetRxSample(ENABLE);
	}
	else
	{
	 	SD_SetTxSample(DISABLE);
	 	SD_SetRxSample(DISABLE);
	}

	//set timeout
	SD_SetTimeoutCount(200);

	//set sdclk frequency
	SD_SetClkDiv(SDCLK_frequency);

	//trans mode
	SD_SetTranstioDir(TRANS_DIR_WR);
	SD_SetDatResponse(DAT_PRES_OFF);

	//set SDIO controller buswidth/blocksize
	if (card_bus_width == CARD_BUS_WIDTH_1_BIT)
	{
		SD_SetBusWidth(BUS_WIDTH_1_BIT);
	}
	if (card_bus_width == CARD_BUS_WIDTH_4_BIT)
	{
		SD_SetBusWidth(BUS_WIDTH_4_BIT);
	}

	SD_SetBlockSize(BLOCKSIZE);

	//set SD card buswidth/blocksize
	if((Card_Type == SDSC_V1)||(Card_Type==SDSC_V2V3))
	{
//		MyPrintf("\n-----CMD55-----");
		SD_SendCmd(CMD55_REPRENSENT_SPECIFIC_CMD, RCA<<16, RESP_TYPE_48);

//		MyPrintf("\n-----ACMD6-----");
		SD_SendCmd(ACMD6_SET_BUS_WIDTH, card_bus_width, RESP_TYPE_48);

//		MyPrintf("\n-----CMD16-----");
		SD_SendCmd(CMD16_SET_BLOCK_SIZE, BLOCKSIZE, RESP_TYPE_48);
	}
	else if(Card_Type == SDHC_SDXC)
	{
//		MyPrintf("\n-----CMD55-----");
		SD_SendCmd(CMD55_REPRENSENT_SPECIFIC_CMD, RCA<<16, RESP_TYPE_48);

//		MyPrintf("\n-----ACMD6-----");
		SD_SendCmd(ACMD6_SET_BUS_WIDTH, card_bus_width, RESP_TYPE_48);
	}
}

/** 
 * @brief  setting sd card DMA start address
 * @param    val   :DNA address                   
 * @return  None
 */
void SD_SetDmaStartAddress (uint16_t val)
{
    uint8_t tmp = 0;

    tmp = val & 0xff;
    SD_WriteReg (SD_DMA_SADDR_L, tmp);
    tmp = (val >> 8) & 0xff;

    SD_WriteReg (SD_DMA_SADDR_H, tmp);
}
/** 
 * @brief  setting sd card DMA bufeer length
 * @param    val   :DMA length                  
 * @return  None
 */
void SD_SetDmaBufferLength (uint16_t val)
{
    uint8_t tmp = 0;

    tmp = val & 0xff;
    SD_WriteReg (SD_DMA_LEN_L, tmp);
    tmp = (val >> 8) & 0xff;

    SD_WriteReg (SD_DMA_LEN_H, tmp);
}

// dma_hw_start
/** 
 * @brief  :set DMA write start
 * @param    cmd                      
 * @return  None
 */
void SD_SetWtiteDmaStart (FunctionalState cmd)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_DMA_CTRL);
   // tmp = tmp & (~(1 << 0)); // clear bit[0]
    tmp = tmp & 0xfe;

	//if(cmd)
	tmp |= cmd;
    SD_WriteReg (SD_DMA_CTRL, tmp);
}

/** 
 * @brief  :Whether to select MRAM
 * @param    cmd:0/1                      
 * @return  None
 */
void SD_SetSelectMram (FunctionalState cmd)
{
    uint8_t tmp = 0;

    tmp = SD_ReadReg(SD_DMA_CTRL);
    tmp = tmp & 0xef; // clear bit[4]
       tmp = tmp | cmd;
//    tmp = tmp & (~(1 << 4)); // clear bit[4]
//
//		if(cmd)
//			tmp |= (1 << 4);
    SD_WriteReg (SD_DMA_CTRL, tmp);
}


/** 
 * @brief  :set block count
 * @param    val  :block num                    
 * @return  None
 */
void SD_SetBlockCount (uint16_t val)
{
    uint8_t tmp = 0;

    tmp = val & 0xff;
    SD_WriteReg(SD_BLK_CNT_L, tmp);

    tmp = (val >> 8) & 0xff;
    SD_WriteReg(SD_BLK_CNT_H, tmp);
}

// wait_dat
/** 
 * @brief  Waiting for response data
 * @param    void                     
 * @return  
 */
uint8_t SD_WaitResponseData (void)
{
	uint8_t tmp1 = 0;
	uint8_t tmp2 = 0;

	do
	{
		SD_GetNormalInterupt(resp_8bit);
		tmp1 = resp_8bit[0];

		SD_GetErrorInterrupt(resp_8bit);
		tmp2 = resp_8bit[0];
		// check complete--bit[1]
		if (tmp1 & 0x02)
		{
//			// check errirq--bit[4]
//			if (tmp1 & 0x10)
//				MyPrintf("Err_Irq!\t");
//			// check endbit--bit[6]
//			if (tmp2 & 0x40)
//				MyPrintf("ERR_DAT_ENDBIT!\t");
//			// check crc--bit[5]
//			if (tmp2 & 0x20)
//				MyPrintf("ERR_DAT_CRC!\t");

			if(tmp2 & 0x60)//exist mistake
				return ERR_DAT;
			else
				return ERR_NONE;
		}

		// check timeout--bit[4]
		if (tmp2 & 0x10)
		{
//			MyPrintf("ERR_DAT_TIMEOUT!\t");

			SD_GetDataStatus(resp_8bit);		//data status
//			MyPrintf("\nSD_DAT_STATUS=0x%02x!", resp_8bit[0]);

			SD_SoftwareReset();

			return ERR_DAT_TIMEOUT;
		}
	}while((tmp1 & 0x02) != 1);

	return 0;
}
/** 
 * @brief  :The SD card reads data in one block
 * @param    buffer:The start address of the cache from which the data is read                   
 * @param    sector :Which block to start reading from                  
 * @return  
 */
uint8_t SD_ReadSingleBlock (uint8_t *buffer, uint32_t sector)
{
	//��׼���Ķ�д��ַ����ByteΪ��λ��
	if((Card_Type == SDSC_V1)||(Card_Type == SDSC_V2V3))
	{
		sector = sector*512;
	}
	//SD DMA Init
	SD_SetDmaStartAddress((uint32_t)buffer);
	SD_SetDmaBufferLength(512);
	SD_SetWtiteDmaStart(DISABLE);
	SD_SetSelectMram(ENABLE);

	SD_SetBlockCount(1);

	SD_SetTranstioDir(TRANS_DIR_RD);
	SD_SetDatResponse(DAT_PRES_ON);

//	MyPrintf("\n-----CMD17-----");
	SD_SendCmd(CMD17_READ_SINGLE_BLOCK, sector, RESP_TYPE_48);
	SD_WaitResponseData();

	return SD_RD_SINGLE_BLOCK_SUCCESS;
}

//erase block
/** 
 * @brief  :SD earse some block
 * @param    sector :Start address of erasure                  
 * @param    count :The number of erasures                   
 * @return  None
 */
void SD_EarseBlock (uint32_t sector, uint32_t count)
{
	uint32_t erase_sector_start = 0;
	uint32_t erase_sector_end = 0;

	erase_sector_start = sector;
	erase_sector_end = sector + count - 1;

	if((Card_Type == SDSC_V1)||(Card_Type == SDSC_V2V3))
	{
		erase_sector_start = erase_sector_start * 512;
		erase_sector_end = erase_sector_end * 512;
	}

	SD_SetTranstioDir(TRANS_DIR_WR);
	SD_SetDatResponse(DAT_PRES_OFF);

//	MyPrintf("\n-----CMD32-----");
	SD_SendCmd(CMD32_ERASE_WR_BLK_START, erase_sector_start, RESP_TYPE_48);

//	MyPrintf("\n-----CMD33-----");
	SD_SendCmd(CMD33_ERASE_WR_BLK_END, erase_sector_end, RESP_TYPE_48);

//	MyPrintf("\n-----CMD38-----");
	SD_SendCmd(CMD38_ERASE, 0, RESP_TYPE_48);

	//delay_ms(200);
}


/** 
 * @brief  :Gets the current state
 * @param    void                     
 * @return  :0=idle;1=ready;2=ident;3=stby;4=tran;5=data;6=rcv;7=prg;8=dis;9-14=reserved;15=reserved for I/O mode
 */
uint8_t SD_SetCurrentStatus(void)
{
	uint8_t tmp = 0;
	//uint8_t ret = 0;

	//trans mode
	SD_SetTranstioDir(TRANS_DIR_WR);
	SD_SetDatResponse(DAT_PRES_OFF);

//	MyPrintf("\n-----CMD13-----\n");
	SD_SendCmd(CMD13_GET_CARD_STATUS, RCA<<16, RESP_TYPE_48);
	SD_GetResponse32(resp_8bit);
	tmp = (resp_8bit[1] & 0x1E) >> 1;	//bit[12]-bit[9](SD_RSP_B1)
	//MyPrintf("\nCurrent_State=%d!", tmp);

	return tmp;
}
/** 
 * @brief  :The SD card write data in one block
 * @param    buffer:The start address of the cache from which the data is write                   
 * @param    sector :Which block to start reading from                  
 * @return  
 */
uint8_t SD_WriteSingleBlock (uint32_t *buffer, uint32_t sector)
{
	/*uint16_t count = 0;
	//��׼���Ķ�д��ַ����ByteΪ��λ��
	if((Card_Type == SDSC_V1)||(Card_Type == SDSC_V2V3)){
		sector = sector*512;
	}
	//SD DMA Init
	sd_set_dma_saddr((uint16_t)buffer);
	sd_set_dma_len(512);
	sd_set_dma_hw_start(DISABLE);
	sd_set_mram_sel(ENABLE);

	sd_set_blk_cnt(1);

	sd_set_trans_dir(TRANS_DIR_WR);
	sd_set_dat_pres(DAT_PRES_ON);

	MyPrintf("\n-----CMD24-----");
	sd_send_cmd(CMD24_WRITE_SINGLE_BLOCK, sector, RESP_TYPE_48);
	sd_wait_dat();
	do{
		count++;
	}while((sd_get_current_state() != SD_TRAN_STATE) && (count < 500));//retry
	return SD_WR_SINGLE_BLOCK_SUCCESS;*/
}


/** 
 * @brief  :Initialize SD Card
 * @param    void                     
 * @return  :Status of the SD card,0:success,1:init timeout,2:unadle SD,3:not SD card
 */
uint8_t SD_Init (void)
{
	uint8_t ret = 0;
	uint16_t count = 0;
	uint8_t retry = 0;
	uint16_t OCR = 0;	//VDD Voltage Window
	//uint16_t CSD = 0;

	SysTick_DelayMs(100);//wait power on

 	 SD_RccClockCmd(PWM_SDIO_CLK, ENABLE);
 	SD_SetClkCmd(ENABLE);

 	//set sample
 	SD_SetTxSample(DISABLE);
 	SD_SetRxSample(DISABLE);

  //set sdclk frequency
	SD_SetClkDiv(SDCLK_Frequency_400KB);

	//trans mode
	SD_SetTranstionMode(TRANS_DIR_WR | DAT_PRES_OFF | CMD_IDX_CHK_ON | CMD_CRC_CHK_ON);

	do
	{
		do
		{
//			MyPrintf("\n-----CMD0-----");
			ret = SD_SendCmd(CMD0_RESET, 0, RESP_TYPE_NONE);
			retry++;
		}while((ret != ERR_NONE) && (retry<200));

		if(retry == 200)
		{
			SD_SoftwareReset();
			return SD_INIT_TIMEOUT;
		}

//		MyPrintf("\n-----CMD8-----");

		ret = SD_SendCmd(CMD8_HIGH_CAPACITY_MEMCARD, 0x01aa, RESP_TYPE_48);

		if(ret == ERR_CMD_TIMEOUT)
		{
			SD_SoftwareReset();//��ʱ����и�λ
			CMD8_RESP_FLAG = NOT_HIGH_CAPACITY_CARD;
		}
		else if(ret == ERR_CMD)
		{
			if(count > 1)
				return UNUSABLE_SD_CARD;
		}
		else
			CMD8_RESP_FLAG = HIGH_CAPACITY_CARD;

		count++;
	}while(ret == ERR_CMD);//retry one more time

	if(CMD8_RESP_FLAG == NOT_HIGH_CAPACITY_CARD)
	{
//		MyPrintf("\n-----CMD55-----");

		ret = SD_SendCmd(CMD55_REPRENSENT_SPECIFIC_CMD, 0, RESP_TYPE_48);

		if(ret == ERR_CMD_TIMEOUT)
		{
			SD_SoftwareReset();
			return NOT_SD_CARD;
		}

		SD_SetCmdIndexChk(CMD_IDX_CHK_OFF);//ACMD41 not check CMD's respone index or crc
		SD_SetCmdCRCChk(CMD_CRC_CHK_OFF);
//		MyPrintf("\n-----ACMD41-----");
		ret = SD_SendCmd(ACMD41_GET_VOLTAGE, 0, RESP_TYPE_48);	//�����õ�ѹ
		SD_SetCmdIndexChk(CMD_IDX_CHK_ON);
		SD_SetCmdCRCChk(CMD_CRC_CHK_ON);

		//get OCR
		OCR = SD_GetVoltageWindows();
//		MyPrintf("OCR = %x\n", OCR);

		if(ret == ERR_CMD)
		{
			return UNUSABLE_SD_CARD;
		}
		else
		{
			count = 0;

			do {
//				MyPrintf("\n-----CMD55-----");
				ret = SD_SendCmd(CMD55_REPRENSENT_SPECIFIC_CMD, 0, RESP_TYPE_48);
				SD_SetCmdIndexChk(CMD_IDX_CHK_OFF);
				SD_SetCmdCRCChk(CMD_CRC_CHK_OFF);

//				MyPrintf("\n-----ACMD41-----");
				ret = SD_SendCmd(ACMD41_GET_VOLTAGE, OCR<<8, RESP_TYPE_48_BUSY);//set OCR
				SD_SetCmdIndexChk(CMD_IDX_CHK_ON);
				SD_SetCmdCRCChk(CMD_CRC_CHK_ON);

				if(ret == ERR_CMD_TIMEOUT)
				{
					SD_SoftwareReset();
					return UNUSABLE_SD_CARD;
				}
				else if(ret == ERR_CMD)
				{
					return UNUSABLE_SD_CARD;
				}
				else
				{
					MEM_FLAG =1;
					Card_Type = SDSC_V1;
				}

				ret = SD_GetBusyStatus();
				count++;

				SysTick_DelayMs(10);
			}while (count < 500 && (ret == BUSY));

			if (count >= 500)
			{
//				MyPrintf("\nACMD41 Error: try more than 500 times with out ready!");
				SD_SoftwareReset();
				return UNUSABLE_SD_CARD;
			}

//			MyPrintf("\nACMD41: Card Ready!retry_count=%d", count);
		}
	}
	else if(CMD8_RESP_FLAG == HIGH_CAPACITY_CARD)
	{
//		MyPrintf("\n-----CMD55-----");
		ret = SD_SendCmd(CMD55_REPRENSENT_SPECIFIC_CMD, 0, RESP_TYPE_48);

		if(ret == ERR_CMD_TIMEOUT)
		{
			SD_SoftwareReset();
			return UNUSABLE_SD_CARD;
		}

		SD_SetCmdIndexChk(CMD_IDX_CHK_OFF);//ACMD41 not check CMD's respone index or crc
		SD_SetCmdCRCChk(CMD_CRC_CHK_OFF);

//		MyPrintf("\n-----ACMD41-----");
		ret = SD_SendCmd(ACMD41_GET_VOLTAGE, 0x41000000, RESP_TYPE_48);
		SD_SetCmdIndexChk(CMD_IDX_CHK_ON);
		SD_SetCmdCRCChk(CMD_CRC_CHK_ON);

		//get OCR
		OCR = SD_GetVoltageWindows();
//		MyPrintf("OCR=%x!\n", OCR);

		if(ret == ERR_CMD)
		{
			return UNUSABLE_SD_CARD;
		}
		else
		{
			count = 0;

			do {
//				MyPrintf("\n-----CMD55-----");
				ret = SD_SendCmd(CMD55_REPRENSENT_SPECIFIC_CMD, 0, RESP_TYPE_48);
				SD_SetCmdIndexChk(CMD_IDX_CHK_OFF);
				SD_SetCmdCRCChk(CMD_CRC_CHK_OFF);

//				MyPrintf("\n-----ACMD41-----");
				ret = SD_SendCmd(ACMD41_GET_VOLTAGE, 0x41000000|OCR<<8, RESP_TYPE_48_BUSY);	//set 2.7-3.6V
				SD_SetCmdIndexChk(CMD_IDX_CHK_ON);
				SD_SetCmdCRCChk(CMD_CRC_CHK_ON);

				if(ret == ERR_CMD_TIMEOUT)
				{
					SD_SoftwareReset();
					return UNUSABLE_SD_CARD;
				}
				else if(ret == ERR_CMD)
				{
					return UNUSABLE_SD_CARD;
				}

				ret = SD_GetBusyStatus();
				count ++;

				SysTick_DelayMs(10);
			}while (count < 500 && (ret == BUSY));

			S18R = SD_GetResponseS18R();
//			MyPrintf("\nS18R=%d",S18R);

			if (count >= 500)
			{
//				MyPrintf("\nACMD41 Error: try more than 500 times with out ready!count=%d",count);
				SD_SoftwareReset();

				return UNUSABLE_SD_CARD;
			}

//			MyPrintf("\nACMD41: Card Ready!retry_count=%d",count);
			SD_CheckCardCapaticy();
		}
	}

	SD_SetCmdIndexChk(CMD_IDX_CHK_OFF);

//	MyPrintf("\n-----CMD2-----");
	ret = SD_SendCmd(CMD2_GET_CID, 0, RESP_TYPE_136);
	SD_SetCmdIndexChk(CMD_IDX_CHK_ON);

	do{
//		MyPrintf("\n-----CMD3-----");

		ret = SD_SendCmd(CMD3_CARD_SEND_RCA, 0, RESP_TYPE_48);
		RCA = SD_GetRCA();
//		MyPrintf("\nRCA=%x!",RCA);

		SysTick_DelayMs(1);
	}while(RCA == 0);//retry

//	MyPrintf("\nCard_Type=%d\n",Card_Type);

	SD_SelectCard();
	SD_ReadWriteBlockConfig(CARD_BUS_WIDTH_1_BIT, SDCLK_Frequency_24M, MULTI_BLOCK_MODE);

	return SD_INIT_SUCCESS;
}
/** 
 * @brief  :Set the clock of the SD card
 * @param    RCC_CLOCK                
 * @param    cmd  :enable or disable                    
 * @return  None
 */
void SD_RccClockCmd(RCC_CLOCK_InitTypeDef RCC_CLOCK,FunctionalState cmd)
{
  uint16_t tmp = 0;
	
	tmp = HREADW(CORE_CLOCK_OFF);
	
	if (cmd & 0x01) // enable
			tmp = tmp & (~(1 << RCC_CLOCK)); // bit[13], sdio_clk_en
	else 
			tmp = tmp | (1 << RCC_CLOCK);
	
	HWRITEW(CORE_CLOCK_OFF, tmp);
}

/** 
 * @brief  :Writes data to the registers of the SD card
 * @param    addr :reg address              
 * @param    val :write data                     
 * @return  None
 */
void SD_WriteReg(uint8_t addr, uint8_t val)
{
    HWRITE(CORE_ADDA_COEF_WDATA_0, addr);
	HWRITE(CORE_ADDA_COEF_WDATA_1, val);
	HWRITE(CORE_SD_REG_WR, 1);
}
/** 
 * @brief  Writes data to the registers of the SD card
 * @param    addr :red address                    
 * @return  
 */
uint8_t SD_ReadReg (uint8_t addr)
{
    HWRITE(CORE_ADDA_COEF_WDATA_0, addr);
    return HREAD(CORE_SD_REG_RDATA);
}






