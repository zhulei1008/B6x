/*
 * Copyright (c) 2006-2021, YICHIP Development Team
 * @file     usbd_ccid_if.c
 * @brief    source file for setting xxx
 *
 * Change Logs:
 * Date           Author      Version        Notes
 * 2021-03-29     chenqixiong V1.0.0         the first version
 */

/* Includes ------------------------------------------------------------------*/
#include "usbd_ccid_if.h"
#include "usbd_ioreq.h"
#include "usbd_usr.h"
#include "usb_main.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint8_t Ccid_BulkState;
uint8_t UsbIntMessageBuffer[INTR_MAX_PACKET_SIZE];  /* data buffer */
volatile uint8_t PrevXferComplete_IntrIn;
usb_ccid_param_t usb_ccid_param;

uint8_t *pUsbMessageBuffer;
static uint32_t UsbMessageLength;
Ccid_bulkin_data_t pCcid_resp_buff;
Ccid_SlotStatus_t Ccid_SlotStatus;


uint8_t BulkOut_Data_Buff[BULK_MAX_PACKET_SIZE];

Ccid_bulkin_data_t Ccid_bulkin_data;

Ccid_bulkout_data_t Ccid_bulkout_data;

uint8_t UsbIntMessageBuffer[INTR_MAX_PACKET_SIZE];

/* Private function prototypes -----------------------------------------------*/

void Sleep(uint32_t Count)
{
    while (Count--);
}

/* Private function ----------------------------------------------------------*/
/**
  * @brief  CCID_Init
  *         Initialize the CCID USB Layer
  * @param  pdev: device instance
  * @retval None
  */
void CCID_Init(USB_OTG_CORE_HANDLE *pdev)
{
    /* CCID Related Initialization */
    CCID_SetIntrTransferStatus(1);  /* Transfer Complete Status */
    CCID_UpdSlotChange(1);
    UsbMessageLength = 0;
    pUsbMessageBuffer = (uint8_t *) & Ccid_bulkout_data;
}

/**
  * @brief  CCID_DeInit
  *         Uninitialize the CCID Machine
  * @param  pdev: device instance
  * @retval None
  */
void CCID_DeInit(USB_OTG_CORE_HANDLE *pdev)
{
    Ccid_BulkState = CCID_STATE_IDLE;
}

/**
  * @brief  CCID_Message_In
  *         Handle Bulk IN & Intr IN data stage
  * @param  pdev: device instance
  * @param  uint8_t epnum: endpoint index
  * @retval None
  */
void CCID_BulkMessage_In(USB_OTG_CORE_HANDLE *pdev, uint8_t epnum)
{
    if (epnum == (CCID_BULK_IN_EP & 0x7F))
    {
    }
    else if (epnum == (CCID_INTR_IN_EP & 0x7F))
    {
        /* Filter the epnum by masking with 0x7f (mask of IN Direction)  */
        CCID_SetIntrTransferStatus(1);  /* Transfer Complete Status */
    }
}



/**
  * @brief  CCID_BulkMessage_Out
  *         Proccess CCID OUT data
  * @param  pdev: device instance
  * @param  uint8_t epnum: endpoint index
  * @retval None
  */

extern uint16_t rx_DataLength;
extern byte *usb_rxptr;

void CCID_BulkMessage_Out(USB_OTG_CORE_HANDLE *pdev, uint8_t epnum)
{

    uint16_t dataLen;
    uint16_t rx_ep;

    dataLen = USBD_GetRxCount(pdev, CCID_BULK_OUT_EP);
    UsbMessageLength += dataLen;
    CCID_ReceiveCmdHeader(pUsbMessageBuffer, dataLen);
    pUsbMessageBuffer += dataLen;   /* Point to new offset */
    Ccid_bulkin_data.bSlot = Ccid_bulkout_data.bSlot;
    Ccid_bulkin_data.bSeq = Ccid_bulkout_data.bSeq;
    if (UsbMessageLength >= Ccid_bulkout_data.dwLength + CCID_CMD_HEADER_SIZE)
    {
        if (UsbMessageLength == Ccid_bulkout_data.dwLength + CCID_CMD_HEADER_SIZE)
            CCID_CmdDecode(pdev);
        else
        {
            Ccid_BulkState = CCID_STATE_UNCORRECT_LENGTH;
        }
        UsbMessageLength = 0;
        pUsbMessageBuffer = (uint8_t *) & Ccid_bulkout_data;
    }

}

/**
  * @brief  CCID_Response_SendData
  *         Send the data on bulk-in EP
  * @param  pdev: device instance
  * @param  uint8_t* buf: pointer to data buffer
  * @param  uint16_t len: Data Length
  * @retval None
  */
static void CCID_Response_SendData(USB_OTG_CORE_HANDLE *pdev,
                                   uint8_t *buf, uint16_t len)
{
    DCD_EP_Tx(pdev, CCID_BULK_IN_EP, buf, len);
}


/**
  * @brief  CCID_CmdDecode
  *         Parse the commands and Proccess command
  * @param  pdev: device instance
  * @retval None
  */
uint8_t GETSLOTSTATUS_FLAG;
void CCID_CmdDecode(USB_OTG_CORE_HANDLE *pdev)
{
    uint8_t errorCode;

    switch (Ccid_bulkout_data.bMessageType)
    {
    case PC_TO_RDR_ICCPOWERON:
        errorCode = PC_to_RDR_IccPowerOn();
        RDR_to_PC_DataBlock(errorCode);
        break;
    case PC_TO_RDR_ICCPOWEROFF:
        errorCode = PC_to_RDR_IccPowerOff();
        RDR_to_PC_SlotStatus(errorCode);
        break;

    case PC_TO_RDR_GETSLOTSTATUS:
        errorCode = PC_to_RDR_GetSlotStatus();
        RDR_to_PC_SlotStatus(errorCode);
        GETSLOTSTATUS_FLAG = 1;
        break;

    case PC_TO_RDR_XFRBLOCK:
        errorCode = PC_to_RDR_XfrBlock();
        Ccid_BulkState = CCID_STATE_IDLE;
        break;

    case PC_TO_RDR_GETPARAMETERS:
        errorCode = PC_to_RDR_GetParameters();
        RDR_to_PC_Parameters(errorCode);
        break;

    case PC_TO_RDR_RESETPARAMETERS:
        errorCode = PC_to_RDR_ResetParameters();
        RDR_to_PC_Parameters(errorCode);
        break;

    case PC_TO_RDR_SETPARAMETERS:
        errorCode = PC_to_RDR_SetParameters();
        RDR_to_PC_Parameters(errorCode);
        break;

    case PC_TO_RDR_ESCAPE:
        errorCode = PC_to_RDR_Escape();
        RDR_to_PC_Escape(errorCode);
        break;

    case PC_TO_RDR_ICCCLOCK:
        errorCode = PC_to_RDR_IccClock();
        RDR_to_PC_SlotStatus(errorCode);
        break;

    case PC_TO_RDR_ABORT:
        errorCode = PC_to_RDR_Abort();
        RDR_to_PC_SlotStatus(errorCode);
        break;

    case PC_TO_RDR_T0APDU:
        errorCode = PC_TO_RDR_T0Apdu();
        RDR_to_PC_SlotStatus(errorCode);
        break;

    case PC_TO_RDR_MECHANICAL:
        errorCode = PC_TO_RDR_Mechanical();
        RDR_to_PC_SlotStatus(errorCode);
        break;

    case PC_TO_RDR_SETDATARATEANDCLOCKFREQUENCY:
        errorCode = PC_TO_RDR_SetDataRateAndClockFrequency();
        RDR_to_PC_DataRateAndClockFrequency(errorCode);
        break;

    case PC_TO_RDR_SECURE:
        errorCode = PC_TO_RDR_Secure();
        RDR_to_PC_DataBlock(errorCode);
        break;

    default:
        RDR_to_PC_SlotStatus(SLOTERROR_CMD_NOT_SUPPORTED);
        break;
    }

    /********** Decide for all commands ***************/
    if (Ccid_BulkState == CCID_STATE_SEND_RESP)
    {
        CCID_Response_SendData(pdev, (uint8_t *) & Ccid_bulkin_data,
                               Ccid_bulkin_data.u16SizeToSend);
        Ccid_BulkState = CCID_STATE_IDLE;
    }
}

/**
  * @brief  Transfer_Data_Request
  *         Prepare the request response to be sent to the host
  * @param  uint8_t* dataPointer: Pointer to the data buffer to send
  * @param  uint16_t dataLen : number of bytes to send
  * @retval None
  */
void Transfer_Data_Request(uint8_t *dataPointer, uint16_t dataLen)
{
    /**********  Update Global Variables ***************/
    Ccid_bulkin_data.u16SizeToSend = dataLen;
    Ccid_BulkState = CCID_STATE_SEND_RESP;
}


/**
  * @brief  CCID_IntMessage
  *         Send the Interrupt-IN data to the host
  * @param  pdev: device instance
  * @retval None
  */

void CCID_IntMessage(USB_OTG_CORE_HANDLE *pdev)
{
	// 	 if (HREAD(core_usb_txbusy)  & 0x02)
	 //       return;
#ifdef CCID_DEMO
	    RDR_to_PC_NotifySlotChange();
		CCID_SetIntrTransferStatus(0);  /* Reset the Status */
		CCID_UpdSlotChange(0);          /* Reset the Status of Slot Change */
		DCD_EP_Tx(pdev, CCID_INTR_IN_EP, UsbIntMessageBuffer, 2);
#else
 if (HREAD(core_usb_txbusy)  & 0x02)
        return;
    /* Check if there us change in Smartcard Slot status */
    if (CCID_IsSlotStatusChange() && CCID_IsIntrTransferComplete())
    {
        /* Check Slot Status is changed. Card is Removed/ Fitted  */
        RDR_to_PC_NotifySlotChange();
        CCID_SetIntrTransferStatus(0);  /* Reset the Status */
        CCID_UpdSlotChange(0);          /* Reset the Status of Slot Change */
        DCD_EP_Tx(pdev, CCID_INTR_IN_EP, UsbIntMessageBuffer, 2);
    }
#endif
}

/**
  * @brief  CCID_ReceiveCmdHeader
  *         Receive the Data from USB BulkOut Buffer to Pointer
  * @param  uint8_t* pDst: destination address to copy the buffer
  * @param  uint8_t u8length: length of data to copy
  * @retval None
  */
void CCID_ReceiveCmdHeader(uint8_t *pDst, uint8_t u8length)
{
    uint32_t Counter;

    for (Counter = 0; Counter < u8length; Counter++)
    {
        *pDst++ = BulkOut_Data_Buff[Counter];
    }

}

/**
  * @brief  CCID_IsIntrTransferComplete
  *         Provides the status of previous Interrupt transfer status
  * @param  None
  * @retval uint8_t PrevXferComplete_IntrIn: Value of the previous transfer status
  */
uint8_t CCID_IsIntrTransferComplete(void)
{
    return PrevXferComplete_IntrIn;
}

/**
  * @brief  CCID_IsIntrTransferComplete
  *         Set the value of the Interrupt transfer status
  * @param  uint8_t xfer_Status: Value of the Interrupt transfer status to set
  * @retval None
  */
void CCID_SetIntrTransferStatus(uint8_t xfer_Status)
{
    PrevXferComplete_IntrIn = xfer_Status;
}

/************************ (C) COPYRIGHT Yichip Microelectronics *****END OF FILE****/
