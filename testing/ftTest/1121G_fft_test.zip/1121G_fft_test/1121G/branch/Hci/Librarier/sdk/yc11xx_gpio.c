/**
 * @file yc11xx_gpio.c
 * @author duanchu.he
 * @brief GPIO driver
 * @version 0.1
 * @date 2021-07-06
 * 
 * 
 */
#include "yc11xx_gpio.h"
#include "reg_addr.h"
#include "MyPrintf.h"
#include "btreg.h"


/**
 * @brief gpio function deinit
 * 
 * @param gpiox   GPIOA,
 * 				  GPIOB,
 * 				  GPIOC,
 * 				  GPIOD,
 * 				  GPIOE,
 */
void GPIO_DeInit(GPIO_TypeDef* gpiox)
{
		uint32_t regConfigAddr = 0;

		_ASSERT(IS_GPIO(gpiox));
	
		if(gpiox != GPIOE)
		{
			regConfigAddr = CORE_GPIO0_CONFIG + GPIO_TRANSNUM(gpiox, 0);

			for(uint8_t i = 0; i < 8; i++)
				HWRITE(regConfigAddr + i, GPIO_Mode_Deinit);
		}
		else
		{
			regConfigAddr = CORE_GPIO_CONF1;

			for(uint8_t i = 0; i < 6; i++)
				HWRITE(regConfigAddr + i, GPIO_Mode_Deinit);
		}
}

/**
 * @brief  Initializes the GPIOx peripheral according to the specified
 *          parameters in the GPIO_InitStruct.
 * 
 * @param gpiox  where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_InitStruct 
 */
void GPIO_Init(GPIO_TypeDef* gpiox, GPIO_InitTypeDef* gpio_InitStruct)
{
		uint32_t regConfigAddr = 0;
	
		_ASSERT(IS_GPIO(gpiox));
		_ASSERT(IS_GPIO_PIN(gpio_InitStruct->GPIO_Pin));
		_ASSERT(IS_GPIO_SPEED(gpio_InitStruct->GPIO_Speed));
	
		if(gpiox != GPIOE)
			regConfigAddr = CORE_GPIO0_CONFIG + GPIO_TRANSNUM(gpiox, 0);
		else
			regConfigAddr = CORE_GPIO_CONF1;

		HWRITE(regConfigAddr + (gpio_InitStruct->GPIO_Pin), gpio_InitStruct->GPIO_Mode);
}

/**
 * @brief Reads the specified GPIO input data bit.
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  	 				This parameter can be GPIO_Pin_x where x can be (0..7).
 * @return gpio input data bit value.
 */
uint8_t GPIO_ReadDataBit(GPIO_TypeDef* gpiox, uint16_t gpio_pin)
{
		uint8_t value = 0;
		uint32_t regConfigAddr = 0;

		_ASSERT(IS_GPIO(gpiox));
		_ASSERT(IS_GPIO_PIN(gpio_pin));
	
		if(gpiox != GPIOE)
			regConfigAddr = CORE_GPIO_IN + (uint32_t)gpiox;
		else
			regConfigAddr = CORE_GPIO_IN1;
		
		if(HREAD(regConfigAddr) & (1 << gpio_pin))
				value = 1;
		else
				value = 0;

		return value; 
}

/**
 * @brief Reads the specified GPIO input data bit.
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @return gpio input port bit value. 
 */
uint8_t GPIO_ReadData(GPIO_TypeDef* gpiox)
{
		uint8_t value = 0;
		uint32_t regConfigAddr = 0;

		_ASSERT(IS_GPIO(gpiox));
	
		if(gpiox != GPIOE)
			regConfigAddr = CORE_GPIO_IN + (uint32_t)gpiox;
		else
			regConfigAddr = CORE_GPIO_IN1;
		
		value = HREAD(regConfigAddr);

		return value; 
}

/**
 * @brief Sets the selected data port bits.
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  				 	This parameter can be GPIO_Pin_x where x can be (0..7).
 */
void GPIO_SetBits(GPIO_TypeDef* gpiox, uint16_t gpio_pin)
{
		uint32_t regConfigAddr = 0;
	
		_ASSERT(IS_GPIO(gpiox));
		_ASSERT(IS_GPIO_PIN(gpio_pin));
	
		if(gpiox != GPIOE)
			regConfigAddr = CORE_GPIO0_CONFIG + GPIO_TRANSNUM(gpiox, 0);
		else
			regConfigAddr = CORE_GPIO_CONF1;
	
		HWRITE(regConfigAddr + gpio_pin, GPIO_Mode_Out_High);
}


/**
 * @brief Clears the selected data port bits.
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *   					This parameter can be GPIO_Pin_x where x can be (0..7).
 */
void GPIO_ResetBits(GPIO_TypeDef* gpiox, uint16_t gpio_pin)
{
		uint32_t regConfigAddr = 0;
	
		_ASSERT(IS_GPIO(gpiox));
		_ASSERT(IS_GPIO_PIN(gpio_pin));
	
		if(gpiox != GPIOE)
			regConfigAddr = CORE_GPIO0_CONFIG + GPIO_TRANSNUM(gpiox, 0);
		else
			regConfigAddr = CORE_GPIO_CONF1;

		HWRITE(regConfigAddr + gpio_pin, (uint8_t)GPIO_Mode_Out_Low);
}

/**
 * @brief Sets or clears the selected data port bit.
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *   					This parameter can be GPIO_Pin_x where x can be (0..7).
 * @param bitaction specifies the value to be written to the selected bit.
 *   				This parameter can be one of the BitAction enum values:
 *     			@arg Bit_RESET: to clear the port pin
 *     			@arg Bit_SET: to set the port pin
 */
void GPIO_WriteBit(GPIO_TypeDef* gpiox, uint16_t gpio_pin, BitAction bitaction)
{
		_ASSERT(IS_GPIO(gpiox));
		_ASSERT(IS_GPIO_PIN(gpio_pin));
		_ASSERT(IS_BITACTION(bitaction));
	
		if(bitaction != Bit_RESET)
			GPIO_SetBits(gpiox, gpio_pin);
		else
			GPIO_ResetBits(gpiox, gpio_pin);
}

/**
 * @brief Writes data to the specified GPIO data port.
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param portval specifies the value to be written to the port output data register.
 */
void GPIO_Write(GPIO_TypeDef* gpiox, uint16_t portval)
{
		_ASSERT(IS_GPIO(gpiox));
	
		for(uint8_t i = 0; i < 8; i++)
		{
			if(0 != (portval & (1 << i)))
				GPIO_SetBits(gpiox, i);
			else
				GPIO_ResetBits(gpiox, i);
		} 
}

/**
 * @brief Read gpio interrupt status.
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  				 	This parameter can be GPIO_Pin_x where x can be (0..7).
 * @return true 
 * @return false 
 */
bool  GPIO_InterruptStatus(GPIO_TypeDef* gpiox, uint16_t gpio_pin)
{
	 	uint8_t col = 0;
	 	uint8_t ret = 0;
	 	uint32_t temp = 0;

	 	_ASSERT(IS_GPIO(gpiox));
	 	_ASSERT(IS_GPIO_PIN(gpio_pin));

		col = GPIO_TRANSNUM(gpiox, gpio_pin);

		if(col <= 31)
		{
			temp = HREADL(CORE_GPIO_ISR_L);

			if((temp & (1 << col)) != 0)
				ret = 1;
			else
				ret = 0;
		}
		else
		{
			col -= 32;
			temp = HREAD(CORE_GPIO_ISR_H);

			if((temp & (1 << col)) != 0)
				ret = 1;
			else
				ret = 0;
		}

		return ret;
}

/**
 * @brief Sets the gpio interrupt trigger mode.
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  				 	This parameter can be GPIO_Pin_x where x can be (0..7).
 * @param interrupt_type gpio interrupt type structure
 */
void GPIO_SetInterrupt(GPIO_TypeDef* gpiox, uint16_t gpio_pin, Interrupt_TypeDef interrupt_type)
{
		uint8_t  col = 0;
		uint32_t addr = 0;
		uint32_t tmp = 0;

		_ASSERT(IS_GPIO(gpiox));
		_ASSERT(IS_GPIO_PIN(gpio_pin));
		_ASSERT(IS_INTERRUPT(interrupt_type));

		col = GPIO_TRANSNUM(gpiox, gpio_pin);

		if(col <= 31)
		{
			switch(interrupt_type)
			{
				case Rising_Interrupt :
					tmp = HREADL(CORE_GPIO_RTS_L);
					tmp |= 1 << col;
					HWRITEL(CORE_GPIO_RTS_L, tmp);
					break;
				case Fall_Interrupt :
					tmp = HREADL(CORE_GPIO_RTS_L);
					tmp |= 1 << col;
					HWRITEL(CORE_GPIO_FTS_L, tmp);
					break;
				case Low_Interrupt :
					tmp = HREADL(CORE_GPIO_LTS_L);
					tmp |= 1 << col;
					HWRITEL(CORE_GPIO_LTS_L, tmp);
					break;
				case High_Interrupt :
					tmp = HREADL(CORE_GPIO_LTS_L);
					tmp &= ~(1 << col);
					HWRITEL(CORE_GPIO_LTS_L, tmp);
					break;
				case Rising_Interrupt | Fall_Interrupt :
					tmp = HREADL(CORE_GPIO_RTS_L);
					tmp |= 1 << col;
					HWRITEL(CORE_GPIO_RTS_L, tmp);
					tmp = HREADL(CORE_GPIO_FTS_L);
					tmp |= 1 << col;
					HWRITEL(CORE_GPIO_FTS_L, tmp);
					break;
			}

			tmp = HREADL(CORE_GPIO_IEN_L);
			tmp |= 1 << col;
			HWRITEL(CORE_GPIO_IEN_L, tmp);


		}
		else
		{
			col -= 32;
			tmp = HREAD(CORE_GPIO_IEN_H);
			tmp |= 1 << col;
			HWRITE(CORE_GPIO_IEN_H, tmp);

			switch(interrupt_type)
			{
				case Rising_Interrupt :
					tmp = HREAD(CORE_GPIO_RTS_H);
					tmp |= 1 << col;
					HWRITE(CORE_GPIO_RTS_H, tmp);
					break;
				case Fall_Interrupt :
					tmp = HREAD(CORE_GPIO_FTS_H);
					tmp |= 1 << col;
					HWRITE(CORE_GPIO_FTS_H, tmp);
					break;
				case Low_Interrupt :
					tmp = HREAD(CORE_GPIO_LTS_H);
					tmp |= 1 << col;
					HWRITE(CORE_GPIO_LTS_H, tmp);
					break;
				case High_Interrupt :
					tmp = HREAD(CORE_GPIO_LTS_H);
					tmp &= ~(1 << col);
					HWRITE(CORE_GPIO_LTS_H, tmp);
					break;
				case Rising_Interrupt | Fall_Interrupt :
					tmp = HREAD(CORE_GPIO_RTS_H);
					tmp |= 1 << col;
					HWRITE(CORE_GPIO_RTS_H, tmp);
					tmp = HREAD(CORE_GPIO_FTS_H);
					tmp |= 1 << col;
					HWRITE(CORE_GPIO_FTS_H, tmp);
					break;
			}
		}
}

/**
 * @brief Clear  gpio interrupt status
 * 
 * @param gpiox where x can be (A..E) to select the GPIO peripheral.
 * @param gpio_pin specifies the port bit to read.
 *  				 	This parameter can be GPIO_Pin_x where x can be (0..7).
 */
void  GPIO_ClearInterrupt(GPIO_TypeDef* gpiox, uint16_t gpio_pin)
{
		uint8_t col = 0;
	 	uint8_t ret = 0;
	 	uint32_t temp = 0;

	 	_ASSERT(IS_GPIO(gpiox));
	 	_ASSERT(IS_GPIO_PIN(gpio_pin));

		col = GPIO_TRANSNUM(gpiox, gpio_pin);

		if(col <= 31)
		{
			temp = HREADL(CORE_GPIO_ICR_L);
			temp |= (1 << col);
			HWRITEL(CORE_GPIO_ICR_L, temp);
			temp &= ~(1 << col);
			HWRITEL(CORE_GPIO_ICR_L, temp);
		}
		else
		{
			col -= 32;
			temp = HREAD(CORE_GPIO_ICR_H);
			temp |= (1 << col);
			HWRITE(CORE_GPIO_ICR_H, temp);
			temp &= ~(1 << col);
			HWRITE(CORE_GPIO_ICR_H, temp);
		}
}

/**
 * @brief Clear all gpio interrupt status
 * 
 */
void GPIO_ClearAllInterrupt(void)
{
	HWRITEL(CORE_GPIO_ICR_L, 0xffffffff);
	HWRITE(CORE_GPIO_ICR_H, 0xff);
	HWRITEL(CORE_GPIO_ICR_L, 0x00000000);
	HWRITE(CORE_GPIO_ICR_H, 0x00);
}

/**
 * @brief Gpio long press reset
 * 
 * @param GPIO_Pinx_Reset Initializes the GPIOx  peripheral according to the specified
 *          parameters in the GPIO_LongPress_Reset.
 * @param newstate DISABE or ENABLE
 */
void GPIOx_LongPressReset(GPIO_LongPress_Reset GPIO_Pinx_Reset, FunctionalState newstate)
{
		CoreReg_LpmWrite2IceWdtLongRst(0x19);

		if(newstate != 0)
			HWOR(CORE_AUDIO_CLKSEL + 1, 1 << GPIO_Pinx_Reset);
		else
			HWCOR(CORE_AUDIO_CLKSEL + 1, 1 << GPIO_Pinx_Reset);
}

/**
 * @brief Gpio long press reset time config
 * 
 * @param longpress_timeout gpio longpress reset time set
 */
void GPIOx_LongPressTimeOut(GPIO_LongPress_TimeOut longpress_timeout)
{
		HWRITE(CORE_LPM_RD_MUX + 1, longpress_timeout);
}

/**
 * @brief Gpio long press reset time config
 *
 * @param longpress_timeout gpio longpress reset time set
 */
void GPIOx_WakeUp(GPIO_TypeDef* gpiox, uint16_t gpio_pin, GPIOWakeUp_TypeDef wakeuptype)
{
		uint8_t col = 0;
		uint32_t temp = 0;


		col = GPIO_TRANSNUM(gpiox, gpio_pin);

		if(wakeuptype != GPIO_WakeUpLow)
		{
			if(col <= 31)
			{
				temp = HREADL(mem_gpio_wakeup_low);
				//temp = HREADL(CORE_GPIO_LOW_WAKEUP_ENABLE);
				temp &= ~(1 << col);
				//CoreReg_LpmWriteGpioLowWake(temp);
				HWRITEL(mem_gpio_wakeup_low, temp);
				temp = HREADL(mem_gpio_wakeup_high);
				//temp = HREADL(CORE_GPIO_HIGH_WAKEUP_ENABLE);
				temp |= (1 << col);
				HWRITEL(mem_gpio_wakeup_high, temp);
				//CoreReg_LpmWriteGpioHighWake(temp);
			}
			else
			{
				col -= 32;
				temp = HREADL(mem_gpio2_wakeup_low);
				temp &= ~(1 << col);
				HWRITEL(mem_gpio2_wakeup_low, temp);
				temp = HREADL(mem_gpio2_wakeup_high);
				temp |= (1 << col);
				HWRITEL(mem_gpio2_wakeup_high, temp);
			}
		}
		else
		{
			if(col <= 31)
			{
				temp = HREADL(mem_gpio_wakeup_high);
				//temp = HREADL(CORE_GPIO_HIGH_WAKEUP_ENABLE);
				temp &= ~(1 << col);
				HWRITEL(mem_gpio_wakeup_high, temp);
				//CoreReg_LpmWriteGpioHighWake(temp);
				temp = HREADL(mem_gpio_wakeup_low);
				//temp = HREADL(CORE_GPIO_LOW_WAKEUP_ENABLE);
				temp |= (1 << col);
				HWRITEL(mem_gpio_wakeup_low, temp);
				//CoreReg_LpmWriteGpioLowWake(temp);
			}
			else
			{
				col -= 32;
				temp = HREADL(mem_gpio2_wakeup_high);
				temp &= ~(1 << col);
				HWRITEL(mem_gpio2_wakeup_high, temp);
				temp = HREADL(mem_gpio2_wakeup_low);
				temp |= (1 << col);
				HWRITEL(mem_gpio2_wakeup_low, temp);
			}
		}
}

