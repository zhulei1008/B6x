#ifndef __YC11XX_QSPI2_H__
#define __YC11XX_QSPI2_H__

#include "yc11xx.h"

#define QSPI2_MODE_1_BIT        0
#define QSPI2_MODE_2_BIT        1
#define QSPI2_MODE_4_BIT        2


#define QSPI2_TXADDR0           0x80
#define QSPI2_TXADDR1           0x81
#define QSPI2_TXLEN0            0x82
#define QSPI2_TXLEN1            0x83
#define QSPI2_RXADDR0           0x84
#define QSPI2_RXADDR1           0x85
#define QSPI2_RXLEN0            0x86
#define QSPI2_RXLEN1            0x87
#define QSPI2_CTRL0             0x88
#define QSPI2_CTRL1             0x89
#define QSPI2_CMDLEN			0x8e
#define QSPI2_START             0x90
#define QSPI2_CMDADDR0		    0x8c
#define QSPI2_CMDADDR1		    0x8d
#define QSPI2_STATUS            0x94

#define QSPI2_MRAM_SEL_ON                 1
#define QSPI2_MRAM_SEL_OFF                0

void qspi2_reg_wr(unsigned char addr, unsigned char val);
unsigned char qspi2_reg_rd(unsigned char addr);
void qspi2_reg_wr_seg(unsigned char addr, unsigned char sbit, unsigned char ebit, unsigned char val);
void qspi2_set_txaddr (unsigned short val);
void qspi2_set_txlen (unsigned short val);
void qspi2i_set_rxaddr (unsigned short val);
void qspi2_set_rxlen (unsigned short val);
void qspi2_set_cmdaddr (unsigned short val);
void qspi2_set_cmdlen (unsigned char val);
void qspi2_set_ctrl0 (unsigned char val);
void qspi2_set_mode (unsigned char val);
void qspi2_set_inc (unsigned char val);
void qspi2_set_mbyte (unsigned char val);
void qspi2_set_clk (unsigned char val);
void qspi2_set_interrupt (unsigned char val);
void qspi2_set_clkp (unsigned char val);
void qspi2_set_ctrl1 (unsigned char val);
void qspi2_set_dly (unsigned char val);
void qspi2_set_start (unsigned char val);
void qspi2_wait_done (void);
void qspi2_delay_ms(unsigned short val);

#endif
