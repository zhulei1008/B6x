
#ifndef _YC11XX_UART_H_
#define _YC11XX_UART_H_

#include "yc11xx.h"

#ifdef __cplusplus
extern "C" {
#endif
#define UARTE_BAUDRATE_BAUDRATE_Baud3000        (0xbe80) /*!< 3000 baud  */
#define UARTE_BAUDRATE_BAUDRATE_Baud4800        (0xa710) /*!< 4800 baud  */
#define UARTE_BAUDRATE_BAUDRATE_Baud9600        (0x9388) /*!< 9600 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud14400       (0x8d05) /*!< 14400 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud19200       (0x89c4) /*!< 19200 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud31250       (0x8600) /*!< 31250 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud38400       (0x84e2) /*!< 38400 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud56000       (0x8359) /*!< 56000 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud57600       (0x8342) /*!< 57600 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud76800       (0x8271) /*!< 76800 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud115200      (0x81A0) /*!< 115200 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud230400      (0x80d0) /*!< 230400 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud256000      (0x80bb) /*!< 250000 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud460800      (0x8066) /*!< 460800 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud921600      (0x8034) /*!< 921600 baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud1M          (0x8030) /*!< 1Mega baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud1_5M        (0x8020) /*!< 1Mega baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud1_6M        (0x801e) /*!< 1Mega baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud2M          (0x8018) /*!< 2Mega baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud2_5M        (0x8013) /*!< 2Mega baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud3M          (0x8010) /*!< 2Mega baud */
#define UARTE_BAUDRATE_BAUDRATE_Baud_deviation  (0xcb00)

#define IS_UARTE_BAUDRATE(BAUDRATE) ((BAUDRATE > 0) && (BAUDRATE < UARTE_BAUDRATE_BAUDRATE_Baud3000))

#define UARTN_BAUDRATE_BAUDRATE_Baud3000        (0x3e80) /*!< 2400 baud  */
#define UARTN_BAUDRATE_BAUDRATE_Baud4800        (0x2710) /*!< 4800 baud  */
#define UARTN_BAUDRATE_BAUDRATE_Baud9600        (0x1388) /*!< 9600 baud  */
#define UARTN_BAUDRATE_BAUDRATE_Baud14400       (0x0d05) /*!< 14400 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud19200       (0x09c4) /*!< 19200 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud31250       (0x0600) /*!< 31250 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud38400       (0x04e2) /*!< 38400 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud56000       (0x0359) /*!< 56000 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud57600       (0x0342) /*!< 57600 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud76800       (0x0271) /*!< 76800 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud115200      (0x01A0) /*!< 115200 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud230400      (0x00d0) /*!< 230400 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud256000      (0x00bb) /*!< 250000 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud460800      (0x0066) /*!< 460800 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud921600      (0x0034) /*!< 921600 baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud1M          (0x0030) /*!< 1Mega baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud1_5M        (0x0020) /*!< 1.5Mega baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud1_6M        (0x001e) /*!< 1.6Mega baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud2M          (0x0018) /*!< 2Mega baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud2_5M        (0x0013) /*!< 2.5Mega baud */
#define UARTN_BAUDRATE_BAUDRATE_Baud3M          (0x0010) /*!< 3Mega baud */
#define UART_PER_NUM 2
#define IS_UARTN_BAUDRATE(BAUDRATE) ((BAUDRATE > 0) && (BAUDRATE< UARTN_BAUDRATE_BAUDRATE_Baud3000))



/** @
  * @defgroup UART_Word_Length 
  */ 
#define UART_WordLength_8b                  (0<<2)
#define UART_WordLength_9b                  (1<<2)

#define IS_UART_WORD_LENGTH(LENGTH) 		(((LENGTH) == UART_WordLength_8b) || \
                                    	((LENGTH) == UART_WordLength_9b))

/** @defgroup UART_Stop_Bits 
  * @{
  */ 
#define UART_StopBits_1                 (0<<3)
#define UART_StopBits_2                 (1<<3)
#define IS_UART_STOPBITS(STOPBITS)		 (((STOPBITS) == UART_StopBits_1) ||  \
							((STOPBITS) == UART_StopBits_2) )
/**
  * @}
  */ 


  /** @defgroup UART_Parity 
  * @{
  */ 
#define UART_Parity_Even                    (0<<1)
#define UART_Parity_Odd                     (1 << 1) 
#define IS_UART_PARITY(PARITY)		 ( ((PARITY) == UART_Parity_Even) || \
                                 ((PARITY) == UART_Parity_Odd))
/**
  * @}
  */

/** @defgroup UART_Mode 
  * @{
  */ 
#define UART_Mode_Single_Line        (1<<6)
#define UART_Mode_duplex                      (0<<6)
#define IS_UART_MODE(MODE) 		(((MODE) == UART_Mode_Single_Line) ||\
				((MODE) == UART_Mode_duplex))
/**
  * @}
  */ 

/** @defgroup UART_Hardware_Flow_Control 
  * @{
  */ 
#define UART_HardwareFlowControl_None       (0<<4)
#define UART_HardwareFlowControl_ENABLE       (1<<4)


#define IS_UART_HARDWARE_FLOW_CONTROL(CONTROL)\
                              (((CONTROL) == UART_HardwareFlowControl_None) || \
                               ((CONTROL) == UART_HardwareFlowControl_ENABLE))
/**
  * @}
  */ 
	


/** @defgroup  UART_TXLen   
  * @{
  */ 
#define IS_UART_TXLen(TxLen)       ((TxLen > 0) && (TxLen <= uart_DMA_buf_len))
/**
  * @}
  */ 


/** @defgroup  UART_RXLen   
  * @{
  */ 
#define IS_UART_RXLen(RxLen)       ((RxLen > 0) && (RxLen <= uart_DMA_buf_len))
/**
  * @}
  */ 

/** 
  * @brief  UART channel define
  */ 
typedef enum
{
	UARTA = 0,
	UARTB = 1,
}UART_TypeDef;

#define IS_UARTAB(UARTx)         (UARTx == UARTA)||\
						(UARTx == UARTB)

/** 
  * @brief  UART Init Structure definition  
  */ 

/** @defgroup  UART_RXBuffer   
  * @{
  */ 
#define IS_UART_RXBuffer(RxBuffer)         ((RxBuffer > 0x10000000) ||(RxBuffer < 0x10001fff) ) |\
									((RxBuffer < 0x10004000) ||(RxBuffer > 0x10004fff))|\
									((RxBuffer < 0x10010000) ||(RxBuffer > 0x10013fff))
/**
  * @}
  */ 

/** @defgroup  UART_TXBuffer   
  * @{
  */ 
#define IS_UART_TXBuffer(TxBuffer)         ((0x10000000 < TxBuffer ) ||(TxBuffer < 0x10001fff) ) |\
									((TxBuffer < 0x10004000) ||(TxBuffer > 0x10004fff))|\
									((TxBuffer < 0x10010000) ||(TxBuffer > 0x10013fff))
/**
  * @}
  */
typedef struct 
{
	uint16_t Baudrate;
	uint16_t RxSadr;
	uint16_t RxEadr;
	uint16_t RxRptr;
	uint16_t TxSadr;
	uint16_t TxEadr;
	uint16_t TxWptr;
}UartxRegDef;

typedef struct
{
	UartxRegDef rbu;
	uint8_t cbu;
}UartxRegControlBackup;

UartxRegControlBackup regBeck[UART_PER_NUM];

typedef struct
{
  uint16_t UART_BaudRate;            /*!< This member configures the UART communication baud rate.
                                           The baud rate is computed using the following formula:
                                            - IntegerDivider = ((PCLKx) / (8 * (OVR8+1) * (UART_InitStruct->UART_BaudRate)))
                                            - FractionalDivider = ((IntegerDivider - ((u32) IntegerDivider)) * 8 * (OVR8+1)) + 0.5 
                                           Where OVR8 is the "oversampling by 8 mode" configuration bit in the CR1 register. */

  uint16_t UART_WordLength;          /*!< Specifies the number of data bits transmitted or received in a frame.
                                           This parameter can be a value of @ref UART_Word_Length */

  uint16_t UART_StopBits;            /*!< Specifies the number of stop bits transmitted.
                                           This parameter can be a value of @ref UART_Stop_Bits */

  uint16_t UART_Parity;              /*!< Specifies the parity mode.
                                           This parameter can be a value of @ref UART_Parity
                                           @note When parity is enabled, the computed parity is inserted
                                                 at the MSB position of the transmitted data (9th bit when
                                                 the word length is set to 9 data bits; 8th bit when the
                                                 word length is set to 8 data bits). */
 
  uint16_t UART_Mode;                /*!< Specifies wether the Receive or Transmit mode is enabled or disabled.
                                           This parameter can be a value of @ref UART_Mode */

  uint16_t UART_HardwareFlowControl; /*!< Specifies wether the hardware flow control mode is enabled
                                           or disabled.
                                           This parameter can be a value of @ref UART_Hardware_Flow_Control */

  uint16_t UART_TXLen; /*!< Specifies Tx DMA buff len */
  
  uint16_t UART_RXLen; /*!< Specifies Rx DMA buff len */

  uint32_t UART_TxBuffer; /*!Tx ring buffer start addr */

  uint32_t UART_RxBuffer; /*!Rx ring buffer start addr */
} UART_InitTypeDef;





void UART_DeInit(UART_TypeDef UARTx);
void UART_Init(UART_TypeDef UARTx, UART_InitTypeDef* UART_InitStruct);
void UART_StructInit(UART_TypeDef UARTx);
void UART_Addr_IFAB(UART_TypeDef UARTx);
void UART_SendData(UART_TypeDef UARTx, uint8_t Data);
uint8_t UART_ReceiveData(UART_TypeDef UARTx);
uint16_t UART_ReadDatatoBuff(UART_TypeDef UARTx, uint8_t* RxBuff, uint16_t RxSize);
uint16_t UART_SendDataFromBuff(UART_TypeDef UARTx, uint8_t* TxBuff, uint16_t TxLen);
uint16_t UART_GetRxCount(UART_TypeDef UARTx);
uint16_t UART_GetTxCount(UART_TypeDef UARTx);
void UART_SetRxITNum(UART_TypeDef UARTx, uint8_t Num);
void UART_SetRxTimeout(UART_TypeDef UARTx, uint16_t time);

#ifdef __cplusplus
}
#endif

#endif /* _UART_H_ */












