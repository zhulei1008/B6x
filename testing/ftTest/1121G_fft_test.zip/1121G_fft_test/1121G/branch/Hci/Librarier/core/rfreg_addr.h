#ifndef __RFREG_ADDR_H
#define __RFREG_ADDR_H
#define CORE_codec_ldo_en0							0x8b00
#define CORE_codec_ldo_cfg0							0x8b01
#define CORE_codec_ldo_cfg1							0x8b02
#define CORE_codec_ldo_cfg2							0x8b04
#define CORE_codec_vmid_en0							0x8b05
#define CORE_codec_vmid_cfg0						0x8b06
#define CORE_codec_vmid_cfg1						0x8b07
#define CORE_codec_vmid_cfg2						0x8b08
#define CORE_codec_vmid_cfg3						0x8b09
#define CORE_codec_vmid_ind							0x8b0a
#define CORE_au_adc_en0								0x8b0b
#define CORE_au_adc_en1								0x8b0c
#define CORE_au_adc_cfg0							0x8b0d
#define CORE_au_adc_cfg1							0x8b0e
#define CORE_au_adc_cfg2							0x8b0f
#define CORE_au_adc_cfg3							0x8b10
#define CORE_au_adc_cfg4							0x8b11
#define CORE_au_adc_cfg5							0x8b12
#define CORE_au_adc_cfg6							0x8b13
#define CORE_au_dac_en0								0x8b14
#define CORE_au_dac_en1								0x8b15
#define CORE_au_dac_en2								0x8b16
#define CORE_au_dac_en3								0x8b17
#define CORE_au_dac_cfg0							0x8b18
#define CORE_au_dac_cfg1							0x8b19
#define CORE_au_dac_cfg2							0x8b1a
#define CORE_au_dac_cfg3							0x8b1b
#endif
