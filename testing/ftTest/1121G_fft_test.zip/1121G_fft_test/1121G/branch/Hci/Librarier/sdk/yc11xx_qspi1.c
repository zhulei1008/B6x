#include "yc11xx_qspi1.h"
//#include "system.h"

//delay ms
void qspi1_delay_ms(unsigned short val)
{
    unsigned short i, j;
    for (i = 0; i < val; i ++)
    {
        for (j = 0; j < 1019; j ++ )
        { // to  be done!!!
            ;
        }
    }
}

// reg wr
void qspi1_reg_wr(unsigned char addr, unsigned char val)
{
    int paddr;
    paddr = (unsigned int)(addr) |0x1001f000; // regmap
    *(volatile unsigned char *)(paddr) = val;
}

// reg rd
unsigned char qspi1_reg_rd(unsigned char addr)
{
    int paddr;
    paddr = (unsigned int)(addr) | 0x1001f000; // regmap
    return *(volatile unsigned char *)(paddr);
}

// reg wr
void qspi1_reg_wr_seg(unsigned char addr, unsigned char sbit, unsigned char ebit, unsigned char val)
{
    unsigned char tmp, msk, i;
    msk = 0;
    for (i=0; i<8; i++) {
        if ((i>=sbit) && (i<=ebit)) {
            msk = msk + (0x01 << i);
        }
    }
    tmp = qspi1_reg_rd(addr);
    tmp = tmp & (~msk);
    tmp = tmp | ((val << sbit) & msk);
    qspi1_reg_wr(addr, tmp);
}

// txaddr
void qspi1_set_txaddr (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi1_reg_wr(QSPI1_TXADDR0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi1_reg_wr(QSPI1_TXADDR1, tmp);
}

// txlen
void qspi1_set_txlen (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi1_reg_wr(QSPI1_TXLEN0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi1_reg_wr(QSPI1_TXLEN1, tmp);
}

// rxaddr
void qspi1_set_rxaddr (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi1_reg_wr(QSPI1_RXADDR0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi1_reg_wr(QSPI1_RXADDR1, tmp);
}

// txlen
void qspi1_set_rxlen (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi1_reg_wr(QSPI1_RXLEN0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi1_reg_wr(QSPI1_RXLEN1, tmp);
}

// cmdaddr
void qspi1_set_cmdaddr (unsigned short val)
{
    unsigned char tmp;
    tmp = val & 0xff;
    qspi1_reg_wr(QSPI1_CMDADDR0, tmp);
    tmp = (val >> 8) & 0xff;
    qspi1_reg_wr(QSPI1_CMDADDR1, tmp);
}

// cmdlen
void qspi1_set_cmdlen (unsigned char val)
{
	qspi1_reg_wr(QSPI1_CMDLEN, val);
}

// ctrl0
void qspi1_set_ctrl0 (unsigned char val)
{
	qspi1_reg_wr(QSPI1_CTRL0, val);
}

// mode
void qspi1_set_mode (unsigned char val)
{
	qspi1_reg_wr_seg(QSPI1_CTRL0, 0, 1, val);
}

// auto_inc
void qspi1_set_inc (unsigned char val)
{
	qspi1_reg_wr_seg(QSPI1_CTRL0, 2, 2, val);
}

// auto_inc
void qspi1_set_clk (unsigned char val)
{
	qspi1_reg_wr_seg(QSPI1_CTRL0, 5, 5, val);
}


// mbyte
void qspi1_set_mbyte (unsigned char val)
{
	qspi1_reg_wr_seg(QSPI1_CTRL0, 4, 4, val);
}

// interrupt
void qspi1_set_interrupt(unsigned char val)
{
	qspi1_reg_wr_seg(QSPI1_CTRL0, 6, 6, val);
}

// clkp
void qspi1_set_clkp (unsigned char val)
{
	qspi1_reg_wr_seg(QSPI1_CTRL0, 7, 7, val);
}

// ctrl1
void qspi1_set_ctrl1 (unsigned char val)
{
	qspi1_reg_wr(QSPI1_CTRL1, val);
}

// dly
void qspi1_set_dly (unsigned char val)
{
	qspi1_reg_wr_seg(QSPI1_CTRL1, 0, 3, val);
}

// start
void qspi1_set_start (unsigned char val)
{
	qspi1_reg_wr(QSPI1_START, val);
}

// wait_done
void qspi1_wait_done (void)
{
    unsigned char tmp;
    while (1) {
        tmp = qspi1_reg_rd(QSPI1_STATUS);
        //MyPrintf("QSPI2_STATUS=%x\n",tmp);
        //qspi2_delay_ms(100);
        tmp = tmp & 0x01;
        if (tmp == 0x01)
            break;
    }
}


